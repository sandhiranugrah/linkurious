/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-06-23.
 */
'use strict';
const fs = require('fs-extra'), path = require('path'), unzip = require('unzip'), ObjectUpdater = require('../lib/ObjectUpdater');
const LK_DIR = path.resolve(__dirname, '..', '..');
const ROOT_FILES = process.platform === 'win32'
    ? ['menu.bat', 'start.bat', 'stop.bat']
    : (process.platform === 'darwin'
        ? ['menu.sh.command', 'start.sh.command', 'stop.sh.command']
        : ['menu.sh', 'start.sh', 'stop.sh']);
/**
 * CurrentInstallInfo
 *
 * @typedef {object} CurrentInstallInfo
 * @property {string} os Current OS ("windows", "linux" or "osx")
 * @property {string} elasticsearch ElasticSearch version (SemVer)
 * @property {string} node NodeJS version (SemVer)
 * @property {string} linkurious Linkurious version (SemVer)
 */
/**
 * LinkuriousArchiveInfo
 *
 * @typedef {object} LinkuriousArchiveInfo
 * @property {string} filename Name of the Linkurious archive
 * @property {string} os Name of the OS this archive is intended for ("windows", "osx" or "linux")
 * @property {string} version Linkurious version (SemVer)
 */
/**
 * @param {string} linkuriousRoot
 * @constructor
 */
function Updater(linkuriousRoot) {
    this.linkuriousRoot = linkuriousRoot;
    this.logFilePath = this.getPath('data/logs/update.log');
}
Updater.prototype = {
    LK_ARCHIVE_RE: /^Linkurious-(windows|linux|osx)-v(\d+\.\d+\.\d+)\.zip/i,
    CONFIG_FILE_PATH: 'data/config/production.json',
    CONFIG_DIR_PATH: 'data/config',
    UPDATE_TMP: 'tmp.update',
    /**
     * Returns the absolute path of a dir in the current Linkurious root
     *
     * @param {string} dirName
     * @returns {string} the absolute path of `dirName` inside of the current Linkurious root
     */
    getPath: function (dirName) {
        return path.resolve(this.linkuriousRoot, dirName);
    },
    _pressEnterToContinue: function (cb) {
        console.log('\n[PRESS ENTER TO CONTINUE ...]');
        try {
            process.stdin.setRawMode(true);
            process.stdin.resume();
            process.stdin.once('data', () => {
                process.stdin.setRawMode(false);
                cb();
            });
        }
        catch (e) {
            cb();
        }
    },
    _error: function (error) {
        if (typeof error === 'object' && typeof error.stack === 'string') {
            this._tryLogToFile(error.stack.split(/\n\s+/), true);
        }
        this._log('Error: ' + error.message, true, false);
    },
    /**
     * Log a message to standard output
     *
     * @param {string} m message
     * @param {boolean} [exit=false] whether to exit the process after printing message
     * @param {boolean} [cleanup=false] whether to clean up the temporary directory
     * @private
     */
    _log: function (m, exit, cleanup) {
        // 1) if exit was required, first try to cleanup
        if (cleanup) {
            this._cleanUp();
        }
        // 2) log the message to stdout
        console.log(new Date().toISOString() + ' | ' + (exit && !cleanup ? '! ' : '* ') + m);
        // 3) try to log to a file
        this._tryLogToFile(m, exit);
        // 4) if exit was required, actually exit now
        if (exit) {
            this._pressEnterToContinue(() => {
                process.exit(0);
            });
        }
    },
    _tryLogToFile: function (m, exit) {
        try {
            fs.appendFileSync(this.logFilePath, JSON.stringify({ date: (new Date()).toISOString(), message: m, exit: !!exit }) + '\n');
        }
        catch (e) {
            // ignore logfile errors
        }
    },
    /**
     * List linkurious archive file names in a directory
     *
     * @returns {string[]} file names of linkurious archives found in `dir`
     * @private
     */
    _listLkArchives: function () {
        const self = this;
        return fs.readdirSync(self.linkuriousRoot).filter(filename => {
            return self.LK_ARCHIVE_RE.test(filename);
        });
    },
    /**
     * Extract version info from linkurious archive file names.
     *
     * @param {string[]} lkArchives
     * @returns {LinkuriousArchiveInfo[]}
     * @private
     */
    _getLkArchivesInfo: function (lkArchives) {
        const self = this;
        let match, info;
        return lkArchives.map(filename => {
            match = self.LK_ARCHIVE_RE.exec(filename.toLowerCase());
            if (!match) {
                return null;
            }
            info = {
                os: match[1],
                version: match[2],
                filename: filename
            };
            return info;
        }).filter(info => { return info !== null; });
    },
    /**
     * Get current installed version info.
     *
     * @returns {CurrentInstallInfo}
     */
    getCurrentInfo: function () {
        const systemPath = this.getPath('system');
        const versions = fs.readJsonSync(path.resolve(systemPath, 'versions.json'));
        const platform = process.platform;
        const os = platform === 'darwin' ? 'osx' : platform === 'win32' ? 'windows' : 'linux';
        return {
            os: os,
            node: versions.node,
            linkurious: versions.linkurious,
            elasticsearch: versions.elasticsearch
        };
    },
    /**
     * Find the best update candidate from the current version.
     * Returns the newest Linkurious version in the `lkArchivesInfo` if it's newer than the current.
     *
     * @param {CurrentInstallInfo} currentInfo
     * @param {LinkuriousArchiveInfo[]} lkArchivesInfo
     * @returns {LinkuriousArchiveInfo|undefined} a matching update candidate (or undefined if none)
     * @private
     */
    _findUpdateCandidate: function (currentInfo, lkArchivesInfo) {
        const self = this;
        /**
         * @type {Array.<LinkuriousArchiveInfo>}
         */
        const sortedCandidates = lkArchivesInfo.filter(info => {
            return info.os === currentInfo.os;
        }).sort((a, b) => {
            // sort latest first
            return self.compareSemVer(b.version, a.version);
        });
        if (!sortedCandidates.length) {
            return undefined;
        }
        if (this.compareSemVer(sortedCandidates[0].version, currentInfo.linkurious) > 0) {
            return sortedCandidates[0];
        }
        return undefined;
    },
    /**
     * Compare two SemVer strings
     *
     * @param {string} x a string in the format "a.b.c"
     * @param {string} y a string in the format "d.e.f"
     * @returns {number} similar to (x-y): <0 if x<y, >0 if x<y, 0 if x=y
     */
    compareSemVer: ObjectUpdater.prototype.compareSemVer,
    /**
     * Updates file at `"[targetPath]/[original]"` with file found at `"[sourcePath]/[original]"`
     * Keeps a backup of the file in `"[targetPath]/[original].old"`.
     *
     * @param {string} sourcePath the source directory where the new version of the file can be found
     * @param {string} targetPath the target directory where the file must be updated
     * @param {string} original the name of the file to swap
     * @private
     */
    backupAndUpdate: function (sourcePath, targetPath, original) {
        this._backup(targetPath, original);
        this._update(sourcePath, targetPath, original);
    },
    /**
     * @param {string} sourcePath the source directory where the new version of the file can be found
     * @param {string} targetPath the target directory where the file must be updated
     * @param {string} original the name of the file to swap
     * @private
     */
    _update(sourcePath, targetPath, original) {
        this._log('Updating "' + original + '"');
        fs.copySync(path.resolve(sourcePath, original), path.resolve(targetPath, original));
    },
    _backup: function (rootPath, filename, copy) {
        const originalPath = path.resolve(rootPath, filename);
        const backupPath = path.resolve(rootPath, filename + '.old');
        if (fs.existsSync(backupPath)) {
            fs.removeSync(backupPath);
        }
        this._log('Backing up "' + filename + '" to "' + filename + '.old"');
        if (copy) {
            fs.copySync(originalPath, backupPath);
        }
        else {
            fs.renameSync(originalPath, backupPath);
        }
    },
    /**
     * Looks for `*.old` files and folders in the `"[linkuriousRoot]/system"` folder
     * and renames them, removing the `".old"` suffix.
     *
     * Does the same in `"linkuriousRoot]/data/config"` folder.
     */
    restorePrevious: function () {
        this._restoreContents(this.getPath('system'));
        this._restoreContents(this.getPath('data/config'));
    },
    /**
     * @param {string} rootPath a folder that contains backups (.old files or folders)
     * @private
     */
    _restoreContents: function (rootPath) {
        const self = this;
        fs.readdirSync(rootPath).filter(filename => {
            return filename.match(/\.old$/);
        }).forEach(backup => {
            self._restoreBackup(rootPath, backup);
        });
    },
    _restoreBackup: function (rootPath, backup) {
        const original = backup.replace(/\.old/, '');
        const originalPath = path.resolve(rootPath, original);
        this._log('Restoring "' + backup + '" to "' + original + '"');
        if (fs.existsSync(originalPath)) {
            fs.removeSync(originalPath);
        }
        fs.renameSync(path.resolve(rootPath, backup), originalPath);
    },
    _cleanUp: function () {
        const updateTmp = this.getPath(this.UPDATE_TMP);
        fs.removeSync(updateTmp);
    },
    /**
     * Migrate the Linkurious configuration after an update (uses manager/configUpdates.json)
     *
     * @param {string} targetVersion target Linkurious version
     * @param {string} defaultCurrentVersion in case the current version is not set in the config
     */
    migrateConfig: function (targetVersion, defaultCurrentVersion) {
        const configPath = this.getPath(this.CONFIG_FILE_PATH);
        const config = fs.readJsonSync(configPath);
        const updates = fs.readJsonSync(this.getPath('system/manager/configUpdates.json'));
        // backup config
        this._backup(this.getPath(this.CONFIG_DIR_PATH), 'production.json', true);
        // migrate config
        const self = this;
        let currentVersion = config.version || defaultCurrentVersion;
        // if the "version" field is missing from the config file, use the version from "versions.json".
        config.version = currentVersion;
        const configUpdater = new ObjectUpdater(config, self._log.bind(this));
        configUpdater.applyUpdates(updates, targetVersion).forEach(update => {
            self._log('Migrated configuration from v' + currentVersion + ' to v' + update.version + '.');
            currentVersion = update.version;
        });
        fs.writeFileSync(configPath, JSON.stringify(config, null, ' '));
    },
    /**
     * Run the update (throw exceptions on failure)
     */
    _run: function () {
        const self = this;
        if (self.linkuriousRoot === undefined) {
            throw new Error('no Linkurious folder specified for the update');
        }
        self._log('UPDATING LINKURIOUS');
        // 0) check if an unfinished update was interrupted, rollback to previous state if so
        const updateTmp = self.getPath(self.UPDATE_TMP);
        if (fs.existsSync(updateTmp)) {
            self._log('The previous update did not finish properly, restoring previous version ...');
            self.restorePrevious();
            const versions = fs.readJsonSync(self.getPath('system/versions.json'));
            return self._log('Linkurious version ' + versions.linkurious + ' was restored successfully.', true, true);
        }
        fs.emptyDirSync(updateTmp);
        // 1) get current LK version
        const currentInfo = self.getCurrentInfo();
        self._log('Current version: ' + currentInfo.linkurious);
        // 2) look for a linkurious archive in the root dir (zip matching a pattern)
        const lkArchives = self._listLkArchives();
        if (!lkArchives.length) {
            return self._log('No update-archives found in folder: ' + self.linkuriousRoot, true, true);
        }
        // 3) check all versions linkurious in /updates
        const lkArchivesInfo = self._getLkArchivesInfo(lkArchives);
        // 4) if the latest version is not newer than the current version, exit
        const updateArchiveInfo = self._findUpdateCandidate(currentInfo, lkArchivesInfo);
        if (!updateArchiveInfo) {
            return self._log('No newer update-archive was found in folder: ' + self.linkuriousRoot, true, true);
        }
        self._log('Found an update-archive for version ' + updateArchiveInfo.version);
        // 5) extract the update archive
        const updateArchive = self.getPath(updateArchiveInfo.filename);
        if (!fs.existsSync(updateArchive)) {
            return self._log('Update-archive file was not found (' + updateArchive + ')', true, true);
        }
        self._log('Extracting update-archive ...');
        const sourceStream = fs.createReadStream(updateArchive);
        const targetStream = unzip.Extract({ path: updateTmp });
        sourceStream.pipe(targetStream);
        sourceStream.on('end', () => {
            self._log('The update-archive was unzipped successfully');
            const source = path.resolve(updateTmp, fs.readdirSync(updateTmp)[0], 'system');
            const target = self.getPath('system');
            const updateVersions = fs.readJsonSync(path.resolve(source, 'versions.json'));
            // 6.a) update system files
            self.backupAndUpdate(source, target, 'node_modules');
            self.backupAndUpdate(source, target, 'lib');
            self.backupAndUpdate(source, target, 'server');
            self.backupAndUpdate(source, target, 'manager');
            self.backupAndUpdate(source, target, 'versions.json');
            self.backupAndUpdate(source, target, 'release.json');
            // 6.b) update root files
            const sourceRoot = path.resolve(source, '..');
            const targetRoot = path.resolve(target, '..');
            ROOT_FILES.forEach(filename => {
                self._update(sourceRoot, targetRoot, filename);
            });
            // 7) if the node version changed, replace node
            if (currentInfo.node !== updateVersions.node) {
                const nodeFile = 'node' + (process.platform === 'win32' ? '.exe' : '');
                self.backupAndUpdate(source, target, nodeFile);
            }
            else {
                self._log('NodeJS binary is already up-to-date');
            }
            // 8) if the ElasticSearch version changed, replace ElasticSearch
            if (currentInfo.elasticsearch !== updateVersions.elasticsearch) {
                self.backupAndUpdate(source, target, 'elasticsearch');
            }
            else {
                self._log('ElasticSearch is already up-to-date');
            }
            // 9) migrate config
            self.migrateConfig(updateArchiveInfo.version, currentInfo.linkurious);
            // 10) require the second stage updater (from the new version) and run it (if defined)
            let SecondStageUpdater;
            try {
                SecondStageUpdater = require(path.resolve(self.linkuriousRoot, 'system/manager/secondStageUpdater'));
                self._log('Second stage updater found');
            }
            catch (e) {
                // nothing to do, secondStageUpdater is not there
                self._log('Second stage updater not required');
            }
            if (SecondStageUpdater) {
                self._log('Running second stage updater');
                const secondStageUpdaterInstance = new SecondStageUpdater(self.linkuriousRoot);
                secondStageUpdaterInstance.run();
            }
            // 11) cleanup and exit
            return self._log('Linkurious was successfully updated to version ' + updateArchiveInfo.version + '.', true, true);
        });
    },
    /**
     * Runs the update, prints an error message before failing.
     *
     * @param {any[]} args
     */
    run: function (args) {
        try {
            fs.ensureFileSync(this.logFilePath);
            if (args && args.length === 1 && args[0] === 'config') {
                this.migrateConfig(this.getCurrentInfo().linkurious, undefined);
            }
            else {
                this._run();
            }
        }
        catch (e) {
            return this._error(e);
        }
    }
};
const updater = new Updater(LK_DIR);
updater.run(process.argv.slice(2));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBkYXRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21hbmFnZXIvdXBkYXRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFDNUIsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFDdEIsS0FBSyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFDeEIsYUFBYSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBRWxELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUVuRCxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsUUFBUSxLQUFLLE9BQU87SUFDN0MsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUM7SUFDdkMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxRQUFRO1FBQzlCLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixFQUFFLGtCQUFrQixFQUFFLGlCQUFpQixDQUFDO1FBQzVELENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQ3JDLENBQUM7QUFFSjs7Ozs7Ozs7R0FRRztBQUVIOzs7Ozs7O0dBT0c7QUFFSDs7O0dBR0c7QUFDSCxTQUFTLE9BQU8sQ0FBQyxjQUFjO0lBQzdCLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO0lBQ3JDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQzFELENBQUM7QUFFRCxPQUFPLENBQUMsU0FBUyxHQUFHO0lBRWxCLGFBQWEsRUFBRSx3REFBd0Q7SUFFdkUsZ0JBQWdCLEVBQUUsNkJBQTZCO0lBRS9DLGVBQWUsRUFBRSxhQUFhO0lBRTlCLFVBQVUsRUFBRSxZQUFZO0lBRXhCOzs7OztPQUtHO0lBQ0gsT0FBTyxFQUFFLFVBQVMsT0FBTztRQUN2QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQscUJBQXFCLEVBQUUsVUFBUyxFQUFFO1FBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUMvQyxJQUFJO1lBQ0YsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2QixPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFO2dCQUM5QixPQUFPLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDaEMsRUFBRSxFQUFFLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxFQUFFLEVBQUUsQ0FBQztTQUNOO0lBQ0gsQ0FBQztJQUVELE1BQU0sRUFBRSxVQUFTLEtBQUs7UUFDcEIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtZQUNoRSxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxJQUFJLEVBQUUsVUFBUyxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU87UUFDN0IsZ0RBQWdEO1FBQ2hELElBQUksT0FBTyxFQUFFO1lBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQUU7UUFDakMsK0JBQStCO1FBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsR0FBRyxLQUFLLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDckYsMEJBQTBCO1FBQzFCLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVCLDZDQUE2QztRQUM3QyxJQUFJLElBQUksRUFBRTtZQUNSLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUU7Z0JBQzlCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7SUFFRCxhQUFhLEVBQUUsVUFBUyxDQUFDLEVBQUUsSUFBSTtRQUM3QixJQUFJO1lBQ0YsRUFBRSxDQUFDLGNBQWMsQ0FDZixJQUFJLENBQUMsV0FBVyxFQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUMsQ0FBQyxHQUFHLElBQUksQ0FDcEYsQ0FBQztTQUNIO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCx3QkFBd0I7U0FDekI7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxlQUFlLEVBQUU7UUFDZixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsT0FBTyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDM0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxrQkFBa0IsRUFBRSxVQUFTLFVBQVU7UUFDckMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksS0FBSyxFQUFFLElBQUksQ0FBQztRQUNoQixPQUFPLFVBQVUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDL0IsS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQUUsT0FBTyxJQUFJLENBQUM7YUFBRTtZQUM1QixJQUFJLEdBQUc7Z0JBQ0wsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ1osT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLFFBQVEsRUFBRSxRQUFRO2FBQ25CLENBQUM7WUFDRixPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxFQUFFO1FBQ2QsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQyxNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7UUFDNUUsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUNsQyxNQUFNLEVBQUUsR0FBRyxRQUFRLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3RGLE9BQU87WUFDTCxFQUFFLEVBQUUsRUFBRTtZQUNOLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSTtZQUNuQixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVU7WUFDL0IsYUFBYSxFQUFFLFFBQVEsQ0FBQyxhQUFhO1NBQ3RDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxvQkFBb0IsRUFBRSxVQUFTLFdBQVcsRUFBRSxjQUFjO1FBQ3hELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUNsQjs7V0FFRztRQUNILE1BQU0sZ0JBQWdCLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNwRCxPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssV0FBVyxDQUFDLEVBQUUsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDZixvQkFBb0I7WUFDcEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRTtZQUFFLE9BQU8sU0FBUyxDQUFDO1NBQUU7UUFDbkQsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQy9FLE9BQU8sZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDNUI7UUFDRCxPQUFPLFNBQVMsQ0FBQztJQUNuQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsYUFBYSxFQUFFLGFBQWEsQ0FBQyxTQUFTLENBQUMsYUFBYTtJQUVwRDs7Ozs7Ozs7T0FRRztJQUNILGVBQWUsRUFBRSxVQUFTLFVBQVUsRUFBRSxVQUFVLEVBQUUsUUFBUTtRQUN4RCxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsUUFBUTtRQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDekMsRUFBRSxDQUFDLFFBQVEsQ0FDVCxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsRUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQ25DLENBQUM7SUFDSixDQUFDO0lBRUQsT0FBTyxFQUFFLFVBQVMsUUFBUSxFQUFFLFFBQVEsRUFBRSxJQUFJO1FBQ3hDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ3RELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQztRQUM3RCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQUU7UUFDN0QsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7UUFDckUsSUFBSSxJQUFJLEVBQUU7WUFDUixFQUFFLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsQ0FBQztTQUN2QzthQUFNO1lBQ0wsRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDekM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxlQUFlLEVBQUU7UUFDZixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVEOzs7T0FHRztJQUNILGdCQUFnQixFQUFFLFVBQVMsUUFBUTtRQUNqQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDekMsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNsQixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxjQUFjLEVBQUUsVUFBUyxRQUFRLEVBQUUsTUFBTTtRQUN2QyxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM3QyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN0RCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM5RCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQUU7UUFDakUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsUUFBUSxFQUFFO1FBQ1IsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDaEQsRUFBRSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLEVBQUUsVUFBUyxhQUFhLEVBQUUscUJBQXFCO1FBQzFELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDdkQsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzQyxNQUFNLE9BQU8sR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDO1FBRW5GLGdCQUFnQjtRQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBRTFFLGlCQUFpQjtRQUNqQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxjQUFjLEdBQUcsTUFBTSxDQUFDLE9BQU8sSUFBSSxxQkFBcUIsQ0FBQztRQUM3RCxnR0FBZ0c7UUFDaEcsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUM7UUFDaEMsTUFBTSxhQUFhLEdBQUcsSUFBSSxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDdEUsYUFBYSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2xFLElBQUksQ0FBQyxJQUFJLENBQUMsK0JBQStCLEdBQUcsY0FBYyxHQUFHLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQzdGLGNBQWMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO1FBRUgsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxFQUFFO1FBQ0osTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxTQUFTLEVBQUU7WUFDckMsTUFBTSxJQUFJLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1NBQ2xFO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1FBRWpDLHFGQUFxRjtRQUNyRixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNoRCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO1lBQ3pGLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QixNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FDZCxxQkFBcUIsR0FBRyxRQUFRLENBQUMsVUFBVSxHQUFHLDZCQUE2QixFQUFFLElBQUksRUFBRSxJQUFJLENBQ3hGLENBQUM7U0FDSDtRQUNELEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFM0IsNEJBQTRCO1FBQzVCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUV4RCw0RUFBNEU7UUFDNUUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxzQ0FBc0MsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUM1RjtRQUVELCtDQUErQztRQUMvQyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFM0QsdUVBQXVFO1FBQ3ZFLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUNqRixJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUNkLCtDQUErQyxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQ3JFLElBQUksRUFDSixJQUFJLENBQ0wsQ0FBQztTQUNIO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxzQ0FBc0MsR0FBRyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUU5RSxnQ0FBZ0M7UUFDaEMsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMvRCxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNqQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMscUNBQXFDLEdBQUcsYUFBYSxHQUFHLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDM0Y7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLCtCQUErQixDQUFDLENBQUM7UUFDM0MsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3hELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDLENBQUMsQ0FBQztRQUN0RCxZQUFZLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2hDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxDQUFDLENBQUM7WUFDMUQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMvRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RDLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQztZQUU5RSwyQkFBMkI7WUFDM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBQ3JELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxlQUFlLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7WUFFckQseUJBQXlCO1lBQ3pCLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzlDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzlDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUMsQ0FBQztZQUVILCtDQUErQztZQUMvQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtnQkFDNUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQzthQUNoRDtpQkFBTTtnQkFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxDQUFDLENBQUM7YUFDbEQ7WUFFRCxpRUFBaUU7WUFDakUsSUFBSSxXQUFXLENBQUMsYUFBYSxLQUFLLGNBQWMsQ0FBQyxhQUFhLEVBQUU7Z0JBQzlELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxlQUFlLENBQUMsQ0FBQzthQUN2RDtpQkFBTTtnQkFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxDQUFDLENBQUM7YUFDbEQ7WUFFRCxvQkFBb0I7WUFDcEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXRFLHNGQUFzRjtZQUN0RixJQUFJLGtCQUFrQixDQUFDO1lBQ3ZCLElBQUk7Z0JBQ0Ysa0JBQWtCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQ3ZDLElBQUksQ0FBQyxjQUFjLEVBQUUsbUNBQW1DLENBQ3pELENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUM7YUFDekM7WUFBQyxPQUFNLENBQUMsRUFBRTtnQkFDVCxpREFBaUQ7Z0JBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsbUNBQW1DLENBQUMsQ0FBQzthQUNoRDtZQUVELElBQUksa0JBQWtCLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQztnQkFDMUMsTUFBTSwwQkFBMEIsR0FBRyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDL0UsMEJBQTBCLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDbEM7WUFFRCx1QkFBdUI7WUFDdkIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUNkLGlEQUFpRCxHQUFHLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxHQUFHLEVBQ25GLElBQUksRUFDSixJQUFJLENBQ0wsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxHQUFHLEVBQUUsVUFBUyxJQUFJO1FBQ2hCLElBQUk7WUFDRixFQUFFLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUVwQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUNyRCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQUM7YUFDakU7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2I7U0FDRjtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3ZCO0lBQ0gsQ0FBQztDQUNGLENBQUM7QUFFRixNQUFNLE9BQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMifQ==