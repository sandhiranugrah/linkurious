/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-04-13.
 */
'use strict';
const fs = require('fs-extra');
const path = require('path');
const destinationFilePathLinux = path.join(__dirname, '..', '..', 'menu.sh');
const inputFilePathLinux = path.join(__dirname, 'updated_scripts', 'menu.sh');
const destinationFilePathDarwin = path.join(__dirname, '..', '..', 'menu.sh.command');
const inputFilePathDarwin = path.join(__dirname, 'updated_scripts', 'menu.sh.command');
const destinationFilePathWin32Menu = path.join(__dirname, '..', '..', 'menu.bat');
const inputFilePathWin32Menu = path.join(__dirname, 'updated_scripts', 'menu.bat');
const destinationFilePathWin32Start = path.join(__dirname, '..', '..', 'start.bat');
const inputFilePathWin32Start = path.join(__dirname, 'updated_scripts', 'start.bat');
const destinationFilePathWin32Stop = path.join(__dirname, '..', '..', 'stop.bat');
const inputFilePathWin32Stop = path.join(__dirname, 'updated_scripts', 'stop.bat');
const destinationFilePathWin32Update = path.join(__dirname, '..', '..', 'update.bat');
const inputFilePathWin32Update = path.join(__dirname, 'updated_scripts', 'update.bat');
/**
 * This is a workaround to solve issue #820.
 * It's needed to update users from version <1.8 to newer versions.
 */
function replaceScript() {
    const platform = process.platform;
    if (platform === 'linux') {
        fs.copySync(inputFilePathLinux, destinationFilePathLinux);
        fs.chmodSync(destinationFilePathLinux, '755');
    }
    else if (platform === 'darwin') {
        fs.copySync(inputFilePathDarwin, destinationFilePathDarwin);
        fs.chmodSync(destinationFilePathDarwin, '755');
    }
    else if (platform === 'win32') {
        fs.copySync(inputFilePathWin32Menu, destinationFilePathWin32Menu);
        fs.copySync(inputFilePathWin32Start, destinationFilePathWin32Start);
        fs.copySync(inputFilePathWin32Stop, destinationFilePathWin32Stop);
        fs.copySync(inputFilePathWin32Update, destinationFilePathWin32Update);
    }
    else {
        throw new Error('No support for platform "' + platform + '"');
    }
}
replaceScript();
console.log('Linkurious manager was updated, please run this script again');
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG0yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vbWFuYWdlci9wbTIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0IsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBRTdCLE1BQU0sd0JBQXdCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztBQUM3RSxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO0FBRTlFLE1BQU0seUJBQXlCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3RGLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztBQUV2RixNQUFNLDRCQUE0QixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDbEYsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUVuRixNQUFNLDZCQUE2QixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFDcEYsTUFBTSx1QkFBdUIsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLENBQUMsQ0FBQztBQUVyRixNQUFNLDRCQUE0QixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDbEYsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUVuRixNQUFNLDhCQUE4QixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDdEYsTUFBTSx3QkFBd0IsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxZQUFZLENBQUMsQ0FBQztBQUV2Rjs7O0dBR0c7QUFDSCxTQUFTLGFBQWE7SUFDcEIsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztJQUNsQyxJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUU7UUFDeEIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO1FBQzFELEVBQUUsQ0FBQyxTQUFTLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDL0M7U0FBTSxJQUFJLFFBQVEsS0FBSyxRQUFRLEVBQUU7UUFDaEMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBQzVELEVBQUUsQ0FBQyxTQUFTLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDaEQ7U0FBTSxJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUU7UUFDL0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSw0QkFBNEIsQ0FBQyxDQUFDO1FBQ2xFLEVBQUUsQ0FBQyxRQUFRLENBQUMsdUJBQXVCLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztRQUNwRSxFQUFFLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLDRCQUE0QixDQUFDLENBQUM7UUFDbEUsRUFBRSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsRUFBRSw4QkFBOEIsQ0FBQyxDQUFDO0tBQ3ZFO1NBQU07UUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLDJCQUEyQixHQUFHLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQztLQUMvRDtBQUNILENBQUM7QUFFRCxhQUFhLEVBQUUsQ0FBQztBQUNoQixPQUFPLENBQUMsR0FBRyxDQUFDLDhEQUE4RCxDQUFDLENBQUMifQ==