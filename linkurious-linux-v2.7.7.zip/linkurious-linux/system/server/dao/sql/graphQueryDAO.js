"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-24.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
// services
const LKE = require("../../services");
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
// locals
const graphQuery_1 = require("../../models/sql/graphQuery");
class GraphQueryDAO {
    /**
     * Create a graph query and associate it with the user.
     */
    createGraphQuery(graphQuery, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return Db.models.graphQuery.create(_.merge(graphQuery, {
                    version: graphQuery_1.currentGraphQueryVersion,
                    userId: userId
                }));
            });
        });
    }
    /**
     * Add an association between each group in groups and the graph query.
     */
    shareGraphQueryWithGroups(graphQueryInstance, groups) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return graphQueryInstance
                    .setGroups(groups)
                    .then(() => {
                    return graphQueryInstance.save();
                })
                    .return();
            });
        });
    }
    /**
     * Remove all the group associations of the graph query.
     */
    unshareGraphQueryWithAllGroups(graphQueryInstance) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return graphQueryInstance
                    .setGroups([])
                    .then(() => {
                    return graphQueryInstance.save();
                })
                    .return();
            });
        });
    }
    /**
     * Get a graph query. Return `undefined` if the query is not found.
     */
    getGraphQuery(id) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return Db.models.graphQuery
                    .findOne({ where: { version: graphQuery_1.currentGraphQueryVersion, id: id } })
                    .then(instance => {
                    if (Utils.noValue(instance)) {
                        return undefined;
                    }
                    return instance;
                });
            });
        });
    }
    /**
     * Delete the graph query and all its associations to groups.
     */
    deleteGraphQuery(graphQueryInstance) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return graphQueryInstance.destroy();
            });
        });
    }
    /**
     * Modify the graph query.
     */
    updateGraphQuery(graphQueryInstance, graphQuery) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                _.forEach(graphQuery, (value, key) => {
                    if (Utils.hasValue(value)) {
                        // @ts-ignore a GraphQueryInstance has all the fields of an IGraphQuery
                        graphQueryInstance[key] = value;
                    }
                });
                return graphQueryInstance.save();
            });
        });
    }
    /**
     * Check if the graph query is owned by user.
     */
    isOwner(graphQueryInstance, userId) {
        return graphQueryInstance.userId === userId;
    }
    /**
     * Check if the graph query is shared with the data-source.
     */
    isSharedWithDataSource(graphQueryInstance, sourceKey) {
        return graphQueryInstance.sharing === 'source' && graphQueryInstance.sourceKey === sourceKey;
    }
    /**
     * Check if the graph query is shared with the groups.
     */
    isSharedWithGroups(graphQueryInstance, groupIds) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                if (graphQueryInstance.sharing !== 'groups') {
                    return false;
                }
                if (Utils.noValue(groupIds)) {
                    // if groupIds is not specified, we only check graphQueryInstance.sharing
                    return true;
                }
                return graphQueryInstance.getGroups().then(groups => {
                    return (graphQueryInstance.sharing === 'groups' &&
                        _.intersection(_.map(groups, 'id'), groupIds).length > 0);
                });
            });
        });
    }
    /**
     * Get the groups which the graph query is shared with.
     */
    getGraphQueryGroups(graphQueryInstance) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return graphQueryInstance.getGroups();
            });
        });
    }
    /**
     * Get all the graph queries shared with a given data-source.
     */
    getGraphQueriesSharedWithSource(sourceKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return Db.models.graphQuery.findAll({
                    where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey, sharing: 'source' }
                });
            });
        });
    }
    /**
     * Get all the graph queries owned by user in a data-source.
     */
    getGraphQueriesOwnedByUser(sourceKey, userId) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return Db.models.graphQuery.findAll({
                    where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey, userId: userId }
                });
            });
        });
    }
    /**
     * Get all the graph queries shared with some groups.
     */
    getGraphQueriesSharedWithGroups(sourceKey, groupIds) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                return Db.models.graphQuery.findAll({
                    where: { version: graphQuery_1.currentGraphQueryVersion, sourceKey: sourceKey },
                    include: [
                        {
                            model: Db.models.group,
                            through: { where: { groupId: groupIds } },
                            required: true
                        }
                    ]
                });
            });
        });
    }
}
exports.GraphQueryDAO = GraphQueryDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeURBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vc3FsL2dyYXBoUXVlcnlEQU8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOzs7Ozs7Ozs7O0FBRUgsZ0JBQWdCO0FBQ2hCLDRCQUE0QjtBQUU1QixXQUFXO0FBQ1gsc0NBQXVDO0FBQ3ZDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULDREQUlxQztBQUVyQyxNQUFhLGFBQWE7SUFDeEI7O09BRUc7SUFDVSxnQkFBZ0IsQ0FDM0IsVUFBdUIsRUFDdkIsTUFBYzs7WUFFZCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FDaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQ2xCLE9BQU8sRUFBRSxxQ0FBd0I7b0JBQ2pDLE1BQU0sRUFBRSxNQUFNO2lCQUNmLENBQUMsQ0FDSCxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO0tBQUE7SUFFRDs7T0FFRztJQUNVLHlCQUF5QixDQUNwQyxrQkFBc0MsRUFDdEMsTUFBdUI7O1lBRXZCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLE9BQU8sa0JBQWtCO3FCQUN0QixTQUFTLENBQUMsTUFBTSxDQUFDO3FCQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFO29CQUNULE9BQU8sa0JBQWtCLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ25DLENBQUMsQ0FBQztxQkFDRCxNQUFNLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDVSw4QkFBOEIsQ0FDekMsa0JBQXNDOztZQUV0QyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyxPQUFPLGtCQUFrQjtxQkFDdEIsU0FBUyxDQUFDLEVBQUUsQ0FBQztxQkFDYixJQUFJLENBQUMsR0FBRyxFQUFFO29CQUNULE9BQU8sa0JBQWtCLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ25DLENBQUMsQ0FBQztxQkFDRCxNQUFNLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDVSxhQUFhLENBQUMsRUFBVTs7WUFDbkMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVU7cUJBQ3hCLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxxQ0FBd0IsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQztxQkFDN0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNmLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTt3QkFDM0IsT0FBTyxTQUFTLENBQUM7cUJBQ2xCO29CQUNELE9BQU8sUUFBUSxDQUFDO2dCQUNsQixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDVSxnQkFBZ0IsQ0FBQyxrQkFBc0M7O1lBQ2xFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLE9BQU8sa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO0tBQUE7SUFFRDs7T0FFRztJQUNVLGdCQUFnQixDQUMzQixrQkFBc0MsRUFDdEMsVUFBZ0M7O1lBRWhDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO29CQUNuQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ3pCLHVFQUF1RTt3QkFDdkUsa0JBQWtCLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO3FCQUNqQztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDSSxPQUFPLENBQUMsa0JBQXNDLEVBQUUsTUFBYztRQUNuRSxPQUFPLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUM7SUFDOUMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksc0JBQXNCLENBQzNCLGtCQUFzQyxFQUN0QyxTQUFpQjtRQUVqQixPQUFPLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxRQUFRLElBQUksa0JBQWtCLENBQUMsU0FBUyxLQUFLLFNBQVMsQ0FBQztJQUMvRixDQUFDO0lBRUQ7O09BRUc7SUFDVSxrQkFBa0IsQ0FDN0Isa0JBQXNDLEVBQ3RDLFFBQW1COztZQUVuQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyxJQUFJLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxRQUFRLEVBQUU7b0JBQzNDLE9BQU8sS0FBSyxDQUFDO2lCQUNkO2dCQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDM0IseUVBQXlFO29CQUN6RSxPQUFPLElBQUksQ0FBQztpQkFDYjtnQkFFRCxPQUFPLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDbEQsT0FBTyxDQUNMLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxRQUFRO3dCQUN2QyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQ3pELENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1UsbUJBQW1CLENBQzlCLGtCQUFzQzs7WUFFdEMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDakMsT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN4QyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1UsK0JBQStCLENBQUMsU0FBaUI7O1lBQzVELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUNsQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUscUNBQXdCLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFDO2lCQUNwRixDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1UsMEJBQTBCLENBQ3JDLFNBQWlCLEVBQ2pCLE1BQWM7O1lBRWQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7b0JBQ2xDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxxQ0FBd0IsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUM7aUJBQ2pGLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDVSwrQkFBK0IsQ0FDMUMsU0FBaUIsRUFDakIsUUFBa0I7O1lBRWxCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO29CQUNsQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUscUNBQXdCLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztvQkFDaEUsT0FBTyxFQUFFO3dCQUNQOzRCQUNFLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUs7NEJBQ3RCLE9BQU8sRUFBRSxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUMsRUFBQzs0QkFDckMsUUFBUSxFQUFFLElBQUk7eUJBQ2Y7cUJBQ0Y7aUJBQ0YsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO0tBQUE7Q0FDRjtBQWpNRCxzQ0FpTUMifQ==