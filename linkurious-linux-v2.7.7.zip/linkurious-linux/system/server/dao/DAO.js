"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-31.
 */
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../services");
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const TYPES = ['Graph', 'Index'];
class DAO {
    /**
     * Base class of a DAO instance.
     *
     * The Connector module will searched for in ./connector/<vendor>/<connectorName>Connector.js
     * The Driver module will searched for in ./<lowerCase(type)>/<vendor>/<driverName>Driver.js
     *
     * @param type             'Graph' or 'Index'
     * @param vendor           Name of the vendor for this DAO (e.g.: neo4j, elasticSearch)
     * @param requiredOptions  List of required option properties
     * @param availableOptions List of available option properties
     * @param options          DAO constructor options
     * @param [graphDao]       The connected GraphDAO (only if type is 'Index', TODO #987 optional to support old DAOs, see #634)
     * @param [connectors]     Connectors of the DAO (TODO #987 optional to support old DAOs, see #634)
     * @param [drivers]        Driver to use from a given version (TODO #987 optional to support old DAOs, see #634)
     */
    constructor(type, vendor, requiredOptions, availableOptions, options, graphDao, connectors, drivers) {
        this.disconnecting = false;
        if (this === undefined) {
            throw Errors.technical('bug', 'DAO: constructor called without "new"');
        }
        // type (Graph or Index)
        if (!_.includes(TYPES, type)) {
            throw Errors.technical('bug', 'DAO: "type" must be one of ' + TYPES);
        }
        this.type = type;
        // vendor name (neo4j, elasticSearch, ...)
        if (!vendor) {
            throw Errors.technical('bug', type + ' DAO: "vendor" is required');
        }
        this.vendor = vendor;
        this.name = type + ' DAO (' + vendor + ')';
        // check options
        if (!requiredOptions) {
            throw Errors.technical('bug', this.name + ': "requiredOptions" is required');
        }
        if (!Array.isArray(requiredOptions)) {
            throw Errors.technical('bug', this.name + ': "requiredOptions" must be an array');
        }
        if (!availableOptions) {
            throw Errors.technical('bug', this.name + ': "availableOptions" is required');
        }
        if (!Array.isArray(availableOptions)) {
            throw Errors.technical('bug', `${this.name}: "availableOptions" must be an array`);
        }
        if (!options) {
            throw Errors.business('bug', this.name + ': "options" is required');
        }
        requiredOptions.forEach(key => {
            if (Utils.noValue(options[key])) {
                throw Errors.business('missing_field', this.name + ': "options.' + key + '" is required');
            }
        });
        const unknownOptions = _.difference(Object.keys(options), availableOptions);
        if (unknownOptions.length > 0) {
            throw Errors.business('invalid_parameter', this.name + ': unknown options: ' + unknownOptions.join(', '));
        }
        this.options = options;
        if (Utils.hasValue(connectors) && Utils.hasValue(drivers)) {
            // Graph options are needed for connecting indices as well
            this.graphOptions =
                type === 'Graph'
                    ? options
                    : graphDao.options;
            this.indexOptions = type === 'Index' ? options : undefined;
            this.graphDao = graphDao;
            this.connectors = Array.isArray(connectors) ? connectors : [connectors];
            // minimum size of `drivers` is 2 (at least 1 driver and the [latest] version supported)
            Utils.check.array('drivers', drivers, 2);
            this.drivers = drivers;
            // we sort them in descending order
            this.drivers.sort((a, b) => {
                return Utils.compareSemVer(b.version, a.version);
            });
        }
    }
    get connector() {
        if (this._connector) {
            return this._connector;
        }
        // TODO #987 after ES refactoring, _connector is undefined only if we are not connected
        return Utils.NOT_IMPLEMENTED();
    }
    get driver() {
        if (this._driver) {
            return this._driver;
        }
        // TODO #987 after ES refactoring, _driver is undefined only if we are not connected
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * @param path
     * @param vendor
     */
    static tryToRequire(path, vendor) {
        try {
            return require(path);
        }
        catch (e) {
            if (Utils.hasValue(e.message) && e.message.startsWith('Cannot find module')) {
                Log.error(e);
                throw Errors.technical('bug', 'Module not found for vendor "' + vendor + '" (' + path + ')');
            }
            else {
                throw e;
            }
        }
    }
    /**
     * Create a DAO instance.
     * The DAO module will searched for in ./<lowerCase(type)>/<vendor>/<vendor>DAO.js
     *
     * @param type       'Graph' or 'Index' (will be set to lowercase to resolve the folder)
     * @param vendor     Vendor name
     * @param options    DAO constructor options
     * @param [graphDao] The connected GraphDAO (only if type is 'Index')
     */
    static createDAOInstance(type, vendor, options, graphDao) {
        if (!type) {
            throw Errors.technical('bug', 'DAO "type" is required');
        }
        if (!vendor) {
            throw Errors.technical('bug', 'DAO "vendor" is required');
        }
        const path = './' + type.toLowerCase() + '/' + vendor + '/' + vendor + 'DAO';
        // tslint:disable-next-line:no-any
        const DAOClass = DAO.tryToRequire(path, vendor);
        if (options && options.vendor) {
            // remove 'vendor' key from options
            options = _.omit(options, 'vendor');
        }
        return new DAOClass(options, graphDao);
    }
    /**
     * Connect for the first time to the DAO using the first connector that works.
     * Return the SemVer version of the remote server.
     *
     * @param [connectors] Connectors still to try
     */
    firstConnect(connectors) {
        if (Utils.noValue(connectors)) {
            // we initialize the connector name list
            connectors = Utils.clone(this.connectors);
        }
        if (connectors.length === 0) {
            // we reach here only if no connectors were defined for the DAO
            return Errors.technical('bug', this.type + ' DAO: at least 1 "connector" is required', true);
        }
        return Bluebird.resolve()
            .then(() => {
            // create the connector
            const Connector = connectors.shift();
            const connector = new Connector(this.graphOptions, this.indexOptions);
            return Bluebird.props({
                connector: connector,
                connectorName: Connector.name,
                version: connector.$connect()
            });
        })
            .then(firstConnectR => {
            this._connector = firstConnectR.connector;
            Log.info(`${this.name} will be using connector: "${firstConnectR.connectorName}Connector".`);
            return firstConnectR.version;
        })
            .catch(error => {
            // if we still have connectors to try we silently ignore the error
            if (connectors.length > 0) {
                return this.firstConnect(connectors);
            }
            // else we fail with the error of the last connector
            throw error;
        });
    }
    /**
     * Connect to the remote server.
     *
     * Based on the version of the vendor and on the `drivers` array, pick the right driver:
     * - If the actual version is higher than the latest supported version,
     *   use the latest driver and show a warning
     * - If the actual version is lower than the earliest supported version,
     *   use the earliest driver and show a warning
     * - Otherwise, pick the driver with the highest version inferior to the actual version
     *
     * Entries of the `drivers` array should be read as:
     * This driver with this `name` is compatible since this `version` of the vendor
     *
     * Return the SemVer version of the remote server.
     */
    connect() {
        return Bluebird.resolve()
            .then(() => {
            // if we already connected in the past, a connector is defined and we can connect directly
            // otherwise, we invoke `firstConnect` that tries all the possible connectors one by one
            if (Utils.hasValue(this._connector)) {
                return this.connector.$connect();
            }
            else {
                return this.firstConnect();
            }
        })
            .then(actualVersion => {
            let currentDriver;
            const drivers = this.drivers;
            if (actualVersion === '[unknown]') {
                // if we cannot obtain the vendor version (actualVersion === [unknown])
                // we default to the latest supported version
                currentDriver = '[latest]';
                actualVersion = drivers[0].version;
                Log.warn(`Linkurious was not able to get the version of ${this.vendor}. ` +
                    'We will be using the latest supported driver.');
            }
            else {
                // we pick the driver with the highest version inferior to the actual version
                for (let i = 0; i < drivers.length; i++) {
                    if (actualVersion >= drivers[i].version) {
                        currentDriver = drivers[i].driver;
                        break;
                    }
                }
            }
            if (currentDriver === '[latest]') {
                currentDriver = drivers[1].driver;
                const latestVersion = drivers[0].version;
                if (actualVersion > latestVersion) {
                    Log.warn('Version ' +
                        actualVersion +
                        ' of ' +
                        this.vendor +
                        ' was never officially tested with Linkurious.' +
                        ' Latest supported version is ' +
                        latestVersion +
                        '.');
                }
            }
            else if (Utils.noValue(currentDriver)) {
                const earliest = drivers[drivers.length - 1];
                currentDriver = earliest.driver;
                Log.warn('Version ' +
                    actualVersion +
                    ' of ' +
                    this.vendor +
                    ' was never officially tested with Linkurious.' +
                    ' Earliest supported version is ' +
                    earliest.version +
                    '.');
            }
            const CurrentDriver = currentDriver;
            return this.connector
                .$getConnectorData()
                .then(connectorData => {
                Log.info(`${this.name} [v${actualVersion}] will be using driver: "${CurrentDriver.name}Driver".`);
                if (this.type === 'Graph') {
                    const graphFeatures = this.features;
                    this._driver = new CurrentDriver(this.connector, this.graphOptions, connectorData, graphFeatures);
                }
                else {
                    // we also pass the index options
                    const indexFeatures = this.features;
                    this._driver = new CurrentDriver(this.connector, this.graphDao, this.indexOptions, connectorData, indexFeatures);
                }
                return this._driver.$onAfterConnect();
            })
                .return(actualVersion);
        });
    }
    /**
     * Disconnect from the remote server.
     *
     * It will never throw.
     */
    disconnect() {
        try {
            if (this._connector) {
                this.disconnecting = true;
                this._connector.$disconnect();
            }
        }
        catch (e) {
            /* ignore any error */
        }
    }
    /**
     * Check if the remote server is alive.
     */
    checkUp() {
        if (this.disconnecting) {
            // prevent periodic checkup during disconnection
            return Bluebird.resolve();
        }
        return this.connector.$checkUp();
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     */
    getStoreId() {
        return this.connector.$getStoreId();
    }
    /**
     * Return a DAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getOption(key, defaultValue) {
        const value = this.options[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Called at the end of the indexation phase for additional initializations.
     */
    onAfterIndexation() {
        // TODO #987 after refactor ES DAOs this check can be removed
        if (!this._driver) {
            return Bluebird.resolve();
        }
        return this.driver.$onAfterIndexation();
    }
}
module.exports = DAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL2Rhby9EQU8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBRUgsZ0JBQWdCO0FBQ2hCLHFDQUFxQztBQUNyQyw0QkFBNEI7QUFFNUIsV0FBVztBQUNYLG1DQUFvQztBQUNwQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBTSxLQUFLLEdBQUcsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFFakMsTUFBZSxHQUFHO0lBcUJoQjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILFlBQ0UsSUFBdUIsRUFDdkIsTUFBYyxFQUNkLGVBQXlCLEVBQ3pCLGdCQUEwQixFQUMxQixPQUErQixFQUMvQixRQUFzRCxFQUN0RCxVQUEyRCxFQUMzRCxPQUEyRTtRQS9CckUsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFpQ3JDLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUN0QixNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLHVDQUF1QyxDQUFDLENBQUM7U0FDeEU7UUFFRCx3QkFBd0I7UUFDeEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQzVCLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsNkJBQTZCLEdBQUcsS0FBSyxDQUFDLENBQUM7U0FDdEU7UUFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUVqQiwwQ0FBMEM7UUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxHQUFHLDRCQUE0QixDQUFDLENBQUM7U0FDcEU7UUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUVyQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUUzQyxnQkFBZ0I7UUFDaEIsSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUNwQixNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsaUNBQWlDLENBQUMsQ0FBQztTQUM5RTtRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQ25DLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxzQ0FBc0MsQ0FBQyxDQUFDO1NBQ25GO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3JCLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxrQ0FBa0MsQ0FBQyxDQUFDO1NBQy9FO1FBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNwQyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksdUNBQXVDLENBQUMsQ0FBQztTQUNwRjtRQUNELElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDWixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcseUJBQXlCLENBQUMsQ0FBQztTQUNyRTtRQUNELGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDNUIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO2dCQUMvQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsQ0FBQzthQUMzRjtRQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxjQUFjLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDNUUsSUFBSSxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUM3QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixJQUFJLENBQUMsSUFBSSxHQUFHLHFCQUFxQixHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQzlELENBQUM7U0FDSDtRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBRXZCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3pELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsWUFBWTtnQkFDZixJQUFJLEtBQUssT0FBTztvQkFDZCxDQUFDLENBQUMsT0FBTztvQkFDVCxDQUFDLENBQUUsUUFBd0QsQ0FBQyxPQUFPLENBQUM7WUFDeEUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUMzRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztZQUV6QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUV4RSx3RkFBd0Y7WUFDeEYsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUV6QyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUN2QixtQ0FBbUM7WUFDbkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3pCLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNuRCxDQUFDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztJQUVELElBQUksU0FBUztRQUNYLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7U0FDeEI7UUFFRCx1RkFBdUY7UUFDdkYsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELElBQUksTUFBTTtRQUNSLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNoQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7U0FDckI7UUFFRCxvRkFBb0Y7UUFDcEYsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7T0FHRztJQUNLLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBWSxFQUFFLE1BQWM7UUFDdEQsSUFBSTtZQUNGLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3RCO1FBQUMsT0FBTyxDQUFDLEVBQUU7WUFDVixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLEVBQUU7Z0JBQzNFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixLQUFLLEVBQ0wsK0JBQStCLEdBQUcsTUFBTSxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUM5RCxDQUFDO2FBQ0g7aUJBQU07Z0JBQ0wsTUFBTSxDQUFDLENBQUM7YUFDVDtTQUNGO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFDLGlCQUFpQixDQUM3QixJQUF1QixFQUN2QixNQUFjLEVBQ2QsT0FBK0IsRUFDL0IsUUFBc0Q7UUFFdEQsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNULE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztTQUN6RDtRQUNELElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDWCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDBCQUEwQixDQUFDLENBQUM7U0FDM0Q7UUFFRCxNQUFNLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDN0Usa0NBQWtDO1FBQ2xDLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBUSxDQUFDO1FBRXZELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDN0IsbUNBQW1DO1lBQ25DLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztTQUNyQztRQUVELE9BQU8sSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLFlBQVksQ0FBQyxVQUFzQztRQUN6RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDN0Isd0NBQXdDO1lBQ3hDLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUF1QyxDQUFDLENBQUM7U0FDeEU7UUFFRCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzNCLCtEQUErRDtZQUMvRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsMENBQTBDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDOUY7UUFFRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUU7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULHVCQUF1QjtZQUN2QixNQUFNLFNBQVMsR0FBSSxVQUF3QyxDQUFDLEtBQUssRUFBd0IsQ0FBQztZQUMxRixNQUFNLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FDN0IsSUFBSSxDQUFDLFlBQXNDLEVBQzNDLElBQUksQ0FBQyxZQUFZLENBQ2xCLENBQUM7WUFFRixPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUM7Z0JBQ3BCLFNBQVMsRUFBRSxTQUFTO2dCQUNwQixhQUFhLEVBQUUsU0FBUyxDQUFDLElBQUk7Z0JBQzdCLE9BQU8sRUFBRSxTQUFTLENBQUMsUUFBUSxFQUFFO2FBQzlCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNwQixJQUFJLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxTQUFTLENBQUM7WUFFMUMsR0FBRyxDQUFDLElBQUksQ0FDTixHQUFHLElBQUksQ0FBQyxJQUFJLDhCQUE4QixhQUFhLENBQUMsYUFBYSxhQUFhLENBQ25GLENBQUM7WUFDRixPQUFPLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFDL0IsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2Isa0VBQWtFO1lBQ2xFLElBQUssVUFBd0MsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUN4RCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDdEM7WUFFRCxvREFBb0Q7WUFDcEQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNJLE9BQU87UUFDWixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUU7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNULDBGQUEwRjtZQUMxRix3RkFBd0Y7WUFDeEYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDbkMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ2xDO2lCQUFNO2dCQUNMLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQzVCO1FBQ0gsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3BCLElBQUksYUFBMEQsQ0FBQztZQUMvRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FHbkIsQ0FBQztZQUVILElBQUksYUFBYSxLQUFLLFdBQVcsRUFBRTtnQkFDakMsdUVBQXVFO2dCQUN2RSw2Q0FBNkM7Z0JBQzdDLGFBQWEsR0FBRyxVQUFVLENBQUM7Z0JBQzNCLGFBQWEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNuQyxHQUFHLENBQUMsSUFBSSxDQUNOLGlEQUFpRCxJQUFJLENBQUMsTUFBTSxJQUFJO29CQUM5RCwrQ0FBK0MsQ0FDbEQsQ0FBQzthQUNIO2lCQUFNO2dCQUNMLDZFQUE2RTtnQkFDN0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3ZDLElBQUksYUFBYSxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUU7d0JBQ3ZDLGFBQWEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO3dCQUNsQyxNQUFNO3FCQUNQO2lCQUNGO2FBQ0Y7WUFFRCxJQUFJLGFBQWEsS0FBSyxVQUFVLEVBQUU7Z0JBQ2hDLGFBQWEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNsQyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUN6QyxJQUFJLGFBQWEsR0FBRyxhQUFhLEVBQUU7b0JBQ2pDLEdBQUcsQ0FBQyxJQUFJLENBQ04sVUFBVTt3QkFDUixhQUFhO3dCQUNiLE1BQU07d0JBQ04sSUFBSSxDQUFDLE1BQU07d0JBQ1gsK0NBQStDO3dCQUMvQywrQkFBK0I7d0JBQy9CLGFBQWE7d0JBQ2IsR0FBRyxDQUNOLENBQUM7aUJBQ0g7YUFDRjtpQkFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3ZDLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM3QyxhQUFhLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztnQkFDaEMsR0FBRyxDQUFDLElBQUksQ0FDTixVQUFVO29CQUNSLGFBQWE7b0JBQ2IsTUFBTTtvQkFDTixJQUFJLENBQUMsTUFBTTtvQkFDWCwrQ0FBK0M7b0JBQy9DLGlDQUFpQztvQkFDakMsUUFBUSxDQUFDLE9BQU87b0JBQ2hCLEdBQUcsQ0FDTixDQUFDO2FBQ0g7WUFFRCxNQUFNLGFBQWEsR0FBRyxhQUFtQyxDQUFDO1lBRTFELE9BQU8sSUFBSSxDQUFDLFNBQVM7aUJBQ2xCLGlCQUFpQixFQUFFO2lCQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3BCLEdBQUcsQ0FBQyxJQUFJLENBQ04sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFNLGFBQWEsNEJBQzdCLGFBQWEsQ0FBQyxJQUNoQixVQUFVLENBQ1gsQ0FBQztnQkFFRixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO29CQUN6QixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO29CQUVwQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksYUFBYSxDQUM5QixJQUFJLENBQUMsU0FBUyxFQUNkLElBQUksQ0FBQyxZQUFZLEVBQ2pCLGFBQWEsRUFDYixhQUFhLENBQ2QsQ0FBQztpQkFDSDtxQkFBTTtvQkFDTCxpQ0FBaUM7b0JBQ2pDLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7b0JBRXBDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxhQUFhLENBQzlCLElBQUksQ0FBQyxTQUFTLEVBQ2QsSUFBSSxDQUFDLFFBQVEsRUFDYixJQUFJLENBQUMsWUFBWSxFQUNqQixhQUFhLEVBQ2IsYUFBYSxDQUNkLENBQUM7aUJBQ0g7Z0JBRUQsT0FBUSxJQUFJLENBQUMsT0FBNkIsQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUMvRCxDQUFDLENBQUM7aUJBQ0QsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVO1FBQ2YsSUFBSTtZQUNGLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDL0I7U0FDRjtRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1Ysc0JBQXNCO1NBQ3ZCO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksT0FBTztRQUNaLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUN0QixnREFBZ0Q7WUFDaEQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFDRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksVUFBVTtRQUNmLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxTQUFTLENBQUMsR0FBVyxFQUFFLFlBQXNCO1FBQ2xELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDaEMsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztJQUN0RCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxpQkFBaUI7UUFDdEIsNkRBQTZEO1FBQzdELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2pCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDMUMsQ0FBQztDQUNGO0FBRUQsaUJBQVMsR0FBRyxDQUFDIn0=