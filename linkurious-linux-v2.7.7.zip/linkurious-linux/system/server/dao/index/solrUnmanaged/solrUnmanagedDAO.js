/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-08-05.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const SolrConnector = require('../../connector/solrConnector');
const SolrUnmanagedDriver = require('./solrUnmanagedDriver');
/**
 * @param {object}   options
 * @param {string}   options.url                  Solr url
 * @param {string}   options.collectionName       Solr collection to use
 * @param {string}   [options.user]               Solr user
 * @param {string}   [options.password]           Solr password
 * @param {boolean}  [options.allowSelfSigned]    Whether to allow self-signed certificates
 * @param {string[]} options.searchKeys           Indexed property keys with type text_general (used for generating the search query)
 * @param {string}   options.categoriesKey        Indexed property key with type string (used for filtering the search on some node categories)
 * @param {string}   [options.indexAlternativeId] Stored property key with type string (used for linking the documents returned from the search to the nodes in the Graph database). Defaults to the default id in Solr
 * @param {string}   [options.graphAlternativeId] Graph property key that has to match with `indexAlternativeId`. Defaults to the native id of the graph db
 */
class SolrUnmanagedDAO extends IndexDAO {
    constructor(options, graphDao) {
        super('solrUnmanaged', [
            'url', 'collectionName', 'searchKeys', 'categoriesKey'
        ], [
            'url', 'collectionName', 'user', 'password', 'allowSelfSigned',
            'searchKeys', 'categoriesKey', 'indexAlternativeId', 'graphAlternativeId'
        ], options, {
            fuzzy: true,
            canIndexCategories: false,
            external: true,
            canCount: false,
            typing: false,
            schema: false,
            canIndexEdges: false,
            searchHitsCount: true
        }, graphDao, SolrConnector, [
            { version: '7.4.0', driver: '[latest]' },
            { version: '7.4.0', driver: SolrUnmanagedDriver }
        ], 
        // only Graph DAOs that support alternativeIds can use unmanaged search DAOs
        ['neo4j', 'janusGraph', 'janusGraphForCompose']);
    }
}
module.exports = SolrUnmanagedDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29sclVubWFuYWdlZERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvc29sclVubWFuYWdlZC9zb2xyVW5tYW5hZ2VkREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsK0JBQStCLENBQUMsQ0FBQztBQUMvRCxNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRTdEOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsTUFBTSxnQkFBaUIsU0FBUSxRQUFRO0lBQ3JDLFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUFDLGVBQWUsRUFDbkI7WUFDRSxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLGVBQWU7U0FDdkQsRUFDRDtZQUNFLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLGlCQUFpQjtZQUM5RCxZQUFZLEVBQUUsZUFBZSxFQUFFLG9CQUFvQixFQUFFLG9CQUFvQjtTQUMxRSxFQUNELE9BQU8sRUFBRTtZQUNQLEtBQUssRUFBRSxJQUFJO1lBQ1gsa0JBQWtCLEVBQUUsS0FBSztZQUV6QixRQUFRLEVBQUUsSUFBSTtZQUNkLFFBQVEsRUFBRSxLQUFLO1lBQ2YsTUFBTSxFQUFFLEtBQUs7WUFFYixNQUFNLEVBQUUsS0FBSztZQUViLGFBQWEsRUFBRSxLQUFLO1lBQ3BCLGVBQWUsRUFBRSxJQUFJO1NBQ3RCLEVBQ0QsUUFBUSxFQUNSLGFBQWEsRUFDYjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsbUJBQW1CLEVBQUM7U0FDaEQ7UUFDRCw0RUFBNEU7UUFDNUUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLHNCQUFzQixDQUFDLENBQ2hELENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDIn0=