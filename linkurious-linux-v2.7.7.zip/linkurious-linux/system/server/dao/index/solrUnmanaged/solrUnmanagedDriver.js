/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-08-05.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
// locals
const IndexDriver = require('../indexDriver');
const DaoUtils = require('../../utils/daoUtils');
class SolrUnmanagedDriver extends IndexDriver {
    /**
     * @param {CypherConnector} connector     Connector used by the DAO
     * @param {GraphDAO}        graphDAO      The connected Graph DAO
     * @param {any}             indexOptions  IndexDAO options
     * @param {any}             connectorData Data from the connector
     * @param {IndexFeatures}   indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this.$schema = connectorData.schema;
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        this.$requiredSchema = [
            {
                name: this.getIndexOption('categoriesKey'),
                requirements: [['indexed', true], ['type', 'string']]
            }
        ];
        if (Utils.hasValue(this.getIndexOption('indexAlternativeId'))) {
            this.$requiredSchema.push({
                name: this.getIndexOption('indexAlternativeId'),
                requirements: [['stored', true]]
            });
        }
        this.$requiredSchema =
            this.$requiredSchema.concat(_.map(this.getIndexOption('searchKeys'), searchKey => ({
                name: searchKey,
                requirements: [['indexed', true], ['type', 'text_general']]
            })));
        return Promise.resolve().then(() => {
            const schemaFields = _.mapKeys(this.$schema.fields, value => value.name);
            for (const requiredSchemaField of this.$requiredSchema) {
                const schemaField = schemaFields[requiredSchemaField.name];
                if (Utils.noValue(schemaField)) {
                    return Errors.business('invalid_parameter', 'The Solr schema doesn\'t include a schema type definition for "' +
                        requiredSchemaField.name + '".', true);
                }
                for (const fieldRequirement of requiredSchemaField.requirements) {
                    if (schemaField[fieldRequirement[0]] !== fieldRequirement[1]) {
                        return Errors.business('invalid_parameter', `The Solr schema for "${requiredSchemaField.name}" is incorrect. ` +
                            `"${fieldRequirement[0]}" should be ${fieldRequirement[1]} ` +
                            `instead of ${schemaField[fieldRequirement[0]]}.`, true);
                    }
                }
            }
        });
    }
    /**
     * Given a lucene query, apply the `options.categoriesOrTypes` filter.
     *
     * @param {string} luceneQuery
     * @param {LkSearchOptions}    options
     * @returns {string}
     */
    _createLuceneFilteredQuery(luceneQuery, options) {
        if (Utils.hasValue(options.categoriesOrTypes)) {
            // Solr field where the categories are stored
            const categoriesKey = this.getIndexOption('categoriesKey');
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.categoriesOrTypes, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
            let nodeCategoryFilterQuery = readableCategories.map(c => categoriesKey + ':' + c).join(' OR ');
            if (options.categoriesOrTypes.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                nodeCategoryFilterQuery += ` OR (NOT ${categoriesKey}:*)`;
            }
            luceneQuery = '(' + luceneQuery + ') AND (' + nodeCategoryFilterQuery + ')';
        }
        return luceneQuery;
    }
    /**
     * Search for nodes using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param {SearchOptions} options
     * @returns {Bluebird<SearchResponse>}
     */
    $search(options) {
        const indexAlternativeId = this.getIndexOption('indexAlternativeId', 'id'); // defaults to the default id in Solr
        const graphAlternativeId = this.getIndexOption('graphAlternativeId'); // defaults to undefined, (native ID of the graph db)
        // heuristic to see if the query may be advanced
        const possibleAdvancedQuery = options.q.includes(':');
        return Promise.resolve().then(() => {
            if (!possibleAdvancedQuery) {
                return Promise.resolve();
            }
            const advancedSearchQuery = this._createLuceneFilteredQuery(options.q, options);
            return this.connector.$search(advancedSearchQuery, options.size, options.from).catch(() => {
                // we silently ignore any error
                // it's not an advanced search query, so we will try to build it
                return;
            });
        }).then(results => {
            if (Utils.hasValue(results)) {
                return results;
            }
            // if no result was returned, either because:
            //  - the query was not detected as advanced
            //  - the advanced query was wrong
            // we build our own lucene query
            const luceneQuery = this._createLuceneFilteredQuery(DaoUtils.generateLuceneQuery(options.q, options.fuzziness, { fields: this.getIndexOption('searchKeys') }), options);
            return this.connector.$search(luceneQuery, options.size, options.from);
        }).then(result => {
            return {
                type: 'node',
                totalHits: result.numFound,
                alternativeId: graphAlternativeId,
                results: _.map(result.docs, doc => {
                    const documentId = doc[indexAlternativeId];
                    if (Utils.noValue(documentId)) {
                        Log.warn('The following document returned by Solr was ignored ' +
                            'because it had no stored indexAlternativeId: ' + JSON.stringify(doc));
                        // we soft-fail with a fake unique key that will result in a empty entry in the results
                        return '[missingAlternativeKey]';
                    }
                    return documentId;
                })
            };
        });
    }
}
module.exports = SolrUnmanagedDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29sclVubWFuYWdlZERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvc29sclVubWFuYWdlZC9zb2xyVW5tYW5hZ2VkRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxTQUFTO0FBQ1QsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDOUMsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFFakQsTUFBTSxtQkFBb0IsU0FBUSxXQUFXO0lBRTNDOzs7Ozs7T0FNRztJQUNILFlBQVksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWE7UUFDekUsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUV2RSxJQUFJLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGVBQWUsR0FBRztZQUNyQjtnQkFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUM7Z0JBQzFDLFlBQVksRUFBRSxDQUFDLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ3REO1NBQ0YsQ0FBQztRQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLENBQUMsRUFBRTtZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQztnQkFDeEIsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUM7Z0JBQy9DLFlBQVksRUFBRSxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2pDLENBQUMsQ0FBQztTQUNKO1FBRUQsSUFBSSxDQUFDLGVBQWU7WUFDbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakYsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsWUFBWSxFQUFFLENBQUMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7YUFDNUQsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVQLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV6RSxLQUFLLE1BQU0sbUJBQW1CLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtnQkFDdEQsTUFBTSxXQUFXLEdBQUcsWUFBWSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQzlCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsaUVBQWlFO3dCQUNqRSxtQkFBbUIsQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksQ0FDdEMsQ0FBQztpQkFDSDtnQkFFRCxLQUFLLE1BQU0sZ0JBQWdCLElBQUksbUJBQW1CLENBQUMsWUFBWSxFQUFFO29CQUMvRCxJQUFJLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM1RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLHdCQUF3QixtQkFBbUIsQ0FBQyxJQUFJLGtCQUFrQjs0QkFDbEUsSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsZUFBZSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsR0FBRzs0QkFDNUQsY0FBYyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FDeEQsQ0FBQztxQkFDSDtpQkFDRjthQUNGO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsMEJBQTBCLENBQUMsV0FBVyxFQUFFLE9BQU87UUFDN0MsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQzdDLDZDQUE2QztZQUM3QyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBRTNELDBEQUEwRDtZQUMxRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUMzRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsNEJBQTRCLENBQUMsQ0FBQztZQUVwRCxJQUFJLHVCQUF1QixHQUFHLGtCQUFrQixDQUFDLEdBQUcsQ0FDbEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxhQUFhLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FDN0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFZixJQUFJLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0JBQzdFLHVCQUF1QixJQUFJLFlBQVksYUFBYSxLQUFLLENBQUM7YUFDM0Q7WUFFRCxXQUFXLEdBQUcsR0FBRyxHQUFHLFdBQVcsR0FBRyxTQUFTLEdBQUcsdUJBQXVCLEdBQUcsR0FBRyxDQUFDO1NBQzdFO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMscUNBQXFDO1FBQ2pILE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMscURBQXFEO1FBRTNILGdEQUFnRDtRQUNoRCxNQUFNLHFCQUFxQixHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXRELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxDQUFDLHFCQUFxQixFQUFFO2dCQUMxQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUMxQjtZQUVELE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFaEYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUN4RiwrQkFBK0I7Z0JBQy9CLGdFQUFnRTtnQkFDaEUsT0FBTztZQUNULENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2hCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDM0IsT0FBTyxPQUFPLENBQUM7YUFDaEI7WUFFRCw2Q0FBNkM7WUFDN0MsNENBQTRDO1lBQzVDLGtDQUFrQztZQUNsQyxnQ0FBZ0M7WUFFaEMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FDOUUsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUMsQ0FDMUUsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUVaLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLE1BQU07Z0JBQ1osU0FBUyxFQUFFLE1BQU0sQ0FBQyxRQUFRO2dCQUMxQixhQUFhLEVBQUUsa0JBQWtCO2dCQUNqQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztvQkFFM0MsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO3dCQUM3QixHQUFHLENBQUMsSUFBSSxDQUNOLHNEQUFzRDs0QkFDdEQsK0NBQStDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUN6RSx1RkFBdUY7d0JBQ3ZGLE9BQU8seUJBQXlCLENBQUM7cUJBQ2xDO29CQUVELE9BQU8sVUFBVSxDQUFDO2dCQUNwQixDQUFDLENBQUM7YUFDSCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLG1CQUFtQixDQUFDIn0=