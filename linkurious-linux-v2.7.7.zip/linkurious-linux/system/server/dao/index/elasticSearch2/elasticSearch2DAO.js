/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-08-30.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // fix with refactoring
// libraries
const _ = require('lodash');
const Promise = require('bluebird');
const fs = require('fs');
// imports
const IndexDAO = require('../indexDAO');
const LKE = require('../../../services/index');
const LkRequest = require('../../../lib/LkRequest');
// services
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const DaoUtils = require('../../utils/daoUtils');
////////////////////////////////////////////////////////////////////////////////
const DOT_REPLACEMENT_CHAR = '\u00B7';
const UNDERSCORE_REPLACEMENT_CHAR = '\u0332';
const EARLIEST_SUPPORTED_VERSION = '2.0';
// size of the payload of a bulk operation
// https://www.elastic.co/guide/en/elasticsearch/guide/current/bulk.html#_how_big_is_too_big
const BULK_SIZE_IN_BYTE = 10000000; // 10MB
// name of the fields where categories and types are store in ES documents
const NODE_CATEGORIES_FIELD = 'lk_categories';
const EDGE_TYPE_FIELD = 'lk_type';
// how to translate ES field types
const MAPPING_ES_TYPE = {
    'text': 'string',
    'string': 'string',
    'byte': 'integer',
    'short': 'integer',
    'integer': 'integer',
    'long': 'integer',
    'float': 'float',
    'double': 'float',
    'boolean': 'boolean',
    'date': 'date'
};
// This fields are interesting for two reasons:
// - The score of a match on one of these fields is boosted in comparison to other fields
// - This fields are used as names in record results
const INTERESTING_FIELDS = ['name', 'title', 'label', 'caption', 'rdfs:label'];
const BOOSTED_INTERESTING_FIELDS = INTERESTING_FIELDS.map(field => field + '^1.5').concat(['_all']);
const DISPLAY_NAME_PROPERTIES_HEURISTIC = _.flatten(_.map(INTERESTING_FIELDS, e => [e, _.capitalize(e), e.toUpperCase()]));
// RegExp to recognize an advanced query
const ADVANCED_QUERY_RE = /(\sAND\s|\s\|\|\s|\s&&\s|\sOR\s|>|<|\[|:|\s\+|\s-)/;
const ES_META_FIELDS = [
    '_index', '_uid', '_type',
    '_id', '_source', '_size',
    '_all', '_field_names', '_ignored',
    '_routing', '_meta'
];
const ES_META_FIELDS_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f, f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR)]));
const ES_META_FIELDS_REVERSE_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR), f]));
class ElasticSearch2DAO extends IndexDAO {
    /**
     * ElasticSearch2 DAO constructor
     *
     * Notes:
     * We are going to have two individual indices, one for nodes and one for edges (if edge
     * indexation is enabled).
     *
     * @param {object} options
     * @param {string} options.host                   ES host
     * @param {string|number} options.port            ES port
     * @param {boolean} [options.https]               Boolean that represents if we have to use HTTP over SSL
     * @param {string} [options.username]             ES username
     * @param {string} [options.password]             ES password
     * @param {boolean} [options.dynamicMapping=true] Boolean that represents if ES can automatically choose the type of a field
     * @param {string[]} [options.forceStringMapping] List of fields that are mapped to strings even with dynamicMapping=true
     * @param {boolean} [options.analyzer]            Analyzer used by ES to index string fields
     * @param {boolean} [options.skipEdgeIndexation]  Boolean that represents if we don't have to index the edges
     * @param {string} options.indexName              Prefix of the names of the indices
     * @param {string} options.caCert                 Absolute path to CA certificate
     * @param {GraphDAO} graphDao                     The connected Graph DAO
     */
    constructor(options, graphDao) {
        super('elasticSearch2', // name of the index
        ['host', 'port'], // required params
        ['host', 'port', 'https', 'user', 'password', 'dynamicMapping', 'forceStringMapping',
            'analyzer', 'forceReindex', 'caCert', 'simplifiedSearch'], // optional params
        options, {
            canCount: true,
            fuzzy: true,
            canIndexEdges: true,
            canIndexCategories: true,
            searchHitsCount: true,
            external: false,
            schema: false,
            typing: true,
            advancedQueryDialect: 'elasticsearch'
        });
        // TODO #987 refactor this check with ES refactoring
        // check if graph vendor is different from stardog
        if (graphDao.vendor === 'stardog') {
            throw Errors.technical('critical', `Cannot use "${this.vendor}" with Graph DAO "${graphDao.vendor}".`, true);
        }
        this._simplifiedSearch = options.simplifiedSearch;
        this._nodeIndexName = options.indexName + '_nodes';
        this._edgeIndexName = options.indexName + '_edges';
        // dynamicMapping set to true means that if the schema is consistent the fields are mapped
        // automatically to a type (integer, float, boolean, date, string). This break if the
        // schema is not consistent and it must be disabled. If disabled all fields are still mapped
        // automatically to the type string.
        this._dynamicMapping = this.getOption('dynamicMapping', false); // by default it's false
        this._forceStringMapping = this.getOption('forceStringMapping', []);
        this._analyzer = this.getOption('analyzer', 'lk_analyzer');
        const protocol = options.https ? 'https' : 'http';
        this._url = protocol + '://' + options.host + ':' + options.port;
        this._request = new LkRequest({
            baseUrl: this._url,
            auth: options.user ? {
                user: options.user,
                password: options.password
            } : undefined,
            json: true,
            pool: { maxSockets: 5 },
            gzip: true,
            agentOptions: {
                ca: options.caCert ? fs.readFileSync(options.caCert) : undefined
            }
        }, {
            errorPrefix: 'ElasticSearch2'
        });
    }
    get META_FIELD_MAPPING() {
        return ES_META_FIELDS_MAPPING;
    }
    get META_FIELD_REVERSE_MAPPING() {
        return ES_META_FIELDS_REVERSE_MAPPING;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Return a dynamic template that match `match` and index the matched field as a string and
     * as a not_analyzed. The not_analyzed version of the field is called `${field}.raw`.
     *
     * @param {string} match
     * @returns {object}
     * @private
     */
    _templateForNotAnalyzedFields(match) {
        const templateName = match + '_has_raw';
        const result = {};
        result[templateName] = {
            match: match,
            mapping: this.elasticSearch6 ? {
                type: 'text',
                analyzer: this._analyzer,
                fields: {
                    raw: {
                        type: 'keyword'
                    }
                }
            } : {
                type: 'string',
                analyzer: this._analyzer,
                fields: {
                    raw: {
                        type: 'string',
                        index: 'not_analyzed'
                    }
                }
            }
        };
        return result;
    }
    /**
     * It generate the options for the index (indices) based on the `dynamicMapping` and `analyzer`
     * options.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {{mappings: {_default_: {dynamic_templates: *[]}}}}
     * @private
     */
    _newIndexOptions(type) {
        // we add a new analyzer 'lk_analyzer' that will replace `.` with ` ` but, for all the rest,
        // it will behave like the standard analyzer
        // https://www.elastic.co/guide/en/elasticsearch/reference/current/analysis-standard-analyzer.html
        // https://www.elastic.co/guide/en/elasticsearch/guide/current/standard-analyzer.html
        const lkAnalizerIndexSettings = {
            // number_of_shards: 1, // ALWAYS use this line while analyzing the scores
            index: {
                analysis: {
                    'char_filter': {
                        'dot_to_whitespace': {
                            type: 'pattern_replace',
                            pattern: '(\\D)\\.(\\D)',
                            replacement: '$1 $2'
                        },
                        'underscore_to_whitespace': {
                            type: 'pattern_replace',
                            pattern: '_',
                            replacement: ' '
                        }
                    },
                    filter: {
                        'asciifolding_original': {
                            type: 'asciifolding',
                            'preserve_original': true
                        }
                    },
                    analyzer: {
                        'lk_analyzer': {
                            tokenizer: 'standard',
                            'char_filter': [
                                'dot_to_whitespace',
                                'underscore_to_whitespace'
                            ],
                            filter: ['asciifolding_original', 'lowercase', 'stop']
                        }
                    }
                }
            }
        };
        const mappingToString = {
            type: this.elasticSearch6 ? 'text' : 'string',
            analyzer: this._analyzer
        };
        const dynamicTemplates = [];
        if (type === 'node') {
            dynamicTemplates.push(this._templateForNotAnalyzedFields(NODE_CATEGORIES_FIELD));
        }
        else { // 'edge'
            dynamicTemplates.push(this._templateForNotAnalyzedFields(EDGE_TYPE_FIELD));
        }
        if (!this._dynamicMapping) {
            // everything is a string
            dynamicTemplates.push({
                'all_fields_are_strings': {
                    match: '*',
                    mapping: mappingToString
                }
            });
        }
        else {
            // everything in forceStringMapping is forced to a string
            _.forEach(this._forceStringMapping, field => {
                const template = {};
                template[field + '_is_a_string'] = {
                    match: field,
                    mapping: mappingToString
                };
                dynamicTemplates.push(template);
            });
            // we change the analyzer to any other field that was mapped by dynamic mapping as a string
            dynamicTemplates.push({
                'all_strings_use_this_analyzer': {
                    match: '*',
                    'match_mapping_type': 'string',
                    mapping: mappingToString
                }
            });
        }
        const indexOptions = {
            'settings': lkAnalizerIndexSettings,
            'mappings': {
                '_default_': {
                    'dynamic_templates': dynamicTemplates
                }
            }
        };
        // change _all mapping to use our analyzer
        indexOptions.mappings[type] = {
            '_all': {
                type: this.elasticSearch6 ? 'text' : 'string',
                analyzer: this._analyzer
            }
        };
        return indexOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Return the index url for nodes and edges.
     *
     * @param {string} type
     * @returns {string}
     * @private
     */
    _indexUrl(type) {
        if (type === 'node') {
            return this._nodeIndexName;
        }
        else {
            return this._edgeIndexName;
        }
    }
    /**
     * Return the type url for nodes and edges.
     *
     * @param {string} type
     * @returns {string}
     * @private
     */
    _typeUrl(type) {
        return this._indexUrl(type) + '/' + type;
    }
    /**
     * Return the id url for a given type and id.
     *
     * @param {string} type
     * @param {*} id
     * @returns {string}
     * @private
     */
    _idUrl(type, id) {
        return this._typeUrl(type) + '/' + encodeURIComponent(id);
    }
    /**
     * Return the array of indices used by this DAO.
     * Usually used when we have to do the same operation (create, delete, flush) on both indices.
     *
     * @returns {string[]}
     * @private
     */
    _indices() {
        return [this._nodeIndexName, this._edgeIndexName];
    }
    /**
     * @param {string} type 'node' or 'edge'
     * @param {boolean} [raw] true to obtain the not_analyzed field
     * @returns {string}
     * @private
     */
    _fieldCategoriesOrTypes(type, raw) {
        let result;
        if (type === 'node') {
            result = NODE_CATEGORIES_FIELD;
        }
        else {
            result = EDGE_TYPE_FIELD;
        }
        if (raw) {
            return result + '.raw';
        }
        return result;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * A wrapper for bulk operations to ES.
     * This function will automatically split the bulk request in many requests as long as the payload
     * of each is close to `BULK_SIZE_IN_BYTE`.
     *
     * The format of `operations` follows the pattern used by ElasticSearch:
     *   https://www.elastic.co/guide/en/elasticsearch/reference/current/docs-bulk.html
     *
     * The main difference here is that entries are not delimited by the newline character
     * (as requested by ES) but they are in an array.
     *
     * The possible actions are 'index', 'create', 'delete' and 'update'.
     * 'index', 'create' and 'update' actions require a 'source' field.
     * 'delete' cannot have a 'source' field.
     *
     * @example
     * _bulk([
     *   {
     *     action: {index: {_index: 'test', _type: 'type1', _id: 1}},
     *     source: {field1: 'value1'}
     *   },
     *   {
     *     action: {delete: {_index: 'test', _type: 'type1', _id: 2}}
     *   }
     * ])
     * It indexes a document {field1: value1} in '/test/type1/1' and it deletes '/test/type1/2'.
     *
     * @param {object[]} operations
     * @param {string} [defaultIndex] Instead of specifying the index for each bulk operation use this default index
     * @param {string} [defaultType]  Instead of specifying the type for each bulk operation use this default type (`defaultIndex` is required)
     * @returns {Bluebird<object[]>} a response for each action (exactly as returned by ES)
     * @private
     */
    _bulk(operations, defaultIndex, defaultType) {
        return Promise.resolve().then(() => {
            if (operations.length === 0) {
                return [];
            }
            // 1) split the operations in payloads of BULK_SIZE_IN_BYTE
            const payloads = [];
            let body = '';
            _.forEach(operations, operation => {
                body += global.JSON.stringify(operation.action) + '\n';
                if (Utils.hasValue(operation.source)) {
                    // an 'index', 'create' and 'update' action will use 2 lines
                    body += global.JSON.stringify(operation.source) + '\n';
                }
                if (body.length >= BULK_SIZE_IN_BYTE) {
                    payloads.push(body);
                    body = '';
                }
            });
            if (body.length > 0) {
                payloads.push(body);
            }
            let url = '';
            if (defaultIndex) {
                url += '/' + defaultIndex;
                if (defaultType) {
                    url += '/' + defaultType;
                }
            }
            url += '/_bulk';
            // 2) make as many request as payloads we have
            return Promise.map(payloads, payload => {
                const options = { json: false, body: payload };
                if (this.elasticSearch6) {
                    options.headers = { 'Content-type': 'application/x-ndjson' };
                }
                return this._request.post(url, options, [200]).then(bulkR => {
                    // our body is not a valid json, but the answer is, so we decode it
                    return global.JSON.parse(bulkR.body);
                });
            }, { concurrency: 1 }).then(multipleBulkR => {
                // we join the responses in a unique response
                return {
                    errors: _.reduce(_.map(multipleBulkR, 'errors'), (clause, error) => {
                        return clause || error;
                    }, false),
                    items: [].concat.apply([], _.map(multipleBulkR, 'items'))
                };
            });
        });
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * Transform a node in another document following these rules:
     * - result = node.data
     * - result[NODE_CATEGORIES_FIELD] = node.categories
     *
     * Transform an edge in another document following these rules:
     * - result = edge.data
     * - result[EDGE_TYPE_FIELD] = edge.type
     *
     * @param {LkNode|LkEdge} lkObject
     * @param {string} type
     * @returns {object}
     * @private
     */
    _transformLkObjectToESDocument(lkObject, type) {
        const result = Utils.clone(lkObject.data);
        if (type === 'node') {
            result[NODE_CATEGORIES_FIELD] = lkObject.categories;
        }
        else { // edge
            result[EDGE_TYPE_FIELD] = lkObject.type;
        }
        // fix unsafe properties.
        const keys = Object.keys(result);
        for (let i = 0; i < keys.length; ++i) {
            const originalKey = keys[i];
            if (this.META_FIELD_MAPPING.has(originalKey)) {
                // If the user property is also an elastic search meta field, replace the property
                // with a non conflicting equivalent.
                const value = result[originalKey];
                result[originalKey] = undefined;
                // Using the combining low line as a replacement
                // https://www.fileformat.info/info/unicode/char/0332/index.htm
                const fixedKey = this.META_FIELD_MAPPING.get(originalKey);
                result[fixedKey] = value;
                continue;
            }
            if (originalKey.includes('.')) {
                // Replace the dot in the key by something ES2 accepts:
                // http://www.fileformat.info/info/unicode/char/b7/index.htm
                const value = result[originalKey];
                result[originalKey] = undefined;
                const fixedKey = originalKey.replace(/[.]/g, DOT_REPLACEMENT_CHAR);
                result[fixedKey] = value;
            }
        }
        return result;
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * ES2 wants the fuzziness expressed in number of characters of distance.
     * The editDistance is 0 if fuzziness === 0
     * AUTO if 0 < fuzziness <= 0.6
     * 2 if fuzziness > 0.6
     *
     * Definition of AUTO:
     * https://www.elastic.co/guide/en/elasticsearch/reference/1.4/common-options.html#_string_fields
     *
     * @param {number} length    length of the searchString
     * @param {number} fuzziness
     * @returns {*}
     * @private
     */
    _editDistanceFromFuzziness(length, fuzziness) {
        if (fuzziness === 0) {
            return 0;
        }
        else if (fuzziness <= 0.6) {
            return 'AUTO';
        }
        else {
            return 2;
        }
    }
    /**
     * Return an array of ES queries that have to be respected but that don't contribute to the score.
     * These queries are constructed on the `filter` and the `categoriesOrTypes` of SearchOptions.
     * All the filter have to be respected and at least a category (or a type) have too.
     *
     * @example
     * we want all the nodes with categories 'Actor' or 'Producer'
     * that are 40 years old and from France.
     * The result will be:
     *
     * [{
     *   bool: {
     *     should: [{
     *       match: {
     *         "lk_categories.raw": {
     *           query: "Actor"
     *         }
     *       }
     *     }, {
     *       match: {
     *         "lk_categories.raw": {
     *           query: "Producer"
     *         }
     *       }
     *     }]
     *   }
     * }, {
     *   match: {
     *     age: {
     *       query: 40
     *     }
     *   }
     * }, {
     *   match: {
     *     country: {
     *       query: "France"
     *     }
     *   }
     * }];
     *
     * @param {string[][]} [filter]          Array of pairs key-value used to filter the result. The keys represent object properties and the values that should match for each property
     * @param {string[]} [categoriesOrTypes] Exclusive list of edge-types or node-categories to restrict the search on
     * @param {string} type                  'node' or 'edge'
     * @returns {*[]} an array of ES queries
     * @private
     */
    _buildFilter(filter, categoriesOrTypes, type) {
        const fieldCategoryOrType = this._fieldCategoriesOrTypes(type);
        const rawFieldCategoryOrType = this._fieldCategoriesOrTypes(type, true);
        const fieldFilters = _.map(filter, fieldFilter => {
            const fieldName = fieldFilter[0];
            const fieldQuery = fieldFilter[1];
            // fuzziness is left to AUTO
            const result = { match: {} };
            result.match[fieldName] = { query: fieldQuery, operator: 'and' };
            return result;
        });
        // If readable categories or type are not specified, do not apply any filter.
        if (Utils.hasValue(categoriesOrTypes)) {
            const categoriesOrTypesFilter = [{ terms: { [rawFieldCategoryOrType]: categoriesOrTypes } }];
            if (categoriesOrTypes.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                // category '[no_category]' means with no categories or types
                // the missing clause has been removed since ES5 we now use must_not -> exists instead
                // https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-exists-query.html#_literal_missing_literal_query
                categoriesOrTypesFilter.push({
                    bool: {
                        'must_not': { exists: { field: fieldCategoryOrType } }
                    }
                });
            }
            fieldFilters.push({ bool: { should: categoriesOrTypesFilter } });
        }
        return fieldFilters;
    }
    /**
     * Pick the most representative field for a document based on a simple heuristic.
     * Return undefined if it wasn't possible to find it.
     *
     * @param {object} document
     * @returns {string} a property of source
     * @private
     */
    _mostRepresentativeField(document) {
        let fields = DISPLAY_NAME_PROPERTIES_HEURISTIC;
        const objectKeys = new Set(_.keys(document));
        fields = _.filter(fields, field => objectKeys.has(field));
        return fields[0];
    }
    /**
     * Convert the artificial fields for categories and types.
     *
     * @param {string} propertyName
     * @returns {string}
     */
    _mapIndexField(propertyName) {
        if (propertyName.indexOf(this._fieldCategoriesOrTypes('node')) >= 0) {
            return '[categories]';
        }
        else if (propertyName.indexOf(this._fieldCategoriesOrTypes('edge')) >= 0) {
            return '[type]';
        }
        else if (propertyName.includes(DOT_REPLACEMENT_CHAR)) {
            return propertyName.replace(new RegExp(DOT_REPLACEMENT_CHAR, 'g'), '.');
        }
        else if (this.META_FIELD_REVERSE_MAPPING.has(propertyName)) {
            return this.META_FIELD_REVERSE_MAPPING.get(propertyName);
        }
        else {
            return propertyName;
        }
    }
    /**
     * Build the query to send to ES.
     *
     * @param {string} type             'node' or 'edge'
     * @param {string} searchString
     * @param {SearchOptions} options
     * @param {boolean} advanced        Wheter to build an advanced query
     * @returns {{query: {bool: {must: {bool: {should: *[]}}, filter: *[]}}, size: (number|*), from: (*|Date), sort: *[], _source: boolean, highlight: *}}
     * @private
     */
    _buildQuery(type, searchString, options, advanced) {
        const editDistance = this._editDistanceFromFuzziness(searchString.length, options.fuzziness);
        const sortingOptions = [{ _score: { order: 'desc' } }];
        if (LKE.isTestMode()) {
            // sort on score first and then id to mantain consistency in pagination
            sortingOptions.push({ _uid: { order: 'asc', 'unmapped_type': 'string' } });
        }
        let shouldQueries = advanced ? [{
                'query_string': {
                    fields: BOOSTED_INTERESTING_FIELDS,
                    lenient: true,
                    query: searchString,
                    analyzer: this._analyzer
                }
            }] : [{
                'multi_match': {
                    fields: ['*'],
                    lenient: true,
                    query: searchString,
                    type: 'phrase_prefix'
                }
            }, {
                'multi_match': {
                    fields: BOOSTED_INTERESTING_FIELDS,
                    lenient: true,
                    query: searchString,
                    fuzziness: editDistance
                }
            }];
        // simplifiedSearch:
        // - doesn't use boosted fields
        // - has no phrase_prefix query
        // - all search tokens must appear in the document
        if (this._simplifiedSearch) {
            shouldQueries = advanced ? [{
                    'query_string': {
                        fields: ['_all'],
                        lenient: true,
                        query: searchString,
                        analyzer: this._analyzer
                    }
                }] : [
                //   {
                // 'multi_match': {
                //   fields: ['*'], // we use '*' instead of '_all' because _all doesn't seem to work with phrase_prefix
                //   lenient: true, // necessary to use field '*'
                //   query: searchString,
                //   type: 'phrase_prefix',
                //   'max_expansions': 50
                // }},
                {
                    match: {
                        _all: {
                            query: searchString,
                            fuzziness: editDistance,
                            operator: 'and'
                        }
                    }
                }
            ];
        }
        return {
            query: {
                bool: {
                    'minimum_should_match': 1,
                    should: shouldQueries,
                    // we enforce the filter and options.categoriesOrTypes
                    filter: this._buildFilter(options.filter, options.categoriesOrTypes, type)
                }
            },
            // we enforce pagination
            size: options.size,
            from: options.from,
            sort: sortingOptions,
            _source: false
        };
    }
    ////////////////////////////////////////////////////////////////////////////////
    /**
     * @inheritdoc
     */
    connect() {
        return this._request.get('', {}, [200]).catch(err => {
            Log.warn('Cannot connect to ElasticSearch due to: ' + err);
            return Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch.', true);
        }).then(connectR => {
            const version = connectR.body.version.number;
            if (Utils.compareSemVer(version, EARLIEST_SUPPORTED_VERSION) < 0) {
                return Errors.business('not_supported', `ElasticSearch ${version} is not supported by ElasticSearch2.`, true);
            }
            if (Utils.compareSemVer(version, '6.0.0') >= 0) {
                // TODO #987 use a custom driver for es6
                this.elasticSearch6 = true;
            }
            return version;
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() {
        return this._request.get('', {}, [200]).catch(() => {
            return Errors.technical('index_unreachable', 'Cannot reach ElasticSearch.', true);
        });
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this._request.get('/_cat/indices', { qs: { format: 'json' } }, [200]).then(indicesR => {
            const indicesInES = _.map(indicesR.body, 'index');
            // we check if it contains the node index and, if we indexed also the edges, the edge index
            return _.includes(indicesInES, this._nodeIndexName) &&
                _.includes(indicesInES, this._edgeIndexName);
        });
    }
    /**
     * Delete ES index with name `indexName`. Return 'true' if deletion was successful.
     *
     * @param {string} indexName
     * @returns {Bluebird<boolean>}
     * @private
     */
    _deleteIfExistsIndexWithName(indexName) {
        return this._request.delete(indexName, {}, [200, 404])
            .then(deleteR => deleteR.statusCode === 200);
    }
    /**
     * @inheritdoc
     */
    $deleteIfExists() {
        return Promise.map(this._indices(), index => {
            return this._deleteIfExistsIndexWithName(index);
        }).then(deleteIndicesR => {
            // It should never happen that one index exists and the other doesn't except if one of them
            // was manually deleted in ES.
            if (deleteIndicesR[0] ? !deleteIndicesR[1] : deleteIndicesR[1]) { // XOR operation
                Log.warn('The was an inconsistency in ES where one of the index existed ' +
                    'and the other did not.');
            }
            return deleteIndicesR[0] || deleteIndicesR[1];
        });
    }
    /**
     * @inheritdoc
     */
    $createIndex() {
        return Promise.map(['node', 'edge'], type => {
            return this._request.put(this._indexUrl(type), { body: this._newIndexOptions(type) }, [200]).return(this._indexUrl(type));
        });
    }
    /**
     * Look at $addEntries.
     *
     * @param {string} type
     * @param {LkNode[]|LkEdge[]} entries
     * @returns {Bluebird<{index: {_version: number}}[]>}
     * @private
     */
    _addEntries(type, entries) {
        const index = type === 'node' ? this._nodeIndexName : this._edgeIndexName;
        return this._bulk(_.map(entries, entry => ({
            action: { index: { _id: entry.id } },
            source: this._transformLkObjectToESDocument(entry, type)
        })), index, type).then(bulkR => {
            if (bulkR.errors) {
                // If there was an error, we search for it so we can throw nicely
                const faultyIndexations = _.filter(bulkR.items, item => [200, 201].indexOf(item.index.status) < 0);
                if (faultyIndexations.length >= 0) {
                    // if the error type is mapper_parsing_exception or illegal_argument_exception we throw an ad-hoc error
                    const error = faultyIndexations[0].index.error;
                    if (error.type === 'mapper_parsing_exception' ||
                        error.type === 'illegal_argument_exception') {
                        // we parse the property name on which occurred the mapping exception
                        // the reason has the following format 'failed to parse [propertyName]' or 'mapper [propertyName] of ...'
                        const propertyName = /\[(.*?)]/g.exec(error.reason)[1];
                        // propertyName is an heuristic. There might be other reasons for 'mapper_parsing_exception' or 'illegal_argument_exception' errors
                        // we build the message
                        let errorMsg = 'There was an error while updating Elasticsearch.';
                        if (Utils.hasValue(propertyName)) {
                            if (error.reason.includes('cannot contain ')) {
                                const char = error.reason.split('cannot contain ')[1];
                                errorMsg = 'The property "' + propertyName + '" has an illegal character: ' + char;
                            }
                            else {
                                errorMsg = 'The property "' + propertyName + '" had an unexpected type.';
                                if (Utils.hasValue(error['caused_by']) &&
                                    error['caused_by'].type === 'number_format_exception') {
                                    errorMsg += ' (expecting a number)';
                                }
                            }
                        }
                        return Errors.business('index_mapping_error', errorMsg, true);
                    }
                    else {
                        // otherwise return a generic error
                        return Errors.technical('critical', 'ElasticSearch wasn\'t able to index the record. ' +
                            global.JSON.stringify(faultyIndexations[0].index.error), true);
                    }
                }
            }
            return bulkR.items;
        });
    }
    /**
     * @inheritdoc
     */
    $addEntries(type, entries) {
        return this._addEntries(type, entries).return();
    }
    /**
     * @inheritdoc
     */
    $commit() {
        return this._request.post(this._indices().join(',') + '/_flush', {}, [200]).catch(e => {
            return Errors.technical('critical', 'Couldn\'t flush indices: ' + e.message, true);
        });
    }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        return this._request.get(this._idUrl(type, '_count'), {}, [200, 404, 403]).then(countR => {
            if (countR.statusCode === 404) {
                return 0;
            }
            if (countR.statusCode === 403) {
                // we shouldn't fail if we don't have the rights, it's not critical
                Log.warn(`Failed to read the ${type} count from the index, ` +
                    'please check elasticsearch permissions');
                this.features.canCount = false;
                return 0;
            }
            return countR.body.count;
        });
    }
    /**
     * @inheritdoc
     */
    $upsertEntry(type, entry) {
        return this._addEntries(type, [entry]).then(addEntriesR => addEntriesR[0].index._version);
    }
    /**
     * @inheritdoc
     */
    $deleteEntry(id, type) {
        return this._request.delete(this._idUrl(type, id), {}, [200, 404]);
    }
    /**
     * @inheritdoc
     */
    $getPropertyTypes(type) {
        return this._request.get(this._indexUrl(type), {}, [200]).then(getPropertyTypesR => {
            // we get the mapping from ES
            const esMappings = getPropertyTypesR.body[this._indexUrl(type)].mappings[type];
            // esMapping may be undefined if no documents are indexed
            let mappings = esMappings ? esMappings.properties : {};
            // we remove artificial fields
            mappings = _.omit(mappings, [NODE_CATEGORIES_FIELD, EDGE_TYPE_FIELD]);
            // for each mapping we translate the type to one type we recognize:
            // string, integer, float, boolean, date
            return _.mapValues(mappings, mapping => MAPPING_ES_TYPE[mapping.type]);
        });
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        return Promise.resolve().then(() => {
            // if options.q looks alike an advanced query
            if (options.q.match(ADVANCED_QUERY_RE)) {
                return this._request.get(this._idUrl(options.type, '_search'), { body: this._buildQuery(options.type, options.q, options, true) }, [200]).catch(() => undefined);
                // catch advanced query errors to fallback to simple query
            }
            else {
                // directly fallback to simple query
                return undefined;
            }
        }).then(advancedQueryR => {
            if (advancedQueryR) {
                return advancedQueryR;
            }
            return this._request.get(this._idUrl(options.type, '_search'), { body: this._buildQuery(options.type, options.q, options, false) }, [200]);
        }).then(queryR => ({
            type: options.type,
            totalHits: queryR.body.hits.total,
            results: queryR.body.hits.hits.map(o => o._id)
        }));
    }
    /**
     * Not implemented because the ES2 is an internal index and (at least for now) the schema feature
     * is disabled.
     */
    $getSchema() { }
}
module.exports = ElasticSearch2DAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxhc3RpY1NlYXJjaDJEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2VsYXN0aWNTZWFyY2gyL2VsYXN0aWNTZWFyY2gyREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsOEJBQThCLENBQUMsdUJBQXVCO0FBRXRELFlBQVk7QUFDWixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUV6QixVQUFVO0FBQ1YsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ3hDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBRXBELFdBQVc7QUFDWCxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFFakQsZ0ZBQWdGO0FBRWhGLE1BQU0sb0JBQW9CLEdBQUcsUUFBUSxDQUFDO0FBQ3RDLE1BQU0sMkJBQTJCLEdBQUcsUUFBUSxDQUFDO0FBQzdDLE1BQU0sMEJBQTBCLEdBQUcsS0FBSyxDQUFDO0FBRXpDLDBDQUEwQztBQUMxQyw0RkFBNEY7QUFDNUYsTUFBTSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsQ0FBQyxPQUFPO0FBRTNDLDBFQUEwRTtBQUMxRSxNQUFNLHFCQUFxQixHQUFHLGVBQWUsQ0FBQztBQUM5QyxNQUFNLGVBQWUsR0FBRyxTQUFTLENBQUM7QUFFbEMsa0NBQWtDO0FBQ2xDLE1BQU0sZUFBZSxHQUFHO0lBQ3RCLE1BQU0sRUFBRSxRQUFRO0lBQ2hCLFFBQVEsRUFBRSxRQUFRO0lBQ2xCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE9BQU8sRUFBRSxPQUFPO0lBQ2hCLFFBQVEsRUFBRSxPQUFPO0lBQ2pCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxNQUFNO0NBQ2YsQ0FBQztBQUVGLCtDQUErQztBQUMvQyx5RkFBeUY7QUFDekYsb0RBQW9EO0FBQ3BELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDL0UsTUFBTSwwQkFBMEIsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUVwRyxNQUFNLGlDQUFpQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQ2pELENBQUMsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FDM0MsQ0FBQyxDQUFDO0FBRUwsd0NBQXdDO0FBQ3hDLE1BQU0saUJBQWlCLEdBQUcsb0RBQW9ELENBQUM7QUFFL0UsTUFBTSxjQUFjLEdBQUc7SUFDckIsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPO0lBQ3pCLEtBQUssRUFBRSxTQUFTLEVBQUUsT0FBTztJQUN6QixNQUFNLEVBQUUsY0FBYyxFQUFFLFVBQVU7SUFDbEMsVUFBVSxFQUFFLE9BQU87Q0FDcEIsQ0FBQztBQUVGLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxHQUFHLENBQUMsY0FBYztLQUNsRCxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSwyQkFBMkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBRWpFLE1BQU0sOEJBQThCLEdBQUcsSUFBSSxHQUFHLENBQUMsY0FBYztLQUMxRCxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLDJCQUEyQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBRWpFLE1BQU0saUJBQWtCLFNBQVEsUUFBUTtJQUV0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FvQkc7SUFDSCxZQUFZLE9BQU8sRUFBRSxRQUFRO1FBQzNCLEtBQUssQ0FDSCxnQkFBZ0IsRUFBRSxvQkFBb0I7UUFDdEMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsa0JBQWtCO1FBQ3BDLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxnQkFBZ0IsRUFBRSxvQkFBb0I7WUFDbEYsVUFBVSxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsa0JBQWtCLENBQUMsRUFBRSxrQkFBa0I7UUFDL0UsT0FBTyxFQUNQO1lBQ0UsUUFBUSxFQUFFLElBQUk7WUFDZCxLQUFLLEVBQUUsSUFBSTtZQUNYLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGtCQUFrQixFQUFFLElBQUk7WUFDeEIsZUFBZSxFQUFFLElBQUk7WUFFckIsUUFBUSxFQUFFLEtBQUs7WUFDZixNQUFNLEVBQUUsS0FBSztZQUNiLE1BQU0sRUFBRSxJQUFJO1lBQ1osb0JBQW9CLEVBQUUsZUFBZTtTQUN0QyxDQUNGLENBQUM7UUFFRixvREFBb0Q7UUFDcEQsa0RBQWtEO1FBQ2xELElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUU7WUFDakMsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixVQUFVLEVBQUUsZUFBZSxJQUFJLENBQUMsTUFBTSxxQkFBcUIsUUFBUSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksQ0FDckYsQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztRQUVsRCxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO1FBQ25ELElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUM7UUFFbkQsMEZBQTBGO1FBQzFGLHFGQUFxRjtRQUNyRiw0RkFBNEY7UUFDNUYsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtRQUN4RixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUVwRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRTNELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBRWxELElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO1FBRWpFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2xCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDbkIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2dCQUNsQixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7YUFDM0IsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUNiLElBQUksRUFBRSxJQUFJO1lBQ1YsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLENBQUMsRUFBQztZQUNyQixJQUFJLEVBQUUsSUFBSTtZQUNWLFlBQVksRUFBRTtnQkFDWixFQUFFLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDakU7U0FDRixFQUFFO1lBQ0QsV0FBVyxFQUFFLGdCQUFnQjtTQUM5QixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsSUFBSSxrQkFBa0I7UUFDcEIsT0FBTyxzQkFBc0IsQ0FBQztJQUNoQyxDQUFDO0lBRUQsSUFBSSwwQkFBMEI7UUFDNUIsT0FBTyw4QkFBOEIsQ0FBQztJQUN4QyxDQUFDO0lBRUQsZ0ZBQWdGO0lBRWhGOzs7Ozs7O09BT0c7SUFDSCw2QkFBNkIsQ0FBQyxLQUFLO1FBQ2pDLE1BQU0sWUFBWSxHQUFHLEtBQUssR0FBRyxVQUFVLENBQUM7UUFDeEMsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRztZQUNyQixLQUFLLEVBQUUsS0FBSztZQUNaLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN4QixNQUFNLEVBQUU7b0JBQ04sR0FBRyxFQUFFO3dCQUNILElBQUksRUFBRSxTQUFTO3FCQUNoQjtpQkFDRjthQUNGLENBQUMsQ0FBQyxDQUFDO2dCQUNGLElBQUksRUFBRSxRQUFRO2dCQUNkLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDeEIsTUFBTSxFQUFFO29CQUNOLEdBQUcsRUFBRTt3QkFDSCxJQUFJLEVBQUUsUUFBUTt3QkFDZCxLQUFLLEVBQUUsY0FBYztxQkFDdEI7aUJBQ0Y7YUFDRjtTQUNGLENBQUM7UUFDRixPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGdCQUFnQixDQUFDLElBQUk7UUFDbkIsNEZBQTRGO1FBQzVGLDRDQUE0QztRQUM1QyxrR0FBa0c7UUFDbEcscUZBQXFGO1FBQ3JGLE1BQU0sdUJBQXVCLEdBQUc7WUFDOUIsMEVBQTBFO1lBQzFFLEtBQUssRUFBRTtnQkFDTCxRQUFRLEVBQUU7b0JBQ1IsYUFBYSxFQUFFO3dCQUNiLG1CQUFtQixFQUFFOzRCQUNuQixJQUFJLEVBQUUsaUJBQWlCOzRCQUN2QixPQUFPLEVBQUUsZUFBZTs0QkFDeEIsV0FBVyxFQUFFLE9BQU87eUJBQ3JCO3dCQUNELDBCQUEwQixFQUFFOzRCQUMxQixJQUFJLEVBQUUsaUJBQWlCOzRCQUN2QixPQUFPLEVBQUUsR0FBRzs0QkFDWixXQUFXLEVBQUUsR0FBRzt5QkFDakI7cUJBQ0Y7b0JBQ0QsTUFBTSxFQUFFO3dCQUNOLHVCQUF1QixFQUFFOzRCQUN2QixJQUFJLEVBQUUsY0FBYzs0QkFDcEIsbUJBQW1CLEVBQUUsSUFBSTt5QkFDMUI7cUJBQ0Y7b0JBQ0QsUUFBUSxFQUFFO3dCQUNSLGFBQWEsRUFBRTs0QkFDYixTQUFTLEVBQUUsVUFBVTs0QkFDckIsYUFBYSxFQUFFO2dDQUNiLG1CQUFtQjtnQ0FDbkIsMEJBQTBCOzZCQUMzQjs0QkFDRCxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsRUFBRSxXQUFXLEVBQUUsTUFBTSxDQUFDO3lCQUN2RDtxQkFDRjtpQkFDRjthQUNGO1NBQ0YsQ0FBQztRQUVGLE1BQU0sZUFBZSxHQUFHO1lBQ3RCLElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7WUFDN0MsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO1NBQ3pCLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUU1QixJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDbkIsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7U0FDbEY7YUFBTSxFQUFFLFNBQVM7WUFDaEIsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1NBQzVFO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDekIseUJBQXlCO1lBQ3pCLGdCQUFnQixDQUFDLElBQUksQ0FDbkI7Z0JBQ0Usd0JBQXdCLEVBQUU7b0JBQ3hCLEtBQUssRUFBRSxHQUFHO29CQUNWLE9BQU8sRUFBRSxlQUFlO2lCQUN6QjthQUNGLENBQ0YsQ0FBQztTQUNIO2FBQU07WUFDTCx5REFBeUQ7WUFDekQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQzFDLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDcEIsUUFBUSxDQUFDLEtBQUssR0FBRyxjQUFjLENBQUMsR0FBRztvQkFDakMsS0FBSyxFQUFFLEtBQUs7b0JBQ1osT0FBTyxFQUFFLGVBQWU7aUJBQ3pCLENBQUM7Z0JBRUYsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1lBRUgsMkZBQTJGO1lBQzNGLGdCQUFnQixDQUFDLElBQUksQ0FDbkI7Z0JBQ0UsK0JBQStCLEVBQUU7b0JBQy9CLEtBQUssRUFBRSxHQUFHO29CQUNWLG9CQUFvQixFQUFFLFFBQVE7b0JBQzlCLE9BQU8sRUFBRSxlQUFlO2lCQUN6QjthQUNGLENBQ0YsQ0FBQztTQUNIO1FBRUQsTUFBTSxZQUFZLEdBQUc7WUFDbkIsVUFBVSxFQUFFLHVCQUF1QjtZQUNuQyxVQUFVLEVBQUU7Z0JBQ1YsV0FBVyxFQUFFO29CQUNYLG1CQUFtQixFQUFFLGdCQUFnQjtpQkFDdEM7YUFDRjtTQUNGLENBQUM7UUFFRiwwQ0FBMEM7UUFDMUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRztZQUM1QixNQUFNLEVBQUU7Z0JBQ04sSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUTtnQkFDN0MsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO2FBQ3pCO1NBQ0YsQ0FBQztRQUVGLE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7Ozs7OztPQU1HO0lBQ0gsU0FBUyxDQUFDLElBQUk7UUFDWixJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDbkIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQzVCO2FBQU07WUFDTCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDNUI7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsUUFBUSxDQUFDLElBQUk7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBRTtRQUNiLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFFBQVE7UUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsdUJBQXVCLENBQUMsSUFBSSxFQUFFLEdBQUc7UUFDL0IsSUFBSSxNQUFNLENBQUM7UUFDWCxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDbkIsTUFBTSxHQUFHLHFCQUFxQixDQUFDO1NBQ2hDO2FBQU07WUFDTCxNQUFNLEdBQUcsZUFBZSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxHQUFHLEVBQUU7WUFDUCxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7U0FDeEI7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQsZ0ZBQWdGO0lBRWhGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdDRztJQUNILEtBQUssQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLFdBQVc7UUFDekMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixPQUFPLEVBQUUsQ0FBQzthQUNYO1lBRUQsMkRBQTJEO1lBQzNELE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUVwQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7WUFDZCxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsRUFBRTtnQkFDaEMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ3BDLDREQUE0RDtvQkFDNUQsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQ3hEO2dCQUVELElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxpQkFBaUIsRUFBRTtvQkFDcEMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDcEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDbkIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNyQjtZQUVELElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksWUFBWSxFQUFFO2dCQUNoQixHQUFHLElBQUksR0FBRyxHQUFHLFlBQVksQ0FBQztnQkFDMUIsSUFBSSxXQUFXLEVBQUU7b0JBQ2YsR0FBRyxJQUFJLEdBQUcsR0FBRyxXQUFXLENBQUM7aUJBQzFCO2FBQ0Y7WUFDRCxHQUFHLElBQUksUUFBUSxDQUFDO1lBRWhCLDhDQUE4QztZQUM5QyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFFO2dCQUVyQyxNQUFNLE9BQU8sR0FBRyxFQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBQyxDQUFDO2dCQUM3QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3ZCLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLEVBQUUsQ0FBQztpQkFDOUQ7Z0JBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQzFELG1FQUFtRTtvQkFDbkUsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUN4Qyw2Q0FBNkM7Z0JBQzdDLE9BQU87b0JBQ0wsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7d0JBQ2pFLE9BQU8sTUFBTSxJQUFJLEtBQUssQ0FBQztvQkFDekIsQ0FBQyxFQUFFLEtBQUssQ0FBQztvQkFDVCxLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUMxRCxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILDhCQUE4QixDQUFDLFFBQVEsRUFBRSxJQUFJO1FBQzNDLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzFDLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDO1NBQ3JEO2FBQU0sRUFBRSxPQUFPO1lBQ2QsTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7U0FDekM7UUFFRCx5QkFBeUI7UUFDekIsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUVwQyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFNUIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUM1QyxrRkFBa0Y7Z0JBQ2xGLHFDQUFxQztnQkFDckMsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUNoQyxnREFBZ0Q7Z0JBQ2hELCtEQUErRDtnQkFDL0QsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDMUQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDekIsU0FBUzthQUNWO1lBRUQsSUFBSSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM3Qix1REFBdUQ7Z0JBQ3ZELDREQUE0RDtnQkFDNUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUNoQyxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO2dCQUNuRSxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQzFCO1NBQ0Y7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQsZ0ZBQWdGO0lBRWhGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCwwQkFBMEIsQ0FBQyxNQUFNLEVBQUUsU0FBUztRQUMxQyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDbkIsT0FBTyxDQUFDLENBQUM7U0FDVjthQUFNLElBQUksU0FBUyxJQUFJLEdBQUcsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQztTQUNmO2FBQU07WUFDTCxPQUFPLENBQUMsQ0FBQztTQUNWO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E2Q0c7SUFDSCxZQUFZLENBQUMsTUFBTSxFQUFFLGlCQUFpQixFQUFFLElBQUk7UUFDMUMsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0QsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hFLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO1lBQy9DLE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxNQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEMsNEJBQTRCO1lBQzVCLE1BQU0sTUFBTSxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDO1lBQzNCLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUMsQ0FBQztZQUMvRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztRQUVILDZFQUE2RTtRQUM3RSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRTtZQUVyQyxNQUFNLHVCQUF1QixHQUFHLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsaUJBQWlCLEVBQUMsRUFBQyxDQUFDLENBQUM7WUFFekYsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0JBQ3JFLDZEQUE2RDtnQkFDN0Qsc0ZBQXNGO2dCQUN0Riw2SEFBNkg7Z0JBQzdILHVCQUF1QixDQUFDLElBQUksQ0FBQztvQkFDM0IsSUFBSSxFQUFFO3dCQUNKLFVBQVUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxtQkFBbUIsRUFBQyxFQUFFO3FCQUNyRDtpQkFDRixDQUFDLENBQUM7YUFDSjtZQUVELFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLEVBQUUsRUFBQyxNQUFNLEVBQUUsdUJBQXVCLEVBQUMsRUFBQyxDQUFDLENBQUM7U0FDOUQ7UUFFRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHdCQUF3QixDQUFDLFFBQVE7UUFDL0IsSUFBSSxNQUFNLEdBQUcsaUNBQWlDLENBQUM7UUFDL0MsTUFBTSxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBRTdDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUUxRCxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNuQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsWUFBWTtRQUN6QixJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25FLE9BQU8sY0FBYyxDQUFDO1NBQ3ZCO2FBQU0sSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMxRSxPQUFPLFFBQVEsQ0FBQztTQUNqQjthQUFNLElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO1lBQ3RELE9BQU8sWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztTQUN6RTthQUFNLElBQUksSUFBSSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUM1RCxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDMUQ7YUFBTTtZQUNMLE9BQU8sWUFBWSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFdBQVcsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxRQUFRO1FBQy9DLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU3RixNQUFNLGNBQWMsR0FBRyxDQUFDLEVBQUMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUNwQix1RUFBdUU7WUFDdkUsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFDLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBQyxFQUFDLENBQUMsQ0FBQztTQUN4RTtRQUVELElBQUksYUFBYSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsY0FBYyxFQUFFO29CQUNkLE1BQU0sRUFBRSwwQkFBMEI7b0JBQ2xDLE9BQU8sRUFBRSxJQUFJO29CQUNiLEtBQUssRUFBRSxZQUFZO29CQUNuQixRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVM7aUJBQ3pCO2FBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNQLGFBQWEsRUFBRTtvQkFDYixNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUM7b0JBQ2IsT0FBTyxFQUFFLElBQUk7b0JBQ2IsS0FBSyxFQUFFLFlBQVk7b0JBQ25CLElBQUksRUFBRSxlQUFlO2lCQUN0QjthQUFDLEVBQUU7Z0JBQ0osYUFBYSxFQUFFO29CQUNiLE1BQU0sRUFBRSwwQkFBMEI7b0JBQ2xDLE9BQU8sRUFBRSxJQUFJO29CQUNiLEtBQUssRUFBRSxZQUFZO29CQUNuQixTQUFTLEVBQUUsWUFBWTtpQkFDeEI7YUFBQyxDQUFDLENBQUM7UUFFTixvQkFBb0I7UUFDcEIsK0JBQStCO1FBQy9CLCtCQUErQjtRQUMvQixrREFBa0Q7UUFDbEQsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDMUIsYUFBYSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUIsY0FBYyxFQUFFO3dCQUNkLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQzt3QkFDaEIsT0FBTyxFQUFFLElBQUk7d0JBQ2IsS0FBSyxFQUFFLFlBQVk7d0JBQ25CLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUztxQkFDekI7aUJBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDTixNQUFNO2dCQUNOLG1CQUFtQjtnQkFDbkIsd0dBQXdHO2dCQUN4RyxpREFBaUQ7Z0JBQ2pELHlCQUF5QjtnQkFDekIsMkJBQTJCO2dCQUMzQix5QkFBeUI7Z0JBQ3pCLE1BQU07Z0JBQ047b0JBQ0UsS0FBSyxFQUFFO3dCQUNMLElBQUksRUFBRTs0QkFDSixLQUFLLEVBQUUsWUFBWTs0QkFDbkIsU0FBUyxFQUFFLFlBQVk7NEJBQ3ZCLFFBQVEsRUFBRSxLQUFLO3lCQUNoQjtxQkFDRjtpQkFDRjthQUFDLENBQUM7U0FDTjtRQUVELE9BQU87WUFDTCxLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFO29CQUNKLHNCQUFzQixFQUFFLENBQUM7b0JBQ3pCLE1BQU0sRUFBRSxhQUFhO29CQUNyQixzREFBc0Q7b0JBQ3RELE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQztpQkFDM0U7YUFDRjtZQUNELHdCQUF3QjtZQUN4QixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLElBQUksRUFBRSxjQUFjO1lBQ3BCLE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQztJQUNKLENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEY7O09BRUc7SUFDSCxPQUFPO1FBQ0wsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEQsR0FBRyxDQUFDLElBQUksQ0FBQywwQ0FBMEMsR0FBRyxHQUFHLENBQUMsQ0FBQztZQUMzRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDekYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pCLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztZQUU3QyxJQUFJLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNoRSxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUNwQyxpQkFBaUIsT0FBTyxzQ0FBc0MsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN6RTtZQUVELElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM5Qyx3Q0FBd0M7Z0JBQ3hDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2FBQzVCO1lBRUQsT0FBTyxPQUFPLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPO1FBQ0wsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQ2pELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSw2QkFBNkIsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVk7UUFDVixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxFQUFDLEVBQUUsRUFBRSxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUMsRUFBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDdkYsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ2xELDJGQUEyRjtZQUMzRixPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2pELENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCw0QkFBNEIsQ0FBQyxTQUFTO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUNuRCxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBVSxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFRDs7T0FFRztJQUNILGVBQWU7UUFDYixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQzFDLE9BQU8sSUFBSSxDQUFDLDRCQUE0QixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN2QiwyRkFBMkY7WUFDM0YsOEJBQThCO1lBQzlCLElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCO2dCQUNoRixHQUFHLENBQUMsSUFBSSxDQUFDLGdFQUFnRTtvQkFDdkUsd0JBQXdCLENBQUMsQ0FBQzthQUM3QjtZQUVELE9BQU8sY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVk7UUFDVixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDMUMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUMzQyxFQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUM3RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPO1FBQ3ZCLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFFMUUsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6QyxNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsRUFBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBQyxFQUFDO1lBQ2hDLE1BQU0sRUFBRSxJQUFJLENBQUMsOEJBQThCLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztTQUN6RCxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzdCLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtnQkFDaEIsaUVBQWlFO2dCQUNqRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFDNUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDckQsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO29CQUNqQyx1R0FBdUc7b0JBQ3ZHLE1BQU0sS0FBSyxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7b0JBRS9DLElBQUksS0FBSyxDQUFDLElBQUksS0FBSywwQkFBMEI7d0JBQzNDLEtBQUssQ0FBQyxJQUFJLEtBQUssNEJBQTRCLEVBQUU7d0JBQzdDLHFFQUFxRTt3QkFDckUseUdBQXlHO3dCQUN6RyxNQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkQsbUlBQW1JO3dCQUVuSSx1QkFBdUI7d0JBQ3ZCLElBQUksUUFBUSxHQUFHLGtEQUFrRCxDQUFDO3dCQUVsRSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUU7NEJBQ2hDLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQ0FDNUMsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdEQsUUFBUSxHQUFHLGdCQUFnQixHQUFHLFlBQVksR0FBRyw4QkFBOEIsR0FBRyxJQUFJLENBQUM7NkJBQ3BGO2lDQUFNO2dDQUNMLFFBQVEsR0FBRyxnQkFBZ0IsR0FBRyxZQUFZLEdBQUcsMkJBQTJCLENBQUM7Z0NBQ3pFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7b0NBQ3BDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLEtBQUsseUJBQXlCLEVBQUU7b0NBQ3ZELFFBQVEsSUFBSSx1QkFBdUIsQ0FBQztpQ0FDckM7NkJBQ0Y7eUJBQ0Y7d0JBRUQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDL0Q7eUJBQU07d0JBQ0wsbUNBQW1DO3dCQUNuQyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLGtEQUFrRDs0QkFDcEYsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNsRTtpQkFDRjthQUNGO1lBRUQsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDbEQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTztRQUNMLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDcEYsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSwyQkFBMkIsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsUUFBUSxDQUFDLElBQUk7UUFDWCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUNqRCxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNkLElBQUksTUFBTSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7Z0JBQzdCLE9BQU8sQ0FBQyxDQUFDO2FBQ1Y7WUFFRCxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUM3QixtRUFBbUU7Z0JBQ25FLEdBQUcsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLElBQUkseUJBQXlCO29CQUMxRCx3Q0FBd0MsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7Z0JBQy9CLE9BQU8sQ0FBQyxDQUFDO2FBQ1Y7WUFFRCxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWSxDQUFDLElBQUksRUFBRSxLQUFLO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWSxDQUFDLEVBQUUsRUFBRSxJQUFJO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVEOztPQUVHO0lBQ0gsaUJBQWlCLENBQUMsSUFBSTtRQUNwQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRTtZQUNqRiw2QkFBNkI7WUFDN0IsTUFBTSxVQUFVLEdBQUcsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0UseURBQXlEO1lBQ3pELElBQUksUUFBUSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBRXZELDhCQUE4QjtZQUM5QixRQUFRLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDO1lBRXRFLG1FQUFtRTtZQUNuRSx3Q0FBd0M7WUFDeEMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN6RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVqQyw2Q0FBNkM7WUFDN0MsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUN0QyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLEVBQ3BDLEVBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBQyxFQUNoRSxDQUFDLEdBQUcsQ0FBQyxDQUNOLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN6QiwwREFBMEQ7YUFDM0Q7aUJBQU07Z0JBQ0wsb0NBQW9DO2dCQUNwQyxPQUFPLFNBQVMsQ0FBQzthQUNsQjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN2QixJQUFJLGNBQWMsRUFBRTtnQkFDbEIsT0FBTyxjQUFjLENBQUM7YUFDdkI7WUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLEVBQ3BDLEVBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBQyxFQUNqRSxDQUFDLEdBQUcsQ0FBQyxDQUNOLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2pCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNsQixTQUFTLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztZQUNqQyxPQUFPLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7U0FDL0MsQ0FBQyxDQUFDLENBQUM7SUFDTixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsVUFBVSxLQUFJLENBQUM7Q0FDaEI7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGlCQUFpQixDQUFDIn0=