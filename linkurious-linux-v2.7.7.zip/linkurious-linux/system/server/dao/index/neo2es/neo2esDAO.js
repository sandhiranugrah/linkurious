/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-06-22.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // fix with refactoring
// libraries
const Promise = require('bluebird');
const _ = require('lodash');
// imports
const AbstractElasticDAO = require('../abstractElasticDAO');
const LKE = require('../../../services/index');
const DaoUtils = require('../../utils/daoUtils');
// services
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
/**
 * Index DAO to communicate with an index generated bu the "neo4j-to-elasticsearch" plugin
 */
class N2ESPluginDAO extends AbstractElasticDAO {
    constructor(options, graphDao) {
        super('neo2es', [], ['simplifiedSearch'], options, {
            canCount: true,
            fuzzy: true,
            canIndexEdges: true,
            canIndexCategories: true,
            searchHitsCount: true,
            external: true,
            schema: true,
            typing: true,
            advancedQueryDialect: 'elasticsearch'
        });
        // check if graph vendor is neo4j
        if (graphDao.vendor !== 'neo4j') {
            throw Errors.technical('critical', `Cannot use "${this.vendor}" with Graph DAO "${graphDao.vendor}".`, true);
        }
        this._simplifiedSearch = options.simplifiedSearch;
        // Note: Neo2es is only for Neo4j > 3.0 (the plugin and the procedures were not available before)
        /**
         * @type {Neo4jDAO}
         */
        this.graph = graphDao;
    }
    /**
     * @inheritdoc
     */
    $nodeCategoriesField(raw) {
        return '_labels' + (raw ? '.raw' : '');
    }
    /**
     * @inheritdoc
     */
    $edgeTypeField(raw) {
        return '_relationship' + (raw ? '.raw' : '');
    }
    /**
     * @inheritdoc
     */
    connect() {
        // check that neo4j-to-elasticsearch and graphaware-server-community-all
        // are installed => they should be listed in Neo4j in classpath
        return this.graph.connector.$queryJmx('java.lang', 'type=Runtime', 'ClassPath')
            .then(config => {
            const gaFwkPlugin = /graphaware-server-community-all-(.*?)\.jar/g.exec(config);
            const neo2esPlugin = /graphaware-neo4j-to-elasticsearch-(.*?)\.jar/g.exec(config);
            if (Utils.noValue(gaFwkPlugin)) {
                Log.warn('The GraphAware framework does not seem to be installed.');
                return;
            }
            if (Utils.noValue(neo2esPlugin)) {
                Log.warn('The Neo4j plugin "neo4j-to-elasticsearch" does not seem to be installed.');
                return;
            }
            // Check versions
            const gaFwkVersion = gaFwkPlugin[1];
            const neo2esVersion = neo2esPlugin[1];
            if (neo2esVersion.toLowerCase().includes('snapshot')) {
                // It's safe to assume we gave them the plugin
                Log.warn('"neo4j-to-elasticsearch" SNAPSHOT plugin used: ' + neo2esPlugin[0]);
                return;
            }
            const neo2esMinVersion = '3.1.0.44.7';
            if (Utils.compareSemVer(neo2esVersion, neo2esMinVersion) < 0) {
                Log.warn('The version of Neo4j plugin "neo4j-to-elasticsearch" version ' + neo2esVersion +
                    ' must be above ' + neo2esMinVersion);
                return;
            }
            // We assume that the Neo2ES plugin is always based on the compatible GraphAware version
            if (!neo2esVersion.startsWith(gaFwkVersion)) {
                Log.warn('The Neo4j plugin "neo4j-to-elasticsearch" version ' + neo2esPlugin +
                    'is not compatible with the GraphAware framework version' + gaFwkVersion);
            }
            // check if neo2es plugin is installed
        }).then(() => this._esQuery('ga.es.initialized()', 'status')).catch(Errors.LkError, e => {
            if (e.key === 'bad_graph_request') {
                return Errors.business('index_unreachable', 'The Neo4j plugin "neo4j-to-elasticsearch" does not seem to be installed. ' +
                    'The procedures "ga.*" may not be whitelisted (bad_graph_request).', true);
            }
            return Promise.reject(e);
        }).then(initialized => {
            if (!initialized) {
                return Errors.business('index_unreachable', 'The Neo4j plugin "neo4j-to-elasticsearch" is not initialized.', true);
            }
            // get the current ES version
            return this._esQuery('ga.es.info()', 'json').then(json => global.JSON.parse(json)).then(info => {
                this._version = info.version.number;
                if (Utils.compareSemVer(this._version, '6.0.0') >= 0) {
                    return Errors.business('not_supported', 'ElasticSearch 6.x is not supported yet by Linkurious. Please use ElasticSearch 5.', true);
                }
                return this._version;
            });
        });
    }
    /**
     * @param {string} q
     * @param {string} valueName
     * @returns {Bluebird<Object|LkError>}
     * @private
     */
    _esQuery(q, valueName) {
        const query = 'CALL ' + q + ' YIELD ' + valueName + ' as r RETURN r';
        return this.graph.connector.$doCypherQuery(query).then(response => {
            return response.results[0].rows[0];
        });
    }
    _rawQuery(type, query) {
        const q = global.JSON.stringify(global.JSON.stringify(query));
        return this._esQuery('ga.es.query' + (type === 'node' ? 'Node' : 'Relationship') + 'Raw(' + q + ')', 'json').then(json => global.JSON.parse(json)).then(response => {
            if (response.error) {
                return Promise.reject(response.error);
            }
            return response;
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() { return Promise.resolve(); }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        return this._rawQuery(type, { size: 0 }).then(r => r.hits.total);
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this.$getSize('node').return(true).catch(e => false);
    }
    $resolveESType(itemType) {
        return itemType === 'node' ? 'node' : 'relationship';
    }
    $resolveESIndex(itemType) {
        return undefined;
    }
    _getSimpleSchema(itemType) {
        return this.graph.getSimpleSchema().then(simpleR => {
            const types = itemType === 'node' ? simpleR.nodeCategories : simpleR.edgeTypes;
            const properties = (itemType === 'node' ? simpleR.nodeProperties : simpleR.edgeProperties)
                .map(property => ({ key: property, count: 1 }));
            return types.map(type => ({ name: type, properties: properties, count: 1 }));
        });
    }
    /**
     * @inheritdoc
     */
    $getSchema(itemType) {
        // $getSchema used to fail due to a timeout error/heap size error because of the aggregation
        // We fallback to $getSimpleSchema done by Neo4j
        return super.$getSchema(itemType).then(schema => {
            if (schema.length <= 1) {
                Log.debug('Schema for ' + itemType + 's not available in ES, falling back to graph simple schema.');
                // No schema defined in ES for a given itemType. We fallback to the simple schema from Neo4j
                return this._getSimpleSchema(itemType);
            }
            return schema;
        }).catch(e => {
            Log.debug('$getSchema failed, falling back to graph simple schema', e);
            return this._getSimpleSchema(itemType);
        });
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        const failSafeSearchOptions = Utils.clone(options);
        return this._failSafeSearch(options.type, options.q, failSafeSearchOptions).then(result => {
            const ids = result.hits.hits.map(o => o._id);
            const totalHits = result.hits.total;
            return {
                type: options.type,
                totalHits: totalHits,
                results: ids
            };
        });
    }
    /**
     * @inheritdoc
     */
    $searchPromise(itemType, query) {
        const queryBody = query.body;
        queryBody.from = query.from;
        queryBody.size = query.size;
        queryBody.version = query.version;
        //console.log('QUERY: ' + JSON.stringify(queryBody, null, ' '))
        return this._rawQuery(itemType, queryBody);
    }
    /**
     * @inheritdoc
     */
    $getPropertyTypes(itemType) {
        const q = itemType === 'node'
            ? 'ga.es.nodeMapping()'
            : 'ga.es.relationshipMapping()';
        return this._esQuery(q, 'json').then(json => {
            const r = global.JSON.parse(json);
            const mapping = {};
            const excluded = itemType === 'node' ? this.$nodeCategoriesField() : this.$edgeTypeField();
            _.forEach(r.mappings[this.$resolveESType(itemType)].properties, (m, propertyKey) => {
                if (propertyKey === excluded) {
                    return;
                }
                mapping[propertyKey] = this.MAPPING_ES_TYPE[m.type];
            });
            return mapping;
        });
    }
    /**
     * Generate a nodeCategory or edgeType filter
     *
     * @param {string} type 'node' or 'edge'
     * @param {string[]} categoriesOrTypes include '[no_category]' for nodes with no categories
     * @returns {object} ES filter
     */
    $makeCategoriesOrTypesFilter(type, categoriesOrTypes) {
        // detect request to include 'no category/label' items
        // 'includeNone' can't happen for edges in Neo4j
        const includeNone = (type === 'node') &&
            _.includes(categoriesOrTypes, DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
        categoriesOrTypes = _.filter(categoriesOrTypes, term => {
            return term !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY;
        });
        const field = type === 'node' ? this.$nodeCategoriesField(true) : this.$edgeTypeField(true);
        if (includeNone) {
            return { or: [
                    { missing: { field: this.$nodeCategoriesField(true) } },
                    { terms: {
                            [field]: categoriesOrTypes,
                            execution: 'plain'
                        } }
                ] };
        }
        else {
            return { terms: {
                    [field]: categoriesOrTypes,
                    execution: 'plain'
                } };
        }
    }
    // not needed
    $addEntries() { }
    $commit() { }
    $upsertEntry() { }
    $deleteEntry() { }
    $deleteIfExists() { }
    $createIndex() { }
    $indexSource() { }
}
module.exports = N2ESPluginDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvMmVzREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9uZW8yZXMvbmVvMmVzREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsOEJBQThCLENBQUMsdUJBQXVCO0FBRXRELFlBQVk7QUFDWixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFVBQVU7QUFDVixNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQzVELE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBRS9DLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBRWpELFdBQVc7QUFDWCxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEM7O0dBRUc7QUFDSCxNQUFNLGFBQWMsU0FBUSxrQkFBa0I7SUFFNUMsWUFBWSxPQUFPLEVBQUUsUUFBUTtRQUMzQixLQUFLLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsT0FBTyxFQUFFO1lBQ2pELFFBQVEsRUFBRSxJQUFJO1lBQ2QsS0FBSyxFQUFFLElBQUk7WUFDWCxhQUFhLEVBQUUsSUFBSTtZQUNuQixrQkFBa0IsRUFBRSxJQUFJO1lBQ3hCLGVBQWUsRUFBRSxJQUFJO1lBRXJCLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLElBQUk7WUFDWixNQUFNLEVBQUUsSUFBSTtZQUNaLG9CQUFvQixFQUFFLGVBQWU7U0FDdEMsQ0FBQyxDQUFDO1FBRUgsaUNBQWlDO1FBQ2pDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxPQUFPLEVBQUU7WUFDL0IsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixVQUFVLEVBQUUsZUFBZSxJQUFJLENBQUMsTUFBTSxxQkFBcUIsUUFBUSxDQUFDLE1BQU0sSUFBSSxFQUFFLElBQUksQ0FDckYsQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztRQUVsRCxpR0FBaUc7UUFFakc7O1dBRUc7UUFDSCxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztJQUN4QixDQUFDO0lBRUQ7O09BRUc7SUFDSCxvQkFBb0IsQ0FBQyxHQUFHO1FBQ3RCLE9BQU8sU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7T0FFRztJQUNILGNBQWMsQ0FBQyxHQUFHO1FBQ2hCLE9BQU8sZUFBZSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCx3RUFBd0U7UUFDeEUsK0RBQStEO1FBQy9ELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxjQUFjLEVBQUUsV0FBVyxDQUFDO2FBQzVFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUViLE1BQU0sV0FBVyxHQUFHLDZDQUE2QyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvRSxNQUFNLFlBQVksR0FBRywrQ0FBK0MsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFbEYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUM5QixHQUFHLENBQUMsSUFBSSxDQUFDLHlEQUF5RCxDQUFDLENBQUM7Z0JBQ3BFLE9BQU87YUFDUjtZQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDL0IsR0FBRyxDQUFDLElBQUksQ0FBQywwRUFBMEUsQ0FBQyxDQUFDO2dCQUNyRixPQUFPO2FBQ1I7WUFFRCxpQkFBaUI7WUFDakIsTUFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sYUFBYSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV0QyxJQUFJLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ3BELDhDQUE4QztnQkFDOUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpREFBaUQsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUUsT0FBTzthQUNSO1lBRUQsTUFBTSxnQkFBZ0IsR0FBRyxZQUFZLENBQUM7WUFFdEMsSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDNUQsR0FBRyxDQUFDLElBQUksQ0FBQywrREFBK0QsR0FBRyxhQUFhO29CQUN0RixpQkFBaUIsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUN4QyxPQUFPO2FBQ1I7WUFFRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQzNDLEdBQUcsQ0FBQyxJQUFJLENBQUMsb0RBQW9ELEdBQUcsWUFBWTtvQkFDMUUseURBQXlELEdBQUcsWUFBWSxDQUFDLENBQUM7YUFDN0U7WUFFRCxzQ0FBc0M7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRTtZQUN0RixJQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssbUJBQW1CLEVBQUU7Z0JBQ2pDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLDJFQUEyRTtvQkFDM0UsbUVBQW1FLEVBQ25FLElBQUksQ0FDTCxDQUFDO2FBQ0g7WUFDRCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BCLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQ2hCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLCtEQUErRCxFQUMvRCxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBRUQsNkJBQTZCO1lBQzdCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUMvQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUNoQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDWixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUVwQyxJQUFJLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3BELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLG1GQUFtRixFQUNuRixJQUFJLENBQ0wsQ0FBQztpQkFDSDtnQkFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDdkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFFBQVEsQ0FBQyxDQUFDLEVBQUUsU0FBUztRQUNuQixNQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsQ0FBQyxHQUFHLFNBQVMsR0FBRyxTQUFTLEdBQUcsZ0JBQWdCLENBQUM7UUFFckUsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hFLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLO1FBQ25CLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDOUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUNsQixhQUFhLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sQ0FDdkYsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN0RCxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUU7Z0JBQ2xCLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdkM7WUFDRCxPQUFPLFFBQVEsQ0FBQztRQUNsQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sS0FBSyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFdkM7O09BRUc7SUFDSCxRQUFRLENBQUMsSUFBSTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVk7UUFDVixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCxjQUFjLENBQUMsUUFBUTtRQUNyQixPQUFPLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO0lBQ3ZELENBQUM7SUFFRCxlQUFlLENBQUMsUUFBUTtRQUN0QixPQUFPLFNBQVMsQ0FBQztJQUNuQixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsUUFBUTtRQUN2QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2pELE1BQU0sS0FBSyxHQUFHLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFFL0UsTUFBTSxVQUFVLEdBQUcsQ0FBQyxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO2lCQUN2RixHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWhELE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztRQUM3RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFVBQVUsQ0FBQyxRQUFRO1FBQ2pCLDRGQUE0RjtRQUM1RixnREFBZ0Q7UUFDaEQsT0FBTyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUM5QyxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO2dCQUN0QixHQUFHLENBQUMsS0FBSyxDQUNQLGFBQWEsR0FBRyxRQUFRLEdBQUcsNkRBQTZELENBQ3pGLENBQUM7Z0JBRUYsNEZBQTRGO2dCQUM1RixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUN4QztZQUVELE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNYLEdBQUcsQ0FBQyxLQUFLLENBQUMsd0RBQXdELEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFdkUsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPLENBQUMsT0FBTztRQUNiLE1BQU0scUJBQXFCLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLHFCQUFxQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3hGLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QyxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUVwQyxPQUFPO2dCQUNMLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLE9BQU8sRUFBRSxHQUFHO2FBQ2IsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxLQUFLO1FBQzVCLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDN0IsU0FBUyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQzVCLFNBQVMsQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUM1QixTQUFTLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFFbEMsK0RBQStEO1FBRS9ELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsaUJBQWlCLENBQUMsUUFBUTtRQUN4QixNQUFNLENBQUMsR0FBRyxRQUFRLEtBQUssTUFBTTtZQUMzQixDQUFDLENBQUMscUJBQXFCO1lBQ3ZCLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQztRQUNsQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMxQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxNQUFNLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbkIsTUFBTSxRQUFRLEdBQUcsUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUMzRixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRTtnQkFDakYsSUFBSSxXQUFXLEtBQUssUUFBUSxFQUFFO29CQUFFLE9BQU87aUJBQUU7Z0JBQ3pDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILDRCQUE0QixDQUFDLElBQUksRUFBRSxpQkFBaUI7UUFDbEQsc0RBQXNEO1FBQ3RELGdEQUFnRDtRQUNoRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUM7WUFDbkMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLENBQUMsNEJBQTRCLENBQUMsQ0FBQztRQUV2RSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ3JELE9BQU8sSUFBSSxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztRQUVILE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1RixJQUFJLFdBQVcsRUFBRTtZQUNmLE9BQU8sRUFBQyxFQUFFLEVBQUU7b0JBQ1YsRUFBQyxPQUFPLEVBQUUsRUFBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUFDLEVBQUM7b0JBQ25ELEVBQUMsS0FBSyxFQUFFOzRCQUNOLENBQUMsS0FBSyxDQUFDLEVBQUUsaUJBQWlCOzRCQUMxQixTQUFTLEVBQUUsT0FBTzt5QkFDbkIsRUFBQztpQkFDSCxFQUFDLENBQUM7U0FDSjthQUFNO1lBQ0wsT0FBTyxFQUFDLEtBQUssRUFBRTtvQkFDYixDQUFDLEtBQUssQ0FBQyxFQUFFLGlCQUFpQjtvQkFDMUIsU0FBUyxFQUFFLE9BQU87aUJBQ25CLEVBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQztJQUVELGFBQWE7SUFFYixXQUFXLEtBQUksQ0FBQztJQUNoQixPQUFPLEtBQUksQ0FBQztJQUNaLFlBQVksS0FBSSxDQUFDO0lBQ2pCLFlBQVksS0FBSSxDQUFDO0lBQ2pCLGVBQWUsS0FBSSxDQUFDO0lBQ3BCLFlBQVksS0FBSSxDQUFDO0lBQ2pCLFlBQVksS0FBSSxDQUFDO0NBQ2xCO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMifQ==