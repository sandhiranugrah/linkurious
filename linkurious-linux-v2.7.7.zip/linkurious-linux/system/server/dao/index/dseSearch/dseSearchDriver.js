/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../../services/index');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
// locals
const GremlinSearchDriver = require('../gremlinSearchDriver');
const DseUtils = require('../../utils/dseUtils');
const DaoUtils = require('../../utils/daoUtils');
const GremlinUtils = require('../../utils/gremlinUtils');
const StringUtils = require('../../../../lib/StringUtils').StringUtils;
class DseSearchDriver extends GremlinSearchDriver {
    /**
     * @param {GremlinConnector} connector     Connector used by the DAO
     * @param {GraphDAO}         graphDAO      The connected Graph DAO
     * @param {any}              indexOptions  IndexDAO options
     * @param {any}              connectorData Data from the connector
     * @param {IndexFeatures}    indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this._schemaInfo = {
            propertyTypes: {},
            nodeSchema: {},
            edgeSchema: {},
            searchIndices: {},
            indexedProperties: []
        };
    }
    /**
     * Build the query for $search.
     * - Return undefined if the search query could not be built e.g: Illegal `searchString`
     *
     * @param {string} type         'node' or 'edge'
     * @param {string} searchString Query that will be forwarded to the index. It may be either
     *                              plain text or formatted in a supported query language
     * @param {SearchOptions}       options
     * @returns {Bluebird<string | undefined>}
     */
    $buildSearchQuery(type, searchString, options) {
        return Promise.resolve().then(() => {
            const subQueries = [];
            let fuzzy;
            if (options.fuzziness === 0) {
                fuzzy = 0;
            }
            else if (options.fuzziness <= 0.4) {
                fuzzy = 1;
            }
            else {
                fuzzy = 2;
            }
            let tokens = StringUtils.uniqTokenize(searchString);
            // for asString search indices we use the whole escaped string
            const escapedSearchString = tokens.join(' ');
            // for asText search indices, we use only tokens of a given size
            tokens = _.filter(tokens, token => token.length >= 3);
            const indexedLabel = _.keys(this._schemaInfo.searchIndices).sort();
            for (let i = 0; i < indexedLabel.length; i++) {
                const labelName = indexedLabel[i];
                if (Utils.hasValue(options.categoriesOrTypes) &&
                    !options.categoriesOrTypes.includes(labelName)) {
                    continue; // we skip this label name if it doesn't appear in options.categoriesOrTypes
                }
                const propertyKeys = _.keys(this._schemaInfo.searchIndices[labelName]).sort();
                // `propertyKeys` are the properties indexed with a search index for the label `labelName`
                for (let y = 0; y < propertyKeys.length; y++) {
                    const propertyKey = propertyKeys[y];
                    const indexType = this._schemaInfo.searchIndices[labelName][propertyKey];
                    if (indexType === 'string') {
                        subQueries.push(`g.V().hasLabel('${labelName}').has('${propertyKey}',
            fuzzy('${escapedSearchString}', ${fuzzy ? 2 : 0}))`);
                    }
                    else {
                        for (let z = 0; z < tokens.length; z++) {
                            const token = tokens[z];
                            subQueries.push(`g.V().hasLabel('${labelName}').has('${propertyKey}',
              tokenFuzzy('${token}', ${fuzzy ? 2 : 0}))`);
                        }
                    }
                }
            }
            let sFilters;
            if (Utils.hasValue(options.filter)) {
                sFilters = GremlinUtils.quote(options.filter);
            }
            else {
                sFilters = 'null';
            }
            let sCategories;
            if (Utils.hasValue(options.categoriesOrTypes)) {
                sCategories = GremlinUtils.quote(_.filter(options.categoriesOrTypes, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY));
            }
            else {
                sCategories = 'null';
            }
            return `
      queries = [
        ${subQueries.join(',')}
      ];
      
      search(queries, ${options.from}, ${options.size}, ${sFilters}, ${sCategories});
    `;
        });
    }
    /**
     * Refresh the schema info cached in the driver.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _refreshSchema() {
        return this.connector.$doGremlinQuery('schema.describe();').get('0').then(describeR => {
            this._schemaInfo = DseUtils.parseSchemaInfo(describeR);
        });
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return super.$onAfterConnect().then(() => this._refreshSchema());
    }
    /**
     * Called at the end of the indexation phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterIndexation() {
        return this._refreshSchema();
    }
    /**
     * Get the type of the properties of nodes and edges.
     * Return an object with the property names as keys and the type of those properties as values.
     *
     * Possible returned type values are:
     * - string
     * - integer
     * - float
     * - boolean
     * - date
     *
     * @returns {Bluebird<object>}
     */
    $getPropertyTypes() {
        return Promise.resolve(this._schemaInfo.propertyTypes);
    }
    /**
     * Resolve if there exist indices for search.
     *
     * @returns {Bluebird<void>}
     */
    $checkSearchIndices() {
        return Promise.resolve().then(() => {
            if (Object.keys(this._schemaInfo.searchIndices).length === 0 &&
                !this.getIndexOption('disableIndexExistCheck')) {
                return Errors.business('source_action_needed', 'No search index found in DSE.', true);
            }
        });
    }
}
module.exports = DseSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlU2VhcmNoRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9kc2VTZWFyY2gvZHNlU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sbUJBQW1CLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDOUQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDakQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDakQsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDekQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLDZCQUE2QixDQUFDLENBQUMsV0FBVyxDQUFDO0FBRXZFLE1BQU0sZUFBZ0IsU0FBUSxtQkFBbUI7SUFFL0M7Ozs7OztPQU1HO0lBQ0gsWUFBWSxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYTtRQUN6RSxLQUFLLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXZFLElBQUksQ0FBQyxXQUFXLEdBQUc7WUFDakIsYUFBYSxFQUFFLEVBQUU7WUFDakIsVUFBVSxFQUFFLEVBQUU7WUFDZCxVQUFVLEVBQUUsRUFBRTtZQUNkLGFBQWEsRUFBRSxFQUFFO1lBQ2pCLGlCQUFpQixFQUFFLEVBQUU7U0FDdEIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU87UUFDM0MsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxNQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7WUFDdEIsSUFBSSxLQUFLLENBQUM7WUFFVixJQUFJLE9BQU8sQ0FBQyxTQUFTLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixLQUFLLEdBQUcsQ0FBQyxDQUFDO2FBQ1g7aUJBQU0sSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLEdBQUcsRUFBRTtnQkFDbkMsS0FBSyxHQUFHLENBQUMsQ0FBQzthQUNYO2lCQUFNO2dCQUNMLEtBQUssR0FBRyxDQUFDLENBQUM7YUFDWDtZQUVELElBQUksTUFBTSxHQUFHLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQsOERBQThEO1lBQzlELE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUU3QyxnRUFBZ0U7WUFDaEUsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztZQUV0RCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFbkUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzVDLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFbEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQztvQkFDM0MsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO29CQUNoRCxTQUFTLENBQUMsNEVBQTRFO2lCQUN2RjtnQkFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQzlFLDBGQUEwRjtnQkFFMUYsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzVDLE1BQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDcEMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBRXpFLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTt3QkFDMUIsVUFBVSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsU0FBUyxXQUFXLFdBQVc7cUJBQ3pELG1CQUFtQixNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN0RDt5QkFBTTt3QkFDTCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs0QkFDdEMsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUN4QixVQUFVLENBQUMsSUFBSSxDQUFDLG1CQUFtQixTQUFTLFdBQVcsV0FBVzs0QkFDcEQsS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUM3QztxQkFDRjtpQkFDRjthQUNGO1lBRUQsSUFBSSxRQUFRLENBQUM7WUFFYixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNsQyxRQUFRLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDL0M7aUJBQU07Z0JBQ0wsUUFBUSxHQUFHLE1BQU0sQ0FBQzthQUNuQjtZQUVELElBQUksV0FBVyxDQUFDO1lBRWhCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDN0MsV0FBVyxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUN0RixDQUFDO2FBQ0g7aUJBQU07Z0JBQ0wsV0FBVyxHQUFHLE1BQU0sQ0FBQzthQUN0QjtZQUVELE9BQU87O1VBRUgsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozt3QkFHTixPQUFPLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxLQUFLLFdBQVc7S0FDN0UsQ0FBQztRQUNGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYztRQUNaLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGtCQUFrQjtRQUNoQixPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsaUJBQWlCO1FBQ2YsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxtQkFBbUI7UUFDakIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztnQkFDeEQsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLEVBQzlDO2dCQUNBLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSwrQkFBK0IsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN2RjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUMifQ==