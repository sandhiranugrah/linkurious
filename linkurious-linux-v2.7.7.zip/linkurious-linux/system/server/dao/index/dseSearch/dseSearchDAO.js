/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const DseConnector = require('../../connector/dseConnector');
const DseSearchDriver = require('./dseSearchDriver');
class DseSearchDAO extends IndexDAO {
    constructor(options, graphDao) {
        super('dseSearch', [], ['disableIndexExistCheck'], // for tests only
        options, {
            fuzzy: true,
            external: true,
            canCount: false,
            typing: true,
            schema: false,
            canIndexEdges: false,
            canIndexCategories: false,
            searchHitsCount: false
        }, graphDao, DseConnector, [
            // Note: we are talking about gremlin versions
            { version: '3.2.6', driver: '[latest]' },
            { version: '3.2.6', driver: DseSearchDriver }
            // We explicitly don't support DSE 5.0.x because it doesn't support fuzzy search
        ], ['dse']);
    }
}
module.exports = DseSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlU2VhcmNoREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9kc2VTZWFyY2gvZHNlU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUM3RCxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUVyRCxNQUFNLFlBQWEsU0FBUSxRQUFRO0lBQ2pDLFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUFDLFdBQVcsRUFDZixFQUFFLEVBQ0YsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLGlCQUFpQjtRQUM3QyxPQUFPLEVBQUU7WUFDUCxLQUFLLEVBQUUsSUFBSTtZQUNYLFFBQVEsRUFBRSxJQUFJO1lBQ2QsUUFBUSxFQUFFLEtBQUs7WUFDZixNQUFNLEVBQUUsSUFBSTtZQUNaLE1BQU0sRUFBRSxLQUFLO1lBQ2IsYUFBYSxFQUFFLEtBQUs7WUFDcEIsa0JBQWtCLEVBQUUsS0FBSztZQUN6QixlQUFlLEVBQUUsS0FBSztTQUN2QixFQUNELFFBQVEsRUFDUixZQUFZLEVBQ1o7WUFDRSw4Q0FBOEM7WUFDOUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUM7WUFDdEMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxlQUFlLEVBQUM7WUFDM0MsZ0ZBQWdGO1NBQ2pGLEVBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FDUixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUMifQ==