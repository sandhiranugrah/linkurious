/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-11.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const AzureSearchConnector = require('../../connector/azureSearchConnector');
const AzureSearchDriver = require('./azureSearchDriver');
class AzureSearchDAO extends IndexDAO {
    constructor(options, graphDao) {
        super('azureSearch', ['url', 'apiKey', 'nodeIndexName'], ['url', 'apiKey', 'nodeIndexName', 'edgeIndexName'], options, {
            fuzzy: true,
            external: true,
            canCount: true,
            typing: false,
            schema: false,
            canIndexEdges: true,
            canIndexCategories: true,
            searchHitsCount: true
        }, graphDao, AzureSearchConnector, [
            // The API version of the azure search service has the format: YYYY-MM-DD
            // We use a semVer compatible version format
            { version: '2017.11.11', driver: '[latest]' },
            { version: '2017.11.11', driver: AzureSearchDriver }
        ], ['cosmosDb']);
    }
}
module.exports = AzureSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2F6dXJlU2VhcmNoL2F6dXJlU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO0FBQzdFLE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFFekQsTUFBTSxjQUFlLFNBQVEsUUFBUTtJQUNuQyxZQUFZLE9BQU8sRUFBRSxRQUFRO1FBQzNCLEtBQUssQ0FBQyxhQUFhLEVBQ2pCLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxlQUFlLENBQUMsRUFDbEMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLGVBQWUsRUFBRSxlQUFlLENBQUMsRUFDbkQsT0FBTyxFQUFFO1lBQ1AsS0FBSyxFQUFFLElBQUk7WUFDWCxRQUFRLEVBQUUsSUFBSTtZQUNkLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLEtBQUs7WUFDYixNQUFNLEVBQUUsS0FBSztZQUNiLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGtCQUFrQixFQUFFLElBQUk7WUFDeEIsZUFBZSxFQUFFLElBQUk7U0FDdEIsRUFDRCxRQUFRLEVBQ1Isb0JBQW9CLEVBQ3BCO1lBQ0UseUVBQXlFO1lBQ3pFLDRDQUE0QztZQUM1QyxFQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUMzQyxFQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixFQUFDO1NBQ25ELEVBQ0QsQ0FBQyxVQUFVLENBQUMsQ0FDYixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMifQ==