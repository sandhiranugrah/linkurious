/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-11.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// services
const LKE = require('../../../services/index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const IndexDriver = require('../indexDriver');
const DaoUtils = require('../../utils/daoUtils');
class AzureSearchDriver extends IndexDriver {
    /**
     * Index Driver constructor
     *
     * @param {Connector}     connector     Connector used by the DAO
     * @param {GraphDAO}      graphDAO      The connected Graph DAO
     * @param {any}           indexOptions  IndexDAO options
     * @param {any}           connectorData Data from the connector
     * @param {IndexFeatures} indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this._nodeIndexName = this.getIndexOption('nodeIndexName');
        this._edgeIndexName = this.getIndexOption('edgeIndexName');
        if (Utils.noValue(this._edgeIndexName)) {
            this.indexFeatures.canIndexEdges = false;
        }
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * Optional to implement.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return this._checkIndexes();
    }
    /**
     * Get the number of nodes or edges in the search index.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {Bluebird<number>}
     */
    $getSize(type) {
        if (type === 'node') {
            return this.connector.getCount(this._nodeIndexName);
        }
        if (Utils.hasValue(this._edgeIndexName)) {
            return this.connector.getCount(this._edgeIndexName);
        }
        return Promise.resolve(0);
    }
    /**
     * Check that Node and Edge indices exist.
     * Check that the fields `id` and `label` (required by LKE) are retrievable on each index.
     *
     * @returns {Bluebird<void>}
     * @throws {LkError} If an index doesn't exist or does not have the required fields
     */
    _checkIndexes() {
        const requiredFields = ['label'];
        // The index should be capable to filter by node category/edge type
        return this._getFilterableProperties(this._nodeIndexName, requiredFields).then(filterable => {
            this._filterableNodeProperties = filterable;
            if (Utils.hasValue(this._edgeIndexName)) {
                return this._getFilterableProperties(this._edgeIndexName, requiredFields)
                    .then(filterable => { this._filterableEdgeProperties = filterable; });
            }
        });
    }
    /**
     * Get the list of filterable properties from the index.
     * This method rejects if the list of `requiredFields` are not filterable
     *
     * @param {string}   indexName
     * @param {string[]} [requiredFields]
     * @returns {Bluebird<string[]>} the list of filterable properties
     * @private
     */
    _getFilterableProperties(indexName, requiredFields = []) {
        return this.connector.findIndex(indexName).then(index => {
            const indexFilters = _.map(_.filter(index.fields, 'filterable'), 'name');
            for (const field of requiredFields) {
                if (!indexFilters.includes(field)) {
                    return Errors.business('source_action_needed', `The field "${field}"` +
                        `should be filterable on the index "${indexName}"`, true);
                }
            }
            return indexFilters;
        });
    }
    /**
     * Generate an Azure Search Filter query.
     * Return undefined if there is nothing to filter.
     *
     * @param {SearchOptions} options
     * @param {string[]}      filterableProperties
     * @returns {string | undefined}
     * @private
     */
    _generateFilterQuery(options, filterableProperties) {
        const filterClauses = [];
        if (Utils.hasValue(options.categoriesOrTypes)) {
            filterClauses.push(`search.in(label, '${options.categoriesOrTypes}')`);
        }
        if (Utils.hasValue(options.filter)) {
            _.forEach(options.filter, ([key, value]) => {
                if (filterableProperties.includes(key)) {
                    filterClauses.push(`search.ismatch('${value}', '${key}')`);
                }
            });
        }
        if (filterClauses.length > 0) {
            return filterClauses.join(' and ');
        }
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Search results are grouped by categories or types.
     *
     * Some DAOs can't compute `totalHits` cheaply. As an alternative, `moreResults` is returned.
     * Which one is returned is defined by features.searchHitsCount.
     *
     * Support an eventual advanced query dialect if features.advancedQueryDialect is defined.
     * Detecting if it's an advanced query or a text query is up to the implementation.
     *
     * Support options.fuzziness only if features.fuzzy is true.
     *
     * Support edge entries only if features.canIndexEdges is true.
     *
     * Match the search query on categories fields only if features.canIndexCategories is true.
     *
     * @param {SearchOptions} options
     * @returns {Bluebird<SearchResponse>}
     */
    $search(options) {
        const luceneQuery = DaoUtils.generateLuceneQuery(options.q, options.fuzziness, {});
        const noSearchQuery = luceneQuery.trim().length === 0;
        const noReadableType = Utils.hasValue(options.categoriesOrTypes) &&
            options.categoriesOrTypes.length === 0;
        if (noSearchQuery || noReadableType) {
            return Promise.resolve({
                type: options.type,
                results: []
            });
        }
        const index = options.type === 'node' ? this._nodeIndexName : this._edgeIndexName;
        const filterableProperties = options.type === 'node'
            ? this._filterableNodeProperties
            : this._filterableEdgeProperties;
        return this.connector.doFullTextSearch(index, {
            luceneQuery: luceneQuery,
            filterQuery: this._generateFilterQuery(options, filterableProperties),
            from: options.from,
            size: options.size
        }).then(searchResults => ({
            type: options.type,
            totalHits: searchResults['@odata.count'],
            results: _.map(searchResults.value, 'id')
        }));
    }
}
module.exports = AzureSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2F6dXJlU2VhcmNoL2F6dXJlU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBRWpELE1BQU0saUJBQWtCLFNBQVEsV0FBVztJQUN6Qzs7Ozs7Ozs7T0FRRztJQUNILFlBQVksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWE7UUFDekUsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzNELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDdEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1NBQzFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxRQUFRLENBQUMsSUFBSTtRQUNYLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNyRDtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDdkMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7U0FDckQ7UUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGFBQWE7UUFDWCxNQUFNLGNBQWMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2pDLG1FQUFtRTtRQUNuRSxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMxRixJQUFJLENBQUMseUJBQXlCLEdBQUcsVUFBVSxDQUFDO1lBRTVDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQ3ZDLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsY0FBYyxDQUFDO3FCQUN0RSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMseUJBQXlCLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDekU7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILHdCQUF3QixDQUFDLFNBQVMsRUFBRSxjQUFjLEdBQUcsRUFBRTtRQUNyRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUN0RCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUV6RSxLQUFLLE1BQU0sS0FBSyxJQUFJLGNBQWMsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2pDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSxjQUFjLEtBQUssR0FBRzt3QkFDbkUsc0NBQXNDLFNBQVMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUM3RDthQUNGO1lBRUQsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsb0JBQW9CO1FBQ2hELE1BQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUV6QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7WUFDN0MsYUFBYSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsT0FBTyxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQztTQUN4RTtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRTtnQkFDekMsSUFBSSxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3RDLGFBQWEsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEtBQUssT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDO2lCQUM1RDtZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxJQUFJLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzVCLE9BQU8sYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNwQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0JHO0lBQ0gsT0FBTyxDQUFDLE9BQU87UUFDYixNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25GLE1BQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1FBQ3RELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzlELE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1FBRXpDLElBQUksYUFBYSxJQUFJLGNBQWMsRUFBRTtZQUNuQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7Z0JBQ3JCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsT0FBTyxFQUFFLEVBQUU7YUFDWixDQUFDLENBQUM7U0FDSjtRQUVELE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBQ2xGLE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNO1lBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMseUJBQXlCO1lBQ2hDLENBQUMsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUM7UUFFbkMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRTtZQUM1QyxXQUFXLEVBQUUsV0FBVztZQUN4QixXQUFXLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQztZQUNyRSxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1NBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUN2QjtZQUNFLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNsQixTQUFTLEVBQUUsYUFBYSxDQUFDLGNBQWMsQ0FBQztZQUN4QyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztTQUMxQyxDQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUMifQ==