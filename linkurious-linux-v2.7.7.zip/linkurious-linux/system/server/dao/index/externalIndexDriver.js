"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-07.
 */
// external libs
const Bluebird = require("bluebird");
// locals
const IndexDriver = require("./indexDriver");
class ExternalIndexDriver extends IndexDriver {
    $deleteEntry(id, type) {
        return Bluebird.resolve();
    }
    $upsertEntry(type, entry) {
        return Bluebird.resolve();
    }
    $deleteIfExists() {
        return Bluebird.resolve();
    }
    $createIndex() {
        return Bluebird.resolve();
    }
    $addEntries(type, entries) {
        return Bluebird.resolve();
    }
    $commit() {
        return Bluebird.resolve();
    }
}
module.exports = ExternalIndexDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXh0ZXJuYWxJbmRleERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvZXh0ZXJuYWxJbmRleERyaXZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSCxnQkFBZ0I7QUFDaEIscUNBQXFDO0FBRXJDLFNBQVM7QUFDVCw2Q0FBOEM7QUFFOUMsTUFBZSxtQkFBeUMsU0FBUSxXQUFjO0lBQ3JFLFlBQVksQ0FBQyxFQUFVLEVBQUUsSUFBYztRQUM1QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sWUFBWSxDQUFDLElBQWMsRUFBRSxLQUFzQjtRQUN4RCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sZUFBZTtRQUNwQixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sWUFBWTtRQUNqQixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sV0FBVyxDQUFDLElBQWMsRUFBRSxPQUE0QjtRQUM3RCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sT0FBTztRQUNaLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzVCLENBQUM7Q0FDRjtBQUVELGlCQUFTLG1CQUFtQixDQUFDIn0=