/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-07-28.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // fix with refactoring
// libraries
const _ = require('lodash');
const Promise = require('bluebird');
// imports
const DAO = require('../DAO');
const IndexDAO = require('./indexDAO');
const LKE = require('../../services');
// services
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const DaoUtils = require('../utils/daoUtils');
const DEFAULT_PAGE_SIZE = 20;
// constants
const ADVANCED_QUERY_RE = /(\sAND\s|\s\|\|\s|\s&&\s|\sOR\s|>|<|\[|:|\s\+|\s-)/;
// Heuristic: 'name', 'title' and 'lk_categories' are more important than other fields for nodes
const FIELD_BOOST_NODE = { _all: 1, name: 3, title: 3, '[categories]': 5 };
let FIELD_BOOST_NODE_ARRAY = null;
// Heuristic: 'name', 'title' and 'lk_type' are more important than other fields for edges
const FIELD_BOOST_EDGE = { _all: 1, name: 3, title: 3, '[type]': 5 };
let FIELD_BOOST_EDGE_ARRAY = null;
const DISPLAY_NAME_PROPERTIES_HEURISTIC = _.flatten(_.map(['name', 'title', 'label', 'caption', 'rdfs:label'], e => [e, _.capitalize(e), e.toUpperCase()]));
const BAD_SORT_COLUMN_RE = new RegExp('No mapping found for \\[([^\\]]+)\\] in order to sort on');
const BAD_QUERY_MAPPING_RE = new RegExp('NumberFormatException\\[(.+?")\\];');
const UNDERSCORE_REPLACEMENT_CHAR = '\u0332';
const ES_META_FIELDS = [
    '_index', '_uid', '_type',
    '_id', '_source', '_size',
    '_all', '_field_names', '_ignored',
    '_routing', '_meta'
];
const ES_META_FIELDS_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f, f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR)]));
const ES_META_FIELDS_REVERSE_MAPPING = new Map(ES_META_FIELDS
    .map(f => [f.replace(/[_]/, UNDERSCORE_REPLACEMENT_CHAR), f]));
/**
 * Abstract ElasticSearch Index DAO
 */
class AbstractElasticDAO extends IndexDAO {
    constructor(vendor, requiredOptions, availableOptions, options, features) {
        super(vendor, requiredOptions, availableOptions, options, features);
        this._simplifiedSearch = false;
    }
    /**
     * The `_source` field used to store a node's categories.
     *
     * @param {boolean} [raw=false]
     * @returns {string}
     */
    $nodeCategoriesField(raw) {
        return 'lk_categories';
    }
    /**
     * The `_source` field used to store an edge's type.
     *
     * @param {boolean} [raw=false]
     * @returns {string}
     */
    $edgeTypeField(raw) {
        return 'lk_type';
    }
    get ADVANCED_QUERY_RE() {
        return ADVANCED_QUERY_RE;
    }
    /**
     * Default number of seconds to wait for a connection/ping response
     *
     * @returns {number}
     */
    get DEFAULT_PING_TIMEOUT() {
        return 5;
    }
    /**
     * Maximum number of characters to keep in un-analyzed search sub-fields used for sorting
     *
     * @returns {number}
     */
    get SORT_FIELD_LENGTH() {
        return 15;
    }
    get FIELD_BOOST_NODE_ARRAY() {
        if (FIELD_BOOST_NODE_ARRAY === null) {
            FIELD_BOOST_NODE_ARRAY = _.map(FIELD_BOOST_NODE, (value, key) => {
                return this.resolveIndexField(key) + (value === 1 ? '' : ('^' + value));
            });
        }
        return FIELD_BOOST_NODE_ARRAY;
    }
    get FIELD_BOOST_EDGE_ARRAY() {
        if (FIELD_BOOST_EDGE_ARRAY === null) {
            FIELD_BOOST_EDGE_ARRAY = _.map(FIELD_BOOST_EDGE, (value, key) => {
                return this.resolveIndexField(key) + (value === 1 ? '' : ('^' + value));
            });
        }
        return FIELD_BOOST_EDGE_ARRAY;
    }
    get MAPPING_ES_TYPE() {
        return {
            'string': 'string',
            'byte': 'integer',
            'short': 'integer',
            'integer': 'integer',
            'long': 'integer',
            'float': 'float',
            'double': 'float',
            'boolean': 'boolean',
            'date': 'date'
        };
    }
    get META_FIELD_MAPPING() {
        return ES_META_FIELDS_MAPPING;
    }
    get META_FIELD_REVERSE_MAPPING() {
        return ES_META_FIELDS_REVERSE_MAPPING;
    }
    /**
     * Convert a raw property into it's alias counterpart
     *
     * @param {string} propertyRawName
     * @returns {string}
     */
    mapIndexField(propertyRawName) {
        if (propertyRawName === this.$nodeCategoriesField()) {
            return '[categories]';
        }
        else if (propertyRawName === this.$edgeTypeField()) {
            return '[type]';
        }
        else if (this.META_FIELD_REVERSE_MAPPING.has(propertyRawName)) {
            return this.META_FIELD_REVERSE_MAPPING.get(propertyRawName);
        }
        else {
            return propertyRawName;
        }
    }
    /**
     * Convert a property alias into it's raw counterpart
     *
     * @param {string} propertyAlias
     * @returns {string}
     */
    resolveIndexField(propertyAlias) {
        if (propertyAlias === '[categories]') {
            return this.$nodeCategoriesField();
        }
        else if (propertyAlias === '[type]') {
            return this.$edgeTypeField();
        }
        else {
            return propertyAlias;
        }
    }
    /**
     * @inheritdoc
     */
    $search(options) {
        return this._failSafeSearch(options.type, options.q, options).then(result => {
            return Promise.resolve({
                type: options.type,
                totalHits: result.hits.total,
                results: result.hits.hits.map(o => o._id)
            });
        });
    }
    /**
     * Contains the logic or retrying a search query when advanced mode fails
     *
     * `result.hits.hits` example:
     * [{
     *   _index: 'linkurious_xxxxx',
     *   _type: 'node',
     *   _id: '10906',
     *   _score: 0.095891505
     * }]
     *
     * @param {string} itemType 'node' or 'edge'
     * @param {string} searchString a search query sent by the user
     * @param {SearchOptions} options search options
     * @param {boolean} [forceSimpleMode=false] whether to force a simple query (even with advanced syntax)
     * @returns {Bluebird<{hits: {hits: {_index:string, _type:string, _id:string, _score:number, _source:object, highlight:object}[]}}>}
     */
    _failSafeSearch(itemType, searchString, options, forceSimpleMode) {
        // first call: let the query decide of the search mode
        if (forceSimpleMode === undefined) {
            forceSimpleMode = false;
        }
        let search;
        if (Utils.hasValue(this._version) && Utils.compareSemVer(this._version, '2.0.0') >= 0) {
            // TODO #987 refactor this code
            const advanced = !forceSimpleMode && searchString.match(this.ADVANCED_QUERY_RE);
            search = { query: { body: this._buildES2SearchQuery(itemType, searchString, options, advanced) },
                advanced };
            search.query.size = search.query.body.size;
            search.query.from = search.query.body.from;
            search.query.version = search.query.body.version;
        }
        else {
            search = this._buildSearchQuery(itemType, searchString, options, forceSimpleMode);
        }
        return this.searchPromise(itemType, search.query, search.advanced).catch(customError => {
            if (!search.advanced) {
                // a simple search failing : we have a serious problem
                return Promise.reject(customError);
            }
            else {
                // retry: force 'simple' mode
                return this._failSafeSearch(itemType, searchString, options, true);
            }
        });
    }
    /**
     * @param {string} itemType "node" or "edge"
     * @returns {string} the ElasticSearch type for the given itemType
     */
    $resolveESType(itemType) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * @param {string} itemType
     * @returns {string} the ElasticSearch index for the given itemType
     */
    $resolveESIndex(itemType) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * @param {string} type
     * @param {string} searchString
     * @param {SearchOptions} options
     * @param {boolean} [forceSimple=false]
     * @returns {{object}} ElasticSearch query
     * @private
     */
    _buildSearchQuery(type, searchString, options, forceSimple) {
        let advanced = false;
        // for search stability trade-offs and optimization ideas:
        // http://www.elasticsearch.org/blog/understanding-query-then-fetch-vs-dfs-query-then-fetch/
        const query = {
            size: options.size === undefined ? DEFAULT_PAGE_SIZE : Math.max(1, options.size),
            from: options.from === undefined ? 0 : Math.max(0, options.from),
            // for order/score stability across shards (for pagination)
            body: {
                _source: false,
                query: {
                    filtered: {
                        query: {
                            'dis_max': {
                                'tie_breaker': 0.5,
                                queries: []
                            }
                        },
                        filter: {
                            and: [
                                { term: { _type: this.$resolveESType(type) } }
                            ]
                        }
                    }
                }
            }
        };
        if (LKE.isTestMode()) {
            // better sort stability on small indexes, but slower.
            query.searchType = 'dfs_query_then_fetch';
            // sort on score first, then on document ID to achieve stability (for pagination)
            query.body.sort = [
                { _score: { order: 'desc' } },
                { _uid: { order: 'asc' } }
            ];
        }
        // add all "field filters". Field filter: [ "field_name", "field_value" ]
        if (options && options.filter) {
            options.filter.forEach(filter => {
                const q = { query: { match: {} } };
                q.query.match[this.resolveIndexField(filter[0])] = {
                    query: filter[1],
                    operator: 'and'
                };
                query.body.query.filtered.filter.and.push(q);
            });
        }
        // add NodeCategory/EdgeType filters : inclusive filter (or)
        if (options && options.categoriesOrTypes /* && options.categoriesOrTypes.length > 0*/) {
            const filter = this.$makeCategoriesOrTypesFilter(type, options.categoriesOrTypes);
            query.body.query.filtered.filter.and.push(filter);
        }
        // Choose between ADVANCED (fragile) and SIMPLE (fail safe) search
        if (!forceSimple && searchString.match(this.ADVANCED_QUERY_RE)) {
            // ADVANCED SEARCH : use query_string, uses following syntax:
            // https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#query-string-syntax
            advanced = true;
            query.body.query.filtered.query = {
                'query_string': {
                    query: searchString
                }
            };
            if (options && options.fuzziness) {
                // add fuzziness if required
                query.body.query.filtered.query['query_string'].fuzziness =
                    1 - parseFloat(options.fuzziness);
            }
        }
        else {
            // SIMPLE SEARCH : the search string as a simple string
            query.body.query.filtered.query['dis_max'].queries.push({
                'simple_query_string': {
                    query: searchString,
                    fields: type === 'node' ? this.FIELD_BOOST_NODE_ARRAY : this.FIELD_BOOST_EDGE_ARRAY,
                    'default_operator': 'or'
                }
            });
            query.body.query.filtered.query['dis_max'].queries.push({
                match: {
                    _all: {
                        query: searchString,
                        type: 'phrase_prefix'
                    }
                }
            });
            // (fuzziness == 0.9) means VERY fuzzy.
            // (fuzziness == 0) means NOT fuzzy.
            if (options.fuzziness > 0) {
                query.body.query.filtered.query['dis_max'].queries.push({
                    'function_score': {
                        query: {
                            'fuzzy_like_this': {
                                'like_text': searchString,
                                // ES1 wants the normalized edit similarity
                                fuzziness: 1 - options.fuzziness
                            }
                        },
                        // the stricter the matching, the higher the boost factor
                        'boost_factor': 1 - options.fuzziness
                    }
                });
            }
        }
        return { query: query, advanced: advanced };
    }
    /**
     * TODO #987 refactor this duplicate code from ES2 DAO
     *
     * Return an array of ES queries that have to be respected but that don't contribute to the score.
     * These queries are constructed on the `filter` and the `categoriesOrTypes` of SearchOptions.
     * All the filter have to be respected and at least a category (or a type) have too.
     *
     * @param {string[][]} [filter]          Array of pairs key-value used to filter the result. The keys represent object properties and the values that should match for each property
     * @param {string[]} [categoriesOrTypes] Exclusive list of edge-types or node-categories to restrict the search on
     * @param {string} type                  'node' or 'edge'
     * @returns {*[]} an array of ES queries
     * @private
     */
    _buildES2Filter(filter, categoriesOrTypes, type) {
        const fieldFilters = _.map(filter, fieldFilter => {
            const fieldName = fieldFilter[0];
            const fieldQuery = fieldFilter[1];
            // fuzziness is left to AUTO
            const result = { match: {} };
            result.match[fieldName] = { query: fieldQuery };
            return result;
        });
        const fieldCategoryOrType = type === 'node'
            ? this.$nodeCategoriesField()
            : this.$edgeTypeField();
        const rawFieldCategoryOrType = type === 'node'
            ? this.$nodeCategoriesField(true)
            : this.$edgeTypeField(true);
        const categoriesOrTypesFilter = {
            bool: {
                should: _.map(categoriesOrTypes, categoryOrTypeFilter => {
                    if (categoryOrTypeFilter === DaoUtils.LABEL_NODES_WITH_NO_CATEGORY) {
                        // category '[no_category]' means with no categories or types
                        return { missing: { field: fieldCategoryOrType } };
                    }
                    else {
                        const categoryQuery = { match: {} };
                        categoryQuery.match[rawFieldCategoryOrType] = { query: categoryOrTypeFilter };
                        return categoryQuery;
                    }
                })
            }
        };
        return fieldFilters.concat([categoriesOrTypesFilter]);
    }
    /**
     * ES2 wants the fuzziness expressed in number of characters of distance.
     * The editDistance is 0 if fuzziness === 0
     * AUTO if 0 < fuzziness <= 0.6
     * 2 if fuzziness > 0.6
     *
     * Definition of AUTO:
     * https://www.elastic.co/guide/en/elasticsearch/reference/1.4/common-options.html#_string_fields
     *
     * @param {number} length    length of the searchString
     * @param {number} fuzziness
     * @returns {*}
     * @private
     */
    _editDistanceFromFuzziness(length, fuzziness) {
        if (fuzziness === 0) {
            return 0;
        }
        else if (fuzziness <= 0.6) {
            return 'AUTO';
        }
        else {
            return 2;
        }
    }
    /**
     * Build the query to send to ES2.
     * TODO #987 refactor this duplicate code from ES2 DAO
     *
     * @param {string} type             'node' or 'edge'
     * @param {string} searchString
     * @param {SearchOptions} options
     * @param {boolean} advanced        Wheter to build an advanced query
     * @returns {{query: {bool: {must: {bool: {should: *[]}}, filter: *[]}}, size: (number|*), from: (*|Date), sort: *[], _source: boolean, highlight: *}}
     * @private
     */
    _buildES2SearchQuery(type, searchString, options, advanced) {
        const editDistance = this._editDistanceFromFuzziness(searchString.length, options.fuzziness);
        const sortingOptions = [{ _score: { order: 'desc' } }];
        if (LKE.isTestMode()) {
            // sort on score first and then id to mantain consistency in pagination
            sortingOptions.push({ _uid: { order: 'asc', 'unmapped_type': 'string' } });
        }
        let shouldQueries = advanced ? [{
                'query_string': {
                    fields: this.FIELD_BOOST_NODE_ARRAY.concat('_all'),
                    lenient: true,
                    query: searchString,
                    analyzer: this._analyzer
                }
            }] : [{
                'multi_match': {
                    fields: ['*'],
                    lenient: true,
                    query: searchString,
                    type: 'phrase_prefix'
                }
            }, {
                'multi_match': {
                    fields: this.FIELD_BOOST_NODE_ARRAY.concat('_all'),
                    lenient: true,
                    query: searchString,
                    fuzziness: editDistance
                }
            }];
        if (this._simplifiedSearch) {
            shouldQueries = advanced ? [{
                    'query_string': {
                        fields: ['_all'],
                        lenient: true,
                        query: searchString,
                        analyzer: this._analyzer
                    }
                }] : [
                //   {
                // 'multi_match': {
                //   fields: ['*'], // we use '*' instead of '_all' because _all doesn't seem to work with phrase_prefix
                //   lenient: true, // necessary to use field '*'
                //   query: searchString,
                //   type: 'phrase_prefix',
                //   'max_expansions': 50
                // }},
                {
                    match: {
                        _all: {
                            query: searchString,
                            fuzziness: editDistance,
                            operator: 'and'
                        }
                    }
                }
            ];
        }
        return {
            query: {
                bool: {
                    'minimum_should_match': 1,
                    should: shouldQueries,
                    // we enforce the filter and options.categoriesOrTypes
                    filter: this._buildES2Filter(options.filter, options.categoriesOrTypes, type)
                }
            },
            // we enforce pagination
            size: options.size,
            from: options.from,
            sort: sortingOptions,
            _source: false
        };
    }
    /**
     * Generate a nodeCategory or edgeType filter
     *
     * @param {string} type 'node' or 'edge'
     * @param {string[]} categoriesOrTypes include '[no_category]' for nodes with no categories
     * @returns {object} ES filter
     */
    $makeCategoriesOrTypesFilter(type, categoriesOrTypes) {
        // detect request to include 'no category/label' items
        // 'includeNone' can't happen for edges in Neo4j
        const includeNone = (type === 'node') &&
            _.includes(categoriesOrTypes, DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
        categoriesOrTypes = _.filter(categoriesOrTypes, term => {
            return term !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY;
        });
        const terms = _.flatten(_.map(categoriesOrTypes, term => {
            // term filters are not analyzed and lk_categories/lk_type is indexed with the default analyser:
            // lowercase + space tokenizer
            // a.a, a:a, 1.1 don't have to be split
            term = term.replace(/([a-z])[:.]((?![a-z]).*)/gi, '$1 $2');
            term = term.replace(/([0-9])[.]((?![0-9]).*)/gi, '$1 $2');
            return term.replace(/[()|/@<>#-]+/g, ' ').trim().toLowerCase().split(/ +/);
        }));
        // ONE category/type: make all terms match.
        const andFilter = categoriesOrTypes.length === 1;
        const field = type === 'node' ? this.$nodeCategoriesField(true) : this.$edgeTypeField(true);
        if (includeNone) {
            return { or: [
                    { missing: { field: this.$nodeCategoriesField(true) } },
                    { terms: {
                            [field]: terms,
                            execution: andFilter ? 'and' : 'plain'
                        } }
                ] };
        }
        else {
            return { terms: {
                    [field]: terms,
                    execution: andFilter ? 'and' : 'plain'
                } };
        }
    }
    /**
     * @param {string} itemType "node" or edge"
     * @param {object} queryBody an ElasticSearch query object
     * @param {boolean} [doNotLogErrorQuery=false]
     * @returns {Bluebird<Object|LkError>} a response promise
     */
    searchPromise(itemType, queryBody, doNotLogErrorQuery) {
        return this.$searchPromise(itemType, queryBody).catch(err => {
            if (typeof err === 'object' && typeof err.message === 'string') {
                let groups;
                if ((groups = BAD_SORT_COLUMN_RE.exec(err.message))) {
                    return Errors.business('invalid_parameter', 'ElasticSearch: invalid sort column (' + groups[1] + ')', true);
                }
                if ((groups = BAD_QUERY_MAPPING_RE.exec(err.message))) {
                    return Errors.business('invalid_parameter', 'ElasticSearch: invalid number (' + groups[1] + ')', true);
                }
            }
            if (!doNotLogErrorQuery) {
                Log.error('ElasticSearch error, query was:', global.JSON.stringify(queryBody, null, ' '));
            }
            return Promise.reject(this.getLkError(err, undefined, itemType));
        });
    }
    /**
     * Run a search query
     *
     * @param {string} itemType "node" or "edge"
     * @param {object} query
     * @param {object} query.body actual query
     * @param {number} [query.from]
     * @param {number} [query.size]
     * @param {boolean} [query.version]
     *
     * @returns {Bluebird<object>}
     */
    $searchPromise(itemType, query) { return Utils.NOT_IMPLEMENTED(); }
    /**
     * @inheritdoc
     */
    $getSchema(itemType) {
        return this._getItemTypes(itemType).map(type => {
            return this._getItemTypeProperties(itemType, type.name)
                .then(properties => type.properties = properties)
                .return(type);
        }).then(types => {
            return Promise.props({
                name: '*',
                count: this.$getSize(itemType),
                properties: this._getItemTypeProperties(itemType, undefined)
            }).then(wildcardType => {
                types.push(wildcardType);
                return types;
            });
        });
    }
    /**
     * Get the node-category/edge-type list with item count.
     *
     * @param {string} itemType "node" or "edge"
     * @returns {Bluebird<{name: string, count: number}[]>}
     */
    _getItemTypes(itemType) {
        const field = itemType === 'node' ? this.$nodeCategoriesField(true) : this.$edgeTypeField(true);
        return this.$searchPromise(itemType, {
            size: 0,
            body: {
                query: { 'match_all': {} },
                aggs: {
                    schema: {
                        terms: {
                            field: field,
                            size: 1000 // detect up to 1000 node-categories/edge-types
                        }
                    }
                }
            }
        }).then(r => {
            return r.aggregations.schema.buckets
                .map(bucket => ({ name: bucket.key, count: bucket['doc_count'] }));
        });
    }
    /**
     * @param {string} itemType "node" or "edge"
     * @param {string|undefined} [typeName] The node-category/edge-type to get properties for (can be `undefined` for all properties)
     * @returns {Bluebird<{key:string, count:number}[]>}
     * @private
     */
    _getItemTypeProperties(itemType, typeName) {
        const typeFieldRaw = itemType === 'node'
            ? this.$nodeCategoriesField(true)
            : this.$edgeTypeField(true);
        const typeField = itemType === 'node' ? this.$nodeCategoriesField() : this.$edgeTypeField();
        const ignoredProperties = [
            '_source', '_version', '_all', '_type', '_uid', typeField, typeFieldRaw
        ];
        return this.$searchPromise(itemType, {
            size: 0,
            body: {
                query: typeName === undefined ? undefined : {
                    filtered: {
                        query: { 'match_all': {} },
                        filter: {
                            term: { [typeFieldRaw]: typeName }
                        }
                    }
                },
                aggs: {
                    schema: {
                        terms: {
                            field: '_field_names',
                            size: 1000 // detect up to 1000 property names
                        }
                    }
                }
            }
        }).then(r => {
            return r.aggregations.schema.buckets
                .map(bucket => ({ key: bucket.key, count: bucket['doc_count'] }))
                .filter(property => ignoredProperties.indexOf(property.key) === -1);
        });
    }
    /**
     * @param {*} esError
     * @param {string} [prefix]
     * @param {string} [itemType] "node" or "edge"
   * @returns {LkError}
     */
    getLkError(esError, prefix, itemType) {
        prefix = 'ElasticSearch' + (prefix ? ' ' + prefix : '');
        const errorMessage = (typeof esError === 'string'
            ? esError
            : (esError && typeof esError.message === 'string'
                ? esError.message
                : JSON.stringify(esError)));
        if (errorMessage === 'No Living connections') {
            return Errors.business('dataSource_unavailable', 'Could not connect to ElasticSearch.');
        }
        if (errorMessage.includes('MapperParsingException')) {
            Log.error(esError);
            let message = _.capitalize(itemType || 'item') + ' property had an unexpected type';
            if (errorMessage.includes('NumberFormatException')) {
                message += ' (expected a number)';
            }
            message += ', try setting "dynamicMapping:false" in index configuration.';
            return Errors.business('index_mapping_error', message);
        }
        return Errors.technical('critical', prefix + ': ' + errorMessage);
    }
}
module.exports = AbstractElasticDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3RFbGFzdGljREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9hYnN0cmFjdEVsYXN0aWNEQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYiw4QkFBOEIsQ0FBQyx1QkFBdUI7QUFFdEQsWUFBWTtBQUNaLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsVUFBVTtBQUNWLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDdkMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFFdEMsV0FBVztBQUNYLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUU5QyxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztBQUU3QixZQUFZO0FBQ1osTUFBTSxpQkFBaUIsR0FBRyxvREFBb0QsQ0FBQztBQUUvRSxnR0FBZ0c7QUFDaEcsTUFBTSxnQkFBZ0IsR0FBRyxFQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLGNBQWMsRUFBRSxDQUFDLEVBQUMsQ0FBQztBQUN6RSxJQUFJLHNCQUFzQixHQUFHLElBQUksQ0FBQztBQUVsQywwRkFBMEY7QUFDMUYsTUFBTSxnQkFBZ0IsR0FBRyxFQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUMsQ0FBQztBQUNuRSxJQUFJLHNCQUFzQixHQUFHLElBQUksQ0FBQztBQUVsQyxNQUFNLGlDQUFpQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQ2pELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxDQUFDLEVBQ3ZELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FDM0MsQ0FBQyxDQUFDO0FBRUwsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLE1BQU0sQ0FBQywwREFBMEQsQ0FBQyxDQUFDO0FBRWxHLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxNQUFNLENBQUMsb0NBQW9DLENBQUMsQ0FBQztBQUU5RSxNQUFNLDJCQUEyQixHQUFHLFFBQVEsQ0FBQztBQUU3QyxNQUFNLGNBQWMsR0FBRztJQUNyQixRQUFRLEVBQUUsTUFBTSxFQUFFLE9BQU87SUFDekIsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPO0lBQ3pCLE1BQU0sRUFBRSxjQUFjLEVBQUUsVUFBVTtJQUNsQyxVQUFVLEVBQUUsT0FBTztDQUNwQixDQUFDO0FBRUYsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsQ0FBQyxjQUFjO0tBQ2xELEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFakUsTUFBTSw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxjQUFjO0tBQzFELEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsMkJBQTJCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFFakU7O0dBRUc7QUFDSCxNQUFNLGtCQUFtQixTQUFRLFFBQVE7SUFFdkMsWUFBWSxNQUFNLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLE9BQU8sRUFBRSxRQUFRO1FBQ3RFLEtBQUssQ0FDSCxNQUFNLEVBQ04sZUFBZSxFQUNmLGdCQUFnQixFQUNoQixPQUFPLEVBQ1AsUUFBUSxDQUNULENBQUM7UUFFRixJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixDQUFDLEdBQUc7UUFDdEIsT0FBTyxlQUFlLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYyxDQUFDLEdBQUc7UUFDaEIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVELElBQUksaUJBQWlCO1FBQ25CLE9BQU8saUJBQWlCLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxJQUFJLG9CQUFvQjtRQUN0QixPQUFPLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxpQkFBaUI7UUFDbkIsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRUQsSUFBSSxzQkFBc0I7UUFDeEIsSUFBSSxzQkFBc0IsS0FBSyxJQUFJLEVBQUU7WUFDbkMsc0JBQXNCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtnQkFDOUQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDMUUsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUNELE9BQU8sc0JBQXNCLENBQUM7SUFDaEMsQ0FBQztJQUVELElBQUksc0JBQXNCO1FBQ3hCLElBQUksc0JBQXNCLEtBQUssSUFBSSxFQUFFO1lBQ25DLHNCQUFzQixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQzlELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQzFFLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFDRCxPQUFPLHNCQUFzQixDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUFJLGVBQWU7UUFDakIsT0FBTztZQUNMLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFFBQVEsRUFBRSxPQUFPO1lBQ2pCLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFJLGtCQUFrQjtRQUNwQixPQUFPLHNCQUFzQixDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUFJLDBCQUEwQjtRQUM1QixPQUFPLDhCQUE4QixDQUFDO0lBQ3hDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGFBQWEsQ0FBQyxlQUFlO1FBQzNCLElBQUksZUFBZSxLQUFLLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxFQUFFO1lBQ25ELE9BQU8sY0FBYyxDQUFDO1NBQ3ZCO2FBQU0sSUFBSSxlQUFlLEtBQUssSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFO1lBQ3BELE9BQU8sUUFBUSxDQUFDO1NBQ2pCO2FBQU0sSUFBSSxJQUFJLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQy9ELE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztTQUM3RDthQUFNO1lBQ0wsT0FBTyxlQUFlLENBQUM7U0FDeEI7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxpQkFBaUIsQ0FBQyxhQUFhO1FBQzdCLElBQUksYUFBYSxLQUFLLGNBQWMsRUFBRTtZQUNwQyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1NBQ3BDO2FBQU0sSUFBSSxhQUFhLEtBQUssUUFBUSxFQUFFO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1NBQzlCO2FBQU07WUFDTCxPQUFPLGFBQWEsQ0FBQztTQUN0QjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBRWIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDMUUsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUNyQixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7Z0JBQ2xCLFNBQVMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7Z0JBQzVCLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBQzFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsZUFBZSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLGVBQWU7UUFDOUQsc0RBQXNEO1FBQ3RELElBQUksZUFBZSxLQUFLLFNBQVMsRUFBRTtZQUNqQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1NBQ3pCO1FBRUQsSUFBSSxNQUFNLENBQUM7UUFDWCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDckYsK0JBQStCO1lBQy9CLE1BQU0sUUFBUSxHQUFHLENBQUMsZUFBZSxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDaEYsTUFBTSxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBQztnQkFDM0YsUUFBUSxFQUFDLENBQUM7WUFDWixNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDM0MsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQzNDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUNsRDthQUFNO1lBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQztTQUNuRjtRQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JGLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO2dCQUNwQixzREFBc0Q7Z0JBQ3RELE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUNwQztpQkFBTTtnQkFDTCw2QkFBNkI7Z0JBQzdCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNwRTtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILGNBQWMsQ0FBQyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRTVEOzs7T0FHRztJQUNILGVBQWUsQ0FBQyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRTdEOzs7Ozs7O09BT0c7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxXQUFXO1FBQ3hELElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQztRQUVyQiwwREFBMEQ7UUFDMUQsNEZBQTRGO1FBQzVGLE1BQU0sS0FBSyxHQUFHO1lBQ1osSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQztZQUNoRixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQztZQUNoRSwyREFBMkQ7WUFDM0QsSUFBSSxFQUFFO2dCQUNKLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRTtvQkFDTCxRQUFRLEVBQUU7d0JBQ1IsS0FBSyxFQUFFOzRCQUNMLFNBQVMsRUFBRTtnQ0FDVCxhQUFhLEVBQUUsR0FBRztnQ0FDbEIsT0FBTyxFQUFFLEVBQUU7NkJBQ1o7eUJBQ0Y7d0JBQ0QsTUFBTSxFQUFFOzRCQUNOLEdBQUcsRUFBRTtnQ0FDSCxFQUFDLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFDLEVBQUM7NkJBQzNDO3lCQUNGO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRixDQUFDO1FBRUYsSUFBSSxHQUFHLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDcEIsc0RBQXNEO1lBQ3RELEtBQUssQ0FBQyxVQUFVLEdBQUcsc0JBQXNCLENBQUM7WUFFMUMsaUZBQWlGO1lBQ2pGLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHO2dCQUNoQixFQUFDLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUMsRUFBQztnQkFDekIsRUFBQyxJQUFJLEVBQUUsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQUM7YUFDdkIsQ0FBQztTQUNIO1FBRUQseUVBQXlFO1FBQ3pFLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDN0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzlCLE1BQU0sQ0FBQyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBQyxFQUFDLENBQUM7Z0JBQy9CLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO29CQUNqRCxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztvQkFDaEIsUUFBUSxFQUFFLEtBQUs7aUJBQ2hCLENBQUM7Z0JBQ0YsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9DLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCw0REFBNEQ7UUFDNUQsSUFBSSxPQUFPLElBQUksT0FBTyxDQUFDLGlCQUFpQixDQUFBLDRDQUE0QyxFQUFFO1lBQ3BGLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDbEYsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ25EO1FBRUQsa0VBQWtFO1FBQ2xFLElBQUksQ0FBQyxXQUFXLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRTtZQUM5RCw2REFBNkQ7WUFDN0Qsd0hBQXdIO1lBQ3hILFFBQVEsR0FBRyxJQUFJLENBQUM7WUFFaEIsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRztnQkFDaEMsY0FBYyxFQUFFO29CQUNkLEtBQUssRUFBRSxZQUFZO2lCQUNwQjthQUNGLENBQUM7WUFFRixJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO2dCQUNoQyw0QkFBNEI7Z0JBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUztvQkFDdkQsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDckM7U0FDRjthQUFNO1lBQ0wsdURBQXVEO1lBRXZELEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDdEQscUJBQXFCLEVBQUU7b0JBQ3JCLEtBQUssRUFBRSxZQUFZO29CQUNuQixNQUFNLEVBQUUsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCO29CQUNuRixrQkFBa0IsRUFBRSxJQUFJO2lCQUN6QjthQUNGLENBQUMsQ0FBQztZQUVILEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDdEQsS0FBSyxFQUFFO29CQUNMLElBQUksRUFBRTt3QkFDSixLQUFLLEVBQUUsWUFBWTt3QkFDbkIsSUFBSSxFQUFFLGVBQWU7cUJBQ3RCO2lCQUNGO2FBQ0YsQ0FBQyxDQUFDO1lBRUgsdUNBQXVDO1lBQ3ZDLG9DQUFvQztZQUNwQyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxFQUFFO2dCQUN6QixLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7b0JBQ3RELGdCQUFnQixFQUFFO3dCQUNoQixLQUFLLEVBQUU7NEJBQ0wsaUJBQWlCLEVBQUU7Z0NBQ2pCLFdBQVcsRUFBRSxZQUFZO2dDQUN6QiwyQ0FBMkM7Z0NBQzNDLFNBQVMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLFNBQVM7NkJBQ2pDO3lCQUNGO3dCQUNELHlEQUF5RDt3QkFDekQsY0FBYyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsU0FBUztxQkFDdEM7aUJBQ0YsQ0FBQyxDQUFDO2FBQ0o7U0FDRjtRQUNELE9BQU8sRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsZUFBZSxDQUFDLE1BQU0sRUFBRSxpQkFBaUIsRUFBRSxJQUFJO1FBQzdDLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO1lBQy9DLE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxNQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEMsNEJBQTRCO1lBQzVCLE1BQU0sTUFBTSxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDO1lBQzNCLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDLENBQUM7WUFDOUMsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLG1CQUFtQixHQUFHLElBQUksS0FBSyxNQUFNO1lBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7WUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMxQixNQUFNLHNCQUFzQixHQUFHLElBQUksS0FBSyxNQUFNO1lBQzVDLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTlCLE1BQU0sdUJBQXVCLEdBQUc7WUFDOUIsSUFBSSxFQUFFO2dCQUNKLE1BQU0sRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLG9CQUFvQixDQUFDLEVBQUU7b0JBQ3RELElBQUksb0JBQW9CLEtBQUssUUFBUSxDQUFDLDRCQUE0QixFQUFFO3dCQUNsRSw2REFBNkQ7d0JBQzdELE9BQU8sRUFBQyxPQUFPLEVBQUUsRUFBQyxLQUFLLEVBQUUsbUJBQW1CLEVBQUMsRUFBQyxDQUFDO3FCQUNoRDt5QkFBTTt3QkFDTCxNQUFNLGFBQWEsR0FBRyxFQUFDLEtBQUssRUFBRSxFQUFFLEVBQUMsQ0FBQzt3QkFDbEMsYUFBYSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLEVBQUMsS0FBSyxFQUFFLG9CQUFvQixFQUFDLENBQUM7d0JBQzVFLE9BQU8sYUFBYSxDQUFDO3FCQUN0QjtnQkFDSCxDQUFDLENBQUM7YUFDSDtTQUNGLENBQUM7UUFFRixPQUFPLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCwwQkFBMEIsQ0FBQyxNQUFNLEVBQUUsU0FBUztRQUMxQyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDbkIsT0FBTyxDQUFDLENBQUM7U0FDVjthQUFNLElBQUksU0FBUyxJQUFJLEdBQUcsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQztTQUNmO2FBQU07WUFDTCxPQUFPLENBQUMsQ0FBQztTQUNWO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxRQUFRO1FBQ3hELE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU3RixNQUFNLGNBQWMsR0FBRyxDQUFDLEVBQUMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQyxFQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUNwQix1RUFBdUU7WUFDdkUsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFDLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBQyxFQUFDLENBQUMsQ0FBQztTQUN4RTtRQUVELElBQUksYUFBYSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsY0FBYyxFQUFFO29CQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztvQkFDbEQsT0FBTyxFQUFFLElBQUk7b0JBQ2IsS0FBSyxFQUFFLFlBQVk7b0JBQ25CLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUztpQkFDekI7YUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsYUFBYSxFQUFFO29CQUNiLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQztvQkFDYixPQUFPLEVBQUUsSUFBSTtvQkFDYixLQUFLLEVBQUUsWUFBWTtvQkFDbkIsSUFBSSxFQUFFLGVBQWU7aUJBQ3RCO2FBQUMsRUFBRTtnQkFDSixhQUFhLEVBQUU7b0JBQ2IsTUFBTSxFQUFFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO29CQUNsRCxPQUFPLEVBQUUsSUFBSTtvQkFDYixLQUFLLEVBQUUsWUFBWTtvQkFDbkIsU0FBUyxFQUFFLFlBQVk7aUJBQ3hCO2FBQUMsQ0FBQyxDQUFDO1FBRU4sSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDMUIsYUFBYSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUIsY0FBYyxFQUFFO3dCQUNkLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQzt3QkFDaEIsT0FBTyxFQUFFLElBQUk7d0JBQ2IsS0FBSyxFQUFFLFlBQVk7d0JBQ25CLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUztxQkFDekI7aUJBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDTixNQUFNO2dCQUNOLG1CQUFtQjtnQkFDbkIsd0dBQXdHO2dCQUN4RyxpREFBaUQ7Z0JBQ2pELHlCQUF5QjtnQkFDekIsMkJBQTJCO2dCQUMzQix5QkFBeUI7Z0JBQ3pCLE1BQU07Z0JBQ047b0JBQ0UsS0FBSyxFQUFFO3dCQUNMLElBQUksRUFBRTs0QkFDSixLQUFLLEVBQUUsWUFBWTs0QkFDbkIsU0FBUyxFQUFFLFlBQVk7NEJBQ3ZCLFFBQVEsRUFBRSxLQUFLO3lCQUNoQjtxQkFDRjtpQkFDRjthQUFDLENBQUM7U0FDTjtRQUVELE9BQU87WUFDTCxLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFO29CQUNKLHNCQUFzQixFQUFFLENBQUM7b0JBQ3pCLE1BQU0sRUFBRSxhQUFhO29CQUNyQixzREFBc0Q7b0JBQ3RELE1BQU0sRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQztpQkFDOUU7YUFDRjtZQUNELHdCQUF3QjtZQUN4QixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLElBQUksRUFBRSxjQUFjO1lBQ3BCLE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsaUJBQWlCO1FBQ2xELHNEQUFzRDtRQUN0RCxnREFBZ0Q7UUFDaEQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDO1lBQ25DLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUM7UUFFdkUsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUNyRCxPQUFPLElBQUksS0FBSyxRQUFRLENBQUMsNEJBQTRCLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDdEQsZ0dBQWdHO1lBQ2hHLDhCQUE4QjtZQUU5Qix1Q0FBdUM7WUFDdkMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsNEJBQTRCLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDM0QsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsMkJBQTJCLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFMUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0UsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVKLDJDQUEyQztRQUMzQyxNQUFNLFNBQVMsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1FBRWpELE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1RixJQUFJLFdBQVcsRUFBRTtZQUNmLE9BQU8sRUFBQyxFQUFFLEVBQUU7b0JBQ1YsRUFBQyxPQUFPLEVBQUUsRUFBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUFDLEVBQUM7b0JBQ25ELEVBQUMsS0FBSyxFQUFFOzRCQUNOLENBQUMsS0FBSyxDQUFDLEVBQUUsS0FBSzs0QkFDZCxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU87eUJBQ3ZDLEVBQUM7aUJBQ0gsRUFBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLE9BQU8sRUFBQyxLQUFLLEVBQUU7b0JBQ2IsQ0FBQyxLQUFLLENBQUMsRUFBRSxLQUFLO29CQUNkLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTztpQkFDdkMsRUFBQyxDQUFDO1NBQ0o7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxrQkFBa0I7UUFDbkQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDMUQsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksT0FBTyxHQUFHLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTtnQkFDOUQsSUFBSSxNQUFNLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQ25ELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQUUsc0NBQXNDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQ3BGLENBQUM7aUJBQ0g7Z0JBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQ3JELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQUUsaUNBQWlDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxJQUFJLENBQy9FLENBQUM7aUJBQ0g7YUFDRjtZQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRTtnQkFDdkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFDekMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FDNUMsQ0FBQzthQUNIO1lBRUQsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ25FLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRW5FOztPQUVHO0lBQ0gsVUFBVSxDQUFDLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM3QyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQztpQkFDcEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7aUJBQ2hELE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ25CLElBQUksRUFBRSxHQUFHO2dCQUNULEtBQUssRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztnQkFDOUIsVUFBVSxFQUFFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO2FBQzdELENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ3JCLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3pCLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGFBQWEsQ0FBQyxRQUFRO1FBQ3BCLE1BQU0sS0FBSyxHQUFHLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVoRyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFO1lBQ25DLElBQUksRUFBRSxDQUFDO1lBQ1AsSUFBSSxFQUFFO2dCQUNKLEtBQUssRUFBRSxFQUFDLFdBQVcsRUFBRSxFQUFFLEVBQUM7Z0JBQ3hCLElBQUksRUFBRTtvQkFDSixNQUFNLEVBQUU7d0JBQ04sS0FBSyxFQUFFOzRCQUNMLEtBQUssRUFBRSxLQUFLOzRCQUNaLElBQUksRUFBRSxJQUFJLENBQUMsK0NBQStDO3lCQUMzRDtxQkFDRjtpQkFDRjthQUNGO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNWLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTztpQkFDakMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDckUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxzQkFBc0IsQ0FBQyxRQUFRLEVBQUUsUUFBUTtRQUN2QyxNQUFNLFlBQVksR0FBRyxRQUFRLEtBQUssTUFBTTtZQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQztZQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUU5QixNQUFNLFNBQVMsR0FBRyxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRTVGLE1BQU0saUJBQWlCLEdBQUc7WUFDeEIsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsWUFBWTtTQUN4RSxDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRTtZQUNuQyxJQUFJLEVBQUUsQ0FBQztZQUNQLElBQUksRUFBRTtnQkFDSixLQUFLLEVBQUUsUUFBUSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsUUFBUSxFQUFFO3dCQUNSLEtBQUssRUFBRSxFQUFDLFdBQVcsRUFBRSxFQUFFLEVBQUM7d0JBQ3hCLE1BQU0sRUFBRTs0QkFDTixJQUFJLEVBQUUsRUFBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBQzt5QkFDakM7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsSUFBSSxFQUFFO29CQUNKLE1BQU0sRUFBRTt3QkFDTixLQUFLLEVBQUU7NEJBQ0wsS0FBSyxFQUFFLGNBQWM7NEJBQ3JCLElBQUksRUFBRSxJQUFJLENBQUMsbUNBQW1DO3lCQUMvQztxQkFDRjtpQkFDRjthQUNGO1NBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNWLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTztpQkFDakMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUMsQ0FBQyxDQUFDO2lCQUM5RCxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxVQUFVLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRO1FBQ2xDLE1BQU0sR0FBRyxlQUFlLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXhELE1BQU0sWUFBWSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssUUFBUTtZQUMvQyxDQUFDLENBQUMsT0FBTztZQUNULENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUssUUFBUTtnQkFDL0MsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO2dCQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FDMUIsQ0FDRixDQUFDO1FBRUYsSUFBSSxZQUFZLEtBQUssdUJBQXVCLEVBQUU7WUFDNUMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHdCQUF3QixFQUFFLHFDQUFxQyxDQUFDLENBQUM7U0FDekY7UUFFRCxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsd0JBQXdCLENBQUMsRUFBRTtZQUNuRCxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRW5CLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxHQUFHLGtDQUFrQyxDQUFDO1lBQ3BGLElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLElBQUksc0JBQXNCLENBQUM7YUFDbkM7WUFDRCxPQUFPLElBQUksOERBQThELENBQUM7WUFFMUUsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3hEO1FBRUQsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxNQUFNLEdBQUcsSUFBSSxHQUFHLFlBQVksQ0FBQyxDQUFDO0lBQ3BFLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLENBQUMifQ==