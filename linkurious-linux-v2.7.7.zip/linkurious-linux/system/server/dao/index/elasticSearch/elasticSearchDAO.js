/**
 * LINKURIOUS CONFIDENTIAL
 * __________________
 *
 *  [2012] - [2014] Linkurious SAS
 *  All Rights Reserved.
 *
 *  Description: This file handles the link between the Linkurious API and
 *  the Elasticsearch one.
 *
 */
'use strict';
/* eslint no-unused-vars: 0 */ // fix with refactoring
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const elasticsearch = require('elasticsearch');
// services
const LKE = require('../../../services/index');
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const AbstractElasticDAO = require('../abstractElasticDAO');
/**
 * Embedded ElasticSearch Index DAO
 */
class ElasticSearchDAO extends AbstractElasticDAO {
    /**
     * ElasticSearch DAO constructor
     *
     * @param {object} options
     * @param {string} options.host server host
     * @param {String|Number} options.port server port
     * @param {string} options.indexName index name
     * @param {string} [options.mapping] custom mapping options (see ElasticSearch manual)
     * @param {boolean} [options.https] whether to use an HTTPS connection
     * @param {GraphDAO} graphDao The connected Graph DAO
     */
    constructor(options, graphDao) {
        super('elasticSearch', ['host', 'port'], [
            'url', 'host', 'port', 'mapping', 'forceReindex',
            'dynamicMapping', 'dateDetection', 'user', 'password', 'https', 'analyzer'
        ], options, {
            canCount: true,
            fuzzy: true,
            canIndexEdges: true,
            canIndexCategories: true,
            searchHitsCount: true,
            // this is the internally-indexed ES index
            external: false,
            schema: false,
            // we use the mapping to read types from ES
            typing: true,
            advancedQueryDialect: 'elasticsearch'
        });
        // TODO #987 refactor this check with ES refactoring
        // check if graph vendor is different from stardog
        if (graphDao.vendor === 'stardog') {
            throw Errors.technical('critical', `Cannot use "${this.vendor}" with Graph DAO "${graphDao.vendor}".`, true);
        }
        if (Utils.hasValue(options.url)) {
            this.url = options.url;
        }
        else {
            let auth = '';
            if (Utils.hasValue(options.user) && Utils.hasValue(options.password)) {
                auth = options.user + ':' + options.password + '@';
            }
            this.url = `http${options.https ? 's' : ''}://${auth}${options.host}:${options.port}`;
        }
        this.fieldDataHeapLimit = null;
        // we do not let ElasticSearch print any logs.
        // to change the way ElasticSearch logs, see the documentation:
        // http://www.elasticsearch.org/guide/en/elasticsearch/client/javascript-api/current/logging.html
        function LogPlug() {
            //this.error = Log.error.bind(Log),
            this.error = () => { };
            this.warning = () => { };
            this.info = () => { };
            this.debug = () => { };
            this.trace = () => { };
            this.close = () => { };
        }
        this.esclient = new elasticsearch.Client({
            log: LogPlug,
            host: this.url,
            apiVersion: '1.2'
        });
    }
    /**
     * @param {LkNode|LkEdge} item
     * @param {number} item.version version increment
     * @param {string} type 'node' or 'edge'
     *
     * @returns {{id: string, type: string, data: object, version?: number}}
     * @private
     */
    _formatDataToIndex(item, type) {
        const result = {
            id: item.id,
            type: type === 'node' ? 'node' : 'edge',
            version: item.version,
            data: Utils.clone(item.data)
        };
        // fix unsafe properties.
        const keys = Object.keys(result.data);
        for (let i = 0; i < keys.length; ++i) {
            const originalKey = keys[i];
            if (this.META_FIELD_MAPPING.has(originalKey)) {
                // If the user property is also an elastic search meta field, replace the property
                // with a non conflicting equivalent.
                const value = result.data[originalKey];
                result.data[originalKey] = undefined;
                // Using the combining low line as a replacement
                // https://www.fileformat.info/info/unicode/char/0332/index.htm
                const fixedKey = this.META_FIELD_MAPPING.get(originalKey);
                result.data[fixedKey] = value;
            }
        }
        if (type === 'edge') {
            result.data[this.$edgeTypeField()] = item.type;
        }
        else if (item.categories) {
            result.data[this.$nodeCategoriesField()] = item.categories;
        }
        return result;
    }
    /**
     * @inheritdoc
     */
    connect() {
        const timeout = this.DEFAULT_PING_TIMEOUT * 1000;
        return new Promise((resolve, reject) => {
            /**
             * Connection-error handler
             *
             * @param {*} err
             * @returns {boolean} true if there was an error.
             */
            const handleError = err => {
                if (err) {
                    reject(Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch: ' +
                        (err.message ? err.message : err)));
                    return true;
                }
                else {
                    return false;
                }
            };
            this.esclient.info({ timeout: timeout }, (err, info) => {
                if (err && err.message && err.message.includes &&
                    err.message.includes('contains unrecognized parameter: [timeout]')) {
                    // TODO #1306 refactor embedded ES driver
                    reject(Errors.business('not_supported', 'ElasticSearch 6.x is not supported by this driver. Please use ElasticSearch 2 driver.'));
                }
                if (handleError(err)) {
                    return;
                }
                const version = info.version.number;
                if (Utils.compareSemVer(version, '2.0.0') >= 0) {
                    reject(Errors.business('not_supported', 'ElasticSearch 2.x is not supported by this driver. Please use ElasticSearch 2 driver.'));
                }
                this.esclient.cluster.stats({ timeout: timeout }, (err, stats) => {
                    if (handleError(err)) {
                        return;
                    }
                    // default to 1GB is the value is zero or undefined (zero actually happens)
                    const maxHeap = stats.nodes.jvm.mem['heap_max_in_bytes'] || (1024 * 1000 * 1000);
                    this.esclient.cluster.getSettings({ timeout: timeout }, (err, settings) => {
                        // default values
                        let fieldDataLimit = '60%';
                        let fieldDataOverhead = 1.03;
                        // ignore error: this will fails (HTTP 401) in AWS because of security policies
                        if (!err) {
                            // see https://www.elastic.co/guide/en/elasticsearch/reference/1.5/index-modules-fielddata.html
                            fieldDataLimit = settings.persistent['indices.breaker.fielddata.limit'] || '60%';
                            fieldDataOverhead = settings.persistent['indices.breaker.fielddata.limit'] || 1.03;
                        }
                        const fieldDataLimitRatio = fieldDataLimit.replace('%', '') / 100;
                        // maximum number of bytes that can be used by field-data (e.g.: sorting)
                        this.fieldDataHeapLimit = Math.floor(maxHeap * fieldDataLimitRatio / fieldDataOverhead);
                        resolve(version);
                    });
                });
            });
        }).then(version => {
            // fill the size caches and return the version
            return Promise.join(version, this.$getSize('node'), this.$getSize('edge'), version => version);
        });
    }
    /**
     * @inheritdoc
     */
    $indexExists() {
        return this._indexAction('exists', { expandWildcards: 'closed' });
    }
    /**
     * @inheritdoc
     */
    $deleteIfExists() {
        return this.$indexExists().then(exists => {
            if (!exists) {
                return false;
            }
            return this._indexAction('delete');
        }).then(() => {
            return true;
        });
    }
    /**
     * @inheritdoc
     */
    checkUp() {
        return new Promise((resolve, reject) => {
            this.esclient.ping({ requestTimeout: this.DEFAULT_PING_TIMEOUT * 1000 }, err => {
                if (err) {
                    reject(Errors.technical('index_unreachable', 'Cannot connect to ElasticSearch: ' +
                        (err.message ? err.message : err)));
                }
                else {
                    resolve();
                }
            });
        });
    }
    /**
     * @inheritdoc
     */
    $getSize(type) {
        const indexName = this.$resolveESIndex(type);
        return new Promise((resolve, reject) => {
            this.esclient.count({
                index: indexName,
                ignoreUnavailable: true,
                type: type
            }, (err, result) => {
                if (err && err.message) {
                    if (err.message === 'IndexMissingException[[' + indexName + '] missing]') {
                        return resolve(0);
                    }
                    if (err.message === 'Service Unavailable') {
                        return resolve(0);
                    }
                }
                if (err) {
                    return this.onError(reject, err, undefined, type);
                }
                if (!result) {
                    return resolve(0);
                }
                resolve(result.count);
            });
        });
    }
    /**
     * @inheritdoc
     */
    $commit() {
        return new Promise((resolve, reject) => {
            this.esclient.indices.flush({ index: this.options.indexName }, err => {
                if (err) {
                    return this.onError(reject, err);
                }
                resolve();
            });
        });
    }
    /**
     * @inheritdoc
     */
    $createIndex() {
        const defaultAnalyzer = this.getOption('analyzer', 'standard');
        // analysis config
        const analysisConfig = {
            analyzer: {
                // sort field (*.sort) analyser
                'lk_sort': {
                    type: 'custom',
                    tokenizer: 'keyword',
                    filter: [
                        //'icu_collation',
                        'lowercase',
                        'trim',
                        'truncateSort' // cut sort field at 15 chars
                    ]
                }
            },
            filter: {
                truncateSort: {
                    type: 'truncate',
                    length: this.SORT_FIELD_LENGTH
                }
            }
        };
        // field for sorting
        const sortField = { sort: {
                type: 'string', analyzer: 'lk_sort', stored: false, 'include_in_all': false //, index: 'no'
            } };
        // dynamic mapping safety (default: true). see issue #273
        const dynamicMapping = this.getOption('dynamicMapping', true);
        // dynamic template for sorting sub-field
        const fieldTemplate = {
            'lk_template': {
                match: '*',
                mapping: {
                    type: dynamicMapping ? '{dynamic_type}' : 'string',
                    analyzer: defaultAnalyzer,
                    fields: sortField
                }
            }
        };
        // set node/edge mapping
        let mapping = {};
        if (this.options.mapping) {
            mapping = this.options.mapping;
        }
        const nodeMapping = Utils.clone(mapping);
        nodeMapping[this.$nodeCategoriesField()] = { type: 'string', fields: sortField };
        const edgeMapping = Utils.clone(mapping);
        edgeMapping[this.$edgeTypeField()] = { type: 'string', fields: sortField };
        // date detection safety. (default: false). see issues #282
        const dateDetection = this.getOption('dateDetection', false);
        return this._indexAction('create', {
            body: {
                settings: {
                    // custom analyzer for efficient sorting. see:
                    // https://www.elastic.co/guide/en/elasticsearch/guide/master/sorting-collations.html
                    analysis: analysisConfig
                },
                mappings: {
                    '_default_': {
                        'dynamic_templates': [fieldTemplate]
                    },
                    node: {
                        'date_detection': dateDetection,
                        properties: nodeMapping,
                        dynamic: true // must always be true to allow dynamic templates
                    },
                    edge: {
                        'date_detection': dateDetection,
                        properties: edgeMapping,
                        dynamic: true // must always be true to allow dynamic templates
                    }
                }
            }
        }).catch(Errors.LkError, e => {
            if (e.message.indexOf('IndexAlreadyExistsException') > 0) {
                // ignore this error
                return;
            }
            return Promise.reject(e);
        });
    }
    /**
     * Call method `action` on ESClient.indices with options (`index:indexName` is added to options)
     *
     * @param {string} action action name
     * @param {object} [options]
     * @returns {Bluebird<*>}
     * @private
     */
    _indexAction(action, options) {
        if (!options) {
            options = {};
        }
        options.index = this.options.indexName;
        return new Promise((resolve, reject) => {
            // create new index
            this.esclient.indices[action](options, (err, result) => {
                if (err) {
                    return this.onError(reject, err, 'could not ' + action + ' index "' + options.index + '"');
                }
                resolve(result);
            });
        });
    }
    /**
     * @inheritdoc
     */
    $upsertEntry(type, entry) {
        const indexEntry = this._formatDataToIndex(entry, type);
        return new Promise((resolve, reject) => {
            this.esclient.update({
                // force an index refresh to make sur we read up-to-date values in the next read
                //   see:
                //   Boolean — Specify whether to perform the operation in realtime or search mode
                refresh: true,
                index: this.$resolveESIndex(indexEntry.type),
                type: this.$resolveESType(indexEntry.type),
                id: indexEntry.id,
                body: {
                    doc: indexEntry.data,
                    'doc_as_upsert': true
                }
            }, (err, result) => {
                if (err) {
                    if (err.message && err.message.match('DocumentMissingException')) {
                        const key = indexEntry.type === 'node' ? 'node_not_found' : 'edge_not_found';
                        return reject(Errors.business(key, JSON.stringify(err)));
                    }
                    return this.onError(reject, err, undefined, type);
                }
                resolve(result._version);
            });
        });
    }
    /**
     * Delete an entry
     *
     * @param {string} id the id fo the entry to delete
     * @param {string} type the type ('node' or 'edge') or the entry to delete
     * @returns {Promise}
     */
    $deleteEntry(id, type) {
        return new Promise((resolve, reject) => {
            this.esclient.delete({
                index: this.$resolveESIndex(type),
                type: this.$resolveESType(type),
                id: id
            }, err => {
                if (err) {
                    if (err.message && err.message.match('Not Found')) {
                        return resolve();
                    }
                    return this.onError(reject, err, undefined, type);
                }
                return resolve();
            });
        });
    }
    /**
     * @inheritdoc
     */
    $addEntries(type, entries) {
        // about batch size:
        // http://www.elasticsearch.org/guide/en/elasticsearch/guide/current/bulk.html#_how_big_is_too_big
        // 1000 / 5000 document
        const chunkSize = 1000;
        if (entries.length === 0) {
            return Promise.resolve();
        }
        const startIndexes = [];
        if (entries.length > chunkSize) {
            for (let i = 0; i < Math.ceil(entries.length / chunkSize); ++i) {
                startIndexes.push(i * chunkSize);
            }
        }
        else {
            startIndexes.push(0);
        }
        return Promise.each(startIndexes, startIndex => {
            const commands = [];
            for (let i = startIndex; i < entries.length && i < (startIndex + chunkSize); i++) {
                commands.push({ index: {
                        '_id': entries[i].id
                    } });
                commands.push(this._formatDataToIndex(entries[i], type).data);
            }
            return new Promise((resolve, reject) => {
                this.esclient.bulk({
                    index: this.$resolveESIndex(type),
                    type: this.$resolveESType(type),
                    body: commands
                }, (err, res) => {
                    if (err) {
                        return this.onError(reject, err, undefined, type);
                    }
                    if (res.errors && res.errors.length) {
                        return this.onError(reject, res.errors, undefined, type);
                    }
                    if (res.errors === true) {
                        let error = 'unknown error';
                        _.forEach(res.items, item => {
                            if (item.index && item.index.error) {
                                error = item.index.error;
                                return false;
                            }
                        });
                        return this.onError(reject, error, undefined, type);
                    }
                    resolve();
                });
            });
        });
    }
    /**
     * @inheritdoc
     */
    $getPropertyTypes(type) {
        return this._indexAction('getMapping', { type: type }).then(res => {
            const mapping = {};
            _.forEach(res[this.options.indexName].mappings[type].properties, (m, propertyKey) => {
                mapping[propertyKey] = this.MAPPING_ES_TYPE[m.type];
            });
            return mapping;
        });
    }
    /**
     * @inheritdoc
     */
    $searchPromise(itemType, query) {
        query.index = this.$resolveESIndex(itemType);
        query.type = this.$resolveESType(itemType);
        return new Promise((resolve, reject) => {
            this.esclient.search(query, (err, result) => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(result);
                }
            });
        });
    }
    /**
     * @inheritdoc
     */
    $resolveESType(itemType) {
        return itemType;
    }
    /**
     * @inheritdoc
     */
    $resolveESIndex(itemType) {
        return this.options.indexName;
    }
    /**
     * @param {function} reject Promise rejection callback
     * @param {*} esError
     * @param {string|undefined} [prefix]
     * @param {string} [itemType] "node" or "edge"
     */
    onError(reject, esError, prefix, itemType) {
        return reject(this.getLkError(esError, prefix, itemType));
    }
}
/**
 * @param {string} query
 * @param {string} field
 * @param {*} value
 * @returns {{query: {span_first: {end: number, match: {span_multi: {match: {}}}}}}}
 *
 * @private
 */
function spanFirstFilter(query, field, value) {
    value = value.toLowerCase();
    const f = { query: {
            'span_first': {
                end: 1,
                match: {
                    'span_multi': {
                        match: {}
                    }
                }
            }
        } };
    f.query['span_first'].match['span_multi'].match[query] = {};
    f.query['span_first'].match['span_multi'].match[query][field] = value;
    return f;
}
module.exports = ElasticSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxhc3RpY1NlYXJjaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvZWxhc3RpY1NlYXJjaC9lbGFzdGljU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7O0dBVUc7QUFDSCxZQUFZLENBQUM7QUFFYiw4QkFBOEIsQ0FBQyx1QkFBdUI7QUFFdEQsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBRS9DLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUMvQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFNUQ7O0dBRUc7QUFDSCxNQUFNLGdCQUFpQixTQUFRLGtCQUFrQjtJQUMvQzs7Ozs7Ozs7OztPQVVHO0lBQ0gsWUFBWSxPQUFPLEVBQUUsUUFBUTtRQUMzQixLQUFLLENBQ0gsZUFBZSxFQUNmLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUNoQjtZQUNFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxjQUFjO1lBQ2hELGdCQUFnQixFQUFFLGVBQWUsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxVQUFVO1NBQzNFLEVBQ0QsT0FBTyxFQUNQO1lBQ0UsUUFBUSxFQUFFLElBQUk7WUFDZCxLQUFLLEVBQUUsSUFBSTtZQUNYLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGtCQUFrQixFQUFFLElBQUk7WUFDeEIsZUFBZSxFQUFFLElBQUk7WUFFckIsMENBQTBDO1lBQzFDLFFBQVEsRUFBRSxLQUFLO1lBRWYsTUFBTSxFQUFFLEtBQUs7WUFFYiwyQ0FBMkM7WUFDM0MsTUFBTSxFQUFFLElBQUk7WUFFWixvQkFBb0IsRUFBRSxlQUFlO1NBQ3RDLENBQ0YsQ0FBQztRQUVGLG9EQUFvRDtRQUNwRCxrREFBa0Q7UUFDbEQsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTtZQUNqQyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQ3BCLFVBQVUsRUFBRSxlQUFlLElBQUksQ0FBQyxNQUFNLHFCQUFxQixRQUFRLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxDQUNyRixDQUFDO1NBQ0g7UUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQy9CLElBQUksQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQztTQUN4QjthQUFNO1lBQ0wsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ2QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDcEUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO2FBQ3BEO1lBQ0QsSUFBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUN2RjtRQUVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7UUFFL0IsOENBQThDO1FBQzlDLCtEQUErRDtRQUMvRCxpR0FBaUc7UUFDakcsU0FBUyxPQUFPO1lBQ2QsbUNBQW1DO1lBQ25DLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1FBQ3hCLENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksYUFBYSxDQUFDLE1BQU0sQ0FBQztZQUN2QyxHQUFHLEVBQUUsT0FBTztZQUNaLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztZQUNkLFVBQVUsRUFBRSxLQUFLO1NBQ2xCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUk7UUFDM0IsTUFBTSxNQUFNLEdBQUc7WUFDYixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxJQUFJLEVBQUUsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNO1lBQ3ZDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztZQUNyQixJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQzdCLENBQUM7UUFFRix5QkFBeUI7UUFDekIsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFFcEMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTVCLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDNUMsa0ZBQWtGO2dCQUNsRixxQ0FBcUM7Z0JBQ3JDLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3ZDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsU0FBUyxDQUFDO2dCQUNyQyxnREFBZ0Q7Z0JBQ2hELCtEQUErRDtnQkFDL0QsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDMUQsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDL0I7U0FDRjtRQUVELElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDaEQ7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDMUIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7U0FDNUQ7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPO1FBQ0wsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQztRQUNqRCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBRXJDOzs7OztlQUtHO1lBQ0gsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLEVBQUU7Z0JBQ3hCLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLG1DQUFtQzt3QkFDOUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FDbEMsQ0FBQyxDQUFDO29CQUNILE9BQU8sSUFBSSxDQUFDO2lCQUNiO3FCQUFNO29CQUNMLE9BQU8sS0FBSyxDQUFDO2lCQUNkO1lBQ0gsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0JBQ25ELElBQ0UsR0FBRyxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRO29CQUMxQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyw0Q0FBNEMsQ0FBQyxFQUNsRTtvQkFDQSx5Q0FBeUM7b0JBQ3pDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2YsdUZBQXVGLENBQ3hGLENBQUMsQ0FBQztpQkFDSjtnQkFFRCxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFBRSxPQUFPO2lCQUFFO2dCQUVqQyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztnQkFDcEMsSUFBSSxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQzlDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2YsdUZBQXVGLENBQ3hGLENBQUMsQ0FBQztpQkFDSjtnQkFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7b0JBQzdELElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUFFLE9BQU87cUJBQUU7b0JBRWpDLDJFQUEyRTtvQkFDM0UsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO29CQUVqRixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLEVBQUU7d0JBQ3RFLGlCQUFpQjt3QkFDakIsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDO3dCQUMzQixJQUFJLGlCQUFpQixHQUFHLElBQUksQ0FBQzt3QkFFN0IsK0VBQStFO3dCQUMvRSxJQUFJLENBQUMsR0FBRyxFQUFFOzRCQUNSLCtGQUErRjs0QkFDL0YsY0FBYyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsaUNBQWlDLENBQUMsSUFBSSxLQUFLLENBQUM7NEJBQ2pGLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsaUNBQWlDLENBQUMsSUFBSSxJQUFJLENBQUM7eUJBQ3BGO3dCQUVELE1BQU0sbUJBQW1CLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDO3dCQUNsRSx5RUFBeUU7d0JBQ3pFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO3dCQUV4RixPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ25CLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsOENBQThDO1lBQzlDLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFDaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWTtRQUNWLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFBQyxlQUFlLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxlQUFlO1FBQ2IsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ1gsT0FBTyxLQUFLLENBQUM7YUFDZDtZQUNELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLEVBQUMsRUFBRSxHQUFHLENBQUMsRUFBRTtnQkFDM0UsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsbUNBQW1DO3dCQUM5RSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUNsQyxDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsT0FBTyxFQUFFLENBQUM7aUJBQ1g7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsUUFBUSxDQUFDLElBQUk7UUFDWCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdDLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7Z0JBQ2xCLEtBQUssRUFBRSxTQUFTO2dCQUNoQixpQkFBaUIsRUFBRSxJQUFJO2dCQUN2QixJQUFJLEVBQUUsSUFBSTthQUNYLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ2pCLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxPQUFPLEVBQUU7b0JBQ3RCLElBQUksR0FBRyxDQUFDLE9BQU8sS0FBSyx5QkFBeUIsR0FBRyxTQUFTLEdBQUcsWUFBWSxFQUFFO3dCQUN4RSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbkI7b0JBQ0QsSUFBSSxHQUFHLENBQUMsT0FBTyxLQUFLLHFCQUFxQixFQUFFO3dCQUN6QyxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbkI7aUJBQ0Y7Z0JBQ0QsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNuRDtnQkFDRCxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNuQjtnQkFFRCxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxPQUFPO1FBQ0wsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUMsRUFBRSxHQUFHLENBQUMsRUFBRTtnQkFDakUsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQztpQkFDbEM7Z0JBQ0QsT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsWUFBWTtRQUNWLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRS9ELGtCQUFrQjtRQUNsQixNQUFNLGNBQWMsR0FBRztZQUNyQixRQUFRLEVBQUU7Z0JBQ1IsK0JBQStCO2dCQUMvQixTQUFTLEVBQUU7b0JBQ1QsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsU0FBUyxFQUFFLFNBQVM7b0JBQ3BCLE1BQU0sRUFBRTt3QkFDTixrQkFBa0I7d0JBQ2xCLFdBQVc7d0JBQ1gsTUFBTTt3QkFDTixjQUFjLENBQUMsNkJBQTZCO3FCQUM3QztpQkFDRjthQUNGO1lBQ0QsTUFBTSxFQUFFO2dCQUNOLFlBQVksRUFBRTtvQkFDWixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsTUFBTSxFQUFFLElBQUksQ0FBQyxpQkFBaUI7aUJBQy9CO2FBQ0Y7U0FDRixDQUFDO1FBRUYsb0JBQW9CO1FBQ3BCLE1BQU0sU0FBUyxHQUFHLEVBQUMsSUFBSSxFQUFFO2dCQUN2QixJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsZUFBZTthQUM1RixFQUFDLENBQUM7UUFFSCx5REFBeUQ7UUFDekQsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUU5RCx5Q0FBeUM7UUFDekMsTUFBTSxhQUFhLEdBQUc7WUFDcEIsYUFBYSxFQUFFO2dCQUNiLEtBQUssRUFBRSxHQUFHO2dCQUNWLE9BQU8sRUFBRTtvQkFDUCxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtvQkFDbEQsUUFBUSxFQUFFLGVBQWU7b0JBQ3pCLE1BQU0sRUFBRSxTQUFTO2lCQUNsQjthQUNGO1NBQ0YsQ0FBQztRQUVGLHdCQUF3QjtRQUN4QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTtZQUN4QixPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FDaEM7UUFDRCxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFDLENBQUM7UUFDL0UsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLEdBQUcsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUMsQ0FBQztRQUV6RSwyREFBMkQ7UUFDM0QsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFN0QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRTtZQUNqQyxJQUFJLEVBQUU7Z0JBQ0osUUFBUSxFQUFFO29CQUNSLDhDQUE4QztvQkFDOUMscUZBQXFGO29CQUNyRixRQUFRLEVBQUUsY0FBYztpQkFDekI7Z0JBQ0QsUUFBUSxFQUFFO29CQUNSLFdBQVcsRUFBRTt3QkFDWCxtQkFBbUIsRUFBRSxDQUFDLGFBQWEsQ0FBQztxQkFDckM7b0JBQ0QsSUFBSSxFQUFFO3dCQUNKLGdCQUFnQixFQUFFLGFBQWE7d0JBQy9CLFVBQVUsRUFBRSxXQUFXO3dCQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLGlEQUFpRDtxQkFDaEU7b0JBQ0QsSUFBSSxFQUFFO3dCQUNKLGdCQUFnQixFQUFFLGFBQWE7d0JBQy9CLFVBQVUsRUFBRSxXQUFXO3dCQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLGlEQUFpRDtxQkFDaEU7aUJBQ0Y7YUFDRjtTQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRTtZQUMzQixJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUN4RCxvQkFBb0I7Z0JBQ3BCLE9BQU87YUFDUjtZQUNELE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLE1BQU0sRUFBRSxPQUFPO1FBQzFCLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFBRSxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFDL0IsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztRQUV2QyxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLG1CQUFtQjtZQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ3JELElBQUksR0FBRyxFQUFFO29CQUNQLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FDakIsTUFBTSxFQUFFLEdBQUcsRUFBRSxZQUFZLEdBQUcsTUFBTSxHQUFHLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FDdEUsQ0FBQztpQkFDSDtnQkFDRCxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVksQ0FBQyxJQUFJLEVBQUUsS0FBSztRQUN0QixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hELE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ25CLGdGQUFnRjtnQkFDaEYsU0FBUztnQkFDVCxrRkFBa0Y7Z0JBQ2xGLE9BQU8sRUFBRSxJQUFJO2dCQUNiLEtBQUssRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7Z0JBQzVDLElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7Z0JBQzFDLEVBQUUsRUFBRSxVQUFVLENBQUMsRUFBRTtnQkFDakIsSUFBSSxFQUFFO29CQUNKLEdBQUcsRUFBRSxVQUFVLENBQUMsSUFBSTtvQkFDcEIsZUFBZSxFQUFFLElBQUk7aUJBQ3RCO2FBQ0YsRUFBRSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDakIsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLEVBQUU7d0JBQ2hFLE1BQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7d0JBQzdFLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUMxRDtvQkFDRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ25EO2dCQUVELE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxZQUFZLENBQUMsRUFBRSxFQUFFLElBQUk7UUFDbkIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztnQkFDbkIsS0FBSyxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO2dCQUNqQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7Z0JBQy9CLEVBQUUsRUFBRSxFQUFFO2FBQ1AsRUFBRSxHQUFHLENBQUMsRUFBRTtnQkFDUCxJQUFJLEdBQUcsRUFBRTtvQkFDUCxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ2pELE9BQU8sT0FBTyxFQUFFLENBQUM7cUJBQ2xCO29CQUNELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDbkQ7Z0JBQ0QsT0FBTyxPQUFPLEVBQUUsQ0FBQztZQUNuQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPO1FBQ3ZCLG9CQUFvQjtRQUNwQixrR0FBa0c7UUFDbEcsdUJBQXVCO1FBQ3ZCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQztRQUV2QixJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3hCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO1FBQ3hCLElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxTQUFTLEVBQUU7WUFDOUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDOUQsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUM7YUFDbEM7U0FDRjthQUFNO1lBQ0wsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QjtRQUVELE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLEVBQUU7WUFDN0MsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBRXBCLEtBQUssSUFBSSxDQUFDLEdBQUcsVUFBVSxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEYsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRTt3QkFDcEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO3FCQUNyQixFQUFDLENBQUMsQ0FBQztnQkFDSixRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDL0Q7WUFFRCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztvQkFDakIsS0FBSyxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO29CQUNqQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7b0JBQy9CLElBQUksRUFBRSxRQUFRO2lCQUNmLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7b0JBQ2QsSUFBSSxHQUFHLEVBQUU7d0JBQ1AsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNuRDtvQkFFRCxJQUFJLEdBQUcsQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7d0JBQ25DLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQzFEO29CQUVELElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxJQUFJLEVBQUU7d0JBQ3ZCLElBQUksS0FBSyxHQUFHLGVBQWUsQ0FBQzt3QkFDNUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFOzRCQUMxQixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUU7Z0NBQ2xDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztnQ0FDekIsT0FBTyxLQUFLLENBQUM7NkJBQ2Q7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNyRDtvQkFFRCxPQUFPLEVBQUUsQ0FBQztnQkFDWixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDOUQsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ25CLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRTtnQkFDbEYsT0FBTyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxPQUFPLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxjQUFjLENBQUMsUUFBUSxFQUFFLEtBQUs7UUFDNUIsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzdDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUzQyxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDMUMsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNiO3FCQUFNO29CQUNMLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDakI7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsY0FBYyxDQUFDLFFBQVE7UUFDckIsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZUFBZSxDQUFDLFFBQVE7UUFDdEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUTtRQUN2QyxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUM1RCxDQUFDO0NBQ0Y7QUFFRDs7Ozs7OztHQU9HO0FBQ0gsU0FBUyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLO0lBQzFDLEtBQUssR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDNUIsTUFBTSxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUU7WUFDaEIsWUFBWSxFQUFFO2dCQUNaLEdBQUcsRUFBRSxDQUFDO2dCQUNOLEtBQUssRUFBRTtvQkFDTCxZQUFZLEVBQUU7d0JBQ1osS0FBSyxFQUFFLEVBQUU7cUJBQ1Y7aUJBQ0Y7YUFDRjtTQUNGLEVBQUMsQ0FBQztJQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDNUQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQztJQUN0RSxPQUFPLENBQUMsQ0FBQztBQUNYLENBQUM7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGdCQUFnQixDQUFDIn0=