"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
// external libs
const Bluebird = require("bluebird");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Driver = require("../driver");
class IndexDriver extends Driver {
    /**
     * @param connector     Connector used by the DAO
     * @param graphDAO      The connected GraphDAO
     * @param indexOptions  IndexDAO options
     * @param connectorData Data from the connector
     * @param indexFeatures Features of the IndexDAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO.options, connectorData);
        this.graphDAO = graphDAO;
        this.indexOptions = indexOptions;
        this.indexFeatures = indexFeatures;
    }
    /**
     * Return an IndexDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getIndexOption(key, defaultValue) {
        const value = this.indexOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Run the indexation of the external index.
     *
     * Implement only if features.external is true.
     * Optional to implement.
     *
     * @param progress Instance used to keep track of the progress
     */
    $indexSource(progress) {
        return Bluebird.resolve();
    }
    /**
     * Get a detailed schema from the index.
     *
     * Re-implement only if features.schema is true. By default the simple schema from the GraphDAO is used.
     *
     * @param type 'node' or 'edge'
     */
    $getSchema(type) {
        return this.graphDAO.getSimpleSchema().then(simpleR => {
            const types = type === 'node' ? simpleR.nodeCategories : simpleR.edgeTypes;
            // by default (if features.schema is not defined), every property is assigned to every node category/edge type
            const properties = (type === 'node' ? simpleR.nodeProperties : simpleR.edgeProperties).map(property => ({
                key: property,
                count: 1
            }));
            return types.map(t => ({ name: t, properties: properties, count: 1 }));
        });
    }
}
module.exports = IndexDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXhEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2luZGV4RHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFFckMsV0FBVztBQUNYLHNDQUF1QztBQUV2QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFJN0Isb0NBQXFDO0FBRXJDLE1BQWUsV0FBaUMsU0FBUSxNQUFTO0lBTS9EOzs7Ozs7T0FNRztJQUNILFlBQ0UsU0FBWSxFQUNaLFFBQXFELEVBQ3JELFlBQW9DLEVBQ3BDLGFBQXFDLEVBQ3JDLGFBQTRCO1FBRTVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN6QixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztRQUNqQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDTyxjQUFjLENBQUMsR0FBVyxFQUFFLFlBQXNCO1FBQzFELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDckMsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztJQUN0RCxDQUFDO0lBdUZEOzs7Ozs7O09BT0c7SUFDSSxZQUFZLENBQUMsUUFBa0I7UUFDcEMsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFVBQVUsQ0FBQyxJQUFjO1FBQzlCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDcEQsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUUzRSw4R0FBOEc7WUFDOUcsTUFBTSxVQUFVLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUN4RixRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ1gsR0FBRyxFQUFFLFFBQVE7Z0JBQ2IsS0FBSyxFQUFFLENBQUM7YUFDVCxDQUFDLENBQ0gsQ0FBQztZQUVGLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FrQkY7QUFFRCxpQkFBUyxXQUFXLENBQUMifQ==