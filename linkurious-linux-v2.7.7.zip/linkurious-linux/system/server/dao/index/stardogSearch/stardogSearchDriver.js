/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-21.
 */
'use strict';
// locals
const SparqlSearchDriver = require('../sparqlSearchDriver');
const DaoUtils = require('../../utils/daoUtils');
// services
const LKE = require('../../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
class StardogSearchDriver extends SparqlSearchDriver {
    /**
     * Search for statements matching `searchString`.
     *
     * @param {string} searchString String to search (can be just text or written in `advancedQueryDialect`)
     * @param {number} limit        Maximum number of statements we want to receive (for pagination)
     * @param {number} offset       Offset of the first result (for pagination)
     * @param {number} fuzziness    Acceptable normalized edit distance among the query and the result
     * @returns {Bluebird<string[][]>}
     */
    $doTextQuery(searchString, limit, offset, fuzziness) {
        // escape the searchString and apply the fuzziness
        const searchQuery = DaoUtils.generateLuceneQuery(searchString, fuzziness, {});
        return this.connector.$doSparqlQuery(`select distinct ?s ?p ?l ${this._fromClause} where {` +
            '?s ?p ?l. (?l ?score) <tag:stardog:api:property:textMatch> (\'' + searchQuery + '\').' +
            ' } order by desc(?score) limit ' + limit + ' offset ' + offset, { reasoning: 'disabled' }).catch(() => {
            // soft-fail. It has the habit to fail if it doesn't like the search query
            return [];
        });
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        const baseUrl = Utils.normalizeUrl(this.getGraphOption('url')) + '/admin/databases/' +
            encodeURIComponent(this.getGraphOption('repository'));
        return this.connector.$request.put('/options', { baseUrl: baseUrl, body: { 'search.enabled': '' }, json: true }, [200])
            .then(response => {
            const enabled = response.body['search.enabled'];
            if (!enabled) {
                return Errors.business('source_action_needed', 'Search is not enabled in Stardog', true);
            }
        });
    }
}
module.exports = StardogSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhcmRvZ1NlYXJjaERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvc3RhcmRvZ1NlYXJjaC9zdGFyZG9nU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDNUQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFFakQsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxtQkFBb0IsU0FBUSxrQkFBa0I7SUFFbEQ7Ozs7Ozs7O09BUUc7SUFDSCxZQUFZLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUztRQUNqRCxrREFBa0Q7UUFDbEQsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFOUUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FDbEMsNEJBQTRCLElBQUksQ0FBQyxXQUFXLFVBQVU7WUFDdEQsZ0VBQWdFLEdBQUcsV0FBVyxHQUFHLE1BQU07WUFDdkYsaUNBQWlDLEdBQUcsS0FBSyxHQUFHLFVBQVUsR0FBRyxNQUFNLEVBQUUsRUFBQyxTQUFTLEVBQUUsVUFBVSxFQUFDLENBQ3pGLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRTtZQUNYLDBFQUEwRTtZQUMxRSxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsbUJBQW1CO1lBQ2xGLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUV4RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQzNDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBQyxnQkFBZ0IsRUFBRSxFQUFFLEVBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNuRSxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFFZixNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFaEQsSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDWixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQzNDLGtDQUFrQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzdDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLG1CQUFtQixDQUFDIn0=