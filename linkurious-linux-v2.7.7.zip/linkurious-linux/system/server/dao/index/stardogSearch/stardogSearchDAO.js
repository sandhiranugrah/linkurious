/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const StardogConnector = require('../../connector/stardogConnector');
const StardogSearchDriver = require('./stardogSearchDriver');
class StardogSearchDAO extends IndexDAO {
    constructor(options, graphDao) {
        super('stardogSearch', [], [], options, {
            fuzzy: true,
            canIndexCategories: true,
            external: true,
            canCount: false,
            typing: false,
            schema: false,
            canIndexEdges: false,
            searchHitsCount: false
        }, graphDao, StardogConnector, [
            { version: '5.0.3', driver: '[latest]' },
            { version: '5.0.0', driver: StardogSearchDriver }
        ], ['stardog']);
    }
}
module.exports = StardogSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhcmRvZ1NlYXJjaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vaW5kZXgvc3RhcmRvZ1NlYXJjaC9zdGFyZG9nU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0FBQ3JFLE1BQU0sbUJBQW1CLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFN0QsTUFBTSxnQkFBaUIsU0FBUSxRQUFRO0lBQ3JDLFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUFDLGVBQWUsRUFDbkIsRUFBRSxFQUNGLEVBQUUsRUFDRixPQUFPLEVBQUU7WUFDUCxLQUFLLEVBQUUsSUFBSTtZQUNYLGtCQUFrQixFQUFFLElBQUk7WUFFeEIsUUFBUSxFQUFFLElBQUk7WUFDZCxRQUFRLEVBQUUsS0FBSztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBRWIsTUFBTSxFQUFFLEtBQUs7WUFFYixhQUFhLEVBQUUsS0FBSztZQUNwQixlQUFlLEVBQUUsS0FBSztTQUN2QixFQUNELFFBQVEsRUFDUixnQkFBZ0IsRUFDaEI7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLG1CQUFtQixFQUFDO1NBQ2hELEVBQ0QsQ0FBQyxTQUFTLENBQUMsQ0FDWixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyJ9