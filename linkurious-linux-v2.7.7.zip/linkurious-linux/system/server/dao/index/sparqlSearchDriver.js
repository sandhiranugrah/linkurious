/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-21.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // abstract methods
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// locals
const IndexDriver = require('./indexDriver');
const SparqlUtils = require('../utils/sparqlUtils');
const DaoUtils = require('../utils/daoUtils');
// timeout after which $getSchema will give up
const GET_SCHEMA_TIMEOUT = 10000; // 10 seconds
// max number of distinct categories returned by $getSchema
const SCHEMA_CATEGORY_LIMIT = 200;
// 50 statements per search query
const SEARCH_STATEMENTS_LIMIT = 50;
class SparqlSearchDriver extends IndexDriver {
    /**
     * @param {SparqlConnector} connector     Connector used by the DAO
     * @param {GraphDAO}        graphDAO      The connected Graph DAO
     * @param {any}             indexOptions  IndexDAO options
     * @param {any}             connectorData Data from the connector
     * @param {IndexFeatures}   indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        // each driver is responsible to validate its connectorData (also done in SparqlDriver)
        Utils.check.properties('connectorData', connectorData, {
            prefixToURI: { required: true, check: (k, prefixToURI) => {
                    prefixToURI.forEach((value, key) => {
                        Utils.check.string(k + '[' + key + ']', value, true);
                    });
                } },
            categoryPredicate: { required: true, check: 'nonEmpty' },
            defaultNamespace: { required: true, check: 'nonEmpty' }
        });
        this._utils = new SparqlUtils(connectorData.prefixToURI, connectorData.defaultNamespace, connectorData.categoryPredicate, this.getGraphOption('idPropertyName'));
        this._categoryPredicate = connectorData.categoryPredicate;
        this._fromClause = connector.$fromClause;
    }
    /**
     * Search for statements matching `searchString`.
     *
     * @param {string} searchString String to search (can be just text or written in `advancedQueryDialect`)
     * @param {number} limit        Maximum number of statements we want to receive (for pagination)
     * @param {number} offset       Offset of the first result (for pagination)
     * @param {number} fuzziness    Acceptable normalized edit distance among the query and the result
     * @returns {Bluebird<string[][]>}
     */
    $doTextQuery(searchString, limit, offset, fuzziness) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Search for nodes using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param {SearchOptions} options
     * @returns {Bluebird<SearchResponse>}
     */
    $search(options) {
        // nodes retrieved are sorted by importance with the statement on which it matched the query
        /**@type {LkNode[]}*/
        const foundNodes = [];
        const nodesSeen = new Set(); // Set of LkNodes ids to avoid duplicates
        let totalObjToSkip = options.from; // variable used as a count down
        let currentPage = 0;
        let moreResults = true;
        const retrieveMoreNodes = () => {
            // 1) Do a paginated search query
            return this.$doTextQuery(options.q, SEARCH_STATEMENTS_LIMIT, SEARCH_STATEMENTS_LIMIT * currentPage, options.fuzziness).then(statements => {
                if (statements.length === 0) {
                    moreResults = false;
                    return;
                }
                /**@type {Map<string, string[]>}*/ // statements indexed by their sources
                const statementsByNodeId = new Map();
                // `statements` may contain edges and/or statements with the same node id
                // 2) Filter unwanted statements away
                _.forEach(statements, statement => {
                    // if the statement is not an edge and the node id was never seen
                    if (!this._utils.statementIsAnEdge(statement) && !nodesSeen.has(statement[0])) {
                        nodesSeen.add(statement[0]);
                        statementsByNodeId.set(statement[0], statement);
                    }
                });
                const idsToRetrieve = Array.from(statementsByNodeId.keys());
                // Each statement now represent an incomplete node that we have to ask to the triple store
                // 3) Retrieve the nodes and save them along with the statement that matched the FTI query
                return ( /**@type {SparqlDriver}*/(this.graphDAO.driver)).$getNodesByURI({ ids: idsToRetrieve, reasoning: 'disabled' }).then(nodes => {
                    _.forEach(nodes, node => {
                        // 4) Ensure `options.size`
                        if (foundNodes.length >= options.size) {
                            return;
                        }
                        // 5) enforce `options.categoriesOrTypes`
                        if (DaoUtils.hasCategoriesFilter(options.categoriesOrTypes, node.categories)) {
                            return;
                        }
                        // 6) enforce `options.filter`
                        if (DaoUtils.hasPropertyValuesFilter(options.filter, node.data)) {
                            return;
                        }
                        // 7) Ensure `options.from` (unfortunately it can only be done here after the filtering)
                        if (totalObjToSkip > 0) {
                            totalObjToSkip--;
                            return;
                        }
                        foundNodes.push(node);
                    });
                });
            }).catch(error => {
                Log.warn('fallback to no more results in case of malformed query/other errors', error);
                moreResults = false;
            });
        };
        const loopPromise = () => {
            if (moreResults && foundNodes.length < options.size) {
                return retrieveMoreNodes().then(() => {
                    currentPage++;
                    return loopPromise();
                });
            }
            return Promise.resolve();
        };
        return loopPromise().then(() => {
            return {
                type: options.type,
                moreResults: moreResults,
                results: _.map(foundNodes, 'id')
            };
        });
    }
}
module.exports = SparqlSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BhcnFsU2VhcmNoRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9zcGFycWxTZWFyY2hEcml2ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYiw4QkFBOEIsQ0FBQyxtQkFBbUI7QUFFbEQsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLFNBQVM7QUFDVCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDN0MsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDcEQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFFOUMsOENBQThDO0FBQzlDLE1BQU0sa0JBQWtCLEdBQUcsS0FBSyxDQUFDLENBQUMsYUFBYTtBQUUvQywyREFBMkQ7QUFDM0QsTUFBTSxxQkFBcUIsR0FBRyxHQUFHLENBQUM7QUFFbEMsaUNBQWlDO0FBQ2pDLE1BQU0sdUJBQXVCLEdBQUcsRUFBRSxDQUFDO0FBRW5DLE1BQU0sa0JBQW1CLFNBQVEsV0FBVztJQUUxQzs7Ozs7O09BTUc7SUFDSCxZQUFZLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhO1FBQ3pFLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFdkUsdUZBQXVGO1FBQ3ZGLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUU7WUFDckQsV0FBVyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLEVBQUU7b0JBQ3RELFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7d0JBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsRUFBQztZQUNGLGlCQUFpQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3RELGdCQUFnQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO1NBQ3RELENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxXQUFXLENBQzNCLGFBQWEsQ0FBQyxXQUFXLEVBQ3pCLGFBQWEsQ0FBQyxnQkFBZ0IsRUFDOUIsYUFBYSxDQUFDLGlCQUFpQixFQUMvQixJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQ3RDLENBQUM7UUFFRixJQUFJLENBQUMsa0JBQWtCLEdBQUcsYUFBYSxDQUFDLGlCQUFpQixDQUFDO1FBQzFELElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxZQUFZLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUztRQUNqRCxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsT0FBTyxDQUFDLE9BQU87UUFDYiw0RkFBNEY7UUFDNUYscUJBQXFCO1FBQ3JCLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUV0QixNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMseUNBQXlDO1FBRXRFLElBQUksY0FBYyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxnQ0FBZ0M7UUFDbkUsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQztRQUV2QixNQUFNLGlCQUFpQixHQUFHLEdBQUcsRUFBRTtZQUM3QixpQ0FBaUM7WUFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUN0QixPQUFPLENBQUMsQ0FBQyxFQUNULHVCQUF1QixFQUN2Qix1QkFBdUIsR0FBRyxXQUFXLEVBQ3JDLE9BQU8sQ0FBQyxTQUFTLENBQ2xCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNsQixJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUMzQixXQUFXLEdBQUcsS0FBSyxDQUFDO29CQUNwQixPQUFPO2lCQUNSO2dCQUVELGtDQUFrQyxDQUFDLHNDQUFzQztnQkFDekUsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUVyQyx5RUFBeUU7Z0JBQ3pFLHFDQUFxQztnQkFDckMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLEVBQUU7b0JBQ2hDLGlFQUFpRTtvQkFDakUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3RSxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM1QixrQkFBa0IsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO3FCQUNqRDtnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFFSCxNQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBRTVELDBGQUEwRjtnQkFDMUYsMEZBQTBGO2dCQUMxRixPQUFPLEVBQUMseUJBQTBCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FDdEUsRUFBQyxHQUFHLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUMsQ0FDNUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7d0JBQ3RCLDJCQUEyQjt3QkFDM0IsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUU7NEJBQ3JDLE9BQU87eUJBQ1I7d0JBRUQseUNBQXlDO3dCQUN6QyxJQUFJLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFOzRCQUM1RSxPQUFPO3lCQUNSO3dCQUVELDhCQUE4Qjt3QkFDOUIsSUFBSSxRQUFRLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQy9ELE9BQU87eUJBQ1I7d0JBRUQsd0ZBQXdGO3dCQUN4RixJQUFJLGNBQWMsR0FBRyxDQUFDLEVBQUU7NEJBQ3RCLGNBQWMsRUFBRSxDQUFDOzRCQUNqQixPQUFPO3lCQUNSO3dCQUVELFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3hCLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNmLEdBQUcsQ0FBQyxJQUFJLENBQUMscUVBQXFFLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZGLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDdEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBRyxHQUFHLEVBQUU7WUFDdkIsSUFBSSxXQUFXLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxFQUFFO2dCQUNuRCxPQUFPLGlCQUFpQixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDbkMsV0FBVyxFQUFFLENBQUM7b0JBQ2QsT0FBTyxXQUFXLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQyxDQUFDLENBQUM7YUFDSjtZQUNELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQztRQUVGLE9BQU8sV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM3QixPQUFPO2dCQUNMLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsV0FBVyxFQUFFLFdBQVc7Z0JBQ3hCLE9BQU8sRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7YUFDakMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsQ0FBQyJ9