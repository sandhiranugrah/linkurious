/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-21.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// our libs
const StringUtils = require('../../../../lib/StringUtils').StringUtils;
// services
const LKE = require('../../../services');
const Errors = LKE.getErrors();
// locals
const SparqlSearchDriver = require('../sparqlSearchDriver');
const S_EXPRESSION_RESERVED_WORDS = ['and', 'or', 'phrase', 'match', 'fuzzy'];
const MIN_SEARCH_LENGTH_TO_SORT = 4;
class AllegroGraphSearchDriver extends SparqlSearchDriver {
    /**
     * Return true if `searchString` is an S-expression.
     * We will test the query. If it returns an HTTP status other than 200 it isn't an S-expression.
     *
     * @param {string} searchString
     * @returns {Bluebird<boolean>} resolved with `true` if `searchString` is an S-expression
     * @private
     */
    _isAnSExpression(searchString) {
        searchString = searchString.trim();
        const hasParenthesis = searchString.startsWith('(') && searchString.endsWith(')');
        let containsAReservedWord = false;
        _.forEach(S_EXPRESSION_RESERVED_WORDS, reservedWord => {
            containsAReservedWord = containsAReservedWord || searchString.includes(reservedWord);
        });
        if (hasParenthesis && containsAReservedWord) {
            return this._doFreeTextQuery(searchString, true, 1, 0).then(() => true).catch(() => false);
        }
        else {
            // we don't need to ask Allegro since it's obviously not an S-expression.
            return Promise.resolve(false);
        }
    }
    /**
     * Escape `searchString` and apply fuzziness to it if `fuzzy` is true.
     * The last token is always considered a prefix.
     *
     * If `searchString` is already a pattern query, return it directly.
     *
     * Note:
     * It's not possible to use fuzziness (~) and a wildcard (*) on the same word.
     *
     * @param {string}  searchString
     * @param {boolean} fuzzy
     * @returns {string}
     * @private
     */
    _generateFuzzyQuery(searchString, fuzzy) {
        if (/[()|*?~]/g.test(searchString)) {
            return searchString; // it's a pattern query or even an S-expression query
        }
        const tokens = StringUtils.uniqTokenize(searchString);
        searchString = '';
        for (let i = 0; i < tokens.length; i++) {
            if (i !== tokens.length - 1) {
                searchString += tokens[i] + (fuzzy ? '~' : '') + ' | ';
            }
            else {
                // last token has to be treated differently because it will be used also as a prefix
                if (fuzzy) {
                    searchString += `(${tokens[i]}~ | ${tokens[i]}*)`;
                }
                else {
                    searchString += tokens[i] + '*';
                }
            }
        }
        return searchString;
    }
    /**
     * Execute a free text query 'searchString' on AllegroGraph.
     * It uses the right endpoint depending on `isAnSExpression`.
     *
     * @param {string}  searchString
     * @param {boolean} isSExpression
     * @param {number}  limit
     * @param {number}  offset
     * @returns {Bluebird<string[][]>}
     * @private
     */
    _doFreeTextQuery(searchString, isSExpression, limit, offset) {
        // sorting may be expensive, apply only if searchString is at least 4 chars
        const sorted = searchString.length >= MIN_SEARCH_LENGTH_TO_SORT;
        const qs = { limit: limit, offset: offset, sorted: sorted };
        if (isSExpression) {
            qs.expression = searchString;
        }
        else {
            qs.pattern = searchString;
        }
        return this.connector.$request.post('/freetext', { qs }, [200]).get('body');
    }
    /**
     * Search for statements matching `searchString`.
     *
     * The `searchString` param can be any of the following kind of queries:
     * - S-expression query, e.g: (and (phrase "common lisp") (or "programming" (match "develop*")))
     * - pattern query, e.g: "common lisp" (programming | develop*)
     * - base query, e.g: helloo wor
     *
     * A base query is technically a pattern query. The only difference is that a base query doesn't
     * contain the following characters: ()|*?~
     *
     * On base queries we will apply a fuzziness according to `fuzziness`.
     *
     * S-expression query and pattern query will ignore `fuzziness` because they can apply
     * fuzziness on their own with a word granularity.
     *
     * @param {string} searchString String to search (can be just text or written in `advancedQueryDialect`)
     * @param {number} limit        Maximum number of statements we want to receive (for pagination)
     * @param {number} offset       Offset of the first result (for pagination)
     * @param {number} fuzziness    Acceptable normalized edit distance among the query and the result
     * @returns {Bluebird<string[][]>}
     */
    $doTextQuery(searchString, limit, offset, fuzziness) {
        // escape the searchString and apply the fuzziness
        const searchQuery = this._generateFuzzyQuery(searchString, fuzziness !== 0);
        // Decide which endpoint to use: 'fti:matchExpression' or 'fti:match'
        return this._isAnSExpression(searchQuery).then(isSExpression => {
            return this._doFreeTextQuery(searchQuery, isSExpression, limit, offset);
        });
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return this.connector.$request.get('/freetext/indices').then(ftiR => {
            // if there are no free-text indices in allegroGraph
            // and we are not in test mode (where the index will be created by allegroSetup)
            if (!(ftiR.statusCode === 200 && ftiR.body.length > 0 ||
                this.getIndexOption('disableIndexExistCheck'))) {
                return Errors.business('source_action_needed', 'No free-text indices found in AllegroGraph.', true);
            }
        });
    }
}
module.exports = AllegroGraphSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxsZWdyb0dyYXBoU2VhcmNoRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9hbGxlZ3JvR3JhcGhTZWFyY2gvYWxsZWdyb0dyYXBoU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsV0FBVztBQUNYLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUV2RSxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLFNBQVM7QUFDVCxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRTVELE1BQU0sMkJBQTJCLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFFOUUsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLENBQUM7QUFFcEMsTUFBTSx3QkFBeUIsU0FBUSxrQkFBa0I7SUFFdkQ7Ozs7Ozs7T0FPRztJQUNILGdCQUFnQixDQUFDLFlBQVk7UUFDM0IsWUFBWSxHQUFHLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNuQyxNQUFNLGNBQWMsR0FBRyxZQUFZLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEYsSUFBSSxxQkFBcUIsR0FBRyxLQUFLLENBQUM7UUFFbEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQywyQkFBMkIsRUFBRSxZQUFZLENBQUMsRUFBRTtZQUNwRCxxQkFBcUIsR0FBRyxxQkFBcUIsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3ZGLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxjQUFjLElBQUkscUJBQXFCLEVBQUU7WUFDM0MsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM1RjthQUFNO1lBQ0wseUVBQXlFO1lBQ3pFLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMvQjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsbUJBQW1CLENBQUMsWUFBWSxFQUFFLEtBQUs7UUFDckMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ2xDLE9BQU8sWUFBWSxDQUFDLENBQUMscURBQXFEO1NBQzNFO1FBRUQsTUFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUV0RCxZQUFZLEdBQUcsRUFBRSxDQUFDO1FBRWxCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3RDLElBQUksQ0FBQyxLQUFLLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUMzQixZQUFZLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUN4RDtpQkFBTTtnQkFDTCxvRkFBb0Y7Z0JBQ3BGLElBQUksS0FBSyxFQUFFO29CQUNULFlBQVksSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztpQkFDbkQ7cUJBQU07b0JBQ0wsWUFBWSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQ2pDO2FBQ0Y7U0FDRjtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsTUFBTTtRQUN6RCwyRUFBMkU7UUFDM0UsTUFBTSxNQUFNLEdBQUcsWUFBWSxDQUFDLE1BQU0sSUFBSSx5QkFBeUIsQ0FBQztRQUVoRSxNQUFNLEVBQUUsR0FBRyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDLENBQUM7UUFDMUQsSUFBSSxhQUFhLEVBQUU7WUFDakIsRUFBRSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUM7U0FDOUI7YUFBTTtZQUNMLEVBQUUsQ0FBQyxPQUFPLEdBQUcsWUFBWSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXFCRztJQUNILFlBQVksQ0FBQyxZQUFZLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTO1FBQ2pELGtEQUFrRDtRQUNsRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUU1RSxxRUFBcUU7UUFDckUsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQzdELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzFFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEUsb0RBQW9EO1lBQ3BELGdGQUFnRjtZQUNoRixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFLLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO2dCQUNqRCxJQUFJLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUMzQyw2Q0FBNkMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN4RDtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyx3QkFBd0IsQ0FBQyJ9