/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-22.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const AllegroGraphConnector = require('../../connector/allegroGraphConnector');
const AllegroGraphSearchDriver = require('./allegroGraphSearchDriver');
class AllegroGraphSearchDAO extends IndexDAO {
    constructor(options, graphDao) {
        super('allegroGraphSearch', [], ['disableIndexExistCheck'], // for tests only
        options, {
            external: true,
            schema: false,
            canCount: false,
            typing: false,
            fuzzy: true,
            canIndexEdges: false,
            canIndexCategories: true,
            advancedQueryDialect: 'allegro',
            searchHitsCount: false
        }, graphDao, AllegroGraphConnector, [
            { version: '6.2.3', driver: '[latest]' },
            { version: '6.0.0', driver: AllegroGraphSearchDriver }
        ], ['allegroGraph']);
    }
}
module.exports = AllegroGraphSearchDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxsZWdyb0dyYXBoU2VhcmNoREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9pbmRleC9hbGxlZ3JvR3JhcGhTZWFyY2gvYWxsZWdyb0dyYXBoU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLHFCQUFxQixHQUFHLE9BQU8sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0FBQy9FLE1BQU0sd0JBQXdCLEdBQUcsT0FBTyxDQUFDLDRCQUE0QixDQUFDLENBQUM7QUFFdkUsTUFBTSxxQkFBc0IsU0FBUSxRQUFRO0lBQzFDLFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsS0FBSyxDQUFDLG9CQUFvQixFQUN4QixFQUFFLEVBQ0YsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLGlCQUFpQjtRQUM3QyxPQUFPLEVBQUU7WUFDUCxRQUFRLEVBQUUsSUFBSTtZQUNkLE1BQU0sRUFBRSxLQUFLO1lBQ2IsUUFBUSxFQUFFLEtBQUs7WUFDZixNQUFNLEVBQUUsS0FBSztZQUNiLEtBQUssRUFBRSxJQUFJO1lBQ1gsYUFBYSxFQUFFLEtBQUs7WUFDcEIsa0JBQWtCLEVBQUUsSUFBSTtZQUN4QixvQkFBb0IsRUFBRSxTQUFTO1lBQy9CLGVBQWUsRUFBRSxLQUFLO1NBQ3ZCLEVBQ0QsUUFBUSxFQUNSLHFCQUFxQixFQUNyQjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsd0JBQXdCLEVBQUM7U0FDckQsRUFDRCxDQUFDLGNBQWMsQ0FBQyxDQUNqQixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQyJ9