"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-08.
 */
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const DAO = require("../DAO");
/**
 * IndexFeatures
 *
 * @property external               Whether the index stays in sync with the graph database automatically
 * @property schema                 Whether the index is able to produce a full schema
 * @property canCount               Whether the index can count nodes and edges
 * @property typing                 Whether the schema is able to fetch type information for properties
 * @property fuzzy                  Whether the index allows fuzzy search queries
 * @property canIndexEdges          Whether the index can index edges
 * @property canIndexCategories     Whether the index can index categories
 * @property [advancedQueryDialect] Whether the index provide advanced queries and with which 'dialect'
 * @property searchHitsCount        Whether the search result will contain 'totalHits' or 'moreResults'
 */
/**
 * SearchOptions
 *
 * @property type                The item type to search
 * @property q                   Search query
 * @property [fuzziness=0.1]     Fuzziness value (`0` means exact match, `1` completely fuzzy)
 * @property [size]              Page size (maximum number of returned items)
 * @property [from=0]            Offset from the first result
 * @property [categoriesOrTypes] Exclusive list of edge types or node categories to restrict the search on (use `[no_category]` to search nodes with no categories)
 * @property [filter]            Array of pairs key-value used to filter the result. The keys represent object properties and the values that should match for each property
 */
/**
 * SearchResponse
 *
 * @property type            'node' or 'edge'
 * @property [totalHits]     Number of search results matching the search query (available if features.searchHitsCount is true)
 * @property [moreResults]   Whether other results were not returned due to pagination (available if features.searchHitsCount is false)
 * @property [alternativeId] The property to match `results` on (instead of the actual IDs)
 * @property results         An array of IDs that matched the search query
 */
class IndexDAO extends DAO {
    /**
     * @param vendor               Name of the vendor for this DAO (e.g.: neo4j, elasticSearch)
     * @param requiredOptions      List of required option properties
     * @param availableOptions     List of available option properties
     * @param options              DAO constructor options
     * @param features             Features of the IndexDAO
     * @param [graphDao]           The connected GraphDAO (TODO #987 optional to support old DAOs, see #634)
     * @param [connectors]         Connectors of the DAO (TODO #987 optional to support old DAOs, see #634)
     * @param [drivers]            Driver to use from a given version (TODO #987 optional to support old DAOs, see #634)
     * @param [supportedGraphDAOs] List of supported graphDAOs (TODO #987 optional to support old DAOs, see #634)
     */
    constructor(vendor, requiredOptions, availableOptions, options, features, graphDao, connectors, drivers, supportedGraphDAOs) {
        super('Index', vendor, requiredOptions.concat(['indexName']), availableOptions.concat(['indexName', 'skipEdgeIndexation']), options, graphDao, connectors, drivers);
        if (!features) {
            throw Errors.technical('bug', 'IndexDAO: "features" is required');
        }
        this.features = features;
        Utils.check.properties('features', this.features, {
            external: { required: true, type: 'boolean' },
            schema: { required: true, type: 'boolean' },
            canCount: { required: true, type: 'boolean' },
            typing: { required: true, type: 'boolean' },
            fuzzy: { required: true, type: 'boolean' },
            canIndexEdges: { required: true, type: 'boolean' },
            canIndexCategories: { required: true, type: 'boolean' },
            advancedQueryDialect: { check: 'nonEmpty' },
            searchHitsCount: { required: true, type: 'boolean' }
        });
        if (Utils.hasValue(supportedGraphDAOs) &&
            Utils.hasValue(graphDao) &&
            !supportedGraphDAOs.includes(graphDao.vendor)) {
            throw Errors.business('invalid_parameter', 'Index vendor ' +
                vendor +
                ' is not compatible with the graph vendor "' +
                graphDao.vendor +
                '". Please use one of the following instead: "' +
                supportedGraphDAOs.join('", "') +
                '".');
        }
    }
    /**
     * Create an IndexDAO instance.
     *
     * @param vendor   Vendor name
     * @param options  IndexDAO constructor options
     * @param graphDao The connected Graph DAO
     */
    static createIndexDAOInstance(vendor, options, graphDao) {
        return DAO.createDAOInstance('Index', vendor, options, graphDao);
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param options
     */
    search(options) {
        if (Utils.hasValue(options.categoriesOrTypes) && _.isEmpty(options.categoriesOrTypes)) {
            // nothing to search
            return Bluebird.resolve({ type: options.type, totalHits: 0, results: [] });
        }
        if (options.type === 'edge' && !this.features.canIndexEdges) {
            // edges are not indexed
            return Bluebird.resolve({ type: options.type, totalHits: 0, results: [] });
        }
        return this.$search(options);
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param options
     */
    $search(options) {
        // TODO #987 remove these functions from the DAO once there are no more old DAOs
        return this.driver.$search(options);
    }
    /**
     * Get the number of nodes or edges in the search index.
     *
     * @param type 'node' or 'edge'
     */
    getSize(type) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting nodes and edges is not supported ' + 'by ' + this.vendor + '.', true);
        }
        else {
            return this.$getSize(type);
        }
    }
    /**
     * Get the number of nodes or edges in the search index.
     *
     * @param type 'node' or 'edge'
     */
    $getSize(type) {
        return this.driver.$getSize(type);
    }
    /**
     * Delete an entry. Do nothing if the entry to delete was not found.
     *
     * @param id   ID of the entry to delete
     * @param type 'node' or 'edge'
     */
    deleteEntry(id, type) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            return this.$deleteEntry(id, type);
        });
    }
    /**
     * Delete an entry. Do nothing if the entry to delete was not found.
     *
     * @param id   ID of the entry to delete
     * @param type 'node' or 'edge'
     */
    $deleteEntry(id, type) {
        return this.driver.$deleteEntry(id, type);
    }
    /**
     * Index an entry if it doesn't exist or update it if it does.
     *
     * @param type  'node' or 'edge'
     * @param entry Entries to add
     */
    upsertEntry(type, entry) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            return this.$upsertEntry(type, entry);
        });
    }
    /**
     * Remove all the entries from the index and make a new one.
     */
    clear() {
        if (this.features.external) {
            return Bluebird.resolve();
        }
        return this.$deleteIfExists().then(() => {
            return this.$createIndex();
        });
    }
    /**
     * Index an entry if it doesn't exist or update it if it does.
     *
     * @param type  'node' or 'edge'
     * @param entry Entries to add
     */
    $upsertEntry(type, entry) {
        return this.driver.$upsertEntry(type, entry);
    }
    /**
     * Delete the index if it exists.
     */
    $deleteIfExists() {
        return this.driver.$deleteIfExists();
    }
    /**
     * Create the index.
     */
    $createIndex() {
        return this.driver.$createIndex();
    }
    /**
     * Index nodes or edges.
     *
     * @param type    'node' or 'edge'
     * @param entries Entries to add
     */
    addEntries(type, entries) {
        return Bluebird.resolve().then(() => {
            if (this.features.external) {
                return;
            }
            // nothing to do
            if (entries.length === 0) {
                return;
            }
            return this.$addEntries(type, entries);
        });
    }
    /**
     * Index nodes or edges.
     *
     * @param type    'node' or 'edge'
     * @param entries Entries to add
     */
    $addEntries(type, entries) {
        return this.driver.$addEntries(type, entries);
    }
    /**
     * Commit the changes to the index.
     */
    commit() {
        if (this.features.external) {
            return Bluebird.resolve();
        }
        return this.$commit();
    }
    /**
     * Commit the changes to the index.
     */
    $commit() {
        return Utils.retryPromise('Commit write to search index', () => this.driver.$commit(), {
            delay: 3000,
            retries: 5
        });
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     */
    indexSource(progress) {
        return Bluebird.resolve().then(() => {
            if (!this.features.external) {
                return;
            }
            return this.$indexSource(progress);
        });
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     */
    $indexSource(progress) {
        return this.driver.$indexSource(progress);
    }
    /**
     * Get a detailed schema from the index.
     *
     * @param type 'node' or 'edge'
     */
    getSchema(type) {
        return this.$getSchema(type);
    }
    /**
     * Get a detailed schema from the index.
     *
     * @param type 'node' or 'edge'
     */
    $getSchema(type) {
        return this.driver.$getSchema(type);
    }
    /**
     * Get the type of the properties of nodes and edges.
     * Return an object with the property names as keys and the type of those properties as values.
     *
     * Possible returned type values are:
     * - string
     * - integer
     * - float
     * - boolean
     * - date
     *
     * @param type 'node' or 'edge'
     */
    getPropertyTypes(type) {
        if (!this.features.typing) {
            return Bluebird.resolve({});
        }
        return this.$getPropertyTypes(type);
    }
    /**
     * Get the type of the properties of nodes and edges.
     * Return an object with the property names as keys and the type of those properties as values.
     *
     * Possible returned type values are:
     * - string
     * - integer
     * - float
     * - boolean
     * - date
     *
     * @param type 'node' or 'edge'
     */
    $getPropertyTypes(type) {
        return this.driver.$getPropertyTypes(type);
    }
}
module.exports = IndexDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXhEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L2luZGV4REFPLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCxzQ0FBdUM7QUFDdkMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUkvQiw4QkFBK0I7QUFFL0I7Ozs7Ozs7Ozs7OztHQVlHO0FBRUg7Ozs7Ozs7Ozs7R0FVRztBQUVIOzs7Ozs7OztHQVFHO0FBRUgsTUFBZSxRQUF3RCxTQUFRLEdBQVM7SUFHdEY7Ozs7Ozs7Ozs7T0FVRztJQUNILFlBQ0UsTUFBYyxFQUNkLGVBQXlCLEVBQ3pCLGdCQUEwQixFQUMxQixPQUErQixFQUMvQixRQUF1QixFQUN2QixRQUFzRCxFQUN0RCxVQUEyRCxFQUMzRCxPQUEyRSxFQUMzRSxrQkFBNkI7UUFFN0IsS0FBSyxDQUNILE9BQU8sRUFDUCxNQUFNLEVBQ04sZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQ3JDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDLEVBQzVELE9BQU8sRUFDUCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE9BQU8sQ0FDUixDQUFDO1FBRUYsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsa0NBQWtDLENBQUMsQ0FBQztTQUNuRTtRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO1FBQ3pCLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2hELFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMzQyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDekMsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzNDLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN6QyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDeEMsYUFBYSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ2hELGtCQUFrQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3JELG9CQUFvQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN6QyxlQUFlLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7U0FDbkQsQ0FBQyxDQUFDO1FBRUgsSUFDRSxLQUFLLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDO1lBQ2xDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQ3hCLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFDN0M7WUFDQSxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixlQUFlO2dCQUNiLE1BQU07Z0JBQ04sNENBQTRDO2dCQUM1QyxRQUFRLENBQUMsTUFBTTtnQkFDZiwrQ0FBK0M7Z0JBQy9DLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQy9CLElBQUksQ0FDUCxDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUNsQyxNQUFjLEVBQ2QsT0FBK0IsRUFDL0IsUUFBcUQ7UUFFckQsT0FBTyxHQUFHLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUc5RCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLE9BQXNCO1FBQ2xDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQ3JGLG9CQUFvQjtZQUNwQixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1NBQzFFO1FBRUQsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO1lBQzNELHdCQUF3QjtZQUN4QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1NBQzFFO1FBRUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLE9BQU8sQ0FBQyxPQUFzQjtRQUNuQyxnRkFBZ0Y7UUFDaEYsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLE9BQU8sQ0FBQyxJQUFjO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGVBQWUsRUFDZiw0Q0FBNEMsR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQ3hFLElBQUksQ0FDTCxDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1QjtJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksUUFBUSxDQUFDLElBQWM7UUFDNUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXLENBQUMsRUFBVSxFQUFFLElBQWM7UUFDM0MsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUMxQixPQUFPO2FBQ1I7WUFFRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksWUFBWSxDQUFDLEVBQVUsRUFBRSxJQUFjO1FBQzVDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFdBQVcsQ0FBQyxJQUFjLEVBQUUsS0FBc0I7UUFDdkQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNsQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUMxQixPQUFPO2FBQ1I7WUFFRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSztRQUNWLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFDMUIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCxPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ3RDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksWUFBWSxDQUFDLElBQWMsRUFBRSxLQUFzQjtRQUN4RCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxlQUFlO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxZQUFZO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsSUFBYyxFQUFFLE9BQTRCO1FBQzVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtnQkFDMUIsT0FBTzthQUNSO1lBRUQsZ0JBQWdCO1lBQ2hCLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ3hCLE9BQU87YUFDUjtZQUVELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXLENBQUMsSUFBYyxFQUFFLE9BQTRCO1FBQzdELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQzFCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVEOztPQUVHO0lBQ0ksT0FBTztRQUNaLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQyw4QkFBOEIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQ3JGLEtBQUssRUFBRSxJQUFJO1lBQ1gsT0FBTyxFQUFFLENBQUM7U0FDWCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFdBQVcsQ0FBQyxRQUFrQjtRQUNuQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtnQkFDM0IsT0FBTzthQUNSO1lBRUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxZQUFZLENBQUMsUUFBa0I7UUFDcEMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFNBQVMsQ0FBQyxJQUFjO1FBQzdCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFVBQVUsQ0FBQyxJQUFjO1FBQzlCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNJLGdCQUFnQixDQUFDLElBQWM7UUFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO1lBQ3pCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSSxpQkFBaUIsQ0FBQyxJQUFjO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QyxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxRQUFRLENBQUMifQ==