/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
// locals
const Neo4jSearch300Driver = require('./neo4jSearch300Driver');
const CypherUtils = require('../../utils/cypherUtils');
const DaoUtils = require('../../utils/daoUtils');
/**
 * From Neo4JSearch 3.3.0 we can use the following procedures instead of the 'START' clause:
 * - db.index.explicit.auto.searchNodes
 * - db.index.explicit.auto.searchRelationships
 */
class Neo4jSearch330Driver extends Neo4jSearch300Driver {
    /**
     * Build the query for $search.
     *
     * Procedures from:
     * https://neo4j.com/docs/developer-manual/3.3/cypher/schema/index/#explicit-indexes-procedures
     *
     * @param {string} type         'node' or 'edge'
     * @param {string} searchString Query that will be forwarded to the index. It has to be a fielded lucene query
     * @param {SearchOptions}       options
     * @returns {string}
     */
    $buildSearchQuery(type, searchString, options) {
        const sProcedure = type === 'node'
            ? 'db.index.explicit.auto.searchNodes'
            : 'db.index.explicit.auto.searchRelationships';
        const sType = type === 'node' ? 'node' : 'relationship';
        const whereClauses = [];
        if (Utils.hasValue(options.categoriesOrTypes)) {
            if (type === 'node') {
                // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
                const readableCategories = _.filter(options.categoriesOrTypes, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
                let categoryClause = 'ANY (l in labels(i) WHERE l in ' +
                    CypherUtils.encodeValue(readableCategories) + ')';
                // if we can read nodes with no categories
                if (options.categoriesOrTypes.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                    categoryClause += ' OR size(labels(i)) = 0';
                }
                whereClauses.push(categoryClause);
            }
            else {
                const readableTypes = options.categoriesOrTypes;
                whereClauses.push(`type(i) in ${CypherUtils.encodeValue(readableTypes)}`);
            }
        }
        if (Utils.hasValue(options.filter)) {
            for (let i = 0; i < options.filter.length; i++) {
                const filter = options.filter[i];
                whereClauses.push(`toLower(i.${CypherUtils.encodeName(filter[0])}) ` +
                    `CONTAINS toLower(${CypherUtils.encodeValue(filter[1])})`);
            }
        }
        let sWhere = '';
        if (whereClauses.length > 0) {
            sWhere += `WITH i, weight WHERE (${whereClauses.join(') AND (')}) `;
        }
        return `CALL ${sProcedure}(${CypherUtils.encodeValue(searchString)}) ` +
            `YIELD ${sType} as i, weight ` +
            sWhere +
            `RETURN i, weight ORDER BY weight DESC SKIP ${options.from} LIMIT ${options.size}`;
    }
}
module.exports = Neo4jSearch330Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2gzMzBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoMzMwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLFNBQVM7QUFDVCxNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQy9ELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ3ZELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBRWpEOzs7O0dBSUc7QUFDSCxNQUFNLG9CQUFxQixTQUFRLG9CQUFvQjtJQUVyRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsaUJBQWlCLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQzNDLE1BQU0sVUFBVSxHQUFHLElBQUksS0FBSyxNQUFNO1lBQ2hDLENBQUMsQ0FBQyxvQ0FBb0M7WUFDdEMsQ0FBQyxDQUFDLDRDQUE0QyxDQUFDO1FBQ2pELE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO1FBRXhELE1BQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUV4QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7WUFDN0MsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNuQiwwREFBMEQ7Z0JBQzFELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQzNELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO2dCQUVwRCxJQUFJLGNBQWMsR0FBRyxpQ0FBaUM7b0JBQ3BELFdBQVcsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQ3BELDBDQUEwQztnQkFDMUMsSUFBSSxPQUFPLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFO29CQUM3RSxjQUFjLElBQUkseUJBQXlCLENBQUM7aUJBQzdDO2dCQUNELFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDbkM7aUJBQU07Z0JBQ0wsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDO2dCQUVoRCxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDM0U7U0FDRjtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM5QyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxZQUFZLENBQUMsSUFBSSxDQUNmLGFBQWEsV0FBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDbEQsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FDMUQsQ0FBQzthQUNIO1NBQ0Y7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUMzQixNQUFNLElBQUkseUJBQXlCLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztTQUNyRTtRQUVELE9BQU8sUUFBUSxVQUFVLElBQUksV0FBVyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSTtZQUNwRSxTQUFTLEtBQUssZ0JBQWdCO1lBQzlCLE1BQU07WUFDTiw4Q0FBOEMsT0FBTyxDQUFDLElBQUksVUFBVSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDdkYsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQyJ9