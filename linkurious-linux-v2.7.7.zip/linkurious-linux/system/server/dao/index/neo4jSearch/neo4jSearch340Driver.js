"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2018
 *
 * - Created on 2019-01-07.
 */
// services
const LKE = require("../../../services");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const ExternalIndexDriver = require("../externalIndexDriver");
/**
 * From Neo4JSearch 3.5.0 we don't use anymore Neo4j explicit indices
 */
class Neo4jSearch350Driver extends ExternalIndexDriver {
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        throw Errors.business('source_action_needed', 'Neo4jSearch is not supported from Neo4j 3.4.0 to Neo4j 3.5.0 included. ' +
            'Neo4jSearch is supported from Neo4j 3.5.1 and above.');
    }
    $search(options) {
        return Utils.NOT_IMPLEMENTED();
    }
    $getPropertyTypes(type) {
        return Utils.NOT_IMPLEMENTED();
    }
    $getSize(type) {
        return Utils.NOT_IMPLEMENTED();
    }
}
module.exports = Neo4jSearch350Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2gzNDBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoMzQwRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUtILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUsvQiw4REFBK0Q7QUFFL0Q7O0dBRUc7QUFDSCxNQUFNLG9CQUFxQixTQUFRLG1CQUFtQztJQUNwRSxZQUNFLFNBQXlCLEVBQ3pCLFFBQXFELEVBQ3JELFlBQW9DLEVBQ3BDLGFBQXFDLEVBQ3JDLGFBQTRCO1FBRTVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDdkUsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixzQkFBc0IsRUFDdEIseUVBQXlFO1lBQ3ZFLHNEQUFzRCxDQUN6RCxDQUFDO0lBQ0osQ0FBQztJQUVNLE9BQU8sQ0FBQyxPQUFzQjtRQUNuQyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRU0saUJBQWlCLENBQUMsSUFBYztRQUNyQyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRU0sUUFBUSxDQUFDLElBQWM7UUFDNUIsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztDQUNGO0FBRUQsaUJBQVMsb0JBQW9CLENBQUMifQ==