/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// locals
const Neo4jSearchDriver = require('./neo4jSearchDriver');
/**
 * In Neo4JSearch 3.0.0 the configuration keys were renamed, e.g:
 * "node_auto_indexing" got renamed to "dbms.auto_index.nodes.enabled"
 */
class Neo4jSearch300Driver extends Neo4jSearchDriver {
    /**
     * Neo4j configuration key that defines whether the automatic
     * explicit index is enabled for nodes.
     *
     * @type {string}
     */
    get $nodeIndexEnabledConfKey() {
        return 'dbms.auto_index.nodes.enabled';
    }
    /**
     * Neo4j configuration key that defines the property keys
     * indexed by the automatic explicit index for nodes.
     *
     * @type {string}
     */
    get $nodeIndexPropertyListConfKey() {
        return 'dbms.auto_index.nodes.keys';
    }
    /**
     * @type {string}
     */
    get $edgeIndexEnabledConfKey() {
        return 'dbms.auto_index.relationships.enabled';
    }
    /**
     * @type {string}
     */
    get $edgeIndexPropertyListConfKey() {
        return 'dbms.auto_index.relationships.keys';
    }
}
module.exports = Neo4jSearch300Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2gzMDBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoMzAwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFFekQ7OztHQUdHO0FBQ0gsTUFBTSxvQkFBcUIsU0FBUSxpQkFBaUI7SUFFbEQ7Ozs7O09BS0c7SUFDSCxJQUFJLHdCQUF3QjtRQUMxQixPQUFPLCtCQUErQixDQUFDO0lBQ3pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUksNkJBQTZCO1FBQy9CLE9BQU8sNEJBQTRCLENBQUM7SUFDdEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSx3QkFBd0I7UUFDMUIsT0FBTyx1Q0FBdUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLDZCQUE2QjtRQUMvQixPQUFPLG9DQUFvQyxDQUFDO0lBQzlDLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUMifQ==