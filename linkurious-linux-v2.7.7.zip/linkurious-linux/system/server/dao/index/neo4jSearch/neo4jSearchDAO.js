/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// locals
const IndexDAO = require('../indexDAO');
const Neo4jHTTPConnector = require('../../connector/neo4jHTTPConnector');
const Neo4jBoltConnector = require('../../connector/neo4jBoltConnector');
const Neo4jSearchDriver = require('./neo4jSearchDriver');
const Neo4jSearch300Driver = require('./neo4jSearch300Driver');
const Neo4jSearch330Driver = require('./neo4jSearch330Driver');
const Neo4jSearch340Driver = require('./neo4jSearch340Driver');
const Neo4jSearch350Driver = require('./neo4jSearch350Driver');
class Neo4jSearch extends IndexDAO {
    /**
     * @param {object}   options
     * @param {boolean}  [options.initialization=true] Whether to perform the actual indexation on "start indexation" or just refresh the schema
     * @param {string[]} [options.categoriesToIndex]   List of node categories to index (empty array means index everything)
     * @param {string[]} [options.edgeTypesToIndex]    List of edge types to index (empty array means index everything)
     * @param {string}   [options.nodeIndexName]       Name of the index to use to search nodes (defaults to the first index created among the available indices)
     * @param {string}   [options.edgeIndexName]       Name of the index to use to search edges (defaults to the first index created among the available indices)
     * @param {boolean}  [options.indexEdges]          Whether to create or use an edge index
     * @param {boolean}  [options.simplifiedSearch]    Whether phrase prefix search is enabled
     * @param {GraphDAO} graphDao                      The connected Graph DAO
     */
    constructor(options, graphDao) {
        const useBolt = graphDao.getOption('url').toLowerCase().startsWith('bolt');
        super('neo4jSearch', [], [
            'initialization',
            'categoriesToIndex',
            'edgeTypesToIndex',
            'nodeIndexName',
            'edgeIndexName',
            'indexEdges',
            'simplifiedSearch',
            // @backward-compatibility (No longer used since Neo4j 3.5 full-text indices)
            'batchSize',
            'numberOfThreads',
            'initialOffsetNodes',
            'initialOffsetEdges'
        ], options, {
            fuzzy: true,
            external: true,
            canCount: false,
            typing: false,
            schema: false,
            canIndexEdges: true,
            canIndexCategories: false,
            advancedQueryDialect: 'lucene',
            searchHitsCount: false
        }, graphDao, useBolt ? Neo4jBoltConnector : [Neo4jBoltConnector, Neo4jHTTPConnector], [
            { version: '3.5.3', driver: '[latest]' },
            { version: '3.5.1', driver: Neo4jSearch350Driver },
            { version: '3.4.0', driver: Neo4jSearch340Driver },
            { version: '3.3.0', driver: Neo4jSearch330Driver },
            { version: '3.0.0', driver: Neo4jSearch300Driver },
            { version: '2.1.5', driver: Neo4jSearchDriver }
        ], ['neo4j']);
    }
}
module.exports = Neo4jSearch;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2hEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBQ3pFLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFDekUsTUFBTSxpQkFBaUIsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUN6RCxNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQy9ELE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDL0QsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUMvRCxNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBRS9ELE1BQU0sV0FBWSxTQUFRLFFBQVE7SUFFaEM7Ozs7Ozs7Ozs7T0FVRztJQUNILFlBQVksT0FBTyxFQUFFLFFBQVE7UUFDM0IsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFM0UsS0FBSyxDQUFDLGFBQWEsRUFDakIsRUFBRSxFQUNGO1lBQ0UsZ0JBQWdCO1lBQ2hCLG1CQUFtQjtZQUNuQixrQkFBa0I7WUFDbEIsZUFBZTtZQUNmLGVBQWU7WUFDZixZQUFZO1lBQ1osa0JBQWtCO1lBRWxCLDZFQUE2RTtZQUM3RSxXQUFXO1lBQ1gsaUJBQWlCO1lBQ2pCLG9CQUFvQjtZQUNwQixvQkFBb0I7U0FDckIsRUFDRCxPQUFPLEVBQ1A7WUFDRSxLQUFLLEVBQUUsSUFBSTtZQUNYLFFBQVEsRUFBRSxJQUFJO1lBQ2QsUUFBUSxFQUFFLEtBQUs7WUFDZixNQUFNLEVBQUUsS0FBSztZQUNiLE1BQU0sRUFBRSxLQUFLO1lBQ2IsYUFBYSxFQUFFLElBQUk7WUFDbkIsa0JBQWtCLEVBQUUsS0FBSztZQUN6QixvQkFBb0IsRUFBRSxRQUFRO1lBQzlCLGVBQWUsRUFBRSxLQUFLO1NBQ3ZCLEVBQ0QsUUFBUSxFQUNSLE9BQU8sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsa0JBQWtCLENBQUMsRUFDdkU7WUFDRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBQztZQUN0QyxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLG9CQUFvQixFQUFDO1lBQ2hELEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsb0JBQW9CLEVBQUM7WUFDaEQsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxvQkFBb0IsRUFBQztZQUNoRCxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLG9CQUFvQixFQUFDO1lBQ2hELEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsaUJBQWlCLEVBQUM7U0FDOUMsRUFDRCxDQUFDLE9BQU8sQ0FBQyxDQUNWLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyJ9