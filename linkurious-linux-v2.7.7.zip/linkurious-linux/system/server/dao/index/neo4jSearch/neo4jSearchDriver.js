/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
// locals
const IndexDriver = require('../indexDriver');
const CypherUtils = require('../../utils/cypherUtils');
const DaoUtils = require('../../utils/daoUtils');
const NODE_AUTO_INDEX_CONFIG = {
    'name': 'node_auto_index',
    'config': {
        'type': 'fulltext',
        'provider': 'lucene',
        'to_lower_case': 'true'
        // 'analyzer': 'org.apache.lucene.analysis.standard.StandardAnalyzer'
    }
};
const RELATIONSHIP_AUTO_INDEX_CONFIG = {
    'name': 'relationship_auto_index',
    'config': {
        'type': 'fulltext',
        'provider': 'lucene',
        'to_lower_case': 'true'
    }
};
const DEFAULT_BATCH_SIZE = 100000;
const DEFAULT_NUMBER_OF_THREADS = 4;
class Neo4jSearchDriver extends IndexDriver {
    /**
     * @param {CypherConnector} connector     Connector used by the DAO
     * @param {GraphDAO}        graphDAO      The connected Graph DAO
     * @param {any}             indexOptions  IndexDAO options
     * @param {any}             connectorData Data from the connector
     * @param {IndexFeatures}   indexFeatures Features of the Index DAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this._batchSize = this.getIndexOption('batchSize', DEFAULT_BATCH_SIZE);
        this._numberOfThreads = this.getIndexOption('numberOfThreads', DEFAULT_NUMBER_OF_THREADS);
        this._initialization = this.getIndexOption('initialization', true);
        this._categoriesToIndex = this.getIndexOption('categoriesToIndex');
        this._edgeTypesToIndex = this.getIndexOption('edgeTypesToIndex');
    }
    /**
     * Build the query for $search.
     *
     * @param {string} type         'node' or 'edge'
     * @param {string} searchString Query that will be forwarded to the index. It has to be a fielded lucene query
     * @param {SearchOptions}       options
     * @returns {string}
     */
    $buildSearchQuery(type, searchString, options) {
        const sProcedure = type === 'node'
            ? 'START i=node:node_auto_index'
            : 'START i=relationship:relationship_auto_index';
        const whereClauses = [];
        if (Utils.hasValue(options.categoriesOrTypes)) {
            if (type === 'node') {
                // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
                const readableCategories = _.filter(options.categoriesOrTypes, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
                let categoryClause = 'ANY (l in labels(i) WHERE l in ' +
                    CypherUtils.encodeValue(readableCategories) + ')';
                // if we can read nodes with no categories
                if (options.categoriesOrTypes.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                    categoryClause += ' OR size(labels(i)) = 0';
                }
                whereClauses.push(categoryClause);
            }
            else {
                const readableTypes = options.categoriesOrTypes;
                whereClauses.push(`type(i) in ${CypherUtils.encodeValue(readableTypes)}`);
            }
        }
        if (Utils.hasValue(options.filter)) {
            for (let i = 0; i < options.filter.length; i++) {
                const filter = options.filter[i];
                whereClauses.push(`toLower(i.${CypherUtils.encodeName(filter[0])}) ` +
                    `CONTAINS toLower(${CypherUtils.encodeValue(filter[1])})`);
            }
        }
        let sWhere = '';
        if (whereClauses.length > 0) {
            sWhere += `WHERE (${whereClauses.join(') AND (')}) `;
        }
        return `${sProcedure}(${CypherUtils.encodeValue(searchString)}) ` +
            'WITH i ' +
            sWhere +
            `RETURN i SKIP ${options.from} LIMIT ${options.size}`;
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param {SearchOptions} options
     * @returns {Bluebird<SearchResponse>}
     */
    $search(options) {
        // if edge indexation is not enabled and we search for an edge we silently fail
        if (options.type === 'edge' && !this.edgeIndexation) {
            return Promise.resolve({ type: options.type, moreResults: false, results: [] });
        }
        options.size++; // we ask one extra item to see if there are more results
        let query = this.$buildSearchQuery(options.type, options.q, options);
        // first we test it as it is, in case it's already in lucene syntax
        return this.connector.$doCypherQuery(query).catch(() => {
            // we silently ignore any error
            // it's not an advanced search query, so we will try to build it
            // we need to apply the search query to every indexed property
            const properties = options.type === 'node'
                ? this.indexedNodePropertyKeys
                : this.indexedEdgePropertyKeys;
            const luceneQuery = DaoUtils.generateLuceneQuery(options.q, options.fuzziness, { fields: properties });
            query = this.$buildSearchQuery(options.type, luceneQuery, options);
            return this.connector.$doCypherQuery(query);
        }).then(response => {
            let items;
            if (options.type === 'node') {
                items = _.map(response.results, record => record.nodes[0]);
            }
            else {
                items = _.map(response.results, record => record.edges[0]);
            }
            const moreResults = items.length === options.size;
            if (moreResults) {
                // remove the last node, used to check if there were more nodes to ask
                items.splice(-1, 1);
            }
            return {
                type: options.type,
                moreResults: moreResults,
                results: _.map(items, 'id')
            };
        });
    }
    /**
     * Parse a string representing an array of strings from the Neo4j configuration file.
     * The way the array is represented differs from one Neo4j version to another.
     * This function is designed to work over multiple versions.
     *
     * @param {string} fieldName
     * @param {string} [indexedProperties]
     * @returns {string[]}
     * @throws {LkError} if indexedProperties is not defined
     */
    $parseIndexedPropertyList(fieldName, indexedProperties) {
        // if null, undefined, empty string
        if (!indexedProperties || indexedProperties === '[]') {
            throw Errors.business('source_action_needed', '"' + fieldName + '" must be a non-empty comma separated list of property keys.');
        }
        indexedProperties = indexedProperties.trim();
        if (indexedProperties.startsWith('[') && indexedProperties.endsWith(']')) {
            indexedProperties = indexedProperties.slice(1, -1);
        }
        return indexedProperties.split(',').map(indexedProperty => indexedProperty.trim());
    }
    /**
     * Neo4j configuration key that defines whether the automatic
     * explicit index is enabled for nodes.
     *
     * @type {string}
     */
    get $nodeIndexEnabledConfKey() {
        return 'node_auto_indexing';
    }
    /**
     * Neo4j configuration key that defines the property keys
     * indexed by the automatic explicit index for nodes.
     *
     * @type {string}
     */
    get $nodeIndexPropertyListConfKey() {
        return 'node_keys_indexable';
    }
    /**
     * @type {string}
     */
    get $edgeIndexEnabledConfKey() {
        return 'relationship_auto_indexing';
    }
    /**
     * @type {string}
     */
    get $edgeIndexPropertyListConfKey() {
        return 'relationship_keys_indexable';
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return this.connector.$queryJmx('org.neo4j', 'instance=kernel#0,name=Configuration').then(configuration => {
            const autoIndexNode = configuration[this.$nodeIndexEnabledConfKey];
            const autoIndexEdges = configuration[this.$edgeIndexEnabledConfKey];
            if (autoIndexNode !== 'true') {
                return Errors.business('source_action_needed', this.$nodeIndexEnabledConfKey + ' must be set to "true".', true);
            }
            this.indexedNodePropertyKeys = this.$parseIndexedPropertyList(this.$nodeIndexPropertyListConfKey, configuration[this.$nodeIndexPropertyListConfKey]);
            this.edgeIndexation = autoIndexEdges === 'true';
            this.indexFeatures.canIndexEdges = this.edgeIndexation;
            if (this.edgeIndexation) {
                this.indexedEdgePropertyKeys = this.$parseIndexedPropertyList(this.$edgeIndexPropertyListConfKey, configuration[this.$edgeIndexPropertyListConfKey]);
            }
        });
    }
    /**
     * @param {string} type   'node' or 'edge'
     * @param {number} offset
     * @param {string} [categoryOrType]
     * @returns {string}
     * @private
     */
    _generateIndexQuery(type, offset, categoryOrType) {
        const categoryFilter = Utils.hasValue(categoryOrType)
            ? ':' + CypherUtils.encodeName(categoryOrType)
            : '';
        let query = type === 'node'
            ? `MATCH (p${categoryFilter}) `
            : `MATCH ()-[p${categoryFilter}]->() `;
        const properties = type === 'node'
            ? this.indexedNodePropertyKeys
            : this.indexedEdgePropertyKeys;
        query += `WITH p SKIP ${offset} LIMIT ${this._batchSize} `;
        for (let i = 0; i < properties.length; i++) {
            const propertyKeyS = 'p.' + CypherUtils.encodeName(properties[i]);
            query += `SET ${propertyKeyS} = ${propertyKeyS} `;
        }
        query += 'RETURN count(p)';
        return query;
    }
    /**
     * @param {string}   type     'node' or 'edge'
     * @param {Progress} progress Instance used to keep track of the progress
     * @returns {Bluebird<void>}
     * @private
     */
    _indexSource(type, progress) {
        let count = 0;
        let categories = type === 'node' ? this._categoriesToIndex : this._edgeTypesToIndex;
        // empty array from `categoriesToIndex` or `edgeTypesToIndex` means index everything
        if (Utils.hasValue(categories) && categories.length === 0) {
            categories = undefined;
        }
        progress.setInitialOffset(type, count);
        let hasMore = true;
        let categoryIndex = 0;
        const loop = () => {
            if (!hasMore) {
                if (Utils.hasValue(categories) && categoryIndex < categories.length - 1) {
                    hasMore = true;
                    categoryIndex++;
                    count = 0;
                }
                else {
                    return Promise.resolve();
                }
            }
            Log.info(`Last indexed ${type} is at offset ${count} ` +
                `(all ${type}s before this one are indexed)`);
            const queries = [];
            const category = Utils.hasValue(categories) ? categories[categoryIndex] : undefined;
            for (let i = 0; i < this._numberOfThreads; i++) {
                queries.push(this._generateIndexQuery(type, count + this._batchSize * i, category));
            }
            return Promise.map(queries, query => {
                return Utils.retryPromise(`Index batch of ${type}s in Neo4j`, () => this.connector.$doCypherQuery(query, undefined, true), { delay: 3000, retries: 5 }).then(countR => {
                    const indexedItems = countR.results[0].rows[0];
                    if (indexedItems === 0) {
                        hasMore = false;
                    }
                    else {
                        count += indexedItems;
                        progress.add(type, indexedItems);
                    }
                });
            }, { concurrency: this._numberOfThreads }).then(loop);
        };
        return loop();
    }
    /**
     * Run the indexation of the external index.
     *
     * @param {Progress} progress Instance used to keep track of the progress
     * @returns {Bluebird<void>}
     */
    $indexSource(progress) {
        if (!this._initialization) {
            return Promise.resolve();
        }
        Log.info('Creating "node_auto_index" index in Neo4j');
        return this.connector.$doHTTPPostRequest('/db/data/index/node/', NODE_AUTO_INDEX_CONFIG, [201, 400]).then(response => {
            if (response.statusCode === 400) {
                return Errors.business('source_action_needed', 'The index node_auto_index can\'t be overwritten to be lower case: ' +
                    response.body.message, true);
            }
            if (this.edgeIndexation) {
                Log.info('Creating "relationship_auto_index" index in Neo4j');
                return this.connector.$doHTTPPostRequest('/db/data/index/relationship/', RELATIONSHIP_AUTO_INDEX_CONFIG, [201, 400]).then(response => {
                    if (response.statusCode === 400) {
                        return Errors.business('source_action_needed', 'The index relationship_auto_index can\'t be overwritten to be lower case: ' +
                            response.body.message, true);
                    }
                });
            }
        }).then(() => {
            Log.info('Indexing nodes in Neo4j');
            return this._indexSource('node', progress);
        }).then(() => {
            if (this.edgeIndexation) {
                Log.info('Indexing edges in Neo4j');
                return this._indexSource('edge', progress);
            }
        });
    }
}
module.exports = Neo4jSearchDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2hEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxTQUFTO0FBQ1QsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDOUMsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDdkQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFFakQsTUFBTSxzQkFBc0IsR0FBRztJQUM3QixNQUFNLEVBQUUsaUJBQWlCO0lBQ3pCLFFBQVEsRUFBRTtRQUNSLE1BQU0sRUFBRSxVQUFVO1FBQ2xCLFVBQVUsRUFBRSxRQUFRO1FBQ3BCLGVBQWUsRUFBRSxNQUFNO1FBQ3ZCLHFFQUFxRTtLQUN0RTtDQUNGLENBQUM7QUFFRixNQUFNLDhCQUE4QixHQUFHO0lBQ3JDLE1BQU0sRUFBRSx5QkFBeUI7SUFDakMsUUFBUSxFQUFFO1FBQ1IsTUFBTSxFQUFFLFVBQVU7UUFDbEIsVUFBVSxFQUFFLFFBQVE7UUFDcEIsZUFBZSxFQUFFLE1BQU07S0FDeEI7Q0FDRixDQUFDO0FBRUYsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUM7QUFDbEMsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLENBQUM7QUFFcEMsTUFBTSxpQkFBa0IsU0FBUSxXQUFXO0lBRXpDOzs7Ozs7T0FNRztJQUNILFlBQVksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWE7UUFDekUsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUV2RSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsaUJBQWlCLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQzNDLE1BQU0sVUFBVSxHQUFHLElBQUksS0FBSyxNQUFNO1lBQ2hDLENBQUMsQ0FBQyw4QkFBOEI7WUFDaEMsQ0FBQyxDQUFDLDhDQUE4QyxDQUFDO1FBRW5ELE1BQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUV4QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7WUFDN0MsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNuQiwwREFBMEQ7Z0JBQzFELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQzNELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO2dCQUVwRCxJQUFJLGNBQWMsR0FBRyxpQ0FBaUM7b0JBQ3BELFdBQVcsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQ3BELDBDQUEwQztnQkFDMUMsSUFBSSxPQUFPLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFO29CQUM3RSxjQUFjLElBQUkseUJBQXlCLENBQUM7aUJBQzdDO2dCQUNELFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDbkM7aUJBQU07Z0JBQ0wsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDO2dCQUVoRCxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDM0U7U0FDRjtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM5QyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxZQUFZLENBQUMsSUFBSSxDQUNmLGFBQWEsV0FBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDbEQsb0JBQW9CLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FDMUQsQ0FBQzthQUNIO1NBQ0Y7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUMzQixNQUFNLElBQUksVUFBVSxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7U0FDdEQ7UUFFRCxPQUFPLEdBQUcsVUFBVSxJQUFJLFdBQVcsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUk7WUFDL0QsU0FBUztZQUNULE1BQU07WUFDTixpQkFBaUIsT0FBTyxDQUFDLElBQUksVUFBVSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDMUQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILE9BQU8sQ0FBQyxPQUFPO1FBQ2IsK0VBQStFO1FBQy9FLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQ25ELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7U0FDL0U7UUFFRCxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyx5REFBeUQ7UUFFekUsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyRSxtRUFBbUU7UUFDbkUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQ3JELCtCQUErQjtZQUMvQixnRUFBZ0U7WUFFaEUsOERBQThEO1lBQzlELE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTTtnQkFDeEMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUI7Z0JBQzlCLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFFakMsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixDQUM5QyxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBQyxNQUFNLEVBQUUsVUFBVSxFQUFDLENBQ25ELENBQUM7WUFFRixLQUFLLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRW5FLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pCLElBQUksS0FBSyxDQUFDO1lBQ1YsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDM0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RDtpQkFBTTtnQkFDTCxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVEO1lBRUQsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLE1BQU0sS0FBSyxPQUFPLENBQUMsSUFBSSxDQUFDO1lBQ2xELElBQUksV0FBVyxFQUFFO2dCQUNmLHNFQUFzRTtnQkFDdEUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNyQjtZQUVELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2dCQUNsQixXQUFXLEVBQUUsV0FBVztnQkFDeEIsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQzthQUM1QixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gseUJBQXlCLENBQUMsU0FBUyxFQUFFLGlCQUFpQjtRQUNwRCxtQ0FBbUM7UUFDbkMsSUFBSSxDQUFDLGlCQUFpQixJQUFJLGlCQUFpQixLQUFLLElBQUksRUFBRTtZQUNwRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHNCQUFzQixFQUN0QixHQUFHLEdBQUcsU0FBUyxHQUFHLDhEQUE4RCxDQUNqRixDQUFDO1NBQ0g7UUFFRCxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM3QyxJQUFJLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDeEUsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsT0FBTyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDckYsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsSUFBSSx3QkFBd0I7UUFDMUIsT0FBTyxvQkFBb0IsQ0FBQztJQUM5QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxJQUFJLDZCQUE2QjtRQUMvQixPQUFPLHFCQUFxQixDQUFDO0lBQy9CLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksd0JBQXdCO1FBQzFCLE9BQU8sNEJBQTRCLENBQUM7SUFDdEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSw2QkFBNkI7UUFDL0IsT0FBTyw2QkFBNkIsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUM3QixXQUFXLEVBQUUsc0NBQXNDLENBQ3BELENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3JCLE1BQU0sYUFBYSxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQztZQUNuRSxNQUFNLGNBQWMsR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFFcEUsSUFBSSxhQUFhLEtBQUssTUFBTSxFQUFFO2dCQUM1QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0QixJQUFJLENBQUMsd0JBQXdCLEdBQUcseUJBQXlCLEVBQ3pELElBQUksQ0FDTCxDQUFDO2FBQ0g7WUFFRCxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUMzRCxJQUFJLENBQUMsNkJBQTZCLEVBQ2xDLGFBQWEsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FDbEQsQ0FBQztZQUVGLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxLQUFLLE1BQU0sQ0FBQztZQUNoRCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBRXZELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtnQkFDdkIsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FDM0QsSUFBSSxDQUFDLDZCQUE2QixFQUNsQyxhQUFhLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQ2xELENBQUM7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILG1CQUFtQixDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsY0FBYztRQUM5QyxNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQztZQUNuRCxDQUFDLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO1lBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFUCxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssTUFBTTtZQUN6QixDQUFDLENBQUMsV0FBVyxjQUFjLElBQUk7WUFDL0IsQ0FBQyxDQUFDLGNBQWMsY0FBYyxRQUFRLENBQUM7UUFDekMsTUFBTSxVQUFVLEdBQUcsSUFBSSxLQUFLLE1BQU07WUFDaEMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUI7WUFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUVqQyxLQUFLLElBQUksZUFBZSxNQUFNLFVBQVUsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO1FBRTNELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLE1BQU0sWUFBWSxHQUFHLElBQUksR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xFLEtBQUssSUFBSSxPQUFPLFlBQVksTUFBTSxZQUFZLEdBQUcsQ0FBQztTQUNuRDtRQUVELEtBQUssSUFBSSxpQkFBaUIsQ0FBQztRQUUzQixPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUTtRQUN6QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxJQUFJLFVBQVUsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUVwRixvRkFBb0Y7UUFDcEYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3pELFVBQVUsR0FBRyxTQUFTLENBQUM7U0FDeEI7UUFFRCxRQUFRLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXZDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQztRQUNuQixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7UUFFdEIsTUFBTSxJQUFJLEdBQUcsR0FBRyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ1osSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLGFBQWEsR0FBRyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDdkUsT0FBTyxHQUFHLElBQUksQ0FBQztvQkFDZixhQUFhLEVBQUUsQ0FBQztvQkFDaEIsS0FBSyxHQUFHLENBQUMsQ0FBQztpQkFDWDtxQkFBTTtvQkFDTCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztpQkFDMUI7YUFDRjtZQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLElBQUksaUJBQWlCLEtBQUssR0FBRztnQkFDcEQsUUFBUSxJQUFJLGdDQUFnQyxDQUFDLENBQUM7WUFFaEQsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ25CLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ3BGLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQzthQUNyRjtZQUVELE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBRWxDLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FDdkIsa0JBQWtCLElBQUksWUFBWSxFQUNsQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxFQUMzRCxFQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBQyxDQUMxQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDZCxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxZQUFZLEtBQUssQ0FBQyxFQUFFO3dCQUN0QixPQUFPLEdBQUcsS0FBSyxDQUFDO3FCQUNqQjt5QkFBTTt3QkFDTCxLQUFLLElBQUksWUFBWSxDQUFDO3dCQUN0QixRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQztxQkFDbEM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLEVBQUUsRUFBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDO1FBRUYsT0FBTyxJQUFJLEVBQUUsQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFZLENBQUMsUUFBUTtRQUNuQixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN6QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsMkNBQTJDLENBQUMsQ0FBQztRQUN0RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQ3RDLHNCQUFzQixFQUFFLHNCQUFzQixFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUMzRCxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQixJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUMvQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0QixvRUFBb0U7b0JBQ3BFLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2hDO1lBRUQsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUN2QixHQUFHLENBQUMsSUFBSSxDQUFDLG1EQUFtRCxDQUFDLENBQUM7Z0JBQzlELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FDdEMsOEJBQThCLEVBQUUsOEJBQThCLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQzNFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNoQixJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO3dCQUMvQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0Qiw0RUFBNEU7NEJBQzVFLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNoQztnQkFDSCxDQUFDLENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLEdBQUcsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzdDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3ZCLEdBQUcsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQztnQkFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQzthQUM1QztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQyJ9