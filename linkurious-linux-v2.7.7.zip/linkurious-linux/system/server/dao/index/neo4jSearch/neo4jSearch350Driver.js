"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2018
 *
 * - Created on 2019-01-07.
 */
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../../../services");
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const ExternalIndexDriver = require("../externalIndexDriver");
const DaoUtils = require('../../utils/daoUtils');
const CypherUtils = require('../../utils/cypherUtils');
const NODE_INDEX_NAME = 'linkurious_fulltext_nodes';
const EDGE_INDEX_NAME = 'linkurious_fulltext_edges';
/**
 * From Neo4JSearch 3.5.0 we don't use anymore Neo4j explicit indices
 * but we use Neo4j full text indices:
 *
 * https://neo4j.com/docs/operations-manual/current/performance/index-configuration/fulltext/
 *
 * Available procedures:
 * - db.index.fulltext.awaitEventuallyConsistentIndexRefresh
 *   - () :: VOID
 *   - Wait for the updates from recently committed transactions to be applied to any eventually-consistent fulltext indexes.
 * - db.index.fulltext.createNodeIndex
 *   - (indexName :: STRING?, labels :: LIST? OF STRING?, propertyNames :: LIST? OF STRING?, config = {} :: MAP?) :: VOID
 *   - Create a node fulltext index for the given labels and properties.
 * - db.index.fulltext.createRelationshipIndex
 *   - (indexName :: STRING?, relationshipTypes :: LIST? OF STRING?, propertyNames :: LIST? OF STRING?, config = {} :: MAP?) :: VOID
 *   - Create a relationship fulltext index for the given relationship types and properties.
 * - db.index.fulltext.drop
 *   - (indexName :: STRING?) :: VOID
 *   - Drop the specified index
 * - db.index.fulltext.listAvailableAnalyzers
 *   - () :: (analyzer :: STRING?, description :: STRING?)
 *   - List the available analyzers that the fulltext indexes can be configured with.
 * - db.index.fulltext.queryNodes
 *   - (indexName :: STRING?, queryString :: STRING?) :: (node :: NODE?, score :: FLOAT?)
 *   - Query the given fulltext index. Returns the matching nodes and their lucene query score, ordered by score.
 * - db.index.fulltext.queryRelationships
 *   - (indexName :: STRING?, queryString :: STRING?) :: (relationship :: RELATIONSHIP?, score :: FLOAT?)
 *   - Query the given fulltext index. Returns the matching relationships and their lucene query score, ordered by score.
 */
class Neo4jSearch350Driver extends ExternalIndexDriver {
    /**
     * @param connector     Connector used by the DAO
     * @param graphDAO      The connected GraphDAO
     * @param indexOptions  IndexDAO options
     * @param connectorData Data from the connector
     * @param indexFeatures Features of the IndexDAO
     */
    constructor(connector, graphDAO, indexOptions, connectorData, indexFeatures) {
        super(connector, graphDAO, indexOptions, connectorData, indexFeatures);
        this.initialization = this.getIndexOption('initialization', true);
        this.categoriesToIndex = this.getIndexOption('categoriesToIndex');
        this.edgeTypesToIndex = this.getIndexOption('edgeTypesToIndex');
        this.nodeIndexName = this.getIndexOption('nodeIndexName');
        this.edgeIndexName = this.getIndexOption('edgeIndexName');
        this.indexEdges = this.getIndexOption('indexEdges', false);
        this.simplifiedSearch = this.getIndexOption('simplifiedSearch', false);
        this.indexFeatures.canIndexEdges = this.indexEdges;
    }
    /**
     * We choose the index to use based on the following order:
     * - 1) If a user specified an index name, we use it
     *   - We fail if such index doesn't exist in Neo4j
     * - 2) If a Linkurious index already exists, we use it
     * - 3) If initialization is set, we create a Linkurious index and we use it
     *   - This function will return undefined
     * - 4) If initialization is not set, we use the first index among the existing indices
     *   - We fail if no index is available
     *
     * @param userIndexName       Index name specified by the user
     * @param existingIndices     List of existing indices
     * @param linkuriousIndexName Name of the index created by Linkurious
     */
    pickIndexToUse(type, userIndexName, existingIndices, linkuriousIndexName) {
        if (Utils.hasValue(userIndexName)) {
            // Fail if the user specified an index name but it's not found in Neo4j
            if (!existingIndices.includes(userIndexName)) {
                throw Errors.business('invalid_parameter', `No full-text index for ${type}s found in Neo4j called ${userIndexName}`);
            }
            Log.info(`Using user specified full text index for ${type}s: ` + userIndexName);
            return userIndexName;
        }
        // If an index created by Linkurious exists, we use it
        if (existingIndices.includes(linkuriousIndexName)) {
            Log.info(`Using Linkurious full text index for ${type}s: ` + linkuriousIndexName);
            return linkuriousIndexName;
        }
        if (this.initialization) {
            Log.info(`No full text index found for ${type}s: initialization required.`);
            // We return undefined, $indexSource will take care of creating an index called <TYPE>_INDEX_NAME
            return;
        }
        // If a full-text index exists, we use it
        if (existingIndices.length > 0) {
            Log.info(`Using first full text index available for ${type}s: ` + existingIndices[0]);
            return existingIndices[0];
        }
        throw Errors.business('source_action_needed', `No full-text index found in Neo4j for ${type}s. You can automatically create ` +
            'one by setting the index option "initialization" to "true".');
    }
    /**
     * @param type 'node' or 'edge'
     */
    getFullTextIndices(type) {
        return this.connector
            .$doCypherQuery('CALL db.indexes()')
            .then(result => {
            // Each index is an array of properties:
            // [ "description", "indexName", "tokenNames", "properties", "state", "type", "progress", "provider", "id", "failureMessage"]
            // We are interested in the "type" (5) and in the "indexName" (1)
            const indices = _.map(result.results, 'rows');
            if (type === 'node') {
                return _.filter(indices, index => index[5] === 'node_fulltext');
            }
            else {
                return _.filter(indices, index => index[5] === 'relationship_fulltext');
            }
        })
            .map((index) => {
            return {
                name: index[1],
                progress: index[6]
            };
        });
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    $onAfterConnect() {
        // We retrieve all the property keys in the schema
        return this.graphDAO
            .getSimpleSchema()
            .then(simpleSchema => {
            this.simpleSchema = simpleSchema;
            // We retrieve all the existing full-text indices in Neo4j
            return this.getFullTextIndices('node').then(nodeIndices => {
                return this.getFullTextIndices('edge').then(edgeIndices => {
                    this.nodeIndexName = this.pickIndexToUse('node', this.nodeIndexName, _.map(nodeIndices, 'name'), NODE_INDEX_NAME);
                    if (this.indexEdges) {
                        this.edgeIndexName = this.pickIndexToUse('edge', this.edgeIndexName, _.map(edgeIndices, 'name'), EDGE_INDEX_NAME);
                    }
                    else {
                        Log.info('Full text indexation for edges not enabled.');
                    }
                });
            });
        })
            .then(() => {
            return this.graphDAO.getNodeCount(true).then(nodeCount => {
                this.nodeCountCache = nodeCount;
            });
        })
            .then(() => {
            return this.graphDAO.getEdgeCount(true).then(edgeCount => {
                this.edgeCountCache = edgeCount;
            });
        });
    }
    /**
     * Search for nodes or edges using `options.q`.
     * Return the IDs of the items as result.
     *
     * @param options
     */
    $search(options) {
        const sProcedure = options.type === 'node'
            ? 'db.index.fulltext.queryNodes'
            : 'db.index.fulltext.queryRelationships';
        const sType = options.type === 'node' ? 'node' : 'relationship';
        const indexName = options.type === 'node' ? this.nodeIndexName : this.edgeIndexName;
        const sIndexName = CypherUtils.encodeValue(indexName);
        // const simpleSchema = this.simpleSchema as SimpleGraphSchema;
        // const properties =
        //   options.type === 'node' ? simpleSchema.nodeProperties : simpleSchema.edgeProperties;
        const luceneQuery = DaoUtils.generateLuceneQuery(options.q, options.fuzziness, {
            useEditDistance: true,
            minLengthPrefix: this.simplifiedSearch ? 20 : 2
            // fields: properties
        });
        const whereClauses = [];
        if (Utils.hasValue(options.categoriesOrTypes)) {
            if (options.type === 'node') {
                // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
                const readableCategories = _.filter(options.categoriesOrTypes, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
                let categoryClause = 'ANY (l in labels(i) WHERE l in ' + CypherUtils.encodeValue(readableCategories) + ')';
                // if we can read nodes with no categories
                if (options.categoriesOrTypes.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                    categoryClause += ' OR size(labels(i)) = 0';
                }
                whereClauses.push(categoryClause);
            }
            else {
                const readableTypes = options.categoriesOrTypes;
                whereClauses.push(`type(i) in ${CypherUtils.encodeValue(readableTypes)}`);
            }
        }
        if (Utils.hasValue(options.filter)) {
            for (let i = 0; i < options.filter.length; i++) {
                const filter = options.filter[i];
                whereClauses.push(`toLower(i.${CypherUtils.encodeName(filter[0])}) ` +
                    `CONTAINS toLower(${CypherUtils.encodeValue(filter[1])})`);
            }
        }
        let sWhere = '';
        if (whereClauses.length > 0) {
            sWhere += `WITH i WHERE (${whereClauses.join(') AND (')}) `;
        }
        const query = `CALL ${sProcedure}(${sIndexName}, ${CypherUtils.encodeValue(luceneQuery)}) ` +
            `YIELD ${sType} as i ` +
            sWhere +
            `RETURN i SKIP ${options.from} LIMIT ${options.size + 1}`;
        return this.connector.$doCypherQuery(query).then(response => {
            let items;
            if (options.type === 'node') {
                items = _.map(response.results, record => record.nodes[0]);
            }
            else {
                items = _.map(response.results, record => record.edges[0]);
            }
            const moreResults = items.length === options.size + 1;
            if (moreResults) {
                // remove the last node, used to check if there were more nodes to ask
                items.splice(-1, 1);
            }
            return {
                type: options.type,
                moreResults: moreResults,
                results: _.map(items, 'id')
            };
        });
    }
    /**
     * @param type              'node' or 'edge'
     * @param typesToIndex      List of categories/types to index
     * @param propertiesToIndex List of properties to index
     * @param progress          Instance used to keep track of the progress
     */
    indexType(type, typesToIndex, propertiesToIndex, progress) {
        const countCache = (type === 'node' ? this.nodeCountCache : this.edgeCountCache);
        const indexName = type === 'node' ? this.nodeIndexName : this.edgeIndexName;
        if (Utils.hasValue(indexName)) {
            Log.warn(`Requested initialization for ${type}s full text indexation. ` +
                'A full text index is already available and it will be used instead: ' +
                indexName);
            return Bluebird.resolve();
        }
        const sProcedure = type === 'node'
            ? 'db.index.fulltext.createNodeIndex'
            : 'db.index.fulltext.createRelationshipIndex';
        const lkIndexName = type === 'node' ? NODE_INDEX_NAME : EDGE_INDEX_NAME;
        const sLKIndexName = CypherUtils.encodeValue(lkIndexName);
        const sTypesToIndex = CypherUtils.encodeValue(typesToIndex);
        const sPropertiesToIndex = CypherUtils.encodeValue(propertiesToIndex);
        const createIndexQuery = `
      CALL ${sProcedure}(${sLKIndexName}, ${sTypesToIndex}, ${sPropertiesToIndex})
    `;
        return this.connector
            .$doCypherQuery(createIndexQuery)
            .then(() => {
            let progressAlreadyAdded = 0;
            const checkIndexJobStatus = () => {
                return this.getFullTextIndices(type).then(indices => {
                    const linkuriousIndex = _.filter(indices, index => index.name === lkIndexName)[0];
                    const currentProgress = linkuriousIndex.progress;
                    if (currentProgress < 100) {
                        const approxItemsAdded = Math.round(((currentProgress - progressAlreadyAdded) * countCache) / 100);
                        progressAlreadyAdded = currentProgress;
                        progress.add(type, approxItemsAdded);
                        return Bluebird.reject(new Error('indexing'));
                    }
                    return Bluebird.resolve();
                });
            };
            return Utils.retryPromise(`Check ${lkIndexName} status`, checkIndexJobStatus, 
            // Retry the promise as long as the error message is `indexing`. We stop if another error occurred
            { delay: 3000, retries: Infinity, decide: error => error.message === 'indexing' });
        })
            .then(() => {
            if (type === 'node') {
                this.nodeIndexName = NODE_INDEX_NAME;
            }
            else {
                this.edgeIndexName = EDGE_INDEX_NAME;
            }
        });
    }
    /**
     * Run the indexation of the external index.
     *
     * @param progress Instance used to keep track of the progress
     */
    $indexSource(progress) {
        if (!this.initialization) {
            return Bluebird.resolve();
        }
        const simpleSchema = this.simpleSchema;
        return this.indexType('node', this.categoriesToIndex || simpleSchema.nodeCategories, simpleSchema.nodeProperties, progress).then(() => {
            if (this.indexEdges) {
                return this.indexType('edge', this.edgeTypesToIndex || simpleSchema.edgeTypes, simpleSchema.edgeProperties, progress);
            }
            return;
        });
    }
    /**
     * Not implemented because features.typing is false.
     *
     * @param type 'node' or 'edge'
     */
    $getPropertyTypes(type) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Not implemented because features.canCount is false.
     *
     * @param type 'node' or 'edge'
     */
    $getSize(type) {
        return Utils.NOT_IMPLEMENTED();
    }
}
module.exports = Neo4jSearch350Driver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpTZWFyY2gzNTBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2luZGV4L25lbzRqU2VhcmNoL25lbzRqU2VhcmNoMzUwRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBSy9CLDhEQUErRDtBQUMvRCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQWEsQ0FBQztBQUM3RCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQWdCLENBQUM7QUFFdEUsTUFBTSxlQUFlLEdBQUcsMkJBQTJCLENBQUM7QUFDcEQsTUFBTSxlQUFlLEdBQUcsMkJBQTJCLENBQUM7QUFFcEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0E0Qkc7QUFDSCxNQUFNLG9CQUFxQixTQUFRLG1CQUFtQztJQWNwRTs7Ozs7O09BTUc7SUFDSCxZQUNFLFNBQXlCLEVBQ3pCLFFBQXFELEVBQ3JELFlBQW9DLEVBQ3BDLGFBQXFDLEVBQ3JDLGFBQTRCO1FBRTVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFdkUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBWSxDQUFDO1FBQzdFLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUF5QixDQUFDO1FBQzFGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUF5QixDQUFDO1FBQ3hGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQXVCLENBQUM7UUFDaEYsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBdUIsQ0FBQztRQUNoRixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBWSxDQUFDO1FBQ3RFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixFQUFFLEtBQUssQ0FBWSxDQUFDO1FBQ2xGLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDckQsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSyxjQUFjLENBQ3BCLElBQXFCLEVBQ3JCLGFBQWlDLEVBQ2pDLGVBQXlCLEVBQ3pCLG1CQUEyQjtRQUUzQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDakMsdUVBQXVFO1lBQ3ZFLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUM1QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQiwwQkFBMEIsSUFBSSwyQkFBMkIsYUFBYSxFQUFFLENBQ3pFLENBQUM7YUFDSDtZQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsNENBQTRDLElBQUksS0FBSyxHQUFHLGFBQWEsQ0FBQyxDQUFDO1lBQ2hGLE9BQU8sYUFBYSxDQUFDO1NBQ3RCO1FBRUQsc0RBQXNEO1FBQ3RELElBQUksZUFBZSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO1lBQ2pELEdBQUcsQ0FBQyxJQUFJLENBQUMsd0NBQXdDLElBQUksS0FBSyxHQUFHLG1CQUFtQixDQUFDLENBQUM7WUFDbEYsT0FBTyxtQkFBbUIsQ0FBQztTQUM1QjtRQUVELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN2QixHQUFHLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxJQUFJLDZCQUE2QixDQUFDLENBQUM7WUFDNUUsaUdBQWlHO1lBQ2pHLE9BQU87U0FDUjtRQUVELHlDQUF5QztRQUN6QyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLElBQUksS0FBSyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RGLE9BQU8sZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzNCO1FBRUQsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixzQkFBc0IsRUFDdEIseUNBQXlDLElBQUksa0NBQWtDO1lBQzdFLDZEQUE2RCxDQUNoRSxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssa0JBQWtCLENBQ3hCLElBQXFCO1FBT3JCLE9BQU8sSUFBSSxDQUFDLFNBQVM7YUFDbEIsY0FBYyxDQUFDLG1CQUFtQixDQUFDO2FBQ25DLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNiLHdDQUF3QztZQUN4Qyw2SEFBNkg7WUFDN0gsaUVBQWlFO1lBQ2pFLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUU5QyxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssZUFBZSxDQUFDLENBQUM7YUFDakU7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyx1QkFBdUIsQ0FBQyxDQUFDO2FBQ3pFO1FBQ0gsQ0FBQyxDQUFDO2FBQ0QsR0FBRyxDQUFDLENBQUMsS0FBZ0IsRUFBRSxFQUFFO1lBQ3hCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQVc7Z0JBQ3hCLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFXO2FBQzdCLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7T0FFRztJQUNJLGVBQWU7UUFDcEIsa0RBQWtEO1FBQ2xELE9BQU8sSUFBSSxDQUFDLFFBQVE7YUFDakIsZUFBZSxFQUFFO2FBQ2pCLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNuQixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUVqQywwREFBMEQ7WUFDMUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUN4RCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQ3hELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FDdEMsTUFBTSxFQUNOLElBQUksQ0FBQyxhQUFhLEVBQ2xCLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxFQUMxQixlQUFlLENBQ2hCLENBQUM7b0JBRUYsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO3dCQUNuQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQ3RDLE1BQU0sRUFDTixJQUFJLENBQUMsYUFBYSxFQUNsQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsRUFDMUIsZUFBZSxDQUNoQixDQUFDO3FCQUNIO3lCQUFNO3dCQUNMLEdBQUcsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsQ0FBQztxQkFDekQ7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDdkQsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3ZELElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxPQUFPLENBQUMsT0FBc0I7UUFDbkMsTUFBTSxVQUFVLEdBQ2QsT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNO1lBQ3JCLENBQUMsQ0FBQyw4QkFBOEI7WUFDaEMsQ0FBQyxDQUFDLHNDQUFzQyxDQUFDO1FBQzdDLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztRQUVoRSxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNwRixNQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXRELCtEQUErRDtRQUMvRCxxQkFBcUI7UUFDckIseUZBQXlGO1FBRXpGLE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDN0UsZUFBZSxFQUFFLElBQUk7WUFDckIsZUFBZSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9DLHFCQUFxQjtTQUN0QixDQUFDLENBQUM7UUFFSCxNQUFNLFlBQVksR0FBYSxFQUFFLENBQUM7UUFDbEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQzdDLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQzNCLDBEQUEwRDtnQkFDMUQsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUNqQyxPQUFPLENBQUMsaUJBQWlCLEVBQ3pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FDakQsQ0FBQztnQkFFRixJQUFJLGNBQWMsR0FDaEIsaUNBQWlDLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDeEYsMENBQTBDO2dCQUMxQyxJQUFJLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7b0JBQzdFLGNBQWMsSUFBSSx5QkFBeUIsQ0FBQztpQkFDN0M7Z0JBQ0QsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNuQztpQkFBTTtnQkFDTCxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUM7Z0JBRWhELFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxXQUFXLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUMzRTtTQUNGO1FBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNsQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlDLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLFlBQVksQ0FBQyxJQUFJLENBQ2YsYUFBYSxXQUFXLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUNoRCxvQkFBb0IsV0FBVyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUM1RCxDQUFDO2FBQ0g7U0FDRjtRQUVELElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzNCLE1BQU0sSUFBSSxpQkFBaUIsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO1NBQzdEO1FBRUQsTUFBTSxLQUFLLEdBQ1QsUUFBUSxVQUFVLElBQUksVUFBVSxLQUFLLFdBQVcsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUk7WUFDN0UsU0FBUyxLQUFLLFFBQVE7WUFDdEIsTUFBTTtZQUNOLGlCQUFpQixPQUFPLENBQUMsSUFBSSxVQUFVLE9BQU8sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFFNUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDMUQsSUFBSSxLQUEwQixDQUFDO1lBQy9CLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQzNCLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDNUQ7aUJBQU07Z0JBQ0wsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RDtZQUVELE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxNQUFNLEtBQUssT0FBTyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7WUFDdEQsSUFBSSxXQUFXLEVBQUU7Z0JBQ2Ysc0VBQXNFO2dCQUN0RSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3JCO1lBRUQsT0FBTztnQkFDTCxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7Z0JBQ2xCLFdBQVcsRUFBRSxXQUFXO2dCQUN4QixPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO2FBQzVCLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLFNBQVMsQ0FDZixJQUFxQixFQUNyQixZQUFzQixFQUN0QixpQkFBMkIsRUFDM0IsUUFBa0I7UUFFbEIsTUFBTSxVQUFVLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFXLENBQUM7UUFDM0YsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM1RSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDN0IsR0FBRyxDQUFDLElBQUksQ0FDTixnQ0FBZ0MsSUFBSSwwQkFBMEI7Z0JBQzVELHNFQUFzRTtnQkFDdEUsU0FBUyxDQUNaLENBQUM7WUFDRixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMzQjtRQUVELE1BQU0sVUFBVSxHQUNkLElBQUksS0FBSyxNQUFNO1lBQ2IsQ0FBQyxDQUFDLG1DQUFtQztZQUNyQyxDQUFDLENBQUMsMkNBQTJDLENBQUM7UUFFbEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7UUFFeEUsTUFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMxRCxNQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzVELE1BQU0sa0JBQWtCLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRXRFLE1BQU0sZ0JBQWdCLEdBQUc7YUFDaEIsVUFBVSxJQUFJLFlBQVksS0FBSyxhQUFhLEtBQUssa0JBQWtCO0tBQzNFLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTO2FBQ2xCLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUNoQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsSUFBSSxvQkFBb0IsR0FBRyxDQUFDLENBQUM7WUFDN0IsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLEVBQUU7Z0JBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDbEQsTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNsRixNQUFNLGVBQWUsR0FBSSxlQUFzQyxDQUFDLFFBQVEsQ0FBQztvQkFFekUsSUFBSSxlQUFlLEdBQUcsR0FBRyxFQUFFO3dCQUN6QixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQ2pDLENBQUMsQ0FBQyxlQUFlLEdBQUcsb0JBQW9CLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRyxHQUFHLENBQzlELENBQUM7d0JBQ0Ysb0JBQW9CLEdBQUcsZUFBZSxDQUFDO3dCQUN2QyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUNyQyxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztxQkFDL0M7b0JBRUQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsT0FBTyxLQUFLLENBQUMsWUFBWSxDQUN2QixTQUFTLFdBQVcsU0FBUyxFQUM3QixtQkFBbUI7WUFDbkIsa0dBQWtHO1lBQ2xHLEVBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssVUFBVSxFQUFDLENBQ2hGLENBQUM7UUFDSixDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNuQixJQUFJLENBQUMsYUFBYSxHQUFHLGVBQWUsQ0FBQzthQUN0QztpQkFBTTtnQkFDTCxJQUFJLENBQUMsYUFBYSxHQUFHLGVBQWUsQ0FBQzthQUN0QztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxZQUFZLENBQUMsUUFBa0I7UUFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDeEIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBaUMsQ0FBQztRQUU1RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQ25CLE1BQU0sRUFDTixJQUFJLENBQUMsaUJBQWlCLElBQUksWUFBWSxDQUFDLGNBQWMsRUFDckQsWUFBWSxDQUFDLGNBQWMsRUFDM0IsUUFBUSxDQUNULENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNWLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUNuQixNQUFNLEVBQ04sSUFBSSxDQUFDLGdCQUFnQixJQUFJLFlBQVksQ0FBQyxTQUFTLEVBQy9DLFlBQVksQ0FBQyxjQUFjLEVBQzNCLFFBQVEsQ0FDVCxDQUFDO2FBQ0g7WUFDRCxPQUFPO1FBQ1QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGlCQUFpQixDQUFDLElBQWM7UUFDckMsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxRQUFRLENBQUMsSUFBYztRQUM1QixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxvQkFBb0IsQ0FBQyJ9