/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // abstract methods
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
// locals
const Connector = require('./connector');
/**
 * Note:
 * This is the format of subjects, predicates and objects returned
 * by $getStatements and $doSparqlQuery:
 *
 * numbers: "\"1967\"^^<http://www.w3.org/2001/XMLSchema#integer>"
 * string : "\"The Matrix Reloaded\""
 * bnode  : "_:bFDBE1B15x2"
 * uri    : "<http://link.com>"
 */
class SparqlConnector extends Connector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this.$url = Utils.normalizeUrl(this.getGraphOption('url'));
        this.$defaultNamespace = this.getGraphOption('namespace', 'http://linkurio.us/');
        // resolution to a full URI of this.$categoryPredicate will occur inside the '$connect' method
        this.$categoryPredicate = this.getGraphOption('categoryPredicate', '<http://www.w3.org/1999/02/22-rdf-syntax-ns#type>');
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({
            prefixToURI: this.$prefixToURI,
            categoryPredicate: this.$categoryPredicate,
            defaultNamespace: this.$defaultNamespace
        });
    }
    /**
     * Delete all the statements in the triple store that match at least one of the rules in
     * `deleteArray`.
     *
     * A statement match a rule if:
     * - it has `subject` as subject, or any if undefined
     * - it has `predicate` as predicate, or any if undefined
     * - it has `object` as object, or any if undefined
     *
     * Return true if at least a statement was deleted.
     *
     * @param {Array<{subject?: string, predicate?: string, object?: string}>} deleteArray
     * @returns {Bluebird<boolean>}
     */
    $deleteMultipleStatements(deleteArray) {
        return Promise.map(deleteArray, rule => {
            return this.$deleteStatements(rule.subject, rule.predicate, rule.object);
        }).then(results => {
            return results.some(result => result === true);
        });
    }
    /**
     * Get the LkRequest object for direct access to the HTTP endpoint.
     *
     * @type {LkRequest}
     */
    get $request() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Get the mapping from prefixes to namespaces.
     *
     * e.g.:
     * 'foaf' -> 'http://xmlns.com/foaf/0.1/'
     * 'rdf'  -> 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
     *
     * @type {Map<string, string>}
     */
    get $prefixToURI() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Check that a given statement belongs to the triple store.
     *
     * @param {string} subject
     * @param {string} predicate
     * @param {string} object
     * @returns {Bluebird<boolean>}
     */
    $checkStatement(subject, predicate, object) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Return all the statements in the triple store that have subject in `subjects`.
     *
     * Implement only if the SparqlDriver doesn't support blank node labels.
     *
     * @param {string[]} subjects
     * @param {object}   [options]
     * @param {string}   [options.reasoning] 'enabled':  Allow inferred statements
     *                                       'disabled': Forbid inferred statements
     *                                       'default':  Use the configuration flag
     * @returns {Bluebird<string[][]>}
     */
    $getStatementsBySubjects(subjects, options) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Return all the statements in the triple store that:
     * - have subject in `subjects`, or any if undefined
     * - have predicate in `predicates`, or any if undefined
     * - have object in `objects`, or any if undefined
     *
     * Implement only if the SparqlDriver doesn't support blank node labels.
     *
     * @param {string[]} [subjects]
     * @param {string[]} [predicates]
     * @param {string[]} [objects]
     * @returns {Bluebird<string[][]>}
     */
    $getStatements(subjects, predicates, objects) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Delete all the statements in the triple store that:
     * - have `subject` as subject, or any if undefined
     * - have `predicate` as predicate, or any if undefined
     * - have `object` as object, or any if undefined
     *
     * Return true if at least a statement was deleted.
     *
     * @param {string} [subject]
     * @param {string} [predicate]
     * @param {string} [object]
     * @returns {Bluebird<boolean>}
     */
    $deleteStatements(subject, predicate, object) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Delete all the statements in the triple store.
     *
     * @returns {Bluebird<void>}
     */
    $deleteAllStatements() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Add `statements` to the triple store.
     *
     * @param {string[][]} statements
     * @returns {Bluebird<void>}
     */
    $addStatements(statements) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Generate a from clause for each graph of the data set.
     * e.g: `FROM <g1> ... FROM <gn-1> FROM <gn>`
     *
     * @returns {string}
     */
    get $fromClause() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Execute a sparql query on the triple store.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {number}  [options.timeout]   Milliseconds to wait before it fails
     * @param {string}  [options.reasoning] 'enabled':  Allow inferred statements
     *                                      'disabled': Forbid inferred statements
     *                                      'default':  Use the configuration flag
     * @returns {Bluebird<string[][]>}
     */
    $doSparqlQuery(query, options) {
        return Utils.NOT_IMPLEMENTED();
    }
}
module.exports = SparqlConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BhcnFsQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3Ivc3BhcnFsQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsOEJBQThCLENBQUMsbUJBQW1CO0FBRWxELGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBRXpDOzs7Ozs7Ozs7R0FTRztBQUNILE1BQU0sZUFBZ0IsU0FBUSxTQUFTO0lBRXJDOzs7T0FHRztJQUNILFlBQVksWUFBWSxFQUFFLFlBQVk7UUFDcEMsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRTNELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBRWpGLDhGQUE4RjtRQUM5RixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FDM0MsbUJBQW1CLEVBQ25CLG1EQUFtRCxDQUNwRCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxpQkFBaUI7UUFDZixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckIsV0FBVyxFQUFFLElBQUksQ0FBQyxZQUFZO1lBQzlCLGlCQUFpQixFQUFFLElBQUksQ0FBQyxrQkFBa0I7WUFDMUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtTQUN6QyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILHlCQUF5QixDQUFDLFdBQVc7UUFDbkMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQixPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksUUFBUTtRQUNWLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILElBQUksWUFBWTtRQUNkLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZUFBZSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTTtRQUN4QyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsT0FBTztRQUN4QyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsT0FBTztRQUMxQyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNO1FBQzFDLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsb0JBQW9CO1FBQ2xCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWMsQ0FBQyxVQUFVO1FBQ3ZCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUksV0FBVztRQUNiLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsY0FBYyxDQUFDLEtBQUssRUFBRSxPQUFPO1FBQzNCLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDIn0=