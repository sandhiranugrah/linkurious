"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
const _ = require("lodash");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// locals
const CypherConnector = require('./cypherConnector');
var ADVANCED_TYPES;
(function (ADVANCED_TYPES) {
    ADVANCED_TYPES[ADVANCED_TYPES["DATE"] = 0] = "DATE";
    ADVANCED_TYPES[ADVANCED_TYPES["TIME"] = 1] = "TIME";
    ADVANCED_TYPES[ADVANCED_TYPES["DATE_TIME"] = 2] = "DATE_TIME";
    ADVANCED_TYPES[ADVANCED_TYPES["DURATION"] = 3] = "DURATION";
    ADVANCED_TYPES[ADVANCED_TYPES["COORDINATES"] = 4] = "COORDINATES";
    ADVANCED_TYPES[ADVANCED_TYPES["UNKNOWN"] = 5] = "UNKNOWN";
})(ADVANCED_TYPES || (ADVANCED_TYPES = {}));
class Neo4jConnector extends CypherConnector {
    /**
     * @param graphOptions   GraphDAO options
     * @param [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        const envUser = process.env.LINKURIOUS_NEO4J_USER;
        const envPassword = process.env.LINKURIOUS_NEO4J_PASSWORD;
        if (Utils.hasValue(envUser) &&
            Utils.hasValue(envPassword) &&
            Utils.noValue(graphOptions.user) &&
            Utils.noValue(graphOptions.password)) {
            Log.info('Using Neo4j credentials from environment variables.');
            graphOptions.user = envUser;
            graphOptions.password = envPassword;
        }
    }
    /**
     * Do an HTTP POST request toward Neo4j.
     *
     * Used to create a case insensitive Neo4j search index.
     *
     * @param url
     * @param parameters
     * @param expectedStatusCode
     */
    $doHTTPPostRequest(url, parameters, expectedStatusCode) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Do an HTTP GET request toward Neo4j. Return the body of the response directly.
     *
     * Used to retrieve the simple schema before procedures were introduced.
     *
     * @param url
     */
    $doHTTPGetRequest(url) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Do an HTTP GET stream request toward Neo4j.
     *
     * @param url
     */
    $doHTTPGetStreamRequest(url) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Query JMX management data of Neo4j by domain, name and key.
     *
     * @param domain
     * @param name
     * @param [key]
     */
    $queryJmx(domain, name, key) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     */
    $getStoreId() {
        return this.$queryJmx('org.neo4j', 'instance=kernel#0,name=Kernel', 'StoreId');
    }
    /**
     * Detect the Neo4j type from a serialized value.
     *
     * @param value
     */
    static detectObjectType(value) {
        const year = _.get(value, 'year.low', false);
        const hour = _.get(value, 'hour.low', false);
        if (year && hour) {
            return ADVANCED_TYPES.DATE_TIME;
        }
        if (year) {
            return ADVANCED_TYPES.DATE;
        }
        if (hour) {
            return ADVANCED_TYPES.TIME;
        }
        if (_.has(value, 'crs.srid') || _.has(value, 'srid.low')) {
            return ADVANCED_TYPES.COORDINATES;
        }
        if (_.has(value, 'months') || _.has(value, 'seconds')) {
            return ADVANCED_TYPES.DURATION;
        }
        return ADVANCED_TYPES.UNKNOWN;
    }
    /**
     * Convert a Neo4j temporal value to date.
     *
     * @param value
     */
    static temporalValueToDate(value) {
        return new Date(_.get(value, 'year.low', 0), _.get(value, 'month.low', 1) - 1, _.get(value, 'day.low', 1), _.get(value, 'hour.low', 0), _.get(value, 'minute.low', 0), _.get(value, 'second.low', 0));
    }
    /**
     * Convert a Neo4j dateTime object to string.
     *
     * @param value
     */
    static dateTimeToString(value) {
        const d = Neo4jConnector.temporalValueToDate(value);
        return d.toLocaleDateString() + 'T' + d.toLocaleTimeString();
    }
    /**
     * Convert a Neo4j dateTime object to string.
     *
     * @param value
     */
    static dateToString(value) {
        const d = Neo4jConnector.temporalValueToDate(value);
        return d.toLocaleDateString();
    }
    /**
     * Convert a Neo4j time object to string.
     *
     * @param value
     */
    static timeToString(value) {
        const d = Neo4jConnector.temporalValueToDate(value);
        return d.toLocaleTimeString();
    }
    /**
     * Convert a Neo4j duration object to string.
     *
     * @param value
     */
    static durationToString(value) {
        return value.toLocaleString();
    }
    /**
     * Convert a Neo4j spatial object to string.
     *
     * @param value
     */
    static pointToString(value) {
        // the format of the point object is different in http and bolt
        // HTTP: {crs: {srid: number}; coordinates: number[]; type: string}
        // BOLT: {srid: Integer; x: number; y: number; z: number}
        // this method handles both formats
        const srid = _.get(value, 'crs.srid', value.srid);
        const [x = _.get(value, 'x', 0), y = _.get(value, 'y', 0), z = _.get(value, 'z', 0)] = _.get(value, 'coordinates', []);
        return `Point{srid=${srid}, x=${x}, y=${y}, z=${z}}`;
    }
    /**
     * Convert a Neo4j object to string.
     *
     * @param value
     */
    static $objectToString(value) {
        // 1) if value has a stringify function, use it
        if (typeof value.toLocaleString === 'function') {
            const s = value.toLocaleString();
            if (typeof s === 'string') {
                return s;
            }
        }
        // 2) otherwise stringify it based on the type
        switch (Neo4jConnector.detectObjectType(value)) {
            case ADVANCED_TYPES.DATE:
                return Neo4jConnector.dateToString(value);
            case ADVANCED_TYPES.TIME:
                return Neo4jConnector.timeToString(value);
            case ADVANCED_TYPES.DATE_TIME:
                return Neo4jConnector.dateTimeToString(value);
            case ADVANCED_TYPES.DURATION:
                return Neo4jConnector.durationToString(value);
            case ADVANCED_TYPES.COORDINATES:
                return Neo4jConnector.pointToString(value);
            default:
                return JSON.stringify(value);
        }
    }
    /**
     * Encode a property value from Neo4j.
     *
     * @param rawProperty
     */
    $encodeProperty(rawProperty) {
        if (!_.isObject(rawProperty)) {
            // value is a primitive type
            return rawProperty;
        }
        if (Array.isArray(rawProperty)) {
            return rawProperty.map(this.$encodeProperty.bind(this));
        }
        // we wrap objects in an array to prevent data edition
        // TODO #1333 support Neo4j temporal values
        return [Neo4jConnector.$objectToString(rawProperty)];
    }
    /**
     * Extract offset from neo4j error message.
     *
     * @param errorMessage
     */
    extractErrorOffset(errorMessage) {
        // offset information looks like (line 1, column 15 (offset: 14))
        const offsetRx = /[(]line \d+, column \d+ [(]offset: (\d+)[)]{2}$/g;
        // offset information is usually at the end of the first line of the error message
        const match = offsetRx.exec(errorMessage.split('\n')[0]);
        if (match !== null) {
            return Number.parseInt(match[1], 10);
        }
    }
}
module.exports = Neo4jConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9uZW80akNvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFHSCw0QkFBNEI7QUFFNUIsV0FBVztBQUNYLHNDQUF1QztBQUN2QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxTQUFTO0FBQ1QsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFvQixDQUFDO0FBRXhFLElBQUssY0FPSjtBQVBELFdBQUssY0FBYztJQUNqQixtREFBSSxDQUFBO0lBQ0osbURBQUksQ0FBQTtJQUNKLDZEQUFTLENBQUE7SUFDVCwyREFBUSxDQUFBO0lBQ1IsaUVBQVcsQ0FBQTtJQUNYLHlEQUFPLENBQUE7QUFDVCxDQUFDLEVBUEksY0FBYyxLQUFkLGNBQWMsUUFPbEI7QUFFRCxNQUFlLGNBQWUsU0FBUSxlQUFlO0lBQ25EOzs7T0FHRztJQUNILFlBQVksWUFBb0MsRUFBRSxZQUFxQztRQUNyRixLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRWxDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUM7UUFDbEQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztRQUMxRCxJQUNFLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1lBQ3ZCLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO1lBQzNCLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztZQUNoQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFDcEM7WUFDQSxHQUFHLENBQUMsSUFBSSxDQUFDLHFEQUFxRCxDQUFDLENBQUM7WUFDaEUsWUFBWSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUM7WUFDNUIsWUFBWSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7U0FDckM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxrQkFBa0IsQ0FDdkIsR0FBVyxFQUNYLFVBQW1CLEVBQ25CLGtCQUE0QjtRQUU1QixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksaUJBQWlCLENBQUMsR0FBVztRQUNsQyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLHVCQUF1QixDQUFDLEdBQVc7UUFDeEMsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFNBQVMsQ0FBQyxNQUFjLEVBQUUsSUFBWSxFQUFFLEdBQVk7UUFDekQsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksV0FBVztRQUNoQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLCtCQUErQixFQUFFLFNBQVMsQ0FFNUUsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQWM7UUFDNUMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzdDLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUU3QyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7WUFDaEIsT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO1NBQ2pDO1FBRUQsSUFBSSxJQUFJLEVBQUU7WUFDUixPQUFPLGNBQWMsQ0FBQyxJQUFJLENBQUM7U0FDNUI7UUFFRCxJQUFJLElBQUksRUFBRTtZQUNSLE9BQU8sY0FBYyxDQUFDLElBQUksQ0FBQztTQUM1QjtRQUVELElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLEVBQUU7WUFDeEQsT0FBTyxjQUFjLENBQUMsV0FBVyxDQUFDO1NBQ25DO1FBRUQsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsRUFBRTtZQUNyRCxPQUFPLGNBQWMsQ0FBQyxRQUFRLENBQUM7U0FDaEM7UUFFRCxPQUFPLGNBQWMsQ0FBQyxPQUFPLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxNQUFNLENBQUMsbUJBQW1CLENBQUMsS0FBNkI7UUFDOUQsT0FBTyxJQUFJLElBQUksQ0FDYixDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFXLEVBQ3BDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQVksR0FBRyxDQUFDLEVBQzVDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQVcsRUFDcEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBVyxFQUNyQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFXLEVBQ3ZDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQVcsQ0FDeEMsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQTZCO1FBQzNELE1BQU0sQ0FBQyxHQUFHLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwRCxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUMvRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBNkI7UUFDdkQsTUFBTSxDQUFDLEdBQUcsY0FBYyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BELE9BQU8sQ0FBQyxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQTZCO1FBQ3ZELE1BQU0sQ0FBQyxHQUFHLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwRCxPQUFPLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQTZCO1FBQzNELE9BQU8sS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUE2QjtRQUN4RCwrREFBK0Q7UUFDL0QsbUVBQW1FO1FBQ25FLHlEQUF5RDtRQUN6RCxtQ0FBbUM7UUFDbkMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsRCxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUMxRixLQUFLLEVBQ0wsYUFBYSxFQUNiLEVBQUUsQ0FDUyxDQUFDO1FBQ2QsT0FBTyxjQUFjLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUE2QjtRQUMxRCwrQ0FBK0M7UUFDL0MsSUFBSSxPQUFPLEtBQUssQ0FBQyxjQUFjLEtBQUssVUFBVSxFQUFFO1lBQzlDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNqQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLFFBQVEsRUFBRTtnQkFDekIsT0FBTyxDQUFDLENBQUM7YUFDVjtTQUNGO1FBRUQsOENBQThDO1FBQzlDLFFBQVEsY0FBYyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzlDLEtBQUssY0FBYyxDQUFDLElBQUk7Z0JBQ3RCLE9BQU8sY0FBYyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1QyxLQUFLLGNBQWMsQ0FBQyxJQUFJO2dCQUN0QixPQUFPLGNBQWMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDNUMsS0FBSyxjQUFjLENBQUMsU0FBUztnQkFDM0IsT0FBTyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEQsS0FBSyxjQUFjLENBQUMsUUFBUTtnQkFDMUIsT0FBTyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEQsS0FBSyxjQUFjLENBQUMsV0FBVztnQkFDN0IsT0FBTyxjQUFjLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdDO2dCQUNFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ08sZUFBZSxDQUFDLFdBQW9CO1FBQzVDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzVCLDRCQUE0QjtZQUM1QixPQUFPLFdBQThCLENBQUM7U0FDdkM7UUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFhLENBQUM7U0FDckU7UUFFRCxzREFBc0Q7UUFDdEQsMkNBQTJDO1FBQzNDLE9BQU8sQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLFdBQXFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pGLENBQUM7SUFFRDs7OztPQUlHO0lBQ08sa0JBQWtCLENBQUMsWUFBb0I7UUFDL0MsaUVBQWlFO1FBQ2pFLE1BQU0sUUFBUSxHQUFHLGtEQUFrRCxDQUFDO1FBQ3BFLGtGQUFrRjtRQUNsRixNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6RCxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7WUFDbEIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN0QztJQUNILENBQUM7Q0FDRjtBQUVELGlCQUFTLGNBQWMsQ0FBQyJ9