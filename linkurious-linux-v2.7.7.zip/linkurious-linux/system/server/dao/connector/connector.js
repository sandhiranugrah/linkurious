"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
class Connector {
    /**
     * Use `indexOptions` if this connector will be used only for IndexDAOs.
     * If used by a GraphDAO, `indexOptions` is not defined.
     *
     * @param graphOptions   GraphDAO options
     * @param [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        this.CONNECT_TIMEOUT = 10000; // 10 seconds
        this.graphOptions = graphOptions;
        this.indexOptions = indexOptions;
    }
    get SLOW_QUERY_THRESHOLD() {
        return LKE.isTestMode() ? 50 : 1000;
    }
    /**
     * Return a GraphDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getGraphOption(key, defaultValue) {
        const value = this.graphOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Return an IndexDAO option by key (or a default value if undefined or null).
     *
     * @param key            Option key
     * @param [defaultValue] Default value
     */
    getIndexOption(key, defaultValue) {
        if (Utils.noValue(this.indexOptions)) {
            throw Errors.technical('bug', 'Don\'t call getIndexOption in a connector used for GraphDAOs');
        }
        const value = this.indexOptions[key];
        return Utils.hasValue(value) ? value : defaultValue;
    }
    /**
     * Disconnect from the remote server.
     *
     * Optional to implement.
     */
    // tslint:disable-next-line:no-empty
    $disconnect() { }
}
module.exports = Connector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvY29ubmVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUtILFdBQVc7QUFDWCxzQ0FBdUM7QUFDdkMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFlLFNBQVM7SUFNdEI7Ozs7OztPQU1HO0lBQ0gsWUFBWSxZQUFvQyxFQUFFLFlBQXFDO1FBWnZFLG9CQUFlLEdBQUcsS0FBSyxDQUFDLENBQUMsYUFBYTtRQWFwRCxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztRQUNqQyxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztJQUNuQyxDQUFDO0lBRUQsSUFBSSxvQkFBb0I7UUFDdEIsT0FBTyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNPLGNBQWMsQ0FBQyxHQUFXLEVBQUUsWUFBc0I7UUFDMUQsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNyQyxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0lBQ3RELENBQUM7SUFFRDs7Ozs7T0FLRztJQUNPLGNBQWMsQ0FBQyxHQUFXLEVBQUUsWUFBc0I7UUFDMUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNwQyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDhEQUE4RCxDQUFDLENBQUM7U0FDL0Y7UUFFRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7SUFDdEQsQ0FBQztJQU9EOzs7O09BSUc7SUFDSCxvQ0FBb0M7SUFDN0IsV0FBVyxLQUFVLENBQUM7Q0FtQjlCO0FBRUQsaUJBQVMsU0FBUyxDQUFDIn0=