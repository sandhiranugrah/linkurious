/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
*/
'use strict';
// internal libs
const crypto = require('crypto');
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// locals
const SparqlConnector = require('./sparqlConnector');
const LkRequest = require('../../lib/LkRequest');
const SparqlUtils = require('../utils/sparqlUtils');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
class AllegroGraphConnector extends SparqlConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this._catalog = this.getGraphOption('catalog');
        this._catalogURIComponent = Utils.hasValue(this._catalog)
            ? '/catalogs/' + encodeURIComponent(this._catalog)
            : '';
        this.$url = this.$url + this._catalogURIComponent + '/repositories/' +
            encodeURIComponent(this.getGraphOption('repository'));
        this._prefixToURI = new Map();
        this._request = new LkRequest({
            baseUrl: this.$url,
            auth: this.getGraphOption('user') ? {
                user: this.getGraphOption('user'),
                password: this.getGraphOption('password')
            } : undefined,
            strictSSL: !this.getGraphOption('allowSelfSigned'),
            json: true,
            pool: { maxSockets: 5 }
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        // Too late for allegroGraph, the Store ID is not human readable.
        let storeIdComponents = [this.$url, this.$defaultNamespace, this.$categoryPredicate];
        let prefixURIPairs = [];
        this.$prefixToURI.forEach((uri, prefix) => {
            prefixURIPairs.push([prefix, uri]);
        });
        prefixURIPairs = _.sortBy(prefixURIPairs, o => o[0]);
        storeIdComponents = storeIdComponents.concat(prefixURIPairs);
        const storeId = crypto.createHash('md5').update(JSON.stringify(storeIdComponents))
            .digest('hex')
            .slice(0, 8);
        return Promise.resolve(storeId);
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this._request.get('/size', { timeout: this.CONNECT_TIMEOUT }, [200, 404, 401]).catch(e => {
            return Errors.technical('critical', 'Could not connect to the AllegroGraph server (' + e.message + ').', true);
        }).then(existR => {
            // if the repository does not exist
            if (existR.statusCode === 404) {
                // and I can create it
                if (this.getGraphOption('create')) {
                    // create it
                    return this._request.put('', undefined, [204]);
                }
                else {
                    return Errors.technical('critical', 'The repository was not found.', true);
                }
            }
            else if (existR.statusCode === 401) {
                return Errors.business('invalid_parameter', 'Credentials for AllegroGraph are not valid.', true);
            }
        }).then(() => {
            // retrieve the namespaces
            return this._request.get('/namespaces', undefined, [200]).then(nsR => {
                this._prefixToURI.clear();
                for (let i = 0; i < nsR.body.length; i++) {
                    this._prefixToURI.set(nsR.body[i].prefix, nsR.body[i].namespace);
                }
                this._utils = new SparqlUtils(this._prefixToURI, this.$defaultNamespace);
                if (this._utils.isPrefixNotation(this.$categoryPredicate)) {
                    // resolve the category predicate to a full URI
                    this.$categoryPredicate = this._utils.shortNameToFullURI(this.$categoryPredicate);
                }
                // we set the category predicate after we resolved the full URI
                this._utils.categoryPredicate = this.$categoryPredicate;
                if (!this._utils.isURI(this.$categoryPredicate)) {
                    return Errors.business('invalid_parameter', '"' + this.$categoryPredicate +
                        '" is not a valid category predicate (must be a URI wrapped in angle brackets).', true);
                }
            });
        }).then(() => {
            // baseUrl by default is the repository Url. Here we need the AllegroGraph Url
            return this._request.get('/version', { baseUrl: this.getGraphOption('url') }, [200])
                .get('body');
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this._request.get('/size', [200]).return();
    }
    /**
     * Get the LkRequest object for direct access to the HTTP endpoint.
     *
     * @type {LkRequest}
     */
    get $request() {
        return this._request;
    }
    /**
     * Get the mapping from prefixes to namespaces.
     *
     * e.g.:
     * 'foaf' -> 'http://xmlns.com/foaf/0.1/'
     * 'rdf'  -> 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
     *
     * @type {Map<string, string>}
     */
    get $prefixToURI() {
        return this._prefixToURI;
    }
    /**
     * Check that a given statement belongs to the triple store.
     *
     * @param {string} subject
     * @param {string} predicate
     * @param {string} object
     * @returns {Bluebird<boolean>}
     */
    $checkStatement(subject, predicate, object) {
        return this.$getStatements([subject], [predicate], [object]).then(result => {
            return result.length > 0;
        });
    }
    /**
     * Return all the statements in the triple store that have subject in `subjects`.
     *
     * @param {string[]} subjects
     * @returns {Bluebird<string[][]>}
     */
    $getStatementsBySubjects(subjects) {
        return this.$getStatements(subjects);
    }
    /**
     * Return all the statements in the triple store that:
     * - have subject in `subjects`, or any if undefined
     * - have predicate in `predicates`, or any if undefined
     * - have object in `objects`, or any if undefined
     *
     * @param {string[]} [subjects]
     * @param {string[]} [predicates]
     * @param {string[]} [objects]
     * @returns {Bluebird<string[][]>}
     */
    $getStatements(subjects, predicates, objects) {
        // An empty array means none, undefined means all.
        if ((Utils.hasValue(subjects) && subjects.length === 0) ||
            (Utils.hasValue(predicates) && predicates.length === 0) ||
            (Utils.hasValue(objects) && objects.length === 0)) {
            return Promise.resolve([]);
        }
        const form = {};
        if (Utils.hasValue(subjects)) {
            form.subj = subjects;
        }
        if (Utils.hasValue(predicates)) {
            form.pred = predicates;
        }
        if (Utils.hasValue(objects)) {
            form.obj = objects;
        }
        return this._request.post('/statements/query', { form, qsStringifyOptions: { indices: false } }, [200]).get('body');
    }
    /**
     * Delete all the statements in the triple store that:
     * - have `subject` as subject, or any if undefined
     * - have `predicate` as predicate, or any if undefined
     * - have `object` as object, or any if undefined
     *
     * Return true if at least a statement was deleted.
     *
     * @param {string} [subject]
     * @param {string} [predicate]
     * @param {string} [object]
     * @returns {Bluebird<boolean>}
     */
    $deleteStatements(subject, predicate, object) {
        return this._request.delete('/statements', { qs: { subj: subject, pred: predicate, obj: object } }, [200]).then(response => {
            return response.body > 0; // response.body is the number of deleted statements
        });
    }
    /**
     * Delete all the statements in the triple store.
     *
     * @returns {Bluebird<void>}
     */
    $deleteAllStatements() {
        return this._request.delete('/statements', undefined, [200]).return();
    }
    /**
     * Add `statements` to the triple store.
     *
     * @param {string[][]} statements
     * @returns {Bluebird<void>}
     */
    $addStatements(statements) {
        return this._request.post('/statements', { body: statements }, [204]).return();
    }
    /**
     * Generate a from clause for each graph of the data set.
     * e.g: `FROM <g1> ... FROM <gn-1> FROM <gn>`
     *
     * @returns {string}
     */
    get $fromClause() {
        // AllegroGraph queries all graphs by default
        return '';
    }
    /**
     * Execute a sparql query on the triple store.
     *
     * @param {string} query
     * @param {object} [options]
     * @param {number} [options.timeout] Milliseconds to wait before it fails
     * @returns {Bluebird<string[][]>}
     */
    $doSparqlQuery(query, options = {}) {
        const { timeout } = options;
        const t0 = Date.now();
        const request = this._request.post.bind(this._request);
        return request('', { qs: { query: query }, timeout: timeout })
            .then(response => {
            if (response.statusCode !== 200) {
                const isBadGraphRequest = response.body && response.body.includes('MALFORMED QUERY');
                const errorMessage = '$doSparqlQuery wasn\'t able to execute ' +
                    'the query on AllegroGraph: ' + response.statusCode + ' ' + response.body;
                if (isBadGraphRequest) {
                    return Errors.business('bad_graph_request', errorMessage, true);
                }
                else {
                    return Errors.technical('critical', errorMessage, true);
                }
            }
            return response.body.values;
        }).catch(error => {
            // Allegro graph requests fail with a socket error when the request times out.
            if (_.includes(error.message, 'ETIMEDOUT')) {
                throw new GraphRequestTimeout(Vendor.ALLEGRO);
            }
            throw error;
        }).finally(() => {
            Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (HTTP): ' + query, Log);
        });
    }
}
module.exports = AllegroGraphConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxsZWdyb0dyYXBoQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvYWxsZWdyb0dyYXBoQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztFQUtFO0FBQ0YsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUVqQyxnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLFNBQVM7QUFDVCxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNyRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNwRCxNQUFNLEVBQUMsbUJBQW1CLEVBQUUsTUFBTSxFQUFDLEdBQUcsT0FBTyxDQUFDLHlDQUF5QyxDQUFDLENBQUM7QUFFekYsTUFBTSxxQkFBc0IsU0FBUSxlQUFlO0lBRWpEOzs7T0FHRztJQUNILFlBQVksWUFBWSxFQUFFLFlBQVk7UUFDcEMsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLG9CQUFvQixHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUN2RCxDQUFDLENBQUMsWUFBWSxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDbEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUVQLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsZ0JBQWdCO1lBQ2xFLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUV4RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDbEIsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUM7Z0JBQ2pDLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQzthQUMxQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQ2IsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQztZQUNsRCxJQUFJLEVBQUUsSUFBSTtZQUNWLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUM7U0FDdEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxXQUFXO1FBQ1QsaUVBQWlFO1FBQ2pFLElBQUksaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNyRixJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFFeEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDeEMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO1FBRUgsY0FBYyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFckQsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRTdELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsQ0FBQzthQUMvRSxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ2IsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVmLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVE7UUFDTixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQzVGLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsVUFBVSxFQUNWLGdEQUFnRCxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxFQUNuRSxJQUFJLENBQ0wsQ0FBQztRQUVKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLG1DQUFtQztZQUNuQyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUM3QixzQkFBc0I7Z0JBQ3RCLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDakMsWUFBWTtvQkFDWixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNoRDtxQkFBTTtvQkFDTCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLCtCQUErQixFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUM1RTthQUNGO2lCQUFNLElBQUksTUFBTSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7Z0JBQ3BDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsNkNBQTZDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDeEQ7UUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsMEJBQTBCO1lBQzFCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUVuRSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUUxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3hDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2xFO2dCQUVELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFFekUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUN6RCwrQ0FBK0M7b0JBQy9DLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2lCQUNuRjtnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUV4RCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7b0JBQy9DLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCO3dCQUM3QixnRkFBZ0YsRUFDaEYsSUFBSSxDQUNMLENBQUM7aUJBQ0g7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCw4RUFBOEU7WUFDOUUsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQy9FLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksUUFBUTtRQUNWLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxJQUFJLFlBQVk7UUFDZCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxlQUFlLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FDeEIsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQ2pDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2QsT0FBTyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHdCQUF3QixDQUFDLFFBQVE7UUFDL0IsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsY0FBYyxDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsT0FBTztRQUMxQyxrREFBa0Q7UUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7WUFDckQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1lBQ3ZELENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxFQUFFO1lBQ25ELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM1QjtRQUVELE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUM7U0FDdEI7UUFDRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDOUIsSUFBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7U0FDeEI7UUFDRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM0IsSUFBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUM7U0FDcEI7UUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUMzQyxFQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUMsRUFBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNILGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTTtRQUMxQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFDdkMsRUFBQyxFQUFFLEVBQUUsRUFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBQyxFQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUU1RSxPQUFPLFFBQVEsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsb0RBQW9EO1FBQ2hGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsVUFBVTtRQUN2QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxVQUFVLEVBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDL0UsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsSUFBSSxXQUFXO1FBQ2IsNkNBQTZDO1FBQzdDLE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ2hDLE1BQU0sRUFBQyxPQUFPLEVBQUMsR0FBRyxPQUFPLENBQUM7UUFDMUIsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFdkQsT0FBTyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUMsRUFBRSxFQUFFLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUMsQ0FBQzthQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDZixJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUMvQixNQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFFckYsTUFBTSxZQUFZLEdBQUcseUNBQXlDO29CQUM1RCw2QkFBNkIsR0FBRyxRQUFRLENBQUMsVUFBVSxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dCQUU1RSxJQUFJLGlCQUFpQixFQUFFO29CQUNyQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNqRTtxQkFBTTtvQkFDTCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDekQ7YUFDRjtZQUVELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsOEVBQThFO1lBQzlFLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxFQUFFO2dCQUMxQyxNQUFNLElBQUksbUJBQW1CLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQy9DO1lBQ0QsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2QsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLGdCQUFnQixHQUFHLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM5RSxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcscUJBQXFCLENBQUMifQ==