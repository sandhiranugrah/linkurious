/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// locals
const SparqlConnector = require('./sparqlConnector');
const LkRequest = require('../../lib/LkRequest');
const SparqlUtils = require('../utils/sparqlUtils');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
class StardogConnector extends SparqlConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this.$url = this.$url + '/' + encodeURIComponent(this.getGraphOption('repository'));
        this._prefixToURI = new Map();
        this._request = new LkRequest({
            baseUrl: this.$url,
            auth: this.getGraphOption('user') ? {
                user: this.getGraphOption('user'),
                password: this.getGraphOption('password')
            } : undefined,
            strictSSL: !this.getGraphOption('allowSelfSigned'),
            pool: { maxSockets: 5 }
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Promise.resolve(this.getGraphOption('repository'));
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this._request.get('/size', { timeout: this.CONNECT_TIMEOUT }, [200, 404, 401, 403]).catch(e => {
            return Errors.technical('critical', 'Could not connect to the Stardog server (' + e.message + ').', true);
        }).then(existR => {
            // if the repository does not exist
            if (existR.statusCode === 404) {
                return Errors.technical('critical', 'The repository was not found.', true);
            }
            else if (existR.statusCode === 401) {
                return Errors.business('invalid_parameter', 'Credentials for Stardog are not valid.', true);
            }
            else if (existR.statusCode === 403) {
                return Errors.business('invalid_parameter', 'Configured Stardog user is not authorized to perform this action.', true);
            }
        }).then(() => {
            // retrieve the namespaces
            const getNamespaceURL = '/admin/databases/' +
                encodeURIComponent(this.getGraphOption('repository')) + '/options';
            // baseUrl by default is the repository Url. Here we need the Stardog Url
            return this._request.put(getNamespaceURL, { baseUrl: this.getGraphOption('url'), body: { 'database.namespaces': '' }, json: true }, [200]).then(nsR => {
                const namespaceArray = nsR.body['database.namespaces'];
                this._prefixToURI.clear();
                _.forEach(namespaceArray, ns => {
                    // format of `ns` is 'rdf=http://www.w3.org/1999/02/22-rdf-syntax-ns#'
                    const s = Utils.splitOnce(ns, '=');
                    this._prefixToURI.set(s[0], s[1]);
                });
                this._utils = new SparqlUtils(this._prefixToURI, this.$defaultNamespace);
                if (this._utils.isPrefixNotation(this.$categoryPredicate)) {
                    // resolve the category predicate to a full URI
                    this.$categoryPredicate = this._utils.shortNameToFullURI(this.$categoryPredicate);
                }
                // we set the category predicate after we resolved the full URI
                this._utils.categoryPredicate = this.$categoryPredicate;
                if (!this._utils.isURI(this.$categoryPredicate)) {
                    return Errors.business('invalid_parameter', '"' + this.$categoryPredicate +
                        '" is not a valid category predicate (must be a URI wrapped in angle brackets).', true);
                }
            });
        }).then(() => {
            // baseUrl by default is the repository Url. Here we need the Stardog Url
            return this._request.get('/admin/status', { baseUrl: this.getGraphOption('url'), json: true }, [200]).then(versionR => {
                return versionR.body['dbms.version'].value;
            });
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this._request.get('/size', undefined, [200]).return();
    }
    /**
     * Get the LkRequest object for direct access to the HTTP endpoint.
     *
     * @type {LkRequest}
     */
    get $request() {
        return this._request;
    }
    /**
     * Get the mapping from prefixes to namespaces.
     *
     * e.g.:
     * 'foaf' -> 'http://xmlns.com/foaf/0.1/'
     * 'rdf'  -> 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
     *
     * @type {Map<string, string>}
     */
    get $prefixToURI() {
        return this._prefixToURI;
    }
    /**
     * Check that a given statement belongs to the triple store.
     *
     * @param {string} subject
     * @param {string} predicate
     * @param {string} object
     * @returns {Bluebird<boolean>}
     */
    $checkStatement(subject, predicate, object) {
        // a predicate cannot be a blank node
        [subject, object] = this._utils.wrapBlankNodesInAngleBrackets([subject, object]);
        return this.$doSparqlQuery(`SELECT (count(*) as ?exists) ${this.$fromClause} WHERE {
         {
           select * {${subject} ${predicate} ${object}} limit 1
         }
       }`).then(result => {
            return Boolean(this._utils.revertLiteral(result[0][0]));
        });
    }
    /**
     * Delete all the statements in the triple store that:
     * - have `subject` as subject, or any if undefined
     * - have `predicate` as predicate, or any if undefined
     * - have `object` as object, or any if undefined
     *
     * Return true if at least a statement was deleted.
     *
     * @param {string} [subject]
     * @param {string} [predicate]
     * @param {string} [object]
     * @returns {Bluebird<boolean>}
     */
    $deleteStatements(subject, predicate, object) {
        // For performance reasons in this function we prefer BIND and UNION over VALUES
        return Promise.resolve().then(() => {
            if (Utils.noValue(subject) && Utils.noValue(predicate) && Utils.noValue(object)) {
                return Errors.technical('bug', 'subject, predicate and object are undefined', true);
            }
            const values = [];
            if (Utils.hasValue(subject)) {
                [subject] = this._utils.wrapBlankNodesInAngleBrackets([subject]);
                values.push(`{BIND (${subject} as ?s). ?s ?p ?o.}`);
            }
            else {
                subject = '?s';
            }
            if (Utils.hasValue(predicate)) {
                values.push(`{BIND (${predicate} as ?p). ?s ?p ?o.}`);
            }
            else {
                predicate = '?p';
            }
            if (Utils.hasValue(object)) {
                [object] = this._utils.wrapBlankNodesInAngleBrackets([object]);
                values.push(`{BIND (${object} as ?o). ?s ?p ?o.}`);
            }
            else {
                object = '?o';
            }
            const boundValues = values.join('. ');
            return this.$doSparqlQuery(`SELECT ?s ?p ?o ${this.$fromClause} WHERE {${boundValues}}`)
                .then(statements => {
                if (statements.length === 0) {
                    return false;
                }
                // We use the sparql delete sequence to delete form all graphs including the default graph
                // `DELETE WHERE {?s ?p ?o}` only deletes from the default graph
                // `DELETE WHERE { GRAPH ?g {?s ?p ?o} }` deletes from all the graphs except the default graph
                return this.$doSparqlQuery(`DELETE WHERE {${subject} ${predicate} ${object}};` +
                    `DELETE WHERE { GRAPH ?g {${subject} ${predicate} ${object}} }`).return(true);
            });
        });
    }
    /**
     * Delete all the statements in the triple store.
     *
     * @returns {Bluebird<void>}
     */
    $deleteAllStatements() {
        return this._underTransaction(tid => {
            return this._request.post('/' + tid + '/clear', undefined, [200]);
        });
    }
    /**
     * Add `statements` to the triple store.
     *
     * @param {string[][]} statements
     * @returns {Bluebird<void>}
     */
    $addStatements(statements) {
        const nTriples = _.map(statements, statement => statement.join(' ') + ' .').join('\n');
        return this._underTransaction(tid => {
            return this._request.post('/' + tid + '/add', {
                body: nTriples
            }, [200]);
        }).return();
    }
    /**
     * Generate a from clause for each graph of the data set.
     * e.g: `FROM <g1> ... FROM <gn-1> FROM <gn>`
     *
     * @returns {string}
     */
    get $fromClause() {
        // Stardog uses a shortcut to target all graphs in one from clause
        return 'FROM <tag:stardog:api:context:all>';
    }
    /**
     * Execute a sparql query on the triple store using the '/update' or the '/query' endpoint.
     *
     * @param {string}  query
     * @param {number}  [timeout]   Milliseconds to wait before it fails
     * @param {string}  endpoint    '/update' or '/query'
     * @param {string}  [reasoning] 'enabled':  Allow inferred statements
     *                              'disabled': Forbid inferred statements
     *                              'default':  Use the configuration flag
     * @returns {Bluebird<string[][]>}
     * @private
     */
    _doSparqlQuery(query, timeout, endpoint, reasoning = 'default') {
        const enableReasoning = reasoning === 'disabled'
            ? false
            : reasoning === 'enabled' ? true : this.getGraphOption('reasoning', false);
        return this._request.post(endpoint, {
            form: { query: query, reasoning: enableReasoning },
            json: true,
            headers: { 'Accept': 'application/sparql-results+json' },
            timeout: timeout
        }).then(response => {
            if (response.statusCode !== 200) {
                const stardogErrorMessage = response.body && response.body.message ||
                    JSON.stringify(response.body);
                const isBadGraphRequest = stardogErrorMessage.includes('expecting one of');
                const errorMessage = '_doSparqlQuery wasn\'t able to execute ' +
                    'the query on Stardog: ' + response.statusCode + ' ' + stardogErrorMessage;
                if (isBadGraphRequest) {
                    return Errors.business('bad_graph_request', errorMessage, true);
                }
                else {
                    return Errors.technical('critical', errorMessage, true);
                }
            }
            if (Utils.noValue(response.body) || Utils.noValue(response.body.head) ||
                Utils.noValue(response.body.head.vars) || Utils.noValue(response.body.results) ||
                Utils.noValue(response.body.results.bindings)) {
                // this is not an error, but un update query that doesn't return anything
                return [];
            }
            const head = response.body.head.vars;
            const results = response.body.results.bindings;
            return _.map(results, rawStatement => {
                const statement = [];
                for (let i = 0; i < head.length; i++) {
                    // we process each entry s.t. we comply with the output format defined in sparqlConnector
                    const rawEntry = rawStatement[head[i]];
                    if (Utils.noValue(rawEntry)) {
                        // no entry for this column/row
                        statement.push(undefined);
                        continue;
                    }
                    if (rawEntry.type === 'uri') {
                        statement.push('<' + rawEntry.value + '>');
                    }
                    else if (rawEntry.type === 'bnode') {
                        statement.push('_:' + rawEntry.value);
                    }
                    else { // rawEntry.type === 'literal'
                        let literalValue = JSON.stringify(rawEntry.value);
                        if (Utils.hasValue(rawEntry.datatype)) {
                            literalValue += '^^<' + rawEntry.datatype + '>';
                        }
                        statement.push(literalValue);
                    }
                }
                return statement;
            });
        }).catch(error => {
            // Stardog server fails to send a response is the only we have that a timeout occurred from
            // the current request.
            if (error.key === 'critical' && error.message === 'Parse Error') {
                throw new GraphRequestTimeout(Vendor.STARDOG);
            }
            throw error;
        });
    }
    /**
     * Execute a sparql query on the triple store.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {number}  [options.timeout]   Milliseconds to wait before it fails
     * @param {string}  [options.reasoning] 'enabled':  Allow inferred statements
     *                                      'disabled': Forbid inferred statements
     *                                      'default':  Use the configuration flag
     * @returns {Bluebird<string[][]>}
     */
    $doSparqlQuery(query, options = {}) {
        const { timeout, reasoning } = options;
        const t0 = Date.now();
        // Stardog handle write permissions for us
        // but it doesn't like that we send read query to the update endpoint
        // so we first try a simple query
        return this._doSparqlQuery(query, timeout, '/query', reasoning).catch(err => {
            if (err.message && err.message.includes('update query')) {
                return this._doSparqlQuery(query, timeout, '/update', reasoning);
            }
            throw err;
        }).finally(() => {
            Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (HTTP): ' + query, Log);
        });
    }
    /**
     * Execute `func` under a transaction:
     * - commit the transaction if `func` resolves
     * - rollback the transaction if `func` rejects
     *
     * This function resolves with the same value resolved by `func`.
     * `func` will be invoked with 1 parameter, the transaction ID.
     *
     * @param {function(string): Bluebird<any>} func
     * @returns {Bluebird<any>}
     */
    _underTransaction(func) {
        return this._request.post('/transaction/begin', undefined, [200]).then(response => {
            const tid = response.body;
            return func(tid).then(value => {
                return this._request.post('/transaction/commit/' + tid, undefined, [200]).return(value);
            }).catch(e => {
                return this._request.post('/transaction/rollback/' + tid, undefined, [200]).catch(() => { }).then(() => {
                    throw e;
                });
            });
        });
    }
}
module.exports = StardogConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhcmRvZ0Nvbm5lY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vY29ubmVjdG9yL3N0YXJkb2dDb25uZWN0b3IuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLFNBQVM7QUFDVCxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNyRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNwRCxNQUFNLEVBQUMsbUJBQW1CLEVBQUUsTUFBTSxFQUFDLEdBQUcsT0FBTyxDQUFDLHlDQUF5QyxDQUFDLENBQUM7QUFFekYsTUFBTSxnQkFBaUIsU0FBUSxlQUFlO0lBRTVDOzs7T0FHRztJQUNILFlBQVksWUFBWSxFQUFFLFlBQVk7UUFDcEMsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUVwRixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUM1QixPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDbEIsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUM7Z0JBQ2pDLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQzthQUMxQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQ2IsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQztZQUNsRCxJQUFJLEVBQUUsRUFBQyxVQUFVLEVBQUUsQ0FBQyxFQUFDO1NBQ3RCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsV0FBVztRQUNULE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQzlCLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUN0RCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNWLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsVUFBVSxFQUNWLDJDQUEyQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxFQUM5RCxJQUFJLENBQ0wsQ0FBQztRQUVKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLG1DQUFtQztZQUNuQyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUM3QixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLCtCQUErQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzVFO2lCQUFNLElBQUksTUFBTSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7Z0JBQ3BDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM3RjtpQkFBTSxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUNwQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixtRUFBbUUsRUFDbkUsSUFBSSxDQUNMLENBQUM7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCwwQkFBMEI7WUFDMUIsTUFBTSxlQUFlLEdBQUcsbUJBQW1CO2dCQUN6QyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO1lBRXJFLHlFQUF5RTtZQUN6RSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUN0QixlQUFlLEVBQ2YsRUFBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBQyxxQkFBcUIsRUFBRSxFQUFFLEVBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFDLEVBQ3BGLENBQUMsR0FBRyxDQUFDLENBQ04sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ1gsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2dCQUV2RCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUMxQixDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDN0Isc0VBQXNFO29CQUN0RSxNQUFNLENBQUMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDbkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7Z0JBRXpFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDekQsK0NBQStDO29CQUMvQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztpQkFDbkY7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFFeEQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUMvQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixHQUFHLEdBQUcsSUFBSSxDQUFDLGtCQUFrQjt3QkFDN0IsZ0ZBQWdGLEVBQ2hGLElBQUksQ0FDTCxDQUFDO2lCQUNIO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gseUVBQXlFO1lBQ3pFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQ3RCLGVBQWUsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUMxRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUM3QyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUMvRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksUUFBUTtRQUNWLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxJQUFJLFlBQVk7UUFDZCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxlQUFlLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNO1FBQ3hDLHFDQUFxQztRQUNyQyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDakYsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUN4QixnQ0FBZ0MsSUFBSSxDQUFDLFdBQVc7O3VCQUUvQixPQUFPLElBQUksU0FBUyxJQUFJLE1BQU07O1NBRTVDLENBQ0osQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDZCxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNILGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTTtRQUMxQyxnRkFBZ0Y7UUFDaEYsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUMvRSxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDZDQUE2QyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3JGO1lBQ0QsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDM0IsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDakUsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLE9BQU8scUJBQXFCLENBQUMsQ0FBQzthQUNyRDtpQkFBTTtnQkFDTCxPQUFPLEdBQUcsSUFBSSxDQUFDO2FBQ2hCO1lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsU0FBUyxxQkFBcUIsQ0FBQyxDQUFDO2FBQ3ZEO2lCQUFNO2dCQUNMLFNBQVMsR0FBRyxJQUFJLENBQUM7YUFDbEI7WUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzFCLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQy9ELE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxNQUFNLHFCQUFxQixDQUFDLENBQUM7YUFDcEQ7aUJBQU07Z0JBQ0wsTUFBTSxHQUFHLElBQUksQ0FBQzthQUNmO1lBRUQsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV0QyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQ3hCLG1CQUFtQixJQUFJLENBQUMsV0FBVyxXQUFXLFdBQVcsR0FBRyxDQUFDO2lCQUM1RCxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ2pCLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQzNCLE9BQU8sS0FBSyxDQUFDO2lCQUNkO2dCQUNELDBGQUEwRjtnQkFDMUYsZ0VBQWdFO2dCQUNoRSw4RkFBOEY7Z0JBQzlGLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FDeEIsaUJBQWlCLE9BQU8sSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJO29CQUNuRCw0QkFBNEIsT0FBTyxJQUFJLFNBQVMsSUFBSSxNQUFNLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsRixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FDdkIsR0FBRyxHQUFHLEdBQUcsR0FBRyxRQUFRLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQ3ZDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGNBQWMsQ0FBQyxVQUFVO1FBQ3ZCLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkYsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FDdkIsR0FBRyxHQUFHLEdBQUcsR0FBRyxNQUFNLEVBQ2xCO2dCQUNFLElBQUksRUFBRSxRQUFRO2FBQ2YsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUNULENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUksV0FBVztRQUNiLGtFQUFrRTtRQUNsRSxPQUFPLG9DQUFvQyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILGNBQWMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLEdBQUcsU0FBUztRQUM1RCxNQUFNLGVBQWUsR0FBRyxTQUFTLEtBQUssVUFBVTtZQUM5QyxDQUFDLENBQUMsS0FBSztZQUNQLENBQUMsQ0FBQyxTQUFTLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzdFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUNoQztZQUNFLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBQztZQUNoRCxJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxpQ0FBaUMsRUFBQztZQUN0RCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUNGLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLElBQUksUUFBUSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7Z0JBQy9CLE1BQU0sbUJBQW1CLEdBQUcsUUFBUSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU87b0JBQ2hFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNoQyxNQUFNLGlCQUFpQixHQUFHLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2dCQUUzRSxNQUFNLFlBQVksR0FBRyx5Q0FBeUM7b0JBQzVELHdCQUF3QixHQUFHLFFBQVEsQ0FBQyxVQUFVLEdBQUcsR0FBRyxHQUFHLG1CQUFtQixDQUFDO2dCQUU3RSxJQUFJLGlCQUFpQixFQUFFO29CQUNyQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNqRTtxQkFBTTtvQkFDTCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDekQ7YUFDRjtZQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDbkUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO2dCQUM5RSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUMvQyx5RUFBeUU7Z0JBQ3pFLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDckMsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBRS9DLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLEVBQUU7Z0JBQ25DLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQztnQkFDckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3BDLHlGQUF5RjtvQkFDekYsTUFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUV2QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQzNCLCtCQUErQjt3QkFDL0IsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDMUIsU0FBUztxQkFDVjtvQkFFRCxJQUFJLFFBQVEsQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO3dCQUMzQixTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO3FCQUM1Qzt5QkFBTSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO3dCQUNwQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3ZDO3lCQUFNLEVBQUUsOEJBQThCO3dCQUNyQyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDbEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTs0QkFDckMsWUFBWSxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQzt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztxQkFDOUI7aUJBQ0Y7Z0JBRUQsT0FBTyxTQUFTLENBQUM7WUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZiwyRkFBMkY7WUFDM0YsdUJBQXVCO1lBQ3ZCLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxVQUFVLElBQUksS0FBSyxDQUFDLE9BQU8sS0FBSyxhQUFhLEVBQUU7Z0JBQy9ELE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDL0M7WUFDRCxNQUFNLEtBQUssQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxjQUFjLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ2hDLE1BQU0sRUFBQyxPQUFPLEVBQUUsU0FBUyxFQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ3JDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN0QiwwQ0FBMEM7UUFDMUMscUVBQXFFO1FBQ3JFLGlDQUFpQztRQUNqQyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzFFLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDdkQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2FBQ2xFO1lBRUQsTUFBTSxHQUFHLENBQUM7UUFDWixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO1lBQ2QsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLGdCQUFnQixHQUFHLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM5RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsaUJBQWlCLENBQUMsSUFBSTtRQUNwQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUN2QixvQkFBb0IsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FDdkMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFFaEIsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztZQUUxQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzVCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ3ZCLHNCQUFzQixHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FDL0MsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ3ZCLHdCQUF3QixHQUFHLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FDakQsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDMUIsTUFBTSxDQUFDLENBQUM7Z0JBQ1YsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyJ9