/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// external libs
const _ = require('lodash');
const through = require('through');
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
// our libs
const JsonStream = require('../../../lib/JsonStream');
// locals
const Neo4jConnector = require('./neo4jConnector');
const LkRequest = require('../../lib/LkRequest');
const CypherUtils = require('./../utils/cypherUtils');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
class Neo4jHTTPConnector extends Neo4jConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this.$httpUrl = Utils.normalizeUrl(this.getGraphOption('url'));
        this.$request = new LkRequest({
            strictSSL: !this.getGraphOption('allowSelfSigned'),
            auth: this.getGraphOption('user') ? {
                user: this.getGraphOption('user'),
                password: this.getGraphOption('password')
            } : undefined,
            proxy: this.getGraphOption('proxy'),
            pool: { maxSockets: 5 },
            json: true,
            gzip: true
        });
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        // The request is explicitly towards /db/data/ and not /db/data due to a GrapheneDB bug #1201
        return this.$request.get(this.$httpUrl + '/db/data/', {}, [200, 401, 403]).then(response => {
            if (response.statusCode === 401 || response.statusCode === 403) {
                return Errors.business('invalid_parameter', 'Please check the Neo4j username and password in the configuration.', true);
            }
            // check version
            this.version = response.body['neo4j_version'];
            if (Utils.noValue(this.version)) {
                return Errors.technical('critical', 'Cannot get Neo4j version.', true);
            }
            return this.version;
        });
    }
    /**
     * Encode a record from Neo4j in a valid response for Linkurious.
     *
     * @param {any} record
     * @private
     * @returns {{nodes: LkNode[], edges: LkEdge[], rows: any[]}}
     */
    _encodeHTTPResponseRecord(record) {
        // for every node and edge in the graph response we parse it and set it in a map (for nodes or edges)
        // we need the graph response because the row response doesn't contain all the info we need
        // (like the edge source and target or the labels)
        const nodesById = new Map();
        for (let i = 0; i < record.graph.nodes.length; i++) {
            const node = record.graph.nodes[i];
            if (node.deleted) {
                // node was deleted and a deleted node doesn't have labels and properties
                node.labels = [];
            }
            // node.id (as sent by Neo4j) is a string in HTTP responses
            nodesById.set(node.id, {
                id: node.id,
                categories: node.labels.sort(),
                data: _.mapValues(node.properties, this.$encodeProperty.bind(this))
            });
        }
        const edgesById = new Map();
        for (let i = 0; i < record.graph.relationships.length; i++) {
            // edge.id (as sent by Neo4j) is a string in HTTP responses
            const edge = record.graph.relationships[i];
            edgesById.set(edge.id, {
                id: edge.id,
                source: edge.startNode,
                target: edge.endNode,
                type: edge.type,
                data: _.mapValues(edge.properties, this.$encodeProperty.bind(this))
            });
        }
        return {
            nodes: Array.from(nodesById.values()),
            edges: Array.from(edgesById.values()),
            rows: record.row
        };
    }
    /**
     * @private
     */
    get _writeUrl() {
        return Utils.hasValue(this.getGraphOption('writeUrl'))
            ? Utils.normalizeUrl(this.getGraphOption('writeUrl'))
            : this.$httpUrl;
    }
    /**
     * Do an HTTP POST request toward Neo4j.
     *
     * Used to create a case insensitive Neo4j search index.
     *
     * @param {string}   url
     * @param {any}      parameters
     * @param {number[]} expectedStatusCode
     * @returns {Bluebird<IncomingMessage>}
     */
    $doHTTPPostRequest(url, parameters, expectedStatusCode) {
        return this.$request.post(url, {
            baseUrl: this.$httpUrl,
            body: parameters
        }, expectedStatusCode);
    }
    /**
     * Do an HTTP GET request toward Neo4j. Return the body of the response directly.
     *
     * Used to retrieve the simple schema before procedures were introduced.
     *
     * @param {string} url
     * @returns {Bluebird<any>}
     */
    $doHTTPGetRequest(url) {
        return this.$request.get(url, {
            baseUrl: this.$httpUrl
        }, [200]).get('body');
    }
    /**
     * Do an HTTP GET stream request toward Neo4j.
     *
     * @param {string} url
     * @returns {Bluebird<Readable<Buffer>>}
     */
    $doHTTPGetStreamRequest(url) {
        return this.$request.getStream(url, 'get', {
            baseUrl: this.$httpUrl
        }, [200]);
    }
    /**
     * Execute a cypher query on Neo4j.
     *
     * Note that this function is not meant for user queries.
     * We don't enforce a limit or check if the query contains write statements.
     * Use $safeCypherQueryStream instead.
     *
     * @param {string}  query        The graph query
     * @param {object}  [parameters] The graph query parameters
     * @param {boolean} [ignoreSlow] Don't log slow requests
     * @returns {Bluebird<{keys: string[], results: Array<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $doCypherQuery(query, parameters, ignoreSlow) {
        const willWrite = CypherUtils.isWrite(query);
        const baseUrl = willWrite ? this._writeUrl : this.$httpUrl;
        const t0 = Date.now();
        return this.$request.post('/db/data/transaction/commit', {
            baseUrl: baseUrl,
            body: {
                statements: [{
                        statement: query,
                        parameters: parameters,
                        resultDataContents: ['row', 'graph']
                    }]
            }
        }, [200]).then(response => {
            if (Utils.hasValue(response.body.errors) && response.body.errors.length > 0) {
                let errorMessage = Utils.safeGet(response.body, 'errors.0.message');
                const errorCode = Utils.safeGet(response.body, 'errors.0.code');
                // Neo4j has multiple Constraint violation errors (depending on the version):
                // - Neo.ClientError.Schema.ConstraintValidationFailed
                // - Neo.ClientError.Schema.ConstraintViolation
                if (Utils.hasValue(errorCode) && errorCode.includes('Constraint')) {
                    return Errors.business('constraint_violation', 'Constraint violation: ' + errorMessage, true);
                }
                // Query timeout
                // - Neo.ClientError.Transaction.TransactionTimedOut
                if (_.includes(errorCode, 'TimedOut')) {
                    throw new GraphRequestTimeout(Vendor.NEO4J);
                }
                // Neo4j has multiple Syntax errors (depending on the version):
                // - Neo.ClientError.Statement.InvalidSyntax
                // - Neo.ClientError.Statement.SyntaxError
                const isBadGraphRequest = Utils.hasValue(errorCode) && errorCode.includes('Syntax');
                errorMessage = 'Neo4j (HTTP) wasn\'t able to execute the query: ' + errorMessage;
                if (isBadGraphRequest) {
                    const offset = this.extractErrorOffset(errorMessage);
                    if (Utils.hasValue(offset)) {
                        return Errors.business('bad_graph_request', errorMessage, true, { offset: offset });
                    }
                    return Errors.business('bad_graph_request', errorMessage, true);
                }
                return Errors.technical('critical', errorMessage, true);
            }
            // if no record is found, we don't return anything, including the keys
            if (Utils.noValue(response.body.results[0]) || Utils.noValue(response.body.results[0].data[0])) {
                return {
                    keys: [],
                    results: []
                };
            }
            return {
                keys: response.body.results[0].columns,
                results: response.body.results[0].data.map(record => this._encodeHTTPResponseRecord(record))
            };
        }).catch(error => {
            if (error.key === 'socket_error') {
                throw Errors.business('dataSource_unavailable', 'Request to graph server failed: ' + error.message);
            }
            throw error;
        }).finally(() => {
            if (ignoreSlow) {
                return;
            }
            Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (HTTP): ' + query, Log);
        });
    }
    /**
     * Execute `func` under a transaction.
     * `func` will be invoke with two arguments:
     * - transactionURL
     * - rollback function
     *
     * @param {boolean}                              willWrite
     * @param {function(string, any): Bluebird<any>} func
     * @returns {Bluebird<any>}
     */
    _underTransaction(willWrite, func) {
        const baseUrl = (willWrite ? this._writeUrl : this.$httpUrl);
        return this.$request.post('/db/data/transaction', {
            baseUrl: baseUrl,
            body: {
                statements: []
            }
        }, [201]).then(response => {
            const transactionURL = response.headers.location;
            if (!transactionURL) {
                return Errors.business('graph_request_timeout', 'Failed to start transaction.', true);
            }
            return func(transactionURL, () => {
                // rollback function
                return this.$request.delete('/db/data/transaction', {
                    baseUrl: baseUrl
                    // HTTP status code 405 occurs after the transaction timed out in Neo4j
                }, [200, 405]).catch(e => {
                    Log.debug('Failed to delete transaction: ' + e.message);
                });
            });
        });
    }
    /**
     * Query JMX management data of Neo4j by domain, name and key.
     *
     * @param {string} domain
     * @param {string} name
     * @param {string} [key]
     * @returns {Bluebird<any>}
     */
    $queryJmx(domain, name, key) {
        const path = '/db/manage/server/jmx/domain/' + encodeURIComponent(domain) + '/' +
            encodeURIComponent(name);
        return this.$request.get(path, {
            baseUrl: this.$httpUrl
        }, [200]).then(response => {
            const items = _.fromPairs(Utils.safeGet(response.body, '0.attributes').map(i => [i.name, i.value]));
            if (Utils.noValue(key)) {
                return items;
            }
            if (Utils.noValue(items[key])) {
                return Errors.technical('critical', `Cannot get '${key}' (missing field)`, true);
            }
            return items[key];
        });
    }
    /**
     * @param {{code: string, message: string}} error
     * @returns {LkError}
     * @private
     */
    _parseError(error) {
        // Client statement and procedure errors are considered as bad graph request. eg.:
        // Neo.ClientError.Procedure.ProcedureCallFailed
        // Neo.ClientError.Statement.ArithmeticError
        const isBadGraphRequest = /.*ClientError[.](Statement|Procedure).*/.test(error.code);
        if (!isBadGraphRequest) {
            const message = `Unexpected Neo4j response: ${error.message}`;
            return Errors.technical('critical', message);
        }
        const offset = this.extractErrorOffset(error.message);
        const errorHighlight = Utils.hasValue(offset) ? { offset: offset } : undefined;
        const message = `Neo4j wasn't able to execute the cypher query: ${error.message}`;
        return Errors.business('bad_graph_request', message, false, errorHighlight);
    }
    /**
     * Execute a cypher query on Neo4j and return a stream as a result.
     * If `limit` is defined, the limit of the Cypher query is modified to not be higher
     * than `limit`.
     *
     * @param {string[]} queries      The graph queries
     * @param {object}   [parameters] The graph query parameters
     * @param {number}   [limit]      Maximum number of matched subgraphs
     * @returns {Bluebird<{keys: string[], results: Readable<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $safeCypherQueryStream(queries, parameters, limit = Infinity) {
        const willWrite = _.some(queries, query => CypherUtils.checkQuery(query));
        return this._underTransaction(willWrite, (transactionUrl, rollback) => {
            // run the original query using the transaction URL (autocommit)
            const autoCommitUrl = transactionUrl + '/commit';
            // Stream request of the data
            return this.$request.getStream(autoCommitUrl, 'post', {
                body: {
                    statements: queries.map(query => ({
                        statement: query,
                        resultDataContents: ['row', 'graph']
                    }))
                }
            }, [200]).then(readableStream => {
                const self = this;
                return new Promise((resolve, reject) => {
                    const jsonStream = Utils.safePipe(readableStream, JsonStream.parse(['results', '*', 'data', '*'], ['results', 0, 'columns'], ['errors', '*']));
                    // We assume that the initial chunk is the columns. Otherwise we reject.
                    jsonStream.once('data', initialChunk => {
                        const parseError = this._parseError.bind(this);
                        if (!Array.isArray(initialChunk)) {
                            if (Utils.hasValue(initialChunk.code)) {
                                reject(parseError(initialChunk));
                            }
                            reject(Errors.technical('critical', 'Unexpected Neo4j response, "results.columns" is not defined, received data: ' +
                                initialChunk));
                        }
                        const recordStream = through(function (record) {
                            if (Utils.hasValue(record.code)) {
                                this.emit('error', parseError(record));
                            }
                            else if (Utils.noValue(record.graph) || Utils.noValue(record.graph.nodes) ||
                                Utils.noValue(record.graph.relationships) || Utils.noValue(record.row)) {
                                // This is our best hint that Neo4j timedout:
                                // The JSON is properly closed but the data is missing.
                                // At the end of the HTTP response there should be the reason of the error but
                                // it's not easy to access from within the stream that goes through a JsonStream
                                this.emit('error', new GraphRequestTimeout(Vendor.NEO4J));
                            }
                            else {
                                this.queue(self._encodeHTTPResponseRecord(record));
                            }
                        });
                        // Abort the http request (close the socket)
                        const abortRequestJs = readableStream.abort.bind(readableStream);
                        const streamCap = Utils.capStream(limit, () => {
                            abortRequestJs();
                            if (willWrite) {
                                // when write queries are aborted, all changes are rolled back
                                // we fail the query because we know changes will not be persisted
                                streamCap.emit('error', Errors.business('bad_graph_request', `The write query involved more than ${limit} results. No change was applied.`));
                            }
                        });
                        // We want the filter one specific error from jsonStream which is the consequence of
                        // aborting before the end of the json stream.
                        recordStream.on('error', error => {
                            if (!error.message.includes('Unexpected JSON stream end')) {
                                streamCap.emit('error', error);
                            }
                        });
                        // Abort the http request and rollback the transaction
                        streamCap.abort = () => {
                            abortRequestJs();
                            rollback();
                        };
                        // TODO #1565 Use TransformedStream
                        // Warning: pausing the stream at the source is necessary,
                        // otherwise it will keep emitting data and middle streams
                        // can use this data to emit an error while the returned stream is paused
                        // and no error handler is registered, resulting in the application crashing
                        readableStream.pause();
                        jsonStream.pause();
                        resolve({
                            keys: initialChunk,
                            // We have to resolve with a paused stream because the stream is already in flowing mode
                            results: Utils.safePipe(jsonStream, recordStream).pipe(streamCap).pause()
                        });
                    }).resume();
                });
            });
        }).catch(error => {
            if (error.key === 'socket_error') {
                throw Errors.business('dataSource_unavailable', 'Request to graph server failed: ' + error.message);
            }
            throw error;
        });
    }
}
module.exports = Neo4jHTTPConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpIVFRQQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvbmVvNGpIVFRQQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsV0FBVztBQUNYLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBRXRELFNBQVM7QUFDVCxNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNuRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUN0RCxNQUFNLEVBQUMsbUJBQW1CLEVBQUUsTUFBTSxFQUFDLEdBQUcsT0FBTyxDQUFDLHlDQUF5QyxDQUFDLENBQUM7QUFFekYsTUFBTSxrQkFBbUIsU0FBUSxjQUFjO0lBRTdDOzs7T0FHRztJQUNILFlBQVksWUFBWSxFQUFFLFlBQVk7UUFDcEMsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRS9ELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDNUIsU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQztZQUNsRCxJQUFJLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztnQkFDakMsUUFBUSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDO2FBQzFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7WUFDYixLQUFLLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7WUFDbkMsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLENBQUMsRUFBQztZQUNyQixJQUFJLEVBQUUsSUFBSTtZQUNWLElBQUksRUFBRSxJQUFJO1NBQ1gsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sNkZBQTZGO1FBQzdGLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN6RixJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUM5RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixvRUFBb0UsRUFDcEUsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELGdCQUFnQjtZQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDOUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDL0IsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSwyQkFBMkIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN4RTtZQUVELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCx5QkFBeUIsQ0FBQyxNQUFNO1FBQzlCLHFHQUFxRztRQUNyRywyRkFBMkY7UUFDM0Ysa0RBQWtEO1FBRWxELE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDNUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNsRCxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuQyxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ2hCLHlFQUF5RTtnQkFDekUsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7YUFDbEI7WUFDRCwyREFBMkQ7WUFDM0QsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUNyQixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7Z0JBQ1gsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3BFLENBQUMsQ0FBQztTQUNKO1FBQ0QsTUFBTSxTQUFTLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUM1QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFELDJEQUEyRDtZQUMzRCxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7Z0JBQ3JCLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTtnQkFDWCxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0JBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTztnQkFDcEIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDcEUsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxPQUFPO1lBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3JDLEtBQUssRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNyQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEdBQUc7U0FDakIsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksU0FBUztRQUNYLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3BELENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGtCQUFrQixDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsa0JBQWtCO1FBQ3BELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzdCLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtZQUN0QixJQUFJLEVBQUUsVUFBVTtTQUNqQixFQUFFLGtCQUFrQixDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxpQkFBaUIsQ0FBQyxHQUFHO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFO1lBQzVCLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtTQUN2QixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsdUJBQXVCLENBQUMsR0FBRztRQUN6QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7WUFDekMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRO1NBQ3ZCLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ1osQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsY0FBYyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVTtRQUMxQyxNQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLE1BQU0sT0FBTyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUUzRCxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDdEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsRUFBRTtZQUN2RCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLENBQUM7d0JBQ1gsU0FBUyxFQUFFLEtBQUs7d0JBQ2hCLFVBQVUsRUFBRSxVQUFVO3dCQUN0QixrQkFBa0IsRUFBRSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7cUJBQ3JDLENBQUM7YUFDSDtTQUNGLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUMzRSxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztnQkFDcEUsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUNoRSw2RUFBNkU7Z0JBQzdFLHNEQUFzRDtnQkFDdEQsK0NBQStDO2dCQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtvQkFDakUsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUMzQyx3QkFBd0IsR0FBRyxZQUFZLEVBQUUsSUFBSSxDQUM5QyxDQUFDO2lCQUNIO2dCQUVELGdCQUFnQjtnQkFDaEIsb0RBQW9EO2dCQUNwRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxFQUFFO29CQUNyQyxNQUFNLElBQUksbUJBQW1CLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM3QztnQkFFRCwrREFBK0Q7Z0JBQy9ELDRDQUE0QztnQkFDNUMsMENBQTBDO2dCQUMxQyxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFFcEYsWUFBWSxHQUFHLGtEQUFrRCxHQUFHLFlBQVksQ0FBQztnQkFDakYsSUFBSSxpQkFBaUIsRUFBRTtvQkFDckIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNyRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQzFCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUM7cUJBQ25GO29CQUNELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ2pFO2dCQUNELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3pEO1lBRUQsc0VBQXNFO1lBQ3RFLElBQ0UsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQzFGO2dCQUNBLE9BQU87b0JBQ0wsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsT0FBTyxFQUFFLEVBQUU7aUJBQ1osQ0FBQzthQUNIO1lBRUQsT0FBTztnQkFDTCxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztnQkFDdEMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ3hDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3BELENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssY0FBYyxFQUFFO2dCQUNoQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHdCQUF3QixFQUFFLGtDQUFrQyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQzdFLENBQUM7YUFDSDtZQUVELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksVUFBVSxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUMzQixLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsZ0JBQWdCLEdBQUcsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzlFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGlCQUFpQixDQUFDLFNBQVMsRUFBRSxJQUFJO1FBQy9CLE1BQU0sT0FBTyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFN0QsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtZQUNoRCxPQUFPLEVBQUUsT0FBTztZQUNoQixJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLEVBQUU7YUFDZjtTQUNGLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4QixNQUFNLGNBQWMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUVqRCxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUNuQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsdUJBQXVCLEVBQUUsOEJBQThCLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkY7WUFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsR0FBRyxFQUFFO2dCQUMvQixvQkFBb0I7Z0JBQ3BCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLEVBQUU7b0JBQ2xELE9BQU8sRUFBRSxPQUFPO29CQUNoQix1RUFBdUU7aUJBQ3hFLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3ZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMxRCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFNBQVMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUc7UUFDekIsTUFBTSxJQUFJLEdBQUcsK0JBQStCLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRztZQUM3RSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUUzQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRTtZQUM3QixPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7U0FDdkIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hCLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQ3ZCLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQ3pFLENBQUM7WUFFRixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3RCLE9BQU8sS0FBSyxDQUFDO2FBQ2Q7WUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7Z0JBQzdCLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsZUFBZSxHQUFHLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2xGO1lBRUQsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFdBQVcsQ0FBQyxLQUFLO1FBQ2Ysa0ZBQWtGO1FBQ2xGLGdEQUFnRDtRQUNoRCw0Q0FBNEM7UUFDNUMsTUFBTSxpQkFBaUIsR0FBRyx5Q0FBeUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXJGLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtZQUN0QixNQUFNLE9BQU8sR0FBRyw4QkFBOEIsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzlELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDOUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFN0UsTUFBTSxPQUFPLEdBQUcsa0RBQWtELEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNsRixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsc0JBQXNCLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEdBQUcsUUFBUTtRQUMxRCxNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUUxRSxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLEVBQUU7WUFDcEUsZ0VBQWdFO1lBQ2hFLE1BQU0sYUFBYSxHQUFHLGNBQWMsR0FBRyxTQUFTLENBQUM7WUFFakQsNkJBQTZCO1lBQzdCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLE1BQU0sRUFBRTtnQkFDcEQsSUFBSSxFQUFFO29CQUNKLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDaEMsU0FBUyxFQUFFLEtBQUs7d0JBQ2hCLGtCQUFrQixFQUFFLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztxQkFDckMsQ0FBQyxDQUFDO2lCQUNKO2FBQ0YsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUM5QixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBQ2xCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7b0JBQ3JDLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUM5QyxVQUFVLENBQUMsS0FBSyxDQUNkLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLEVBQzdCLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxTQUFTLENBQUMsRUFDekIsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUV0Qix3RUFBd0U7b0JBQ3hFLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxFQUFFO3dCQUNyQyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUU7NEJBQ2hDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzs2QkFDbEM7NEJBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUNoQyw4RUFBOEU7Z0NBQ2hGLFlBQVksQ0FBQyxDQUFDLENBQUM7eUJBQ2hCO3dCQUVELE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxVQUFTLE1BQU07NEJBQzFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0NBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDOzZCQUN4QztpQ0FBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7Z0NBQ3pFLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQ0FDeEUsNkNBQTZDO2dDQUM3Qyx1REFBdUQ7Z0NBQ3ZELDhFQUE4RTtnQ0FDOUUsZ0ZBQWdGO2dDQUNoRixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDOzZCQUMzRDtpQ0FBTTtnQ0FDTCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDOzZCQUNwRDt3QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFFSCw0Q0FBNEM7d0JBQzVDLE1BQU0sY0FBYyxHQUFHLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO3dCQUVqRSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7NEJBQzVDLGNBQWMsRUFBRSxDQUFDOzRCQUNqQixJQUFJLFNBQVMsRUFBRTtnQ0FDYiw4REFBOEQ7Z0NBQzlELGtFQUFrRTtnQ0FDbEUsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDekQsc0NBQXNDLEtBQUssa0NBQWtDLENBQUMsQ0FBQyxDQUFDOzZCQUNuRjt3QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxvRkFBb0Y7d0JBQ3BGLDhDQUE4Qzt3QkFDOUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7NEJBQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFO2dDQUN6RCxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQzs2QkFDaEM7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7d0JBRUgsc0RBQXNEO3dCQUN0RCxTQUFTLENBQUMsS0FBSyxHQUFHLEdBQUcsRUFBRTs0QkFDckIsY0FBYyxFQUFFLENBQUM7NEJBQ2pCLFFBQVEsRUFBRSxDQUFDO3dCQUNiLENBQUMsQ0FBQzt3QkFFRixtQ0FBbUM7d0JBQ25DLDBEQUEwRDt3QkFDMUQsMERBQTBEO3dCQUMxRCx5RUFBeUU7d0JBQ3pFLDRFQUE0RTt3QkFDNUUsY0FBYyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUN2QixVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7d0JBRW5CLE9BQU8sQ0FBQzs0QkFDTixJQUFJLEVBQUUsWUFBWTs0QkFDbEIsd0ZBQXdGOzRCQUN4RixPQUFPLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssRUFBRTt5QkFDMUUsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNkLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssY0FBYyxFQUFFO2dCQUNoQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHdCQUF3QixFQUFFLGtDQUFrQyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQzdFLENBQUM7YUFDSDtZQUVELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGtCQUFrQixDQUFDIn0=