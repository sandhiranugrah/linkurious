/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-06-29.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
// locals
const GremlinConnector = require('./gremlinConnector');
const GremlinUtils = require('../utils/gremlinUtils');
class CosmosDbConnector extends GremlinConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions, {
            manageTransactions: true,
            httpPathGremlinServer: '/gremlin',
            binaryMessages: true,
            useSessions: false
        });
    }
    /**
     * @returns {string} username
     */
    get $username() {
        // Cosmos Db username is derived from the database and the collection
        return `/dbs/${this.getGraphOption('database')}/colls/${this.getGraphOption('collection')}`;
    }
    /**
     * @returns {string} password
     */
    get $password() {
        // The password is the account primary key
        return this.getGraphOption('primaryKey');
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return super.$connect().catch(error => {
            // the url is valid but the authentication failed, the primary key must be wrong
            if (error.message.includes('Invalid credentials')) {
                throw Errors.business('invalid_parameter', 'Authentication failed, ' +
                    'please check cosmos db primaryKey in configuration');
            }
            // the resource could not be found, knows causes:
            // - database and collection are inverted in the config file
            // - some typo in the database name or collection name
            if (error.message.includes('BackendStatusCode : NotFound')) {
                throw Errors.business('invalid_parameter', 'Resource Not Found, ' +
                    'please check cosmos db database and collection in configuration');
            }
            // There can be a confusion here between:
            // - the document db endpoint (.NET SDK URI) e.g: <service-name>.documents.azure.com
            // - the gremlin endpoint for the same service e.g: <service-name>.gremlin.cosmosdb.azure.com
            // Both matches the same service but for different APIs
            // What we need is the gremlin endpoint.
            if (error.message.includes('unexpected server response') &&
                this.getGraphOption('url').includes('documents.azure.com')) {
                throw Errors.business('invalid_parameter', 'Cannot connect to the gremlin server, ' +
                    'please provide the gremlin endpoint as url in configuration');
            }
            throw error;
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this.$doGremlinQuery('g.inject(true)', { session: 'none' }).then(r => {
            if (r && r.length === 1 && r[0] === true) {
                return;
            }
            return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
        }).catch(error => {
            // if the checkup failed, reset the client
            return this.$closeConnection(error);
        });
    }
    /**
     * Get the SemVer of the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $getVersion() {
        // We do not know yet how to detect the cosmos db version.
        return Promise.resolve('[unknown]');
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        const storeId = `${this.getGraphOption('database')}/${this.getGraphOption('collection')}`;
        return Promise.resolve(storeId);
    }
    /**
     * Stream gremlin query results.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {object}  [options.bindings]                      Gremlin Variable bindings
     * @param {number}  [options.batchSize=1]                   Number of results to read from the gremlin server at a time
     * @param {number}  [options.timeout]                       Milliseconds to wait before it fails
     * @param {boolean} [options.allowForbiddenStatements=true] Whether the query can use forbidden statements
     * @param {boolean} [options.useDef]                        Whether to use def keyword to declare session variables
     * @returns {Bluebird<Readable<any>>}
     */
    $streamGremlinQuery(query, options = {}) {
        const { timeout, allowForbiddenStatements } = options;
        return Promise.resolve().then(() => {
            if (!this._connected) {
                return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
            }
            GremlinUtils.checkQuery(query, allowForbiddenStatements);
            const request = this.$buildGremlinRequest(query, {
                scriptEvaluationTimeout: timeout,
                manageTransaction: false,
                batchSize: options.batchSize,
                caching: 'phantom'
            });
            return this.$sendRequest(request).then(messageStream => {
                // the number of results received by the gremlin server at a time depends on `batchSize`
                // we flatten the stream to ensure that we emit one item at a time
                return Utils.safePipe(messageStream, Utils.flatStream());
            });
        });
    }
}
module.exports = CosmosDbConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29zbW9zRGJDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9jb3Ntb3NEYkNvbm5lY3Rvci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDdkQsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFdEQsTUFBTSxpQkFBa0IsU0FBUSxnQkFBZ0I7SUFDOUM7OztPQUdHO0lBQ0gsWUFBWSxZQUFZLEVBQUUsWUFBWTtRQUNwQyxLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRTtZQUNoQyxrQkFBa0IsRUFBRSxJQUFJO1lBQ3hCLHFCQUFxQixFQUFFLFVBQVU7WUFDakMsY0FBYyxFQUFFLElBQUk7WUFDcEIsV0FBVyxFQUFFLEtBQUs7U0FDbkIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gscUVBQXFFO1FBQ3JFLE9BQU8sUUFBUSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxVQUFVLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUU5RixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLFNBQVM7UUFDWCwwQ0FBMEM7UUFDMUMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNwQyxnRkFBZ0Y7WUFDaEYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO2dCQUNqRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUseUJBQXlCO29CQUNsRSxvREFBb0QsQ0FBQyxDQUFDO2FBQ3pEO1lBRUQsaURBQWlEO1lBQ2pELDREQUE0RDtZQUM1RCxzREFBc0Q7WUFDdEQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxFQUFFO2dCQUMxRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsc0JBQXNCO29CQUMvRCxpRUFBaUUsQ0FBQyxDQUFDO2FBQ3RFO1lBRUQseUNBQXlDO1lBQ3pDLG9GQUFvRjtZQUNwRiw2RkFBNkY7WUFDN0YsdURBQXVEO1lBQ3ZELHdDQUF3QztZQUN4QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDO2dCQUN0RCxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO2dCQUM1RCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsd0NBQXdDO29CQUNqRiw2REFBNkQsQ0FBQyxDQUFDO2FBQ2xFO1lBRUQsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN4RSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUN4QyxPQUFPO2FBQ1I7WUFDRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDOUYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsMENBQTBDO1lBQzFDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsMERBQTBEO1FBQzFELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVc7UUFDVCxNQUFNLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQzFGLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxHQUFHLEVBQUU7UUFDckMsTUFBTSxFQUFDLE9BQU8sRUFBRSx3QkFBd0IsRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUNwRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNwQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0Y7WUFDRCxZQUFZLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO1lBRXpELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUU7Z0JBQy9DLHVCQUF1QixFQUFFLE9BQU87Z0JBQ2hDLGlCQUFpQixFQUFFLEtBQUs7Z0JBQ3hCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsT0FBTyxFQUFFLFNBQVM7YUFDbkIsQ0FBQyxDQUFDO1lBRUgsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDckQsd0ZBQXdGO2dCQUN4RixrRUFBa0U7Z0JBQ2xFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFDM0QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsaUJBQWlCLENBQUMifQ==