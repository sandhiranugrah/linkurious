/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// internal libs
const stream = require('stream');
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const WebSocket = require('ws');
const uuid = require('uuid');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
// locals
const Connector = require('./connector');
const GremlinUtils = require('../utils/gremlinUtils');
const LRUQueue = require('../../../lib/LRUQueue');
const GremlinStream = require('../utils/gremlinStream');
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
const { TechnicalError } = require('../../models/errors/TechnicalError');
const DEFAULT_SESSION_POOL_SIZE = 8;
const SESSION_REFRESH_MS = 10 * 60 * 1000; // 10 minutes
const COMMIT_QUERY = 'graph.tx().commit(); []';
class GremlinConnector extends Connector {
    /**
     * @param {any}     graphOptions                               GraphDAO options
     * @param {any}     [indexOptions]                             IndexDAO options (only if the type of the DAO is 'Index')
     * @param {object}  gremlinOptions
     * @param {boolean} gremlinOptions.manageTransactions          Whether transactions are committed automatically
     * @param {string}  [gremlinOptions.httpPathGremlinServer='/'] HTTP path of them gremlin server
     * @param {boolean} gremlinOptions.binaryMessages              Whether messages to the gremlin server should be packed as binary
     * @param {boolean} gremlinOptions.useSessions                 Whether to use a session for all gremlin requests
     */
    constructor(graphOptions, indexOptions, gremlinOptions) {
        super(graphOptions, indexOptions);
        this._manageTransactions = gremlinOptions.manageTransactions;
        this._httpPathGremlinServer = gremlinOptions.httpPathGremlinServer;
        this._aliases = {};
        this._binaryMessages = gremlinOptions.binaryMessages;
        this._useSessions = gremlinOptions.useSessions;
        this._pendingRequests = new Map();
        this._connected = false;
        this._activeSessions = new LRUQueue();
        // Max amount of time before external changes are seen by LKE
        // This helps spacing the read commits frequency
        // It improves performance when the server is under heavy read usage.
        this._maxStale = this.getGraphOption('maxStale', 0);
        this._lastCommit = new Map();
        this._isIndex = Utils.hasValue(indexOptions); // Whether the connector is used by an index dao
    }
    /**
     * Get the size of the session pool
     *
     * @returns {number}
     */
    get sessionPoolSize() {
        if (this._isIndex) {
            // Use only 1 sessions for the index dao
            // This is required for how today  JanusGraphSearchDriver._createIndex is implemented
            return 1;
        }
        return this.getGraphOption('sessionPool', DEFAULT_SESSION_POOL_SIZE);
    }
    /**
     *
     * @returns {boolean} Whether to use a session for all gremlin requests
     */
    get useSessions() {
        return this._useSessions;
    }
    /**
     * @returns {string} username
     */
    get $username() {
        return this.getGraphOption('user');
    }
    /**
     * @returns {string} password
     */
    get $password() {
        return this.getGraphOption('password');
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this._connectGremlinServer().then(() => {
            // Stateless connectors will not require this
            if (this._useSessions) {
                // Generate unique session ids.
                for (let i = 0; i < this.sessionPoolSize; i++) {
                    const sessionId = uuid.v4();
                    this._activeSessions.add(sessionId);
                    this._lastCommit.set(sessionId, 0);
                }
                return this.$initGremlinSession();
            } // checkUp is necessary here to trigger authentication
        }).then(() => this.$checkUp()
            .then(() => this.$getVersion()));
    }
    /**
     * Connect to the gremlin server.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _connectGremlinServer() {
        if (this._connected) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const configuredUrl = /**@type {string}*/ this.getGraphOption('url');
            const { scheme, host = 'localhost', port = 8182 } = Utils.extractHostPort(configuredUrl);
            // connect to the gremlin server via WebSocket
            const ssl = scheme === 'wss' || scheme === 'https';
            const url = `ws${ssl ? 's' : ''}://${host}:${port}${this._httpPathGremlinServer}`;
            const wsOptions = { rejectUnauthorized: !this.getGraphOption('allowSelfSigned', false) };
            this._ws = new WebSocket(url, null, wsOptions)
                .once('open', resolve)
                .once('error', reject)
                .on('open', () => (this._connected = true))
                .on('error', error => Log.error('Gremlin server communication error', error))
                .on('message', message => this._handleProtocolMessage(message))
                .on('close', () => {
                this.$closeConnection(Errors.technical('critical', 'WebSocket closed')).catch(error => {
                    Log.error(error.message);
                });
            });
        });
    }
    /**
     * @param {string} message
     * @private
     */
    _handleProtocolMessage(message) {
        let rawMessage, requestId, statusCode;
        try {
            rawMessage = this._binaryMessages
                ? JSON.parse(new Buffer(message, 'binary').toString('utf-8'))
                : JSON.parse(message);
            requestId = rawMessage.requestId;
            statusCode = rawMessage.status.code;
        }
        catch (e) {
            Log.warn('MalformedResponse', 'Received malformed response message: ' + message);
            return;
        }
        const request = this._pendingRequests.get(requestId);
        // If there was no request for this response, just ignore the response
        if (Utils.noValue(request)) {
            return;
        }
        switch (statusCode) {
            case 200: // SUCCESS
                this._pendingRequests.delete(requestId);
                request.responseStream.push(rawMessage.result.data['@value'] || rawMessage.result.data);
                request.responseStream.push(null);
                break;
            case 204: // NO_CONTENT
                this._pendingRequests.delete(requestId);
                request.responseStream.push(null);
                break;
            case 206: // PARTIAL_CONTENT
                request.responseStream.push(rawMessage.result.data['@value'] || rawMessage.result.data);
                if (this.useSessions) {
                    // allow long running requests to have less concurrency
                    this._activeSessions.touch(request.message.args.session);
                }
                break;
            case 407: // AUTHENTICATE CHALLENGE
                this._sendMessage({
                    requestId: requestId,
                    processor: this._pendingRequests.get(requestId).message.processor,
                    op: 'authentication',
                    args: { saslMechanism: 'PLAIN',
                        sasl: GremlinUtils.encodeSASLCredentials(this.$username, this.$password) }
                });
                break;
            default: {
                // Other status codes (498, 499, 500, 597, 598, 599) are all errors
                this._handleProtocolError(request, rawMessage.status);
                break;
            }
        }
    }
    /**
     * @param {GremlinRequest} request
     * @param {object}         status
     * @param {string | null}  status.message
     * @param {number}         status.code
     * @param {object}         status.attributes
     * @param {string}         [status.attributes.stackTrace]
     * @param {string}         [status.attributes.exceptions]
     * @private
     */
    _handleProtocolError(request, status) {
        const { code, message, attributes } = status;
        this._pendingRequests.delete(request.message.requestId);
        const queryFailed = request.message.args.gremlin;
        const timeout = request.message.args.scriptEvaluationTimeout;
        const errorMessage = message + '\nQuery was: ' + queryFailed + '\nError code: ' + code;
        let error;
        if (code === 597) { // SCRIPT EVALUATION ERROR
            // detect session expired
            const { exceptions = [], stackTrace } = attributes;
            // the best clue that a session expired is when a commit query fails (done before every query)
            // with a null pointer exception. This means that `graph` is no longer defined in the session
            const sessionExpired = queryFailed === COMMIT_QUERY &&
                _.includes(exceptions, 'java.lang.NullPointerException');
            if (sessionExpired) {
                this.$closeConnection(new TechnicalError('critical', `Gremlin session expired ${message} ${stackTrace}`)).catch(error => {
                    Log.error(error.message);
                });
                return;
            }
            // If the session didn't expire then it's just a bad query
            error = Errors.business('bad_graph_request', 'Gremlin server error: ' + errorMessage);
        }
        else if (code === 401) { // UNAUTHORIZED
            error = Errors.business('invalid_parameter', 'Authentication failed, ' +
                'Please check the username and password in the configuration.');
        }
        else if (code === 598) { // SERVER TIMEOUT
            if (timeout === undefined) {
                error = new GraphRequestTimeout(Vendor.GREMLIN_SERVER);
            }
            else {
                // the scriptEvaluation timeout is set by Linkurious based on the rawQueryTimeout configuration parameter
                error = new GraphRequestTimeout(Vendor.LINKURIOUS);
            }
        }
        else {
            // All other errors are technical
            // 498 MALFORMED REQUEST
            // 499 INVALID REQUEST ARGUMENTS
            // 500 SERVER ERROR
            // 599 SERVER SERIALIZATION ERROR
            // see http://tinkerpop.apache.org/docs/current/dev/provider/#_graph_driver_provider_requirements
            error = new TechnicalError('critical', 'Gremlin server error: ' + errorMessage);
        }
        request.responseStream.emit('error', error);
    }
    /**
     * @param {string}                    script
     * @param {GremlinOperationArguments} args
     * @returns {GremlinRequest}
     */
    $buildGremlinRequest(script, args) {
        const gremlinMessage = {
            // V4 is a random id
            requestId: uuid.v4(),
            processor: Utils.hasValue(args.session) ? 'session' : '',
            op: 'eval',
            args: _.merge({
                gremlin: script,
                bindings: {},
                manageTransaction: this._manageTransactions,
                aliases: this._aliases,
                accept: 'application/json',
                language: 'gremlin-groovy'
            }, args)
        };
        return {
            message: gremlinMessage,
            responseStream: new stream.PassThrough({ objectMode: true })
        };
    }
    /**
     * @param {GremlinRequest} request
     * @returns {Bluebrid<ReadableStream>}
     */
    $sendRequest(request) {
        this._pendingRequests.set(request.message.requestId, request);
        return this._sendMessage(request.message)
            .return(request.responseStream)
            .catch(error => {
            this._pendingRequests.delete(request.message.requestId);
            throw error;
        });
    }
    /**
     * @param {GremlinMessage} message
     * @returns {Bluebrid<void>}
     * @private
     */
    _sendMessage(message) {
        return new Promise((resolve, reject) => {
            const formattedMessage = this._binaryMessages ? GremlinUtils.toBinary(message) : message;
            this._ws.send(formattedMessage, { binary: Boolean(this._binaryMessages) }, error => {
                // this callback the only way of being notified that data has actually been sent
                // if `error` is defined, then we have failed to send the message
                if (Utils.hasValue(error)) {
                    reject(error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    /**
     * Disconnect from the gremlin server.
     *
     * @param {Error} [reason]
     * @returns {Bluebird<void>}
     */
    $closeConnection(reason) {
        // release the client
        return Promise.resolve().then(() => {
            if (this._connected) {
                this._connected = false;
                this._cancelPendingRequests(reason);
                return this._closeSessions().catch(error => {
                    Log.error('Failed to close opened sessions', error.stack || error);
                    // Always resolve because gremlin server might not be reachable.
                }).then(() => {
                    // close the WebSocket
                    try {
                        this._ws.close();
                    }
                    catch (e) {
                        // do nothing
                    }
                });
            }
        }).then(() => {
            if (Utils.hasValue(reason)) {
                // fail properly
                return Errors.technical('critical', `Cannot connect to the gremlin server (${this.getGraphOption('url')}): ` +
                    reason.message, true);
            }
        });
    }
    /**
     * Disconnect from the remote server.
     *
     * Optional to implement.
     */
    $disconnect() {
        this.$closeConnection();
    }
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * Implement only if gremlinOptions.useSessions is true.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Close active response streams.
     *
     * @param {Error} [reason]
     * @private
     */
    _cancelPendingRequests(reason) {
        for (const request of this._pendingRequests.values()) {
            request.responseStream.destroy(reason);
        }
    }
    /**
     * Close open gremlin sessions if any.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _closeSessions() {
        return Promise.resolve().then(() => {
            const closingSessions = [];
            for (const session of this._activeSessions) {
                closingSessions.push(this._closeSession(session));
            }
            return Promise.all(closingSessions).return();
        });
    }
    /**
     * Send close session request.
     *
     * @param {string} sessionId
     * @returns {Bluebird<void>}
     * @private
     */
    _closeSession(sessionId) {
        const message = {
            requestId: uuid.v4(),
            processor: 'session',
            op: 'close',
            args: {
                session: sessionId,
                // the force close option force: true will not wait for pending transaction to complete
                // resulting in a faster release of resources
                force: true
            }
        };
        const request = {
            message: message,
            responseStream: new stream.PassThrough({ objectMode: true })
        };
        return this.$sendRequest(request).then(messageStream => {
            return Utils.collectStream(messageStream).then(() => {
                this._activeSessions.delete(sessionId);
                this._lastCommit.delete(sessionId);
            });
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        // Gremlin sessions need to be periodically checked because they expire after 8 hours (default config)
        let sessions = 'none';
        if (this.useSessions) {
            const now = Date.now();
            for (const [, commitTs] of this._lastCommit) {
                if ((now - commitTs) > SESSION_REFRESH_MS) {
                    sessions = 'all';
                    break;
                }
            }
        }
        return this.$doGremlinQuery('true', { session: sessions }).then(r => {
            if (!r.length || _.some(r, status => status !== true)) {
                return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
            }
        }).catch(error => {
            // if the checkup failed, reset the client
            return this.$closeConnection(error);
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is an identifier of the database as specific as possible.
     * It should contains the address (url and port) of the database and, if the service
     * is multi-tenant, the name of the database.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({});
    }
    /**
     * Get the SemVer of the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $getVersion() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * @param {object} aliases
     */
    $setAliases(aliases) {
        this._aliases = aliases;
    }
    /**
     * Attach a transaction commit before or after the query if necessary.
     * Also identifies:
     * - updatedSessions: Sessions known to have updated data.
     * - outdatedSessions: Sessions known to have stale data.
     *
     * @param {number}                    t0            request timestamp
     * @param {string}                    query
     * @param {GremlinOperationArguments} args
     * @param {object}                    [commitStrategy]         How to manage the current transaction
     * @param {boolean}                   [commitStrategy.before]  Commit before executing the query
     * @param {boolean}                   [commitStrategy.after]   Commit after the query is executed
     *
     * @returns {GremlinTransaction}
     * @private
     */
    _buildTransaction(t0, query, args, commitStrategy = {}) {
        const transaction = {
            requests: [],
            outdatedSessions: [],
            updatedSessions: []
        };
        if (commitStrategy.before) {
            // Check last commit for read queries
            if ((t0 - this._lastCommit.get(args.session)) > this._maxStale) {
                transaction.requests.push(this.$buildGremlinRequest(COMMIT_QUERY, args));
                transaction.updatedSessions.push(args.session);
            }
        }
        transaction.requests.push(this.$buildGremlinRequest(query, args));
        if (commitStrategy.after) {
            transaction.requests.push(this.$buildGremlinRequest(COMMIT_QUERY, args));
            // Write queries are committed after the query is successful
            // That means all other sessions will have stale data.
            for (const session of this._activeSessions) {
                // Invalidate all other sessions
                if (args.session !== session) {
                    transaction.outdatedSessions.push(session);
                }
            }
            // Update current session
            transaction.updatedSessions.push(args.session);
        }
        return transaction;
    }
    /**
     * @param {number} t0            time of the request
     * @param {GremlinTransaction[]} transactions
     * @private
     */
    _updatedSessionsStatus(t0, transactions) {
        const outdatedSessions = _.uniq(_.flatMap(transactions, 'outdatedSessions'));
        const updatedSessions = _.uniq(_.flatMap(transactions, 'updatedSessions'));
        for (const session of updatedSessions) {
            this._lastCommit.set(session, t0);
        }
        for (const session of outdatedSessions) {
            this._lastCommit.set(session, -Infinity);
        }
    }
    /**
     * Execute a gremlin query.
     *
     * @param {string}              query
     * @param {GremlinQueryOptions} [options]
     * @returns {Bluebird<any>}
     */
    $doGremlinQuery(query, options = {}) {
        const { timeout, allowForbiddenStatements, autoCommit = true } = options;
        const t0 = Date.now();
        if (!this._connected) {
            return Errors.technical('graph_unreachable', 'Cannot connect to the gremlin server.', true);
        }
        // TODO #919 Improve Gremlin read-only raw query check
        const willWrite = GremlinUtils.checkQuery(query, allowForbiddenStatements);
        const session = this._useSessions ? options.session || 'any' : 'none';
        // use the appropriate caching policy to reduce scripts memory footprint
        // see http://tinkerpop.apache.org/docs/current/reference/#_cache_management
        const scriptCachePolicy = Utils.hasValue(options.caching)
            ? { '#jsr223.groovy.engine.keep.globals': options.caching }
            : {};
        const args = {
            scriptEvaluationTimeout: timeout,
            bindings: _.defaults(scriptCachePolicy, options.bindings)
        };
        const transactions = [];
        if (session === 'none') {
            // transactions are managed for session less requests : 1 request = 1 transaction
            // A transaction is started when the script is first evaluated
            // and is committed automatically when the script completes.
            transactions.push(this._buildTransaction(t0, query, args));
        }
        else {
            const targetSessions = session === 'all'
                ? this._activeSessions.values()
                : session === 'any' ? [this._activeSessions.next()] : [this._activeSessions.touch(session)];
            // Commit the transaction if transactions are not managed directly by the graph vendor.
            // We commit before every query and after every write query
            // to make sure the graph data is up to date
            const commitStrategy = {
                before: autoCommit && !this._manageTransactions,
                // Commit all write queries after the query completed successfully
                after: autoCommit && !this._manageTransactions && willWrite
            };
            for (const sessionId of targetSessions) {
                args.session = sessionId;
                transactions.push(this._buildTransaction(t0, query, args, commitStrategy));
            }
        }
        const requests = _.flatMap(transactions, 'requests');
        // Queries should be executed sequentially and in order.
        return Promise.mapSeries(requests, r => {
            return this.$sendRequest(r).then(messageStream => {
                return Utils.collectStream(messageStream).then(_.flatten);
            });
        }).then(responses => {
            this._updatedSessionsStatus(t0, transactions);
            // The commit request will return empty results
            // We do not want that in the response
            // flatten will discard empty arrays.
            return _.flatten(responses);
        }).finally(() => Utils.logSlow(t0, this.SLOW_QUERY_THRESHOLD, 'Query (WS): ' + query, Log));
    }
    /**
     * Stream gremlin query results.
     *
     * Valid only if `gremlinOptions.useSessions` is true.
     *
     * @param {string}  query
     * @param {object}  [options]
     * @param {object}  [options.bindings]                      Gremlin Variable bindings
     * @param {number}  [options.batchSize=1]                   Number of results to read from the gremlin server at a time
     * @param {number}  [options.timeout]                       Milliseconds to wait before it fails
     * @param {boolean} [options.allowForbiddenStatements=true] Whether the query can use forbidden statements
     * @param {boolean} [options.useDef]                        Whether to use def keyword to declare session variables
     * @returns {Bluebird<Readable<any>>}
     */
    $streamGremlinQuery(query, options = {}) {
        const { batchSize = 1 } = options;
        // V4 is a random uuid, allows streaming multiple raw queries in the same session
        const streamUid = `LK_${uuid.v4().split('-')[0]}`;
        const setupQuery = `${options.useDef ? 'def ' : ''}${streamUid} = ${query}`;
        const cleanupQuery = `${streamUid} = []`;
        const hasNextQuery = `${streamUid}.hasNext()`;
        const nextQuery = `${streamUid}.next(${batchSize})`;
        const sessionId = this._activeSessions.next();
        let initialised = false;
        const fetchNextPage = () => {
            const usedSession = this._activeSessions.touch(sessionId);
            if (!initialised) {
                initialised = true;
                return this.$doGremlinQuery(`${setupQuery}; ${hasNextQuery} ? ${nextQuery} : []`, {
                    timeout: options.timeout,
                    allowForbiddenStatements: options.allowForbiddenStatements,
                    session: usedSession,
                    caching: 'phantom'
                });
            }
            return this.$doGremlinQuery(`${hasNextQuery} ? ${nextQuery} : (${cleanupQuery})`, {
                timeout: options.timeout,
                session: usedSession,
                autoCommit: false,
                caching: 'weak'
            });
        };
        const cleanup = () => {
            const usedSession = this._activeSessions.touch(sessionId);
            // Cleanup is necessary on abort
            return this.$doGremlinQuery(cleanupQuery, {
                session: usedSession,
                caching: 'phantom'
            });
        };
        return Promise.resolve(new GremlinStream(fetchNextPage, cleanup));
    }
}
module.exports = GremlinConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpbkNvbm5lY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vY29ubmVjdG9yL2dyZW1saW5Db25uZWN0b3IuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFFSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRWpDLGdCQUFnQjtBQUNoQixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoQyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFFN0IsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxTQUFTO0FBQ1QsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQ3RELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQ2xELE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3hELE1BQU0sRUFBQyxtQkFBbUIsRUFBRSxNQUFNLEVBQUMsR0FBRyxPQUFPLENBQUMseUNBQXlDLENBQUMsQ0FBQztBQUN6RixNQUFNLEVBQUMsY0FBYyxFQUFDLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFFdkUsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLENBQUM7QUFFcEMsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLGFBQWE7QUFFeEQsTUFBTSxZQUFZLEdBQUcseUJBQXlCLENBQUM7QUFFL0MsTUFBTSxnQkFBaUIsU0FBUSxTQUFTO0lBRXRDOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxZQUFZLEVBQUUsWUFBWSxFQUFFLGNBQWM7UUFDcEQsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsY0FBYyxDQUFDLGtCQUFrQixDQUFDO1FBQzdELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxjQUFjLENBQUMscUJBQXFCLENBQUM7UUFDbkUsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUMsY0FBYyxDQUFDO1FBQ3JELElBQUksQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQztRQUMvQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNsQyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksUUFBUSxFQUFFLENBQUM7UUFDdEMsNkRBQTZEO1FBQzdELGdEQUFnRDtRQUNoRCxxRUFBcUU7UUFDckUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsZ0RBQWdEO0lBQ2hHLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxlQUFlO1FBQ2pCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNqQix3Q0FBd0M7WUFDeEMscUZBQXFGO1lBQ3JGLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUFFLHlCQUF5QixDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVEOzs7T0FHRztJQUNILElBQUksV0FBVztRQUNiLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUMzQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLFNBQVM7UUFDWCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFckMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxTQUFTO1FBQ1gsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1Qyw2Q0FBNkM7WUFDN0MsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUNyQiwrQkFBK0I7Z0JBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM3QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ3BDO2dCQUVELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7YUFDbkMsQ0FBQyxzREFBc0Q7UUFDMUQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7YUFDMUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gscUJBQXFCO1FBQ25CLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxhQUFhLEdBQUcsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRSxNQUFNLEVBQUMsTUFBTSxFQUFFLElBQUksR0FBRyxXQUFXLEVBQUUsSUFBSSxHQUFHLElBQUksRUFBQyxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFdkYsOENBQThDO1lBQzlDLE1BQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLE9BQU8sQ0FBQztZQUNuRCxNQUFNLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNsRixNQUFNLFNBQVMsR0FBRyxFQUFDLGtCQUFrQixFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsRUFBQyxDQUFDO1lBQ3ZGLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUM7aUJBQzNDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2lCQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQztpQkFDckIsRUFBRSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQzFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUM1RSxFQUFFLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM5RCxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLGdCQUFnQixDQUNuQixNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxrQkFBa0IsQ0FBQyxDQUNqRCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDZCxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDM0IsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILHNCQUFzQixDQUFDLE9BQU87UUFDNUIsSUFBSSxVQUFVLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQztRQUN0QyxJQUFJO1lBQ0YsVUFBVSxHQUFHLElBQUksQ0FBQyxlQUFlO2dCQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM3RCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN4QixTQUFTLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQztZQUNqQyxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDckM7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULEdBQUcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsdUNBQXVDLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDakYsT0FBTztTQUNSO1FBRUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVyRCxzRUFBc0U7UUFDdEUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzFCLE9BQU87U0FDUjtRQUVELFFBQVEsVUFBVSxFQUFFO1lBQ2xCLEtBQUssR0FBRyxFQUFFLFVBQVU7Z0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3hDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3hGLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNsQyxNQUFNO1lBQ1IsS0FBSyxHQUFHLEVBQUUsYUFBYTtnQkFDckIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDeEMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xDLE1BQU07WUFDUixLQUFLLEdBQUcsRUFBRSxrQkFBa0I7Z0JBQzFCLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3hGLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtvQkFDcEIsdURBQXVEO29CQUN2RCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDMUQ7Z0JBQ0QsTUFBTTtZQUNSLEtBQUssR0FBRyxFQUFFLHlCQUF5QjtnQkFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQztvQkFDaEIsU0FBUyxFQUFFLFNBQVM7b0JBQ3BCLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTO29CQUNqRSxFQUFFLEVBQUUsZ0JBQWdCO29CQUNwQixJQUFJLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTzt3QkFDNUIsSUFBSSxFQUFFLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBQztpQkFDNUUsQ0FBQyxDQUFDO2dCQUNILE1BQU07WUFDUixPQUFPLENBQUMsQ0FBQztnQkFDUCxtRUFBbUU7Z0JBQ25FLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN0RCxNQUFNO2FBQ1A7U0FDRjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsTUFBTTtRQUNsQyxNQUFNLEVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUMsR0FBRyxNQUFNLENBQUM7UUFDM0MsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUNqRCxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUM3RCxNQUFNLFlBQVksR0FBRyxPQUFPLEdBQUcsZUFBZSxHQUFHLFdBQVcsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFFdkYsSUFBSSxLQUFLLENBQUM7UUFFVixJQUFJLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSwwQkFBMEI7WUFDNUMseUJBQXlCO1lBQ3pCLE1BQU0sRUFBQyxVQUFVLEdBQUcsRUFBRSxFQUFFLFVBQVUsRUFBQyxHQUFHLFVBQVUsQ0FBQztZQUNqRCw4RkFBOEY7WUFDOUYsNkZBQTZGO1lBQzdGLE1BQU0sY0FBYyxHQUFHLFdBQVcsS0FBSyxZQUFZO2dCQUNqRCxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxnQ0FBZ0MsQ0FBQyxDQUFDO1lBRTNELElBQUksY0FBYyxFQUFFO2dCQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVSxFQUNqRCwyQkFBMkIsT0FBTyxJQUFJLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ25FLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMzQixDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPO2FBQ1I7WUFFRCwwREFBMEQ7WUFDMUQsS0FBSyxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsd0JBQXdCLEdBQUcsWUFBWSxDQUFDLENBQUM7U0FDdkY7YUFBTSxJQUFJLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxlQUFlO1lBQ3hDLEtBQUssR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUN6Qyx5QkFBeUI7Z0JBQ3pCLDhEQUE4RCxDQUMvRCxDQUFDO1NBQ0g7YUFBTSxJQUFJLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxpQkFBaUI7WUFDMUMsSUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO2dCQUN6QixLQUFLLEdBQUcsSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDeEQ7aUJBQU07Z0JBQ0wseUdBQXlHO2dCQUN6RyxLQUFLLEdBQUcsSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDcEQ7U0FDRjthQUFNO1lBQ0wsaUNBQWlDO1lBQ2pDLHdCQUF3QjtZQUN4QixnQ0FBZ0M7WUFDaEMsbUJBQW1CO1lBQ25CLGlDQUFpQztZQUNqQyxpR0FBaUc7WUFDakcsS0FBSyxHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsRUFBRSx3QkFBd0IsR0FBRyxZQUFZLENBQUMsQ0FBQztTQUNqRjtRQUVELE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG9CQUFvQixDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQy9CLE1BQU0sY0FBYyxHQUFHO1lBQ3JCLG9CQUFvQjtZQUNwQixTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNwQixTQUFTLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN4RCxFQUFFLEVBQUUsTUFBTTtZQUNWLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNaLE9BQU8sRUFBRSxNQUFNO2dCQUNmLFFBQVEsRUFBRSxFQUFFO2dCQUNaLGlCQUFpQixFQUFFLElBQUksQ0FBQyxtQkFBbUI7Z0JBQzNDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtnQkFDdEIsTUFBTSxFQUFFLGtCQUFrQjtnQkFDMUIsUUFBUSxFQUFFLGdCQUFnQjthQUMzQixFQUFFLElBQUksQ0FBQztTQUNULENBQUM7UUFFRixPQUFPO1lBQ0wsT0FBTyxFQUFFLGNBQWM7WUFDdkIsY0FBYyxFQUFFLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQztTQUMzRCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNILFlBQVksQ0FBQyxPQUFPO1FBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7YUFDdEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7YUFDOUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksQ0FBQyxPQUFPO1FBQ2xCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDekYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNqRixnRkFBZ0Y7Z0JBQ2hGLGlFQUFpRTtnQkFDakUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUN6QixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ2Y7cUJBQU07b0JBQ0wsT0FBTyxFQUFFLENBQUM7aUJBQ1g7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsZ0JBQWdCLENBQUMsTUFBTTtRQUNyQixxQkFBcUI7UUFDckIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ25CLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3BDLE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDekMsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxDQUFDO29CQUNuRSxnRUFBZ0U7Z0JBQ2xFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1gsc0JBQXNCO29CQUN0QixJQUFJO3dCQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7cUJBQ2xCO29CQUFDLE9BQU0sQ0FBQyxFQUFFO3dCQUNULGFBQWE7cUJBQ2Q7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7YUFDSjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzFCLGdCQUFnQjtnQkFDaEIsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUNyQixVQUFVLEVBQ1YseUNBQXlDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEtBQUs7b0JBQ3hFLE1BQU0sQ0FBQyxPQUFPLEVBQ2QsSUFBSSxDQUFDLENBQUM7YUFDVDtRQUNILENBQUMsQ0FBQyxDQUFDO0lBRUwsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxXQUFXO1FBQ1QsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILG1CQUFtQjtRQUNqQixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxzQkFBc0IsQ0FBQyxNQUFNO1FBQzNCLEtBQUssTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxFQUFFO1lBQ3BELE9BQU8sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3hDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYztRQUNaLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsTUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFDO1lBRTNCLEtBQUssTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtnQkFDMUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7YUFDbkQ7WUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDL0MsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsYUFBYSxDQUFDLFNBQVM7UUFDckIsTUFBTSxPQUFPLEdBQUc7WUFDZCxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNwQixTQUFTLEVBQUUsU0FBUztZQUNwQixFQUFFLEVBQUUsT0FBTztZQUNYLElBQUksRUFBRTtnQkFDSixPQUFPLEVBQUUsU0FBUztnQkFDbEIsdUZBQXVGO2dCQUN2Riw2Q0FBNkM7Z0JBQzdDLEtBQUssRUFBRSxJQUFJO2FBQ1o7U0FDRixDQUFDO1FBRUYsTUFBTSxPQUFPLEdBQUc7WUFDZCxPQUFPLEVBQUUsT0FBTztZQUNoQixjQUFjLEVBQUUsSUFBSSxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUMsVUFBVSxFQUFFLElBQUksRUFBQyxDQUFDO1NBQzNELENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3JELE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNsRCxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUVMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLHNHQUFzRztRQUN0RyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUM7UUFDdEIsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3BCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN2QixLQUFLLE1BQU0sQ0FBQyxFQUFFLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsa0JBQWtCLEVBQUU7b0JBQ3pDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ2pCLE1BQU07aUJBQ1A7YUFDRjtTQUNGO1FBQ0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxFQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNoRSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsRUFBRTtnQkFDckQsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzdGO1FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsMENBQTBDO1lBQzFDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsV0FBVztRQUNULE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsaUJBQWlCO1FBQ2YsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVztRQUNULE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVcsQ0FBQyxPQUFPO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxjQUFjLEdBQUcsRUFBRTtRQUNwRCxNQUFNLFdBQVcsR0FBRztZQUNsQixRQUFRLEVBQUUsRUFBRTtZQUNaLGdCQUFnQixFQUFFLEVBQUU7WUFDcEIsZUFBZSxFQUFFLEVBQUU7U0FDcEIsQ0FBQztRQUVGLElBQUksY0FBYyxDQUFDLE1BQU0sRUFBRTtZQUN6QixxQ0FBcUM7WUFDckMsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUM5RCxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3pFLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUNoRDtTQUNGO1FBRUQsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRWxFLElBQUksY0FBYyxDQUFDLEtBQUssRUFBRTtZQUN4QixXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDekUsNERBQTREO1lBQzVELHNEQUFzRDtZQUN0RCxLQUFLLE1BQU0sT0FBTyxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7Z0JBQzFDLGdDQUFnQztnQkFDaEMsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRTtvQkFDNUIsV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDNUM7YUFDRjtZQUNELHlCQUF5QjtZQUN6QixXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDaEQ7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILHNCQUFzQixDQUFDLEVBQUUsRUFBRSxZQUFZO1FBQ3JDLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7UUFDN0UsTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7UUFDM0UsS0FBSyxNQUFNLE9BQU8sSUFBSSxlQUFlLEVBQUU7WUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ25DO1FBQ0QsS0FBSyxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsRUFBRTtZQUN0QyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMxQztJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxlQUFlLENBQUMsS0FBSyxFQUFFLE9BQU8sR0FBRyxFQUFFO1FBQ2pDLE1BQU0sRUFBQyxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsVUFBVSxHQUFHLElBQUksRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUN2RSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDcEIsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzdGO1FBRUQsc0RBQXNEO1FBQ3RELE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFFM0UsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUV0RSx3RUFBd0U7UUFDeEUsNEVBQTRFO1FBQzVFLE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQ3ZELENBQUMsQ0FBQyxFQUFDLG9DQUFvQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQUM7WUFDekQsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUVQLE1BQU0sSUFBSSxHQUFHO1lBQ1gsdUJBQXVCLEVBQUUsT0FBTztZQUNoQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDO1NBQzFELENBQUM7UUFFRixNQUFNLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDeEIsSUFBSSxPQUFPLEtBQUssTUFBTSxFQUFFO1lBQ3RCLGlGQUFpRjtZQUNqRiw4REFBOEQ7WUFDOUQsNERBQTREO1lBQzVELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUM1RDthQUFNO1lBQ0wsTUFBTSxjQUFjLEdBQUcsT0FBTyxLQUFLLEtBQUs7Z0JBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRTtnQkFDL0IsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFFOUYsdUZBQXVGO1lBQ3ZGLDJEQUEyRDtZQUMzRCw0Q0FBNEM7WUFDNUMsTUFBTSxjQUFjLEdBQUc7Z0JBQ3JCLE1BQU0sRUFBRSxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CO2dCQUMvQyxrRUFBa0U7Z0JBQ2xFLEtBQUssRUFBRSxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLElBQUksU0FBUzthQUM1RCxDQUFDO1lBRUYsS0FBSyxNQUFNLFNBQVMsSUFBSSxjQUFjLEVBQUU7Z0JBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO2dCQUN6QixZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDO2FBQzVFO1NBQ0Y7UUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsQ0FBQztRQUVyRCx3REFBd0Q7UUFDeEQsT0FBTyxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUMvQyxPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM1RCxDQUFDLENBQUMsQ0FBQztRQUVMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNsQixJQUFJLENBQUMsc0JBQXNCLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQzlDLCtDQUErQztZQUMvQyxzQ0FBc0M7WUFDdEMscUNBQXFDO1lBQ3JDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLGNBQWMsR0FBRyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILG1CQUFtQixDQUFDLEtBQUssRUFBRSxPQUFPLEdBQUcsRUFBRTtRQUNyQyxNQUFNLEVBQUMsU0FBUyxHQUFHLENBQUMsRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUNoQyxpRkFBaUY7UUFDakYsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDbEQsTUFBTSxVQUFVLEdBQUcsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxTQUFTLE1BQU0sS0FBSyxFQUFFLENBQUM7UUFDNUUsTUFBTSxZQUFZLEdBQUcsR0FBRyxTQUFTLE9BQU8sQ0FBQztRQUN6QyxNQUFNLFlBQVksR0FBRyxHQUFHLFNBQVMsWUFBWSxDQUFDO1FBQzlDLE1BQU0sU0FBUyxHQUFHLEdBQUcsU0FBUyxTQUFTLFNBQVMsR0FBRyxDQUFDO1FBQ3BELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDOUMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFDO1FBRXhCLE1BQU0sYUFBYSxHQUFHLEdBQUcsRUFBRTtZQUN6QixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMxRCxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNoQixXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUNuQixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxVQUFVLEtBQUssWUFBWSxNQUFNLFNBQVMsT0FBTyxFQUFFO29CQUNoRixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87b0JBQ3hCLHdCQUF3QixFQUFFLE9BQU8sQ0FBQyx3QkFBd0I7b0JBQzFELE9BQU8sRUFBRSxXQUFXO29CQUNwQixPQUFPLEVBQUUsU0FBUztpQkFDbkIsQ0FBQyxDQUFDO2FBQ0o7WUFDRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxZQUFZLE1BQU0sU0FBUyxPQUFPLFlBQVksR0FBRyxFQUFFO2dCQUNoRixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBQ3hCLE9BQU8sRUFBRSxXQUFXO2dCQUNwQixVQUFVLEVBQUUsS0FBSztnQkFDakIsT0FBTyxFQUFFLE1BQU07YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsTUFBTSxPQUFPLEdBQUcsR0FBRyxFQUFFO1lBQ25CLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzFELGdDQUFnQztZQUNoQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFO2dCQUN4QyxPQUFPLEVBQUUsV0FBVztnQkFDcEIsT0FBTyxFQUFFLFNBQVM7YUFDbkIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksYUFBYSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMifQ==