/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-07.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
// locals
const GremlinConnector = require('./gremlinConnector');
class DseConnector extends GremlinConnector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions, {
            manageTransactions: true,
            httpPathGremlinServer: '/gremlin',
            binaryMessages: true,
            useSessions: true
        });
    }
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     *
     * @returns {Bluebird<void>}
     */
    $initGremlinSession() {
        const sName = JSON.stringify(this.getGraphOption('graphName'));
        const gremlinQuery = `
      builder = system.graph(${sName});
      if (builder.exists()) {
        return 'already_exist';
      } else if (${!!this.getGraphOption('create')}) {
        builder.create();
        return 'created';
      } else {
        return 'cant_create';
      }
    `;
        return this.$doGremlinQuery(gremlinQuery).get('0').then(state => {
            if (state === 'cant_create') {
                return Errors.technical('graph_unreachable', `The graph database ${sName} does not exist and auto-creation is disabled` +
                    ' ("create" option is false).', true);
            }
            this.$setAliases({
                g: `${this.getGraphOption('graphName')}.g`,
                graph: `${this.getGraphOption('graphName')}.graph`
            });
            if (state === 'created') {
                // We always allow_scan on created graphs (mostly because of testing)
                // Plus, we don't really mind, since the graph was created by us
                return this.$doGremlinQuery(`
          graph.schema().config().option('graph.allow_scan').set('true');
          graph.schema().config().option('graph.tx_autostart').set('true');
        `);
            }
        });
    }
    /**
     * Get the SemVer of the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $getVersion() {
        const q = 'inject(gremlin:Gremlin.version())'; // The gremlin version, not the DSE version
        return this.$doGremlinQuery(q).get('0').get('gremlin')
            .then(version => version.split('-')[0])
            .catch(error => {
            if (error.key === 'bad_graph_request' &&
                error.message && error.message.includes('whitelist_types')) {
                // We cannot retrieve gremlin version. A known cause is that class
                // org.apache.tinkerpop.gremlin.util.Gremlin is not listed under whitelist_types in dse.yaml
                return '[unknown]';
            }
            throw error;
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Promise.resolve(this.getGraphOption('graphName'));
    }
}
module.exports = DseConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvZHNlQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLFNBQVM7QUFDVCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBRXZELE1BQU0sWUFBYSxTQUFRLGdCQUFnQjtJQUV6Qzs7O09BR0c7SUFDSCxZQUFZLFlBQVksRUFBRSxZQUFZO1FBQ3BDLEtBQUssQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFO1lBQ2hDLGtCQUFrQixFQUFFLElBQUk7WUFDeEIscUJBQXFCLEVBQUUsVUFBVTtZQUNqQyxjQUFjLEVBQUUsSUFBSTtZQUNwQixXQUFXLEVBQUUsSUFBSTtTQUNsQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG1CQUFtQjtRQUNqQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUMvRCxNQUFNLFlBQVksR0FBRzsrQkFDTSxLQUFLOzs7bUJBR2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQzs7Ozs7O0tBTTdDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM5RCxJQUFJLEtBQUssS0FBSyxhQUFhLEVBQUU7Z0JBQzNCLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsbUJBQW1CLEVBQ25CLHNCQUFzQixLQUFLLCtDQUErQztvQkFDMUUsOEJBQThCLEVBQzlCLElBQUksQ0FDTCxDQUFDO2FBQ0g7WUFFRCxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUNmLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUk7Z0JBQzFDLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLFFBQVE7YUFDbkQsQ0FBQyxDQUFDO1lBRUgsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO2dCQUN2QixxRUFBcUU7Z0JBQ3JFLGdFQUFnRTtnQkFDaEUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDOzs7U0FHM0IsQ0FBQyxDQUFDO2FBQ0o7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVztRQUNULE1BQU0sQ0FBQyxHQUFHLG1DQUFtQyxDQUFDLENBQUMsMkNBQTJDO1FBQzFGLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQzthQUNuRCxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3RDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxtQkFBbUI7Z0JBQ25DLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDNUQsa0VBQWtFO2dCQUNsRSw0RkFBNEY7Z0JBQzVGLE9BQU8sV0FBVyxDQUFDO2FBQ3BCO1lBQ0QsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsV0FBVztRQUNULE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDM0QsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUMifQ==