/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-08-05.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const Connector = require('./connector');
const LkRequest = require('../../lib/LkRequest');
class SolrConnector extends Connector {
    /**
     * @param {any} graphOptions   GraphDAO options
     * @param {any} [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions);
        this.$httpUrl = Utils.normalizeUrl(this.getIndexOption('url'));
        this.$encodedCollectionName = encodeURIComponent(this.getIndexOption('collectionName'));
        this.$request = new LkRequest({
            strictSSL: !this.getIndexOption('allowSelfSigned'),
            auth: this.getIndexOption('user') ? {
                user: this.getIndexOption('user'),
                password: this.getIndexOption('password')
            } : undefined,
            pool: { maxSockets: 5 },
            json: true,
            gzip: true
        });
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this.$request.get(this.$httpUrl + '/solr/admin/info/system', {}, [200, 401]).then(response => {
            if (response.statusCode === 401) {
                return Errors.business('invalid_parameter', 'Please check the Solr username and password in the configuration.', true);
            }
            return this.$request.get(this.$httpUrl + '/solr/' + this.$encodedCollectionName + '/schema', {}, [200, 404]).then(response => {
                if (response.statusCode === 404) {
                    return Errors.technical('critical', 'The Solr collection was not found.', true);
                }
                this.$schema = response.body.schema;
            }).return(response.body.lucene['solr-spec-version']);
        });
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this.$request.get(this.$httpUrl + '/solr/' + this.$encodedCollectionName + '/admin/ping', {}, [200]).return();
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     *
     * @returns {Bluebird<string>}
     */
    $getStoreId() {
        return Promise.resolve(this.getIndexOption('collectionName'));
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({ schema: this.$schema });
    }
    /**
     * Perform a search in Solr.
     *
     * @param {string} luceneQuery
     * @param {number} size
     * @param {number} from
     * @returns {any}
     */
    $search(luceneQuery, size, from) {
        return this.$request.get(this.$httpUrl + '/solr/' + this.$encodedCollectionName + '/select', {
            qs: {
                q: luceneQuery,
                rows: size,
                start: from
            }
        }, [200]).then(response => response.body.response);
    }
}
module.exports = SolrConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29sckNvbm5lY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vY29ubmVjdG9yL3NvbHJDb25uZWN0b3IuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLFNBQVM7QUFDVCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDekMsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFFakQsTUFBTSxhQUFjLFNBQVEsU0FBUztJQUVuQzs7O09BR0c7SUFDSCxZQUFZLFlBQVksRUFBRSxZQUFZO1FBQ3BDLEtBQUssQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFbEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvRCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7UUFFeEYsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUM1QixTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDO1lBQ2xELElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDO2dCQUNqQyxRQUFRLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUM7YUFDMUMsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUNiLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUM7WUFDckIsSUFBSSxFQUFFLElBQUk7WUFDVixJQUFJLEVBQUUsSUFBSTtTQUNYLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcseUJBQXlCLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUMxRCxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQixJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUMvQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixtRUFBbUUsRUFDbkUsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUNuRixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEIsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtvQkFDL0IsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxvQ0FBb0MsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDakY7Z0JBRUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUV0QyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxRQUFRO1FBQ04sT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixHQUFHLGFBQWEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FDbEYsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNiLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsV0FBVztRQUNULE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGlCQUFpQjtRQUNmLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLElBQUk7UUFDN0IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFNBQVMsRUFBRTtZQUNsRSxFQUFFLEVBQUU7Z0JBQ0YsQ0FBQyxFQUFFLFdBQVc7Z0JBQ2QsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLElBQUk7YUFDWjtTQUNGLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FDVCxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDN0MsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMifQ==