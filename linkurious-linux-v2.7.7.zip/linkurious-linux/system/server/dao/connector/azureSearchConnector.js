/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-07-12.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const Connector = require('./connector');
const LkRequest = require('../../lib/LkRequest');
class AzureSearchConnector extends Connector {
    /**
     * @returns {LkRequest}
     */
    get $request() {
        if (Utils.noValue(this._request)) {
            const { scheme, host, port } = Utils.extractHostPort(this.getIndexOption('url'));
            this._request = new LkRequest({
                headers: {
                    'Content-type': 'application/json',
                    'api-key': this.getIndexOption('apiKey')
                },
                baseUrl: `${scheme}://${host}:${port}`,
                json: true,
                pool: { maxSockets: 5 }
            });
        }
        return this._request;
    }
    /**
     * Azure search service API version.
     *
     * @returns {string}
     */
    get API_VERSION() {
        // Latest version of azure search rest api.
        // It is required for any request and cannot be detected automatically
        return '2017-11-11';
    }
    /**
     * Execute a get request on the azure search endpoint.
     *
     * @param {string}   url
     * @param {object}   [params]
     * @param {number[]} [expectedStatusCodes]
     * @returns {Bluebird<IncomingMessage>}
     * @private
     */
    _doGet(url, params, expectedStatusCodes) {
        const defaultParams = {
            'api-version': this.API_VERSION
        };
        const urlParams = Utils.hasValue(params) ? _.merge(defaultParams, params) : defaultParams;
        return this.$request.get(url, { qs: urlParams }, expectedStatusCodes);
    }
    /**
     * Get the number of indexed documents on `indexName`.
     *
     * @param {string} indexName
     * @returns {Bluebird<number>}
     */
    getCount(indexName) {
        return this._doGet(`/indexes/${indexName}/docs/$count`, undefined, [200]).then(response => {
            return Number.parseInt(response.body);
        });
    }
    /**
     * Return an `AzureSearchIndex` if exists.
     *
     * @param {string} indexName
     * @returns {Bluebird<AzureSearchIndex>}
     * @throws {LkError} If the index does not exist on the search service
     */
    findIndex(indexName) {
        return this._doGet(`/indexes/${indexName}`).then(response => {
            if (response.statusCode !== 200) {
                if (response.statusCode === 404) {
                    return Errors.business('source_action_needed', `Index ${indexName} was not found`, true);
                }
                const errorMessage = response.body.Message || JSON.stringify(response.body);
                return Errors.technical('index_unreachable', `Index ${indexName} was not found, error: ` + errorMessage, true);
            }
            return response.body;
        });
    }
    /**
     * Execute a full text search request on the search service.
     *
     * @param {string}             indexName
     * @param {AzureSearchOptions} options
     * @returns {Bluebird<AzureSearchResult>}
     */
    doFullTextSearch(indexName, options) {
        return this._doGet(`/indexes/${indexName}/docs`, {
            'search': options.luceneQuery,
            'queryType': 'full',
            '$filter': options.filterQuery,
            '$top': options.size,
            '$skip': options.from,
            '$orderby': 'search.score() desc',
            '$count': true
        }, [200]).then(response => response.body);
    }
    /**
     * Connect to the remote server.
     *
     * @returns {Bluebird<string>} resolved with the SemVer version of the remote server
     */
    $connect() {
        return this.$checkUp()
            .catch(error => {
            if (error.key === 'critical' && error.message.includes('403')) {
                throw Errors.business('invalid_parameter', 'Authentication failed, please check azure ' +
                    'search url and apiKey in configuration');
            }
            throw error;
        }).return('[unknown]');
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this._doGet('', undefined, [200]).then(r => {
            if (Utils.noValue(r)) {
                return Errors.technical('index_unreachable', 'Cannot connect to the search service', true);
            }
        });
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({});
    }
}
module.exports = AzureSearchConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmVTZWFyY2hDb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2Nvbm5lY3Rvci9henVyZVNlYXJjaENvbm5lY3Rvci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLFNBQVM7QUFDVCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDekMsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFFakQsTUFBTSxvQkFBcUIsU0FBUSxTQUFTO0lBQzFDOztPQUVHO0lBQ0gsSUFBSSxRQUFRO1FBQ1YsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQyxNQUFNLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsR0FBRyxLQUFLLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDO2dCQUM1QixPQUFPLEVBQUU7b0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtvQkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDO2lCQUN6QztnQkFDRCxPQUFPLEVBQUUsR0FBRyxNQUFNLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRTtnQkFDdEMsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLENBQUMsRUFBQzthQUN0QixDQUFDLENBQUM7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILElBQUksV0FBVztRQUNiLDJDQUEyQztRQUMzQyxzRUFBc0U7UUFDdEUsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsTUFBTSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsbUJBQW1CO1FBQ3JDLE1BQU0sYUFBYSxHQUFHO1lBQ3BCLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVztTQUNoQyxDQUFDO1FBQ0YsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztRQUUxRixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUMsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFFBQVEsQ0FBQyxTQUFTO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLFNBQVMsY0FBYyxFQUFFLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hGLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsU0FBUyxDQUFDLFNBQVM7UUFDakIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDMUQsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDL0IsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtvQkFDL0IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLFNBQVMsU0FBUyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDMUY7Z0JBQ0QsTUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzVFLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFDekMsU0FBUyxTQUFTLHlCQUF5QixHQUFHLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNyRTtZQUNELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsT0FBTztRQUNqQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxTQUFTLE9BQU8sRUFBRTtZQUMvQyxRQUFRLEVBQUUsT0FBTyxDQUFDLFdBQVc7WUFDN0IsV0FBVyxFQUFFLE1BQU07WUFDbkIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxXQUFXO1lBQzlCLE1BQU0sRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNwQixPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDckIsVUFBVSxFQUFFLHFCQUFxQjtZQUNqQyxRQUFRLEVBQUUsSUFBSTtTQUNmLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVE7UUFDTixPQUFPLElBQUksQ0FBQyxRQUFRLEVBQUU7YUFDbkIsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2IsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDN0QsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLDRDQUE0QztvQkFDckYsd0NBQXdDLENBQUMsQ0FBQzthQUM3QztZQUNELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDaEQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsc0NBQXNDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUY7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsaUJBQWlCO1FBQ2YsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzdCLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLENBQUMifQ==