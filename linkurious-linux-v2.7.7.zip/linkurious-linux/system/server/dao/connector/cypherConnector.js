/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // abstract methods
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
// locals
const Connector = require('./connector');
class CypherConnector extends Connector {
    /**
     * Execute a cypher query on Neo4j.
     *
     * Note that this function is not meant for user queries.
     * We don't enforce a limit or check if the query contains write statements.
     * Use $safeCypherQueryStream instead.
     *
     * @param {string}  query        The graph query
     * @param {object}  [parameters] The graph query parameters
     * @param {boolean} [ignoreSlow] Don't log slow requests
     * @returns {Bluebird<{keys: string[], results: Array<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $doCypherQuery(query, parameters, ignoreSlow) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Execute a cypher query on Neo4j and return a stream as a result.
     * If `limit` is defined, the limit of the Cypher query is modified to not be higher
     * than `limit`.
     *
     * @param {string}  query        The graph query
     * @param {object}  [parameters] The graph query parameters
     * @param {number}  [limit]      Maximum number of matched subgraphs
     * @returns {Bluebird<{keys: string[], results: Readable<{nodes: LkNode[], edges: LkEdge[], rows: any[]}>}>}
     */
    $safeCypherQueryStream(query, parameters, limit) {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Check if the remote server is alive.
     *
     * @returns {Bluebird<void>}
     */
    $checkUp() {
        return this.$doCypherQuery('RETURN 0').return(); // any no-op would be ok
    }
    /**
     * Data that the connector will pass to the driver.
     *
     * @returns {Bluebird<any>}
     */
    $getConnectorData() {
        return Promise.resolve({});
    }
}
module.exports = CypherConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwaGVyQ29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9jb25uZWN0b3IvY3lwaGVyQ29ubmVjdG9yLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsOEJBQThCLENBQUMsbUJBQW1CO0FBRWxELGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBRXpDLE1BQU0sZUFBZ0IsU0FBUSxTQUFTO0lBRXJDOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsY0FBYyxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVTtRQUMxQyxPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsc0JBQXNCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxLQUFLO1FBQzdDLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLHdCQUF3QjtJQUMzRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGlCQUFpQjtRQUNmLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3QixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQyJ9