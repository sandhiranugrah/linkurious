"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-07.
 */
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const GremlinConnector = require('./gremlinConnector');
var CONFIGURATION_TYPE;
(function (CONFIGURATION_TYPE) {
    CONFIGURATION_TYPE[CONFIGURATION_TYPE["ALIAS"] = 0] = "ALIAS";
    CONFIGURATION_TYPE[CONFIGURATION_TYPE["INSTANCE"] = 1] = "INSTANCE";
})(CONFIGURATION_TYPE || (CONFIGURATION_TYPE = {}));
// @ts-ignore GremlinConnector needs to be written in TS
class JanusGraphConnector extends GremlinConnector {
    /**
     * @param graphOptions   GraphDAO options
     * @param [indexOptions] IndexDAO options (only if the type of the DAO is 'Index')
     */
    constructor(graphOptions, indexOptions) {
        super(graphOptions, indexOptions, {
            manageTransactions: false,
            // JanusGraph 0.1.1 doesn't care about httpPathGremlinServer
            // The gremlin server of JanusGraph > 0.2.0 does
            httpPathGremlinServer: '/gremlin',
            binaryMessages: true,
            useSessions: true
        });
        // only one of the three can be defined
        this.configurationPath = this.getGraphOption('configurationPath');
        this.configuration = this.getGraphOption('configuration');
        const graphAlias = this.getGraphOption('graphAlias');
        const traversalAlias = this.getGraphOption('traversalSourceAlias', 'g');
        if (Utils.hasValue(graphAlias)) {
            this.configurationType = CONFIGURATION_TYPE.ALIAS;
            this.$setAliases({
                graph: graphAlias,
                g: traversalAlias
            });
        }
        else {
            this.configurationType = CONFIGURATION_TYPE.INSTANCE;
        }
    }
    /**
     * Add definitions in the gremlin session and/or perform additional checks.
     */
    $initGremlinSession() {
        let initGraph = '';
        let initTraversal = '';
        if (this.configurationType === CONFIGURATION_TYPE.INSTANCE) {
            if (Utils.hasValue(this.configurationPath)) {
                initGraph = `graph = JanusGraphFactory.open(${JSON.stringify(this.configurationPath)});`;
            }
            else {
                const configurationString = _.toPairs(this.configuration)
                    .map(kv => `.set(${JSON.stringify(kv[0])}, ${JSON.stringify(kv[1])})`)
                    .join('');
                initGraph = `graph = JanusGraphFactory.build()${configurationString}.open();`;
            }
            initTraversal = 'g = graph.traversal();';
        }
        const initScript = `${initGraph}${initTraversal}graph.isOpen();`;
        return this.$doGremlinQuery(initScript, { session: 'all', autoCommit: false }).then(checkGraphOpenedResult => {
            if (_.some(checkGraphOpenedResult, 'false')) {
                return Errors.technical('graph_unreachable', 'the configured graph is not opened', true);
            }
            return Bluebird.resolve();
        });
    }
    /**
     * Disconnect from the remote server.
     *
     * Close the JanusGraph instance.
     */
    $disconnect() {
        if (this.configurationType === CONFIGURATION_TYPE.INSTANCE) {
            this.$doGremlinQuery('graph.close();', { session: 'all', autoCommit: false }).then(() => super.$disconnect());
        }
        else {
            super.$disconnect();
        }
    }
    /**
     * Get the SemVer of the remote server.
     */
    $getVersion() {
        const q = 'inject(JanusGraph:JanusGraph.version())';
        return this.$doGremlinQuery(q).then(results => {
            const result = results[0];
            const version = result.JanusGraph;
            // detect typed serializer
            if (Utils.noValue(version) && result['@type'] === 'g:Map') {
                // a typed serializer is in use, LKE does not support it yet
                return Errors.business('source_action_needed', 'Unsupported serialization format, please configure Gremlin Server with ' +
                    'GraphSONMessageSerializerGremlinV2d0 ' +
                    'or a prior version of the GraphSon serializer.', true);
            }
            return Bluebird.resolve(version);
        });
    }
    /**
     * Detect the current store ID.
     *
     * A store ID is the name of the current database (if the graph server is multi-tenant)
     * otherwise the vendor name.
     */
    $getStoreId() {
        let storeId;
        if (this.configurationType === CONFIGURATION_TYPE.ALIAS) {
            storeId = Utils.toJSON(this._aliases);
        }
        else {
            if (Utils.hasValue(this.configurationPath)) {
                storeId = this.configurationPath;
            }
            else {
                storeId = Utils.toJSON(this.configuration);
            }
        }
        return Bluebird.resolve(storeId);
    }
}
module.exports = JanusGraphConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaENvbm5lY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vY29ubmVjdG9yL2phbnVzR3JhcGhDb25uZWN0b3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBRUgsZ0JBQWdCO0FBQ2hCLHFDQUFxQztBQUNyQyw0QkFBNEI7QUFFNUIsV0FBVztBQUNYLHNDQUF1QztBQUN2QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLFNBQVM7QUFDVCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBcUIsQ0FBQztBQUUzRSxJQUFLLGtCQUdKO0FBSEQsV0FBSyxrQkFBa0I7SUFDckIsNkRBQUssQ0FBQTtJQUNMLG1FQUFRLENBQUE7QUFDVixDQUFDLEVBSEksa0JBQWtCLEtBQWxCLGtCQUFrQixRQUd0QjtBQUVELHdEQUF3RDtBQUN4RCxNQUFNLG1CQUFvQixTQUFRLGdCQUFnQjtJQUtoRDs7O09BR0c7SUFDSCxZQUFZLFlBQW9DLEVBQUUsWUFBb0M7UUFDcEYsS0FBSyxDQUFDLFlBQVksRUFBRSxZQUFZLEVBQUU7WUFDaEMsa0JBQWtCLEVBQUUsS0FBSztZQUN6Qiw0REFBNEQ7WUFDNUQsZ0RBQWdEO1lBQ2hELHFCQUFxQixFQUFFLFVBQVU7WUFDakMsY0FBYyxFQUFFLElBQUk7WUFDcEIsV0FBVyxFQUFFLElBQUk7U0FDbEIsQ0FBQyxDQUFDO1FBRUgsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUF1QixDQUFDO1FBQ3hGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQXNDLENBQUM7UUFFL0YsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQXVCLENBQUM7UUFDM0UsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsRUFBRSxHQUFHLENBQVcsQ0FBQztRQUVsRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDOUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLGtCQUFrQixDQUFDLEtBQUssQ0FBQztZQUNsRCxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUNmLEtBQUssRUFBRSxVQUFVO2dCQUNqQixDQUFDLEVBQUUsY0FBYzthQUNsQixDQUFDLENBQUM7U0FDSjthQUFNO1lBQ0wsSUFBSSxDQUFDLGlCQUFpQixHQUFHLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztTQUN0RDtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLG1CQUFtQjtRQUN4QixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBRXZCLElBQUksSUFBSSxDQUFDLGlCQUFpQixLQUFLLGtCQUFrQixDQUFDLFFBQVEsRUFBRTtZQUMxRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQzFDLFNBQVMsR0FBRyxrQ0FBa0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDO2FBQzFGO2lCQUFNO2dCQUNMLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO3FCQUN0RCxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO3FCQUNyRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRVosU0FBUyxHQUFHLG9DQUFvQyxtQkFBbUIsVUFBVSxDQUFDO2FBQy9FO1lBQ0QsYUFBYSxHQUFHLHdCQUF3QixDQUFDO1NBQzFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsR0FBRyxTQUFTLEdBQUcsYUFBYSxpQkFBaUIsQ0FBQztRQUVqRSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQy9FLHNCQUFzQixDQUFDLEVBQUU7WUFDdkIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sQ0FBQyxFQUFFO2dCQUMzQyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsb0NBQW9DLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDMUY7WUFDRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUM1QixDQUFDLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksV0FBVztRQUNoQixJQUFJLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUU7WUFDMUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUNwRixLQUFLLENBQUMsV0FBVyxFQUFFLENBQ3BCLENBQUM7U0FDSDthQUFNO1lBQ0wsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksV0FBVztRQUNoQixNQUFNLENBQUMsR0FBRyx5Q0FBeUMsQ0FBQztRQUNwRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzVDLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQThELENBQUM7WUFDdkYsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQztZQUNsQywwQkFBMEI7WUFDMUIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxPQUFPLEVBQUU7Z0JBQ3pELDREQUE0RDtnQkFDNUQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixzQkFBc0IsRUFDdEIseUVBQXlFO29CQUN2RSx1Q0FBdUM7b0JBQ3ZDLGdEQUFnRCxFQUNsRCxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksV0FBVztRQUNoQixJQUFJLE9BQU8sQ0FBQztRQUVaLElBQUksSUFBSSxDQUFDLGlCQUFpQixLQUFLLGtCQUFrQixDQUFDLEtBQUssRUFBRTtZQUN2RCxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDdkM7YUFBTTtZQUNMLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDMUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQzthQUNsQztpQkFBTTtnQkFDTCxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDNUM7U0FDRjtRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNuQyxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxtQkFBbUIsQ0FBQyJ9