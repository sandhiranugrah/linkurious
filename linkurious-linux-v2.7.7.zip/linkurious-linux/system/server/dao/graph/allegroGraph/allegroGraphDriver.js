/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-21.
 */
'use strict';
// external libs
const through = require('through');
// our libs
const JsonStream = require('../../../../lib/JsonStream');
// services
const LKE = require('../../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// locals
const SparqlDriver = require('../sparqlDriver');
class AllegroGraphDriver extends SparqlDriver {
    /**
     * @param {SparqlConnector} connector     Connector used by the DAO
     * @param {any}             graphOptions  GraphDAO options
     * @param {any}             connectorData Data from the connector
     * @param {GraphFeatures}   graphFeatures Features of the Graph DAO
     */
    constructor(connector, graphOptions, connectorData, graphFeatures) {
        super(connector, graphOptions, connectorData, graphFeatures, {
            supportBlankNodeLabels: false,
            implementGetStatements: true,
            supportPropertyPaths: false
        });
        // we use the LkRequest object directly to get the node and edge stream
        this.request = connector.$request;
    }
    /**
     * Create the spogi index in AllegroGraph if it doesn't exit and optimize all the indices.
     * The optimization step will put statements with the same subject next to each other.
     * Only creating the index is not enough. This behaviour, anyway, is undocumented.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _createSpogiAndOptimize() {
        return this.request.get('/indices').then(indicesR => {
            if (indicesR.statusCode !== 200) {
                return Errors.technical('critical', 'Could not list indices (HTTP ' + indicesR.statusCode + '): ' + indicesR.body, true);
            }
            // SPOGI index already present
            if (indicesR.body.indexOf('spogi') >= 0) {
                return;
            }
            // we need to create SPOGI index
            return this.request.put('/indices/spogi').then(spogiR => {
                if (spogiR.statusCode === 204) {
                    return;
                }
                return Errors.technical('critical', 'Could not create the SPOGI index (HTTP ' + spogiR.statusCode + '): ' + spogiR.body, true);
            });
        }).then(() => {
            // optimize indices
            return this.request.post('/indices/optimize?wait=true').then(optimizeR => {
                if (optimizeR.statusCode === 204) {
                    return;
                }
                return Errors.technical('critical', 'Could not optimize indices (HTTP ' + optimizeR.statusCode + '): ' + optimizeR.body, true);
            });
        }).return();
    }
    /**
     * Get a stream of all nodes.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkNode>>}
     */
    $getNodeStream(options) {
        let offset = options.offset || 0;
        Utils.check.integer('offset', offset, 0);
        const self = this;
        return this._createSpogiAndOptimize().then(() => {
            let lastNodeIdSeen;
            let lastNodeStatements = [];
            return this.request.getStream('/statements', 'get', undefined, [200]).then(stream => {
                stream.resume();
                return Utils.safePipe(stream, JsonStream.parse(['*']), through(function (data) {
                    if (data[0] === lastNodeIdSeen) {
                        lastNodeStatements.push(data);
                    }
                    else {
                        if (Utils.hasValue(lastNodeIdSeen)) {
                            if (offset === 0) {
                                try {
                                    const node = self._utils.parseStatementsForNode(lastNodeStatements);
                                    if (node !== null) {
                                        this.queue(node);
                                    }
                                }
                                catch (e) {
                                    Log.warn('While indexing: ', e.message);
                                }
                            }
                            else {
                                --offset;
                            }
                        }
                        lastNodeIdSeen = data[0];
                        lastNodeStatements = [data];
                    }
                }, function () {
                    if (Utils.hasValue(lastNodeIdSeen)) {
                        try {
                            const node = self._utils.parseStatementsForNode(lastNodeStatements);
                            if (node !== null) {
                                this.queue(node);
                            }
                        }
                        catch (e) {
                            Log.warn('While indexing: ', e.message);
                        }
                    }
                    this.queue(null);
                }));
            });
        });
    }
    /**
     * Get a stream of all edges.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkEdge>>}
     */
    $getEdgeStream(options) {
        let offset = options.offset || 0;
        Utils.check.integer('offset', offset, 0);
        const self = this;
        return this.request.getStream('/statements', 'get', undefined, [200]).then(stream => {
            stream.resume();
            return Utils.safePipe(stream, JsonStream.parse(['*']), through(function (data) {
                if (self._utils.statementIsAnEdge(data)) {
                    if (offset === 0) {
                        try {
                            this.queue(self._utils.parseStatementForEdge(data));
                        }
                        catch (e) {
                            Log.warn('While indexing: ', e.message);
                        }
                    }
                    else {
                        --offset;
                    }
                }
            }, function () {
                this.queue(null);
            }));
        });
    }
}
module.exports = AllegroGraphDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxsZWdyb0dyYXBoRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9hbGxlZ3JvR3JhcGgvYWxsZWdyb0dyYXBoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUVuQyxXQUFXO0FBQ1gsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLDRCQUE0QixDQUFDLENBQUM7QUFFekQsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxTQUFTO0FBQ1QsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFFaEQsTUFBTSxrQkFBbUIsU0FBUSxZQUFZO0lBRTNDOzs7OztPQUtHO0lBQ0gsWUFBWSxTQUFTLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhO1FBQy9ELEtBQUssQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUU7WUFDM0Qsc0JBQXNCLEVBQUUsS0FBSztZQUM3QixzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLG9CQUFvQixFQUFFLEtBQUs7U0FDNUIsQ0FBQyxDQUFDO1FBRUgsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHVCQUF1QjtRQUNyQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNsRCxJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUMvQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLFVBQVUsRUFDViwrQkFBK0IsR0FBRyxRQUFRLENBQUMsVUFBVSxHQUFHLEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxFQUM3RSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBRUQsOEJBQThCO1lBQzlCLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUN2QyxPQUFPO2FBQ1I7WUFFRCxnQ0FBZ0M7WUFDaEMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDdEQsSUFBSSxNQUFNLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtvQkFBRSxPQUFPO2lCQUFFO2dCQUUxQyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLFVBQVUsRUFDVix5Q0FBeUMsR0FBRyxNQUFNLENBQUMsVUFBVSxHQUFHLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxFQUNuRixJQUFJLENBQ0wsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLG1CQUFtQjtZQUNuQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUN2RSxJQUFJLFNBQVMsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO29CQUFFLE9BQU87aUJBQUU7Z0JBRTdDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsVUFBVSxFQUNWLG1DQUFtQyxHQUFHLFNBQVMsQ0FBQyxVQUFVLEdBQUcsS0FBSyxHQUFHLFNBQVMsQ0FBQyxJQUFJLEVBQ25GLElBQUksQ0FDTCxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLE9BQU87UUFDcEIsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7UUFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV6QyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFFbEIsT0FBTyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzlDLElBQUksY0FBYyxDQUFDO1lBQ25CLElBQUksa0JBQWtCLEdBQUcsRUFBRSxDQUFDO1lBRTVCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbEYsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNoQixPQUFPLEtBQUssQ0FBQyxRQUFRLENBQ25CLE1BQU0sRUFDTixVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDdkIsT0FBTyxDQUNMLFVBQVMsSUFBSTtvQkFDWCxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxjQUFjLEVBQUU7d0JBQzlCLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDL0I7eUJBQU07d0JBQ0wsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFOzRCQUNsQyxJQUFJLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0NBQ2hCLElBQUk7b0NBQ0YsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO29DQUNwRSxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7d0NBQ2pCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7cUNBQ2xCO2lDQUNGO2dDQUFDLE9BQU0sQ0FBQyxFQUFFO29DQUNULEdBQUcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lDQUN6Qzs2QkFDRjtpQ0FBTTtnQ0FDTCxFQUFFLE1BQU0sQ0FBQzs2QkFDVjt5QkFDRjt3QkFDRCxjQUFjLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN6QixrQkFBa0IsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM3QjtnQkFFSCxDQUFDLEVBQ0Q7b0JBQ0UsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFO3dCQUNsQyxJQUFJOzRCQUNGLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsa0JBQWtCLENBQUMsQ0FBQzs0QkFDcEUsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO2dDQUNqQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDOzZCQUNsQjt5QkFDRjt3QkFBQyxPQUFNLENBQUMsRUFBRTs0QkFDVCxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQzt5QkFDekM7cUJBQ0Y7b0JBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkIsQ0FBQyxDQUNGLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGNBQWMsQ0FBQyxPQUFPO1FBQ3BCLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO1FBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFekMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNsRixNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFDMUIsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQ3ZCLE9BQU8sQ0FDTCxVQUFTLElBQUk7Z0JBQ1gsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUFFO29CQUN2QyxJQUFJLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ2hCLElBQUk7NEJBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7eUJBQ3JEO3dCQUFDLE9BQU0sQ0FBQyxFQUFFOzRCQUNULEdBQUcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3lCQUN6QztxQkFDRjt5QkFBTTt3QkFDTCxFQUFFLE1BQU0sQ0FBQztxQkFDVjtpQkFDRjtZQUNILENBQUMsRUFDRDtnQkFDRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ25CLENBQUMsQ0FDRixDQUNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLENBQUMifQ==