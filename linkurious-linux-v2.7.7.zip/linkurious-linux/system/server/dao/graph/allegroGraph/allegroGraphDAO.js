/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
// locals
const GraphDAO = require('../graphDAO');
const AllegroGraphConnector = require('../../connector/allegroGraphConnector');
const AllegroGraphDriver = require('./allegroGraphDriver');
class AllegroGraphDAO extends GraphDAO {
    /**
     * User can choose the id of a new node by setting `options.idPropertyName` if defined.
     * Updating the id is currently not supported since it would break the indexation.
     *
     * @param {object}  options
     * @param {string}  options.url                               AllegroGraph url
     * @param {string}  options.repository                        AllegroGraph repository name
     * @param {string}  [options.catalog]                         AllegroGraph catalog name (defaults to the root catalog)
     * @param {string}  [options.user]                            AllegroGraph user
     * @param {string}  [options.password]                        AllegroGraph password
     * @param {boolean} [options.create]                          Whether to create the graph repository if it does not exist
     * @param {string}  [options.namespace="http://linkurio.us/"] Default namespace
     * @param {string}  [options.categoryPredicate="rdf:type"]    Predicate that appears in category statements
     * @param {string}  [options.idPropertyName]                  Property name used to show the id in its short form
     * @param {boolean} [options.allowSelfSigned]                 Whether to allow self-signed certificates
     */
    constructor(options) {
        super('allegroGraph', ['url', 'repository'], ['url', 'repository', 'catalog', 'user', 'password', 'create',
            'namespace', 'categoryPredicate', 'idPropertyName', 'allowSelfSigned'], options, {
            edgeProperties: false,
            immutableNodeCategories: false,
            minNodeCategories: 0,
            maxNodeCategories: undefined,
            serializeArrayProperties: true,
            canCount: false,
            alerts: false,
            alternativeIds: false,
            emptyNodes: false,
            dialects: ['sparql'],
            canStream: true,
            detectSupernodes: false,
            canDryRun: false
        }, AllegroGraphConnector, [
            { version: '6.2.3', driver: '[latest]' },
            { version: '6.0.0', driver: AllegroGraphDriver }
        ]);
    }
}
module.exports = AllegroGraphDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxsZWdyb0dyYXBoREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9hbGxlZ3JvR3JhcGgvYWxsZWdyb0dyYXBoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLHFCQUFxQixHQUFHLE9BQU8sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0FBQy9FLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFFM0QsTUFBTSxlQUFnQixTQUFRLFFBQVE7SUFFcEM7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsWUFBWSxPQUFPO1FBQ2pCLEtBQUssQ0FBQyxjQUFjLEVBQ2xCLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUNyQixDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUTtZQUMzRCxXQUFXLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLENBQUMsRUFDeEUsT0FBTyxFQUNQO1lBQ0UsY0FBYyxFQUFFLEtBQUs7WUFDckIsdUJBQXVCLEVBQUUsS0FBSztZQUM5QixpQkFBaUIsRUFBRSxDQUFDO1lBQ3BCLGlCQUFpQixFQUFFLFNBQVM7WUFDNUIsd0JBQXdCLEVBQUUsSUFBSTtZQUM5QixRQUFRLEVBQUUsS0FBSztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBQ2IsY0FBYyxFQUFFLEtBQUs7WUFDckIsVUFBVSxFQUFFLEtBQUs7WUFDakIsUUFBUSxFQUFFLENBQUMsUUFBUSxDQUFDO1lBQ3BCLFNBQVMsRUFBRSxJQUFJO1lBQ2YsZ0JBQWdCLEVBQUUsS0FBSztZQUN2QixTQUFTLEVBQUUsS0FBSztTQUNqQixFQUNELHFCQUFxQixFQUNyQjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsa0JBQWtCLEVBQUM7U0FDL0MsQ0FDRixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUMifQ==