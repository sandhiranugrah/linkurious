/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const through = require('through');
const { InputSerialization } = require('linkurious-shared/umd');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
// locals
const GraphDriver = require('./graphDriver');
const CypherUtils = require('./../utils/cypherUtils');
const DaoUtils = require('./../utils/daoUtils');
class CypherDriver extends GraphDriver {
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param {TemplateDataValue}  value
     * @param {InputSerialization} serializer
     * @returns {string}
     */
    $quote(value, serializer) {
        switch (serializer) {
            case InputSerialization.NODE:
                const id = value + '';
                this.$checkNodeId('nodeId', id);
                return id;
            case InputSerialization.NODE_SET:
                _.forEach(value, v => this.$checkNodeId('nodeId', v));
                return CypherUtils.encodeIDArray(value);
            case InputSerialization.NATIVE_DATE:
                Utils.check.string('date', value, false);
                return `date('${value}')`;
            case InputSerialization.NATIVE_DATE_TIME:
                Utils.check.string('date', value, true);
                const datetime = ( /**@type {string}*/value);
                const withTimezone = /.+([+-]\d{2}:\d{2}|Z)$/.test(datetime);
                const type = withTimezone ? 'datetime' : 'localDatetime';
                return `${type}('${datetime}')`;
            case InputSerialization.STRING:
                return CypherUtils.encodeValue(value);
            default:
                return value + '';
        }
    }
    /**
     * Create a node.
     *
     * @param {LkNodeAttributes} newNode
     * @returns {Bluebird<LkNode>}
     */
    $createNode(newNode) {
        let sLabel = '';
        if (newNode.categories.length > 0) {
            sLabel = ':' + newNode.categories.map(category => CypherUtils.encodeName(category)).join((':'));
        }
        return this.connector.$doCypherQuery(`CREATE (n${sLabel} {data}) RETURN n`, { data: newNode.data }).then(response => {
            return response.results[0].nodes[0];
        });
    }
    /**
     * Create an edge.
     *
     * This method is responsible to check that source and target nodes have been found.
     *
     * @param {LkEdgeAttributes} newEdge The edge to create
     * @returns {Bluebird<LkEdge>}
     */
    $createEdge(newEdge) {
        return this.connector.$doCypherQuery(`MATCH (a), (b) WHERE id(a) = ${newEdge.source} AND id(b) = ${newEdge.target}
       CREATE (a)-[r:${CypherUtils.encodeName(newEdge.type)} {data}]->(b) RETURN r`, { data: newEdge.data }).then(response => {
            if (response.results.length === 0) {
                throw Errors.business('node_not_found', 'Source or target node not found.');
            }
            this._invalidateCaches();
            return response.results[0].edges[0];
        });
    }
    /**
     * Get a stream of all nodes.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkNode>>}
     */
    $getNodeStream(options) {
        // getStream with SKIP but without ORDER BY is risky. We hope Neo4j always returns the nodes
        // in the same order, but no guarantee is given. ORDER BY is extremely expensive:
        // sorting all nodes is done in memory and does not scale
        const query = 'MATCH (n) RETURN n' +
            (options.offset ? ' SKIP ' + options.offset : '');
        return this.connector.$safeCypherQueryStream([query]).then(response => {
            // for every returned row, we emit the first element that is a node
            return Utils.safePipe(response.results, through(function (record) {
                this.emit('data', record.nodes[0]);
            }));
        });
    }
    /**
     * Get a stream of all edges.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkEdge>>}
     */
    $getEdgeStream(options) {
        const query = 'MATCH (a)-[r]->() RETURN r' +
            (options.offset ? ' SKIP ' + options.offset : '');
        return this.connector.$safeCypherQueryStream([query]).then(response => {
            // for every returned row, we emit the first element that is an edge
            return Utils.safePipe(response.results, through(function (record) {
                this.emit('data', record.edges[0]);
            }));
        });
    }
    /**
     * Create a QueryMatchPopulated from a Neo4j response record.
     *
     * @param {{nodes: LkNode[], edges: LkEdge[], rows: any[]}} record A record from Neo4j
     * @param {string[]}                                        keys   The list of returned keys of the query
     * @returns {QueryMatchPopulated}
     * @private
     */
    _getNeoMatchPopulated(record, keys) {
        const properties = {};
        for (let i = 0; i < keys.length; i++) {
            properties[keys[i]] = record.rows[i];
        }
        // we return the populated nodes
        return {
            nodes: _.uniqBy(record.nodes, 'id'),
            edges: _.uniqBy(record.edges, 'id'),
            properties: properties
        };
    }
    /**
     * Create a QueryMatch from a Neo4j response record.
     *
     * @param {{nodes: LkNode[], edges: LkEdge[], rows: any[]}} record A record from Neo4j
     * @param {string[]}                                        keys   The list of returned keys of the query
     * @returns {QueryMatch}
     * @private
     */
    _getNeoMatch(record, keys) {
        const properties = {};
        for (let i = 0; i < keys.length; i++) {
            properties[keys[i]] = record.rows[i];
        }
        // we just return the ids
        return {
            nodes: _.map(record.nodes, 'id'),
            edges: _.map(record.edges, 'id'),
            properties: properties
        };
    }
    /**
     * Run a raw query.
     *
     * If options.populated is true, return a Readable<QueryMatchPopulated>, otherwise a Readable<QueryMatch>.
     *
     * @param {object}   options
     * @param {string}   options.dialect   Supported graph query dialect
     * @param {string[]} options.queries   The graph queries
     * @param {boolean}  options.populated Whether to return QueryMatchPopulated or QueryMatch
     * @param {number}   options.limit     Maximum number of matched subgraphs
     * @returns {Bluebird<Readable<(QueryMatch | QueryMatchPopulated)>>}
     */
    $rawQuery(options) {
        return this.connector.$safeCypherQueryStream(options.queries, null, options.limit).then(response => {
            const self = this;
            if (options.populated) {
                return Utils.safePipe(response.results, through(function (record) {
                    this.queue(self._getNeoMatchPopulated(record, response.keys));
                }));
            }
            else {
                return Utils.safePipe(response.results, through(function (record) {
                    this.queue(self._getNeoMatch(record, response.keys));
                }));
            }
        });
    }
    /**
     * Return true is query is a write query.
     */
    $isWrite(query) {
        return CypherUtils.isWrite(query);
    }
    /**
     * Check if a query is correct.
     *
     * @param {string}  query      The graph query
     * @returns {boolean} Whether the `query` will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    $checkQuery(query) {
        return CypherUtils.checkQuery(query);
    }
    /**
     * Update the properties and categories of a node.
     * Check if the node exists and fail if it doesn't.
     *
     * @param {any}      nodeId                       ID of the node to update
     * @param {object}   nodeUpdate
     * @param {any}      nodeUpdate.data              Properties to update
     * @param {string[]} nodeUpdate.deletedProperties Properties to delete
     * @param {string[]} nodeUpdate.addedCategories   Categories to add
     * @param {string[]} nodeUpdate.deletedCategories Categories to delete
     * @returns {Bluebird<LkNode>} null if not found
     */
    $updateNode(nodeId, nodeUpdate) {
        const sChanges = [];
        // add categories
        if (nodeUpdate.addedCategories.length > 0) {
            sChanges.push('SET n:' + nodeUpdate.addedCategories.map(category => CypherUtils.encodeName(category)).join((':')));
        }
        // remove categories
        if (nodeUpdate.deletedCategories.length > 0) {
            sChanges.push('REMOVE n:' + nodeUpdate.deletedCategories.map(category => CypherUtils.encodeName(category)).join((':')));
        }
        // set properties
        _.forEach(nodeUpdate.data, (value, key) => {
            sChanges.push('SET n.' + CypherUtils.encodeName(key) + ' = ' +
                CypherUtils.encodeValue(value));
        });
        // delete properties
        _.forEach(nodeUpdate.deletedProperties, key => {
            sChanges.push('REMOVE n.' + CypherUtils.encodeName(key));
        });
        const query = 'MATCH (n) WHERE id(n)=' + nodeId + ' ' + sChanges.join(' ') + ' RETURN n';
        return this.connector.$doCypherQuery(query).then(response => {
            return response.results[0] && response.results[0].nodes[0] || null;
        });
    }
    /**
     * Update an edge content.
     * It's not possible to update the type of an edge.
     *
     * @param {any}      edgeId                       ID of the edge
     * @param {object}   edgeUpdate
     * @param {any}      edgeUpdate.data              Properties updates
     * @param {string[]} edgeUpdate.deletedProperties Properties to delete
     * @returns {Bluebird<LkEdge>} null if not found
     */
    $updateEdge(edgeId, edgeUpdate) {
        const sChanges = [];
        // set properties
        _.forEach(edgeUpdate.data, (value, key) => {
            sChanges.push('SET e.' + CypherUtils.encodeName(key) + ' = ' +
                CypherUtils.encodeValue(value));
        });
        // delete properties
        _.forEach(edgeUpdate.deletedProperties, key => {
            sChanges.push('REMOVE e.' + CypherUtils.encodeName(key));
        });
        const query = 'MATCH ()-[e]->() WHERE id(e)=' + edgeId + ' ' + sChanges.join(' ') + ' RETURN e';
        return this.connector.$doCypherQuery(query).then(response => {
            this._invalidateCaches();
            return response.results[0] && response.results[0].edges[0] || null;
        });
    }
    /**
     * Delete an edge.
     *
     * @param {any} edgeId ID of the edge
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteEdge(edgeId) {
        const query = 'MATCH ()-[e]->() WHERE id(e)=' + edgeId +
            ' WITH e, id(e) AS id DELETE e RETURN id';
        return this.connector.$doCypherQuery(query).then(response => {
            this._invalidateCaches();
            return Utils.hasValue(response.results[0]);
        });
    }
    /**
     * Delete a node and all edges connected to it.
     *
     * @param {any} nodeId ID of the node to delete
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteNode(nodeId) {
        const query = 'MATCH (n) WHERE id(n)=' + nodeId +
            ' WITH n, id(n) AS id OPTIONAL MATCH (n)-[r]-() DELETE n, r RETURN id';
        return this.connector.$doCypherQuery(query).then(response => {
            return Utils.hasValue(response.results[0]);
        });
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids             List of IDs to read
     * @param {string} [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByID(options) {
        const sMatch = Utils.noValue(options.alternativeId)
            ? `id(n) IN ${CypherUtils.encodeIDArray(options.ids)}`
            : `n.${CypherUtils.encodeName(options.alternativeId)} IN ` +
                CypherUtils.encodeValue(options.ids);
        const query = `MATCH (n) WHERE ${sMatch} RETURN n`;
        return this.connector.$doCypherQuery(query).then(response => {
            return _.flatMap(response.results, 'nodes');
        });
    }
    /**
     * Get the neighbors of a subset of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Max number of nodes in result
     * @param {string}   options.limitType        "id", "lowestDegree" or "highestDegree" to sort results before limiting
     * @param {string[]} [options.nodeCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge-type to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     */
    $getAdjacentNodes(nodeIds, options) {
        let sEdgeTypeFilter = '';
        let sMatchEdges = '';
        let sReadableCategories = '';
        let sOrder = '';
        if (options.limitType !== 'id') {
            // we have to match edges if we sort nodes by cardinality
            sMatchEdges = 'MATCH (nN)-[nE]-() WITH n, nN, count(nE) as degree ';
        }
        if (options.limitType === 'lowestDegree') {
            sOrder = 'ASC';
        }
        else if (options.limitType === 'highestDegree') {
            sOrder = 'DESC';
        }
        if (Utils.hasValue(options.nodeCategories)) {
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.nodeCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(category => 'nN:' + CypherUtils.encodeName(category));
            // if we can read nodes with no categories
            if (options.nodeCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                readableCategories.push('size(labels(nN)) = 0');
            }
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // Note this filter will not work anymore in the future
        // in conjunction with the use of variable binding, e.g.: ()-[e:TYPE1|:TYPE2]-()
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sIgnoreVisibles = '';
        if (Utils.hasValue(options.ignoredNodeIds)) {
            sIgnoreVisibles = `AND NOT (id(nN) IN ${CypherUtils.encodeIDArray(options.ignoredNodeIds)}) `;
        }
        // nN=neighborNode
        let expandQuery = `MATCH (n)-[${sEdgeTypeFilter}]-(nN) ` +
            `WHERE id(n) IN ${CypherUtils.encodeIDArray(nodeIds)} ` +
            sIgnoreVisibles +
            sReadableCategories +
            sMatchEdges +
            'RETURN nN ';
        if (options.limit > 0) {
            if (options.limitType !== 'id') {
                expandQuery += `ORDER BY degree ${sOrder} `;
            }
            expandQuery += `LIMIT ${options.limit}`;
        }
        // we get the neighbors
        return this.connector.$doCypherQuery(expandQuery).then(response => {
            const neighbors = _.flatMap(response.results, 'nodes');
            return _.uniqBy(neighbors, 'id');
        });
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds         IDs of the first set of nodes
     * @param {string[]} otherNodeIds    IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options) {
        const sNodesIds = CypherUtils.encodeIDArray(nodeIds);
        const sOtherNodeIds = CypherUtils.encodeIDArray(otherNodeIds);
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sReadableCategories = '';
        if (Utils.hasValue(options.nodeCategories)) {
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.nodeCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(category => 'a:' + CypherUtils.encodeName(category));
            // if we can read nodes with no categories
            if (options.nodeCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                readableCategories.push('size(labels(a)) = 0');
            }
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // The reason that variables are called 'a', 'b', 'e' is not casual
        // It's to hint to the planner to actually scan the list of nodes in `nodeIds` instead
        // of nodes in `otherNodeIds`. See #1462
        const edgeQuery = `MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
            `WHERE id(b) IN ${sNodesIds} AND id(a) IN ${sOtherNodeIds} ` +
            sReadableCategories +
            'RETURN DISTINCT e';
        return this.connector.$doCypherQuery(edgeQuery).then(response => {
            const edges = _.map(response.results, record => record.edges[0]);
            return edges;
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param {any[]} nodeIds IDs of the nodes
     * @returns {Bluebird<LkDigestItem[]>}
     */
    $getAdjacencyDigest(nodeIds) {
        const digestQuery = 'MATCH (node)-[e]-(n) ' +
            `WHERE ID(node) IN ${CypherUtils.encodeIDArray(nodeIds)} ` +
            'RETURN type(e), labels(n), count(DISTINCT n), count(DISTINCT e)';
        return this.connector.$doCypherQuery(digestQuery).then(response => {
            return _.map(response.results, result => ({
                edgeType: result.rows[0],
                nodeCategories: result.rows[1].sort(),
                nodes: result.rows[2],
                edges: result.rows[3]
            }));
        });
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param {any[]}    nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @param {boolean}  [options.discreteResults]    Whether to return the degree of each node
     * @returns {Bluebird<number | Map<string, number>>}
     */
    $getNodeDegree(nodeIds, options) {
        const sNodeIds = CypherUtils.encodeIDArray(nodeIds);
        let sReadableCategories = '';
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.readableCategories)) {
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.readableCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(category => 'n:' + CypherUtils.encodeName(category));
            // if we can read nodes with no categories
            if (options.readableCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                readableCategories.push('size(labels(n)) = 0');
            }
            sReadableCategories = `AND (${readableCategories.join(' OR ')}) `;
        }
        // Note this filter will not work anymore in the future
        // in conjunction with the use of variable binding, e.g.: ()-[e:TYPE1|:TYPE2]-()
        if (Utils.hasValue(options.readableTypes)) {
            sEdgeTypeFilter = options.readableTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        const combinedDegreeQuery = `MATCH (node)-[e${sEdgeTypeFilter}]-(n)
      WHERE id(node) IN ${sNodeIds}
      AND NOT id(n) IN ${sNodeIds}
      ${sReadableCategories}
      RETURN count(DISTINCT n)`;
        const discreteDegreeQuery = nodeId => `MATCH (node)-[e${sEdgeTypeFilter}]-(n)
      WHERE id(node) = ${nodeId}
      AND NOT id(n) = ${nodeId}
      ${sReadableCategories}
      RETURN ${nodeId} as id, count(DISTINCT n) as count`;
        let degreeQuery = combinedDegreeQuery;
        if (options.discreteResults) {
            degreeQuery = nodeIds.map(discreteDegreeQuery).join(' UNION ');
        }
        return this.connector.$doCypherQuery(degreeQuery).then(response => {
            if (options.discreteResults) {
                return response.results.reduce((degreeResult, result) => {
                    const [nodeId, degree] = result.rows;
                    return degreeResult.set('' + nodeId, degree);
                }, new Map());
            }
            return response.results[0].rows[0];
        });
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids             List of IDs to read
     * @param {string} [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkEdge[]>}
     */
    $getEdgesByID(options) {
        const sMatch = Utils.noValue(options.alternativeId)
            ? `id(e) IN ${CypherUtils.encodeIDArray(options.ids)}`
            : `e.${CypherUtils.encodeName(options.alternativeId)} IN ` +
                CypherUtils.encodeValue(options.ids);
        const query = `MATCH ()-[e]->() WHERE ${sMatch} RETURN e`;
        return this.connector.$doCypherQuery(query).then(response => {
            return _.flatMap(response.results, 'edges');
        });
    }
    /**
     * List all edgeTypes that exist in the graph database.
     *
     * @returns {Bluebird<string[]>}
     */
    $getEdgeTypes() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param {any}      nodeId                  ID of the node
     * @param {object}   options
     * @param {string[]} [options.readableTypes] Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<LkEdgeDigestItem[]>}
     */
    $getEdgeDigest(nodeId, options) {
        return Promise.resolve().then(() => {
            // if readableTypes is defined, we know we have to compute the edge digest only
            // towards these edge types
            if (Utils.hasValue(options.readableTypes)) {
                return options.readableTypes;
            }
            // Otherwise, we need to retrieve the whole list of edge types
            return Promise.resolve().then(() => {
                // We cache the list of edge types to avoid to retrieve it all the times
                if (Utils.noValue(this._allEdgeTypesCached)) {
                    return this.$getEdgeTypes().then(types => {
                        this._allEdgeTypesCached = types;
                    });
                }
            }).then(() => {
                return this._allEdgeTypesCached;
            });
        }).then(types => {
            if (types.length === 0) {
                return [];
            }
            const queryReturns = [];
            for (let i = 0; i < types.length; i++) {
                queryReturns.push(`size((n)-[:${CypherUtils.encodeName(types[i])}]-())`);
            }
            const query = `MATCH (n) WHERE id(n) = ${nodeId} RETURN ` + queryReturns.join(', ');
            return this.connector.$doCypherQuery(query).then(response => {
                let edgeDigest = _.map(_.zip(types, response.results[0].rows), digestEntry => {
                    return {
                        edgeType: digestEntry[0],
                        edges: digestEntry[1]
                    };
                });
                edgeDigest = _.filter(edgeDigest, digestEntry => digestEntry.edges > 0);
                return edgeDigest;
            });
        });
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * @param {any[]}  nodeIds            IDs of the node
     * @param {number} supernodeThreshold
     * @returns {Bluebird<Map<string, boolean>>}
     */
    $isSuperNode(nodeIds, supernodeThreshold) {
        const degreeQuery = nodeId => `MATCH (n) WHERE id(n) = ${nodeId} RETURN ${nodeId} as id, size((n)-[]-()) as count`;
        const superNodeQuery = nodeIds.map(degreeQuery).join(' UNION ');
        return this.connector.$doCypherQuery(superNodeQuery).then(response => {
            return response.results.reduce((superNodeResult, result) => {
                const [nodeId, degree] = result.rows;
                return superNodeResult.set('' + nodeId, degree >= supernodeThreshold);
            }, new Map());
        });
    }
    /**
     * Invalidate the following caches:
     * - List of edge types (used to compute the edge digest)
     *
     * @private
     */
    _invalidateCaches() {
        this._allEdgeTypesCached = null;
    }
    /**
     * Called at the end of the indexation phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterIndexation() {
        this._invalidateCaches();
        return Promise.resolve();
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        this._invalidateCaches();
        return Promise.resolve();
    }
}
module.exports = CypherDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwaGVyRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9jeXBoZXJEcml2ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkMsTUFBTSxFQUFDLGtCQUFrQixFQUFDLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFOUQsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUM3QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUN0RCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUVoRCxNQUFNLFlBQWEsU0FBUSxXQUFXO0lBQ3BDOzs7Ozs7T0FNRztJQUNILE1BQU0sQ0FBQyxLQUFLLEVBQUUsVUFBVTtRQUN0QixRQUFRLFVBQVUsRUFBRTtZQUNsQixLQUFLLGtCQUFrQixDQUFDLElBQUk7Z0JBQzFCLE1BQU0sRUFBRSxHQUFHLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNoQyxPQUFPLEVBQUUsQ0FBQztZQUVaLEtBQUssa0JBQWtCLENBQUMsUUFBUTtnQkFDOUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxPQUFPLFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFMUMsS0FBSyxrQkFBa0IsQ0FBQyxXQUFXO2dCQUNqQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUN6QyxPQUFPLFNBQVMsS0FBSyxJQUFJLENBQUM7WUFFNUIsS0FBSyxrQkFBa0IsQ0FBQyxnQkFBZ0I7Z0JBQ3RDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hDLE1BQU0sUUFBUSxHQUFHLEVBQUMsbUJBQW9CLEtBQUssQ0FBQyxDQUFDO2dCQUM3QyxNQUFNLFlBQVksR0FBRyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzdELE1BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7Z0JBQ3pELE9BQU8sR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLENBQUM7WUFFbEMsS0FBSyxrQkFBa0IsQ0FBQyxNQUFNO2dCQUM1QixPQUFPLFdBQVcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDeEM7Z0JBQ0UsT0FBTyxLQUFLLEdBQUcsRUFBRSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ2pDLE1BQU0sR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ25DLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDN0Q7UUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUNsQyxZQUFZLE1BQU0sbUJBQW1CLEVBQUUsRUFBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBQyxDQUM1RCxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxXQUFXLENBQUMsT0FBTztRQUNqQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUNsQyxnQ0FBZ0MsT0FBTyxDQUFDLE1BQU0sZ0JBQWdCLE9BQU8sQ0FBQyxNQUFNO3VCQUMzRCxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQzdFLEVBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUMsQ0FDckIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDaEIsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ2pDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxrQ0FBa0MsQ0FBQyxDQUFDO2FBQzdFO1lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDekIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLE9BQU87UUFDcEIsNEZBQTRGO1FBQzVGLGlGQUFpRjtRQUNqRix5REFBeUQ7UUFFekQsTUFBTSxLQUFLLEdBQUcsb0JBQW9CO1lBQ2hDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXBELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3BFLG1FQUFtRTtZQUNuRSxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsVUFBUyxNQUFNO2dCQUM3RCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsT0FBTztRQUNwQixNQUFNLEtBQUssR0FBRyw0QkFBNEI7WUFDeEMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFcEQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDcEUsb0VBQW9FO1lBQ3BFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxVQUFTLE1BQU07Z0JBQzdELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHFCQUFxQixDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQ2hDLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUVELGdDQUFnQztRQUNoQyxPQUFPO1lBQ0wsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDbkMsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDbkMsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQ3ZCLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0QztRQUVELHlCQUF5QjtRQUN6QixPQUFPO1lBQ0wsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDaEMsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7WUFDaEMsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILFNBQVMsQ0FBQyxPQUFPO1FBQ2YsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUMxQyxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsS0FBSyxDQUNyQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNoQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO2dCQUNyQixPQUFPLEtBQUssQ0FBQyxRQUFRLENBQ25CLFFBQVEsQ0FBQyxPQUFPLEVBQ2hCLE9BQU8sQ0FBQyxVQUFTLE1BQU07b0JBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDaEUsQ0FBQyxDQUFDLENBQ0gsQ0FBQzthQUNIO2lCQUFNO2dCQUNMLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FDbkIsUUFBUSxDQUFDLE9BQU8sRUFDaEIsT0FBTyxDQUFDLFVBQVMsTUFBTTtvQkFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQ0gsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRLENBQUMsS0FBSztRQUNaLE9BQU8sV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixPQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUFVO1FBQzVCLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUVwQixpQkFBaUI7UUFDakIsSUFBSSxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDekMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQ3JELFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5RDtRQUVELG9CQUFvQjtRQUNwQixJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzNDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQzFELFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5RDtRQUVELGlCQUFpQjtRQUNqQixDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDeEMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLO2dCQUMxRCxXQUFXLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7UUFFSCxvQkFBb0I7UUFDcEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLEVBQUU7WUFDNUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxLQUFLLEdBQUcsd0JBQXdCLEdBQUcsTUFBTSxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFdBQVcsQ0FBQztRQUN6RixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMxRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFdBQVcsQ0FBQyxNQUFNLEVBQUUsVUFBVTtRQUM1QixNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFFcEIsaUJBQWlCO1FBQ2pCLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUN4QyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUs7Z0JBQzFELFdBQVcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztRQUVILG9CQUFvQjtRQUNwQixDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsRUFBRTtZQUM1QyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLEtBQUssR0FBRywrQkFBK0IsR0FBRyxNQUFNLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO1FBQ2hHLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3pCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUM7UUFDckUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxXQUFXLENBQUMsTUFBTTtRQUNoQixNQUFNLEtBQUssR0FBRywrQkFBK0IsR0FBRyxNQUFNO1lBQ3BELHlDQUF5QyxDQUFDO1FBQzVDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3pCLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxXQUFXLENBQUMsTUFBTTtRQUNoQixNQUFNLEtBQUssR0FBRyx3QkFBd0IsR0FBRyxNQUFNO1lBQzdDLHNFQUFzRSxDQUFDO1FBQ3pFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFELE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQixNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7WUFDakQsQ0FBQyxDQUFDLFlBQVksV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDdEQsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU07Z0JBQzFELFdBQVcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXZDLE1BQU0sS0FBSyxHQUFHLG1CQUFtQixNQUFNLFdBQVcsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMxRCxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILGlCQUFpQixDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQ2hDLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztRQUN6QixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDckIsSUFBSSxtQkFBbUIsR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDOUIseURBQXlEO1lBQ3pELFdBQVcsR0FBRyxxREFBcUQsQ0FBQztTQUNyRTtRQUVELElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxjQUFjLEVBQUU7WUFDeEMsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNoQjthQUFNLElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxlQUFlLEVBQUU7WUFDaEQsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUNqQjtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUMsMERBQTBEO1lBQzFELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsNEJBQTRCLENBQUM7aUJBQ2hELEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFN0QsMENBQTBDO1lBQzFDLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0JBQzFFLGtCQUFrQixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2FBQ2pEO1lBRUQsbUJBQW1CLEdBQUcsUUFBUSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNuRTtRQUVELHVEQUF1RDtRQUN2RCxnRkFBZ0Y7UUFDaEYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNyQyxlQUFlLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQ3JDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQzNDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2I7UUFFRCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUMxQyxlQUFlLEdBQUcsc0JBQXNCLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7U0FDL0Y7UUFFRCxrQkFBa0I7UUFDbEIsSUFBSSxXQUFXLEdBQUcsY0FBYyxlQUFlLFNBQVM7WUFDdEQsa0JBQWtCLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUc7WUFDdkQsZUFBZTtZQUNmLG1CQUFtQjtZQUNuQixXQUFXO1lBQ1gsWUFBWSxDQUFDO1FBRWYsSUFBSSxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtZQUNyQixJQUFJLE9BQU8sQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUM5QixXQUFXLElBQUksbUJBQW1CLE1BQU0sR0FBRyxDQUFDO2FBQzdDO1lBRUQsV0FBVyxJQUFJLFNBQVMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3pDO1FBRUQsdUJBQXVCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hFLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztZQUN2RCxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGVBQWUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE9BQU87UUFDNUMsTUFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRCxNQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzlELElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztRQUN6QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3JDLGVBQWUsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FDckMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FDM0MsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDYjtRQUVELElBQUksbUJBQW1CLEdBQUcsRUFBRSxDQUFDO1FBQzdCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUMsMERBQTBEO1lBQzFELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsNEJBQTRCLENBQUM7aUJBQ2hELEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFNUQsMENBQTBDO1lBQzFDLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0JBQzFFLGtCQUFrQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2FBQ2hEO1lBRUQsbUJBQW1CLEdBQUcsUUFBUSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNuRTtRQUVELG1FQUFtRTtRQUNuRSxzRkFBc0Y7UUFDdEYsd0NBQXdDO1FBRXhDLE1BQU0sU0FBUyxHQUFHLGVBQWUsZUFBZSxRQUFRO1lBQ3RELGtCQUFrQixTQUFTLGlCQUFpQixhQUFhLEdBQUc7WUFDNUQsbUJBQW1CO1lBQ25CLG1CQUFtQixDQUFDO1FBRXRCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzlELE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqRSxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsbUJBQW1CLENBQUMsT0FBTztRQUN6QixNQUFNLFdBQVcsR0FBRyx1QkFBdUI7WUFDekMscUJBQXFCLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUc7WUFDMUQsaUVBQWlFLENBQUM7UUFFcEUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDaEUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN4QyxRQUFRLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3hCLGNBQWMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtnQkFDckMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNyQixLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDdEIsQ0FBQyxDQUFDLENBQUM7UUFDTixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxjQUFjLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDN0IsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNwRCxJQUFJLG1CQUFtQixHQUFHLEVBQUUsQ0FBQztRQUM3QixJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFFekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1lBQzlDLDBEQUEwRDtZQUMxRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUM1RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsNEJBQTRCLENBQUM7aUJBQ2hELEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFNUQsMENBQTBDO1lBQzFDLElBQUksT0FBTyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsNEJBQTRCLENBQUMsRUFBRTtnQkFDOUUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7YUFDaEQ7WUFFRCxtQkFBbUIsR0FBRyxRQUFRLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1NBQ25FO1FBRUQsdURBQXVEO1FBQ3ZELGdGQUFnRjtRQUNoRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3pDLGVBQWUsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FDekMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FDM0MsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDYjtRQUVELE1BQU0sbUJBQW1CLEdBQUcsa0JBQWtCLGVBQWU7MEJBQ3ZDLFFBQVE7eUJBQ1QsUUFBUTtRQUN6QixtQkFBbUI7K0JBQ0ksQ0FBQztRQUU1QixNQUFNLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsa0JBQWtCLGVBQWU7eUJBQ2xELE1BQU07d0JBQ1AsTUFBTTtRQUN0QixtQkFBbUI7ZUFDWixNQUFNLG9DQUFvQyxDQUFDO1FBRXRELElBQUksV0FBVyxHQUFHLG1CQUFtQixDQUFDO1FBRXRDLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtZQUMzQixXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNoRTtRQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hFLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtnQkFDM0IsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDdEQsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNyQyxPQUFPLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDL0MsQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNmO1lBQ0QsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGFBQWEsQ0FBQyxPQUFPO1FBQ25CLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztZQUNqRCxDQUFDLENBQUMsWUFBWSxXQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0RCxDQUFDLENBQUMsS0FBSyxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTTtnQkFDMUQsV0FBVyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFdkMsTUFBTSxLQUFLLEdBQUcsMEJBQTBCLE1BQU0sV0FBVyxDQUFDO1FBRTFELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzFELE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxhQUFhO1FBQ1gsT0FBTyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsTUFBTSxFQUFFLE9BQU87UUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQywrRUFBK0U7WUFDL0UsMkJBQTJCO1lBQzNCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3pDLE9BQU8sT0FBTyxDQUFDLGFBQWEsQ0FBQzthQUM5QjtZQUVELDhEQUE4RDtZQUM5RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyx3RUFBd0U7Z0JBQ3hFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsRUFBRTtvQkFDM0MsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUN2QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxDQUFDLENBQUMsQ0FBQztpQkFDSjtZQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUN0QixPQUFPLEVBQUUsQ0FBQzthQUNYO1lBRUQsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNyQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDMUU7WUFFRCxNQUFNLEtBQUssR0FBRywyQkFBMkIsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVwRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDMUQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUMzRSxPQUFPO3dCQUNMLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO3dCQUN4QixLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztxQkFDdEIsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztnQkFFSCxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUV4RSxPQUFPLFVBQVUsQ0FBQztZQUNwQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsWUFBWSxDQUFDLE9BQU8sRUFBRSxrQkFBa0I7UUFDdEMsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FDM0IsMkJBQTJCLE1BQU0sV0FBVyxNQUFNLGtDQUFrQyxDQUFDO1FBRXZGLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ25FLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ3pELE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDckMsT0FBTyxlQUFlLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxNQUFNLEVBQUUsTUFBTSxJQUFJLGtCQUFrQixDQUFDLENBQUM7WUFDeEUsQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGlCQUFpQjtRQUNmLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxrQkFBa0I7UUFDaEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDM0IsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUMifQ==