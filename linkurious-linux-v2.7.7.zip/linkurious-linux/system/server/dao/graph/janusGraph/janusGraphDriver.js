/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const through = require('through');
// services
const LKE = require('../../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
// locals
const GremlinDriver = require('../gremlinDriver');
/**
 * To build a composite index in JanusGraph (for Alternative IDs):
 * > mgmt = graph.openManagement()
 * > name = mgmt.makePropertyKey('name').dataType(String.class).make()
 * > mgmt.buildIndex('byNameComposite', Vertex.class).addKey(name).buildCompositeIndex()
 *
 * > altEdgeID = mgmt.makePropertyKey('altEdgeID').dataType(String.class).make()
 * > mgmt.buildIndex('byAltEdgeIDComposite', Edge.class).addKey(altEdgeID).buildCompositeIndex()
 *
 * To build a mixed index in JanusGraph (for Search):
 * > title = mgmt.makePropertyKey('title').dataType(String.class).make()
 * > mgmt.buildIndex('byTitleAndNameMixed', Vertex.class).addKey(title, Mapping.TEXTSTRING.asParameter()).addKey(name, Mapping.TEXTSTRING.asParameter()).buildMixedIndex("search")
 *
 * To commit these changes:
 * > mgmt.commit()
 * > graph.tx().commit()
 */
class JanusGraphDriver extends GremlinDriver {
    /**
     * @returns {GremlinOptions}
     */
    get $gremlinOptions() {
        return {
            disableTypeChecks: false,
            useDef: false,
            canFoldAndDedupById: true
        };
    }
    /**
     * Check if the given edge ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkEdgeId(key, id) {
        Utils.check.string(key, id, true, true);
    }
    /**
     * Check if the given node ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkNodeId(key, id) {
        Utils.tryParsePosInt(id, key);
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        // We manually add the default label for node with no category to the schema
        const q = `
      @groovy.transform.TypeChecked(groovy.transform.TypeCheckingMode.SKIP)
      def wrap() {
        def r = [:];
        def mgmt = graph.openManagement();

        r.edgeTypes = [];
        mgmt.getRelationTypes(EdgeLabel).each({ r.edgeTypes.add(it.name()); });

        r.nodeCategories = [];
        mgmt.getVertexLabels().each({ r.nodeCategories.add(it.name()); });
        
        if (!r.nodeCategories.contains('vertex')) {
          r.nodeCategories.add('vertex');
        }

        r.nodeProperties = [];
        mgmt.getRelationTypes(PropertyKey).each({ r.nodeProperties.add(it.name()); });

        r.edgeProperties = r.nodeProperties;

        mgmt.commit(); graph.tx().commit();

        [r];
      }

      wrap();
    `;
        return this.connector.$doGremlinQuery(q).get('0');
    }
    /**
     * @param {string} type                'node' or 'edge'
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<any>>}
     */
    $getStream(type, options) {
        const key = type === 'node' ? 'V' : 'E';
        // the range method in janusgraph does not accept negative values
        // we are using Long.MAX_VALUE as the highRange instead of -1
        const sLimit = options.offset ? '.range(lowRange, Long.MAX_VALUE)' : '';
        const query = `g.${key}()${sLimit}`;
        const { offset = 0, chunkSize = 1000 } = options;
        const bindings = {
            lowRange: offset
        };
        return this.connector.$streamGremlinQuery(query, {
            bindings: bindings,
            batchSize: chunkSize,
            useDef: false
        }).then(readableSteam => {
            const parseItem = (type === 'node' ? this.rawNodeToLkNode : this.rawEdgeToLkEdge).bind(this);
            return Utils.safePipe(readableSteam, through(function (data) { this.push(parseItem(data)); }));
        });
    }
    /**
     * Resolve if alternative IDs are not in use or if there exist indices for the alternative IDs.
     *
     * @returns {Bluebird<void>}
     */
    $checkAlternativeIdsIndices() {
        const altNodeId = this.getGraphOption('alternativeNodeId');
        const altEdgeId = this.getGraphOption('alternativeEdgeId');
        const indexExistsQuery = (type, alternativeId) => `
      def mgmt = graph.openManagement();

      for (index in mgmt.getGraphIndexes(${type}.class)) {
        if (index.isCompositeIndex() &&
          index.getFieldKeys()[0] &&
          index.getFieldKeys()[0].name() == '${alternativeId}'
        ) {
          mgmt.commit(); graph.tx().commit();
          return true;
        }
      }

      mgmt.commit(); graph.tx().commit();

      return false;
    `;
        return Promise.resolve().then(() => {
            if (Utils.hasValue(altNodeId)) {
                return this.connector.$doGremlinQuery(indexExistsQuery('Vertex', altNodeId)).get('0')
                    .then(r => {
                    if (!r && !this.getGraphOption('disableIndexExistCheck')) {
                        return Errors.business('source_action_needed', `No index found in JanusGraph for node property "${altNodeId}".`, true);
                    }
                });
            }
        }).then(() => {
            if (Utils.hasValue(altEdgeId)) {
                return this.connector.$doGremlinQuery(indexExistsQuery('Edge', altEdgeId)).get('0')
                    .then(r => {
                    if (!r && !this.getGraphOption('disableIndexExistCheck')) {
                        return Errors.business('source_action_needed', `No index found in JanusGraph for edge property "${altEdgeId}".`, true);
                    }
                });
            }
        });
    }
}
module.exports = JanusGraphDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaERyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvamFudXNHcmFwaC9qYW51c0dyYXBoRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFFbkMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBRWxEOzs7Ozs7Ozs7Ozs7Ozs7O0dBZ0JHO0FBQ0gsTUFBTSxnQkFBaUIsU0FBUSxhQUFhO0lBQzFDOztPQUVHO0lBQ0gsSUFBSSxlQUFlO1FBQ2pCLE9BQU87WUFDTCxpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsbUJBQW1CLEVBQUUsSUFBSTtTQUMxQixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRTtRQUNsQixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGdCQUFnQjtRQUNkLDRFQUE0RTtRQUM1RSxNQUFNLENBQUMsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBMkJULENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsVUFBVSxDQUFDLElBQUksRUFBRSxPQUFPO1FBQ3RCLE1BQU0sR0FBRyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ3hDLGlFQUFpRTtRQUNqRSw2REFBNkQ7UUFDN0QsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN4RSxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxNQUFNLEVBQUUsQ0FBQztRQUNwQyxNQUFNLEVBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsSUFBSSxFQUFDLEdBQUcsT0FBTyxDQUFDO1FBRS9DLE1BQU0sUUFBUSxHQUFHO1lBQ2YsUUFBUSxFQUFFLE1BQU07U0FDakIsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUU7WUFDL0MsUUFBUSxFQUFFLFFBQVE7WUFDbEIsU0FBUyxFQUFFLFNBQVM7WUFDcEIsTUFBTSxFQUFFLEtBQUs7U0FDZCxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3RCLE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM3RixPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUNqQyxPQUFPLENBQUMsVUFBUyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILDJCQUEyQjtRQUN6QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDM0QsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBRTNELE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLEVBQUUsQ0FBQzs7OzJDQUdYLElBQUk7OzsrQ0FHQSxhQUFhOzs7Ozs7Ozs7O0tBVXZELENBQUM7UUFFRixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDN0IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO3FCQUNsRixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ1IsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsd0JBQXdCLENBQUMsRUFBRTt3QkFDeEQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUMzQyxtREFBbUQsU0FBUyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQzNFO2dCQUNILENBQUMsQ0FBQyxDQUFDO2FBQ047UUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM3QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7cUJBQ2hGLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDUixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFO3dCQUN4RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQzNDLG1EQUFtRCxTQUFTLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDM0U7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7YUFDTjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyJ9