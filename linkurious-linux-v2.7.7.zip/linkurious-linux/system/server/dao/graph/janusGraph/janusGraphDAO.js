/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// locals
const GraphDAO = require('../graphDAO');
const JanusGraphConnector = require('../../connector/janusGraphConnector');
const JanusGraphDriver = require('./janusGraphDriver');
class JanusGraphDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url                 JanusGraph url
     * @param {string}  [options.configurationPath] Path to the Gremlin configuration file
     * @param {object}  [options.configuration]     JanusGraph graph configuration
     * @param {string}  [options.user]              JanusGraph user
     * @param {string}  [options.password]          JanusGraph password
     * @param {boolean} [options.allowSelfSigned]   Whether to allow self-signed certificates
     */
    constructor(options) {
        super('janusGraph', ['url'], [
            'url',
            'graphAlias',
            'traversalSourceAlias',
            'configurationPath',
            'configuration',
            'user',
            'password',
            'allowSelfSigned',
            'disableIndexExistCheck',
            'sessionPool',
            'maxStale' // experimental
        ], options, {
            edgeProperties: true,
            immutableNodeCategories: true,
            minNodeCategories: 1,
            maxNodeCategories: 1,
            serializeArrayProperties: true,
            canCount: false,
            alerts: true,
            alternativeIds: true,
            emptyNodes: true,
            dialects: ['gremlin'],
            canStream: true,
            detectSupernodes: true,
            canDryRun: false
        }, JanusGraphConnector, [
            { version: '0.2.0', driver: '[latest]' },
            { version: '0.1.1', driver: JanusGraphDriver }
        ]);
    }
}
module.exports = JanusGraphDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaERBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvamFudXNHcmFwaC9qYW51c0dyYXBoREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQzNFLE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFFdkQsTUFBTSxhQUFjLFNBQVEsUUFBUTtJQUVsQzs7Ozs7Ozs7T0FRRztJQUNILFlBQVksT0FBTztRQUNqQixLQUFLLENBQUMsWUFBWSxFQUNoQixDQUFDLEtBQUssQ0FBQyxFQUNQO1lBQ0UsS0FBSztZQUNMLFlBQVk7WUFDWixzQkFBc0I7WUFDdEIsbUJBQW1CO1lBQ25CLGVBQWU7WUFDZixNQUFNO1lBQ04sVUFBVTtZQUNWLGlCQUFpQjtZQUNqQix3QkFBd0I7WUFDeEIsYUFBYTtZQUNiLFVBQVUsQ0FBQyxlQUFlO1NBQzNCLEVBQ0QsT0FBTyxFQUNQO1lBQ0UsY0FBYyxFQUFFLElBQUk7WUFDcEIsdUJBQXVCLEVBQUUsSUFBSTtZQUM3QixpQkFBaUIsRUFBRSxDQUFDO1lBQ3BCLGlCQUFpQixFQUFFLENBQUM7WUFDcEIsd0JBQXdCLEVBQUUsSUFBSTtZQUM5QixRQUFRLEVBQUUsS0FBSztZQUNmLE1BQU0sRUFBRSxJQUFJO1lBQ1osY0FBYyxFQUFFLElBQUk7WUFDcEIsVUFBVSxFQUFFLElBQUk7WUFDaEIsUUFBUSxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ3JCLFNBQVMsRUFBRSxJQUFJO1lBQ2YsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQixFQUNELG1CQUFtQixFQUNuQjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsZ0JBQWdCLEVBQUM7U0FDN0MsQ0FDRixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMifQ==