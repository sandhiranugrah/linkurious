/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-02-16.
 */
'use strict';
// locals
const JanusGraphDriver = require('../janusGraph/janusGraphDriver');
class JanusGraphForComposeDriver extends JanusGraphDriver {
    /**
     * @returns {GremlinOptions}
     */
    get $gremlinOptions() {
        return {
            disableTypeChecks: true,
            useDef: true,
            canFoldAndDedupById: true
        };
    }
}
module.exports = JanusGraphForComposeDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiamFudXNHcmFwaEZvckNvbXBvc2VEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2phbnVzR3JhcGhGb3JDb21wb3NlL2phbnVzR3JhcGhGb3JDb21wb3NlRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBQ2IsU0FBUztBQUNULE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7QUFFbkUsTUFBTSwwQkFBMkIsU0FBUSxnQkFBZ0I7SUFDdkQ7O09BRUc7SUFDSCxJQUFJLGVBQWU7UUFDakIsT0FBTztZQUNMLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsTUFBTSxFQUFFLElBQUk7WUFDWixtQkFBbUIsRUFBRSxJQUFJO1NBQzFCLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFDRCxNQUFNLENBQUMsT0FBTyxHQUFHLDBCQUEwQixDQUFDIn0=