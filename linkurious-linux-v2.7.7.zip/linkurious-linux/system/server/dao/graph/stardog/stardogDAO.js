/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
// locals
const GraphDAO = require('../graphDAO');
const StardogConnector = require('../../connector/stardogConnector');
const StardogDriver = require('./stardogDriver');
class StardogDAO extends GraphDAO {
    /**
     * User can choose the id of a new node by setting `options.idPropertyName` if defined.
     * Updating the id is currently not supported since it would break the indexation.
     *
     * @param {object}  options
     * @param {string}  options.url                               Stardog url
     * @param {string}  options.repository                        Stardog repository name
     * @param {string}  [options.user]                            Stardog user
     * @param {string}  [options.password]                        Stardog password
     * @param {string}  [options.namespace="http://linkurio.us/"] Default namespace
     * @param {string}  [options.categoryPredicate="rdf:type"]    Predicate that appears in category statements
     * @param {string}  [options.idPropertyName]                  Property name used to show the id in its short form
     * @param {boolean} [options.allowSelfSigned]                 Whether to allow self-signed certificates
     */
    constructor(options) {
        super('stardog', ['url', 'repository'], ['url', 'repository', 'user', 'password', 'namespace', 'categoryPredicate',
            'idPropertyName', 'allowSelfSigned', 'reasoning'], options, {
            immutableNodeCategories: false,
            minNodeCategories: 0,
            maxNodeCategories: undefined,
            serializeArrayProperties: true,
            edgeProperties: false,
            alerts: false,
            canCount: false,
            alternativeIds: false,
            emptyNodes: false,
            dialects: ['sparql'],
            canStream: false,
            detectSupernodes: true,
            canDryRun: false
        }, StardogConnector, [
            { version: '5.0.3', driver: '[latest]' },
            { version: '5.0.0', driver: StardogDriver }
        ]);
    }
}
module.exports = StardogDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhcmRvZ0RBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvc3RhcmRvZy9zdGFyZG9nREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0FBQ3JFLE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBRWpELE1BQU0sVUFBVyxTQUFRLFFBQVE7SUFFL0I7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILFlBQVksT0FBTztRQUNqQixLQUFLLENBQUMsU0FBUyxFQUNiLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUNyQixDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsbUJBQW1CO1lBQ3hFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLFdBQVcsQ0FBQyxFQUNuRCxPQUFPLEVBQ1A7WUFDRSx1QkFBdUIsRUFBRSxLQUFLO1lBQzlCLGlCQUFpQixFQUFFLENBQUM7WUFDcEIsaUJBQWlCLEVBQUUsU0FBUztZQUM1Qix3QkFBd0IsRUFBRSxJQUFJO1lBQzlCLGNBQWMsRUFBRSxLQUFLO1lBQ3JCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsUUFBUSxFQUFFLEtBQUs7WUFDZixjQUFjLEVBQUUsS0FBSztZQUNyQixVQUFVLEVBQUUsS0FBSztZQUNqQixRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDcEIsU0FBUyxFQUFFLEtBQUs7WUFDaEIsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixTQUFTLEVBQUUsS0FBSztTQUNqQixFQUNELGdCQUFnQixFQUNoQjtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFDO1NBQzFDLENBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDIn0=