/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
'use strict';
// locals
const SparqlDriver = require('../sparqlDriver');
class StardogDriver extends SparqlDriver {
    /**
     * @param {SparqlConnector} connector     Connector used by the DAO
     * @param {any}             graphOptions  GraphDAO options
     * @param {any}             connectorData Data from the connector
     * @param {GraphFeatures}   graphFeatures Features of the Graph DAO
     */
    constructor(connector, graphOptions, connectorData, graphFeatures) {
        super(connector, graphOptions, connectorData, graphFeatures, {
            supportBlankNodeLabels: true,
            implementGetStatements: false,
            supportPropertyPaths: true
        });
    }
}
module.exports = StardogDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhcmRvZ0RyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvc3RhcmRvZy9zdGFyZG9nRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBRWhELE1BQU0sYUFBYyxTQUFRLFlBQVk7SUFFdEM7Ozs7O09BS0c7SUFDSCxZQUFZLFNBQVMsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWE7UUFDL0QsS0FBSyxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRTtZQUMzRCxzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLHNCQUFzQixFQUFFLEtBQUs7WUFDN0Isb0JBQW9CLEVBQUUsSUFBSTtTQUMzQixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyJ9