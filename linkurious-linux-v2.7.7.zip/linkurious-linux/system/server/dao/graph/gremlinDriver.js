/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // abstract methods
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const through = require('through');
const { InputSerialization, TemplateDataValue } = require('linkurious-shared/umd');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
// locals
const GraphDriver = require('./graphDriver');
const GremlinUtils = require('../utils/gremlinUtils');
const GET_STREAM_TIMEOUT = 60 * 60 * 1000; // 1 hour
class GremlinDriver extends GraphDriver {
    /**
     * GremlinOptions
     *
     * @typedef {Object} GremlinOptions
     * @property {boolean} useDef              Whether to use def keyword to declare session variables
     * @property {boolean} disableTypeChecks   Whether type checks need to be disabled
     * @property {boolean} canFoldAndDedupById Whether the gremlin engine can dedup the results of a fold step by id
     */
    /**
     * @returns {GremlinOptions}
     */
    get $gremlinOptions() {
        return Utils.NOT_IMPLEMENTED();
    }
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param {TemplateDataValue}  value
     * @param {InputSerialization} serializer
     * @returns {string}
     */
    $quote(value, serializer) {
        switch (serializer) {
            case InputSerialization.NODE:
                const id = value + '';
                this.$checkNodeId('nodeId', id);
                return GremlinUtils.quote(id);
            case InputSerialization.NODE_SET:
                _.forEach(value, v => this.$checkNodeId('nodeId', v));
                return GremlinUtils.quote(value);
            case InputSerialization.NATIVE_DATE:
            case InputSerialization.NATIVE_DATE_TIME:
            case InputSerialization.STRING:
                return GremlinUtils.quote(value);
            default:
                return value + '';
        }
    }
    /**
     * Encode a raw Node ID in an ID usable in an LkNode.
     *
     * @param {any} rawId
     * @returns {string}
     */
    $encodeNodeId(rawId) {
        return `${rawId}`;
    }
    /**
     * Encode a raw Edge ID in an ID usable in an LkEdge.
     *
     * @param {any} rawId
     * @returns {string}
     */
    $encodeEdgeId(rawId) {
        return `${rawId}`;
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return this.$checkAlternativeIdsIndices();
    }
    /**
     * Resolve if alternative IDs are not in use or if there exist indices for the alternative IDs.
     *
     * @returns {Bluebird<void>}
     */
    $checkAlternativeIdsIndices() {
        return Promise.resolve();
    }
    /**
     * Get a stream of all nodes.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkNode>>}
     */
    $getNodeStream(options) {
        return this.$getStream('node', options);
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param {object}   options
     * @param {string[]} options.ids             List of IDs to read
     * @param {string}   [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByID(options) {
        const query = Utils.noValue(options.alternativeId)
            ? 'g.V().hasId(within(nodeIds))'
            : 'g.V().has(alternativeId, within(nodeIds))';
        const bindings = {
            nodeIds: options.ids,
            alternativeId: options.alternativeId
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(results => {
            return results.map(rawNode => this.rawNodeToLkNode(rawNode));
        });
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param {object}   options
     * @param {string[]} options.ids             List of IDs to read
     * @param {string}   [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkEdge[]>}
     */
    $getEdgesByID(options) {
        const query = Utils.noValue(options.alternativeId)
            ? 'g.E(edgeIds)'
            : 'g.E().has(alternativeId, within(edgeIds))';
        const bindings = {
            edgeIds: options.ids,
            alternativeId: options.alternativeId
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(results => {
            return results.map(rawEdge => this.rawEdgeToLkEdge(rawEdge));
        });
    }
    /**
     * Get the neighbors of a subset of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Max number of nodes in result
     * @param {string}   options.limitType        "id", "lowestDegree" or "highestDegree" to sort results before limiting
     * @param {string[]} [options.nodeCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge-type to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     */
    $getAdjacentNodes(nodeIds, options) {
        let sAdjacentNodes = '.both()';
        if (Utils.hasValue(options.edgeTypes)) {
            sAdjacentNodes = '.bothE().has(label, within(types)).otherV()';
        }
        let sNodeCategoryFilter = '';
        if (Utils.hasValue(options.nodeCategories)) {
            sNodeCategoryFilter = '.has(label, within(categories))';
        }
        let sOrder = '';
        if (options.limitType !== 'id' && options.limit) {
            const order = options.limitType === 'lowestDegree' ? 'incr' : 'decr';
            sOrder = `.order().by(bothE().count(), ${order})`;
        }
        let sLimit = '';
        if (options.limit) {
            sLimit = '.limit(expandThreshold)';
        }
        const query = `g.V().has(id, within(nodeIds))
      ${sAdjacentNodes}${sNodeCategoryFilter}
      .has(id, without(ignoredNodeIds))${sOrder}${sLimit}
      .dedup().by(id)`;
        const bindings = {
            nodeIds: nodeIds,
            ignoredNodeIds: options.ignoredNodeIds,
            categories: options.nodeCategories,
            types: options.edgeTypes,
            expandThreshold: options.limit
        };
        const toLkNode = this.rawNodeToLkNode.bind(this);
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).map(toLkNode);
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param {string[]} nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @param {boolean}  [options.discreteResults]    Whether to return the degree of each node
     * @returns {Bluebird<number | Map<string, number>>}
     */
    $getNodeDegree(nodeIds, options) {
        return /**@type {Bluebird<number | Map<string, number>>}*/ (options.discreteResults
            ? this.$getNodesDiscreteDegree(nodeIds, options)
            : this.$getNodesCombinedDegree(nodeIds, options));
    }
    /**
     * Return a map indexed by id populated with the degree of each node.
     *
     * @param {string[]} nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<Map<string, number>>}
     */
    $getNodesDiscreteDegree(nodeIds, options) {
        let nodeCategoryFilter = '';
        let edgeTypeFilter = '';
        if (options.readableCategories) {
            nodeCategoryFilter = '.has(label, within(readableCategories))';
        }
        if (options.readableTypes) {
            edgeTypeFilter = '.has(label, within(readableTypes))';
        }
        const query = `g.V().hasId(within(nodeIds))
      .project('id', 'degree')
      .by(id)
      .by(__.as('self').bothE()${edgeTypeFilter}
        .otherV()${nodeCategoryFilter}
        .where(neq('self'))
        .dedup().by(id)
        .count())`;
        const bindings = {
            nodeIds: nodeIds,
            readableCategories: options.readableCategories,
            readableTypes: options.readableTypes
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(result => {
            const nodeDegreeResult = new Map();
            _.forEach(result, ({ id, degree }) => {
                nodeDegreeResult.set(this.$encodeNodeId(id), degree);
            });
            return nodeDegreeResult;
        });
    }
    /**
     * Return the degree of the specified node if `nodeIds` has cardinality 1.
     * If multiple `nodeIds` are specified, return the cardinality of the intersection
     * of the neighbors of the nodes (not including the nodes in input themselves).
     *
     * @param {string[]} nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<number>}
     */
    $getNodesCombinedDegree(nodeIds, options) {
        let edgeTypeFilter = '';
        let nodeCategoryFilter = '';
        if (options.readableTypes) {
            edgeTypeFilter = '.has(label, within(readableTypes))';
        }
        if (options.readableCategories) {
            nodeCategoryFilter = '.has(label, within(readableCategories))';
        }
        const query = `g.V().hasId(within(nodeIds))
      .bothE()${edgeTypeFilter}
      .otherV()${nodeCategoryFilter}
      .where(has(id, without(nodeIds)))
      .dedup()
      .count()`;
        const bindings = {
            nodeIds: nodeIds,
            readableTypes: options.readableTypes,
            readableCategories: options.readableCategories
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(results => results[0]);
    }
    /**
     * Build a property step for each property in data.
     *
     * @param {object} data
     * @returns {string}
     * @private
     */
    _propertyStep(data) {
        return _.map(data, (value, key) => `.property(${GremlinUtils.quote(key)}, ${GremlinUtils.quote(value)})`).join('');
    }
    /**
     * Create a node.
     *
     * @param {LkNodeAttributes} newNode
     * @returns {Bluebird<LkNode>}
     */
    $createNode(newNode) {
        const query = 'g.addV(nodeCategory)' + this._propertyStep(newNode.data);
        const bindings = {
            nodeCategory: newNode.categories[0]
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings, caching: 'phantom' })
            .then(createdNodes => {
            if (!createdNodes.length) {
                return null;
            }
            return this.rawNodeToLkNode(createdNodes[0]);
        });
    }
    /**
     * Update the properties and categories of a node.
     * Check if the node exists and fail if it doesn't.
     *
     * @param {string}   nodeId                       ID of the node to update
     * @param {object}   nodeUpdate
     * @param {any}      nodeUpdate.data              Properties to update
     * @param {string[]} nodeUpdate.deletedProperties Properties to delete
     * @param {string[]} nodeUpdate.addedCategories   Categories to add
     * @param {string[]} nodeUpdate.deletedCategories Categories to delete
     * @returns {Bluebird<LkNode>} null if not found
     */
    $updateNode(nodeId, nodeUpdate) {
        return /**@type {Bluebird<LkNode>}*/ (this._updateItem(nodeId, 'node', nodeUpdate));
    }
    /**
     * Delete a node and all edges connected to it.
     *
     * @param {string} nodeId ID of the node to delete
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteNode(nodeId) {
        const query = 'g.V(itemId).store(\'d\').by(id).drop().cap(\'d\')';
        const bindings = {
            itemId: nodeId
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(deletedIds => {
            return deletedIds.length > 0;
        });
    }
    /**
     * Get a stream of all edges.
     *
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<LkEdge>>}
     */
    $getEdgeStream(options) {
        return this.$getStream('edge', options);
    }
    /**
     * @param {string} type                'node' or 'edge'
     * @param {object} options
     * @param {number} [options.chunkSize]
     * @param {number} [options.offset=0]
     * @returns {Bluebird<Readable<any>>}
     */
    $getStream(type, options) {
        const key = type === 'node' ? 'V' : 'E';
        // using -1 as highRange indicates that there is no upper limit
        // http://tinkerpop.apache.org/docs/current/reference/#range-step
        const sLimit = options.offset ? '.range(lowRange, -1)' : '';
        const query = `g.${key}()${sLimit}`;
        const { offset = 0, chunkSize = 1000 } = options;
        const bindings = {
            lowRange: offset
        };
        let timeout;
        // TODO #1416 deprecating gremlinStream.js, we need to set the timeout for the whole query also for DAOs that use sessions
        if (!this.connector.useSessions) {
            timeout = GET_STREAM_TIMEOUT; // this is the timeout for the whole stream (used in Cosmos)
        }
        return this.connector.$streamGremlinQuery(query, {
            timeout: timeout,
            bindings: bindings,
            batchSize: chunkSize,
            useDef: this.$gremlinOptions.useDef
        }).then(readableSteam => {
            const parseItem = (type === 'node' ? this.rawNodeToLkNode : this.rawEdgeToLkEdge).bind(this);
            return Utils.safePipe(readableSteam, through(function (data) { this.push(parseItem(data)); }));
        });
    }
    /**
     * Create an edge.
     *
     * This method is responsible to check that source and target nodes have been found.
     *
     * @param {LkEdgeAttributes} newEdge The edge to create
     * @returns {Bluebird<LkEdge>}
     */
    $createEdge(newEdge) {
        const query = `g.V(source).as('source')
      .V(target).addE(edgeType)
      .from('source')` + this._propertyStep(newEdge.data);
        const bindings = {
            source: newEdge.source,
            target: newEdge.target,
            edgeType: newEdge.type
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings, caching: 'phantom' })
            .then(([newEdge]) => {
            if (Utils.noValue(newEdge)) {
                return Errors.business('node_not_found', 'Source or target node not found.', true);
            }
            return this.rawEdgeToLkEdge(newEdge);
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param {string[]} nodeIds IDs of the nodes
     * @returns {Bluebird<LkDigestItem[]>}
     */
    $getAdjacencyDigest(nodeIds) {
        const byId = this.$gremlinOptions.canFoldAndDedupById ? '.by(id)' : '';
        const query = 
        // 1) Select all adjacent nodes and edges form the given node ids
        'g.V().hasId(within(nodeIds)).as("node")' +
            '.bothE().as("e")' +
            '.otherV().as("n")' +
            '.dedup("node", "e", "n").by(id).select("node", "e", "n")' +
            // 2) Group by the pair edgeType, nodeCategory
            '.group()' +
            '  .by(project("edgeType", "nodeCategories")' +
            '    .by(select("e").label())' +
            '    .by(select("n").label().dedup().fold()))' +
            // 3) From each group, count the nodes and edges
            // - fold() is required for counting in each group
            '  .by(fold().project("edgeType", "nodeCategories", "nodes", "edges")' +
            '    .by(unfold().select("e").label())' +
            '    .by(unfold().select("n").label().dedup().fold())' +
            '    .by(unfold().select("n").dedup()' + byId + '.count())' +
            '    .by(unfold().select("e").dedup()' + byId + '.count()))' +
            // - Flatten
            '.unfold()' +
            '.select(values)';
        const bindings = {
            nodeIds: nodeIds
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings });
    }
    /**
     * @param {any} rawNode
     * @returns {LkNode}
     */
    rawNodeToLkNode(rawNode) {
        const n = {
            id: this.$encodeNodeId(rawNode.id),
            data: this._parseProperties(rawNode),
            categories: [rawNode.label]
        };
        return n;
    }
    /**
     * Convert a raw edge to an LkEdge.
     *
     * @param {any} rawEdge
     * @returns {LkEdge}
     */
    rawEdgeToLkEdge(rawEdge) {
        return {
            id: this.$encodeEdgeId(rawEdge.id),
            data: this._parseProperties(rawEdge),
            type: rawEdge.label,
            source: this.$encodeNodeId(rawEdge.outV),
            target: this.$encodeNodeId(rawEdge.inV)
        };
    }
    /**
     * @param {any} rawItem
     * @returns {any} the properties of the raw item
     * @private
     */
    _parseProperties(rawItem) {
        const data = {};
        if (rawItem.properties === undefined) {
            return data;
        }
        for (const key in rawItem.properties) {
            if (!rawItem.properties.hasOwnProperty(key)) {
                continue;
            }
            let value = rawItem.properties[key];
            if (rawItem.type === 'vertex') {
                value = value[0].value;
            }
            if (value === null) {
                // because typeof(null) is 'object'
                data[key] = value;
            }
            else if (typeof (value) === 'object') {
                if (value.type === 'Point') {
                    data[key] = '' + value.coordinates[0] + ',' + value.coordinates[1];
                }
                else {
                    Log.warn('GremlinDriver._parseProperties: ' +
                        'unknown type "' + value.type + '": ' + GremlinUtils.quote(value));
                }
            }
            else {
                data[key] = value;
            }
        }
        return data;
    }
    /**
     * Update an edge content.
     * It's not possible to update the type of an edge.
     *
     * @param {string}      edgeId                    ID of the edge
     * @param {object}   edgeUpdate
     * @param {any}      edgeUpdate.data              Properties updates
     * @param {string[]} edgeUpdate.deletedProperties Properties to delete
     * @returns {Bluebird<LkEdge>} null if not found
     */
    $updateEdge(edgeId, edgeUpdate) {
        return /**@type {Bluebird<LkEdge>}*/ (this._updateItem(edgeId, 'edge', edgeUpdate));
    }
    /**
     * Update an item content.
     *
     * @param {string}   itemId                       Existing item ID
     * @param {string}   itemType                     'node' or 'edge'
     * @param {object}   itemUpdate
     * @param {object}   itemUpdate.data              Property updates
     * @param {string[]} itemUpdate.deletedProperties Properties to delete
     * @returns {Bluebird<LkNode | LkEdge>}
     * @private
     */
    _updateItem(itemId, itemType, itemUpdate) {
        const sPropertiesUpdates = Object.keys(itemUpdate.data).map(key => `.property(${GremlinUtils.quote(key)}, ${GremlinUtils.quote(itemUpdate.data[key])})`);
        const sPropertyDeletes = itemUpdate.deletedProperties.length
            ? '.properties(' + GremlinUtils.quote(itemUpdate.deletedProperties, true) + ').drop()'
            : '';
        const query = `
      g.${itemType === 'node' ? 'V' : 'E'}(${GremlinUtils.quote(itemId)})
        .store('updated')
        ${sPropertiesUpdates.join('')}
        ${sPropertyDeletes}
        .cap('updated');
    `;
        return this.connector.$doGremlinQuery(query, { caching: 'phantom' }).then(updatedItems => {
            if (updatedItems.length && updatedItems[0].length) {
                return itemType === 'node'
                    ? this.rawNodeToLkNode(updatedItems[0][0])
                    : this.rawEdgeToLkEdge(updatedItems[0][0]);
            }
            // will generate a *_not_found error in graphDAO
            return null;
        });
    }
    /**
     * Delete an edge.
     *
     * @param {string} edgeId ID of the edge
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteEdge(edgeId) {
        const query = 'g.E(itemId).store(\'d\').by(id).drop().cap(\'d\')';
        const bindings = {
            itemId: edgeId
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(deletedIds => {
            return deletedIds.length > 0;
        });
    }
    /**
     * Extract from `root` all the vertex and edge encountered as LkNode, LkEdge and properties.
     *
     * @param {any}             root
     * @param {string | number} key
     * @param {LkNode[]}        [nodes]
     * @param {LkEdge[]}        [edges]
     * @param {object}          [properties]
     * @returns {{nodes: LkNode[], edges: LkEdge[], properties: object}}
     * @private
     */
    _extractItems(root, key = 0, nodes = [], edges = [], properties = {}) {
        if (Utils.hasValue(root)) {
            switch (GremlinUtils.qualifyQueryResult(root)) {
                case 'node':
                    nodes.push(this.rawNodeToLkNode(root, []));
                    break;
                case 'edge':
                    edges.push(this.rawEdgeToLkEdge(root));
                    break;
                case 'property':
                    properties[key] = root.value;
                    break;
                case 'literal':
                    properties[key] = root;
                    break;
                default:
                    _.forEach(root, (value, index) => {
                        this._extractItems(value, index, nodes, edges, properties);
                    });
            }
        }
        return { nodes: nodes, edges: edges, properties: properties };
    }
    /**
     * @param {LkNode[]} nodes
     * @param {LkEdge[]} edges
     * @param {object}   properties
     * @returns {QueryMatchPopulated}
     * @private
     */
    _buildQueryMatchPopulated(nodes, edges, properties) {
        return { nodes: _.uniqBy(nodes, 'id'), edges: _.uniqBy(edges, 'id'), properties: properties };
    }
    /**
     * @param {LkNode[]} nodes
     * @param {LkEdge[]} edges
     * @param {object}   properties
     * @returns {QueryMatch}
     * @private
     */
    _buildQueryMatch(nodes, edges, properties) {
        return {
            nodes: _.map(nodes, 'id'),
            edges: _.map(edges, 'id'),
            properties: properties
        };
    }
    /**
     * Run a raw query.
     *
     * If options.populated is true, return a Readable<QueryMatchPopulated>, otherwise a Readable<QueryMatch>.
     *
     * @param {object}   options
     * @param {string}   options.dialect   Supported graph query dialect
     * @param {string[]} options.queries   The graph queries
     * @param {boolean}  options.populated Whether to return QueryMatchPopulated or QueryMatch
     * @param {number}   options.limit     Maximum number of matched subgraphs
     * @returns {Bluebird<Readable<(QueryMatch | QueryMatchPopulated)>>}
     */
    $rawQuery(options) {
        const buildMatch = (options.populated
            ? this._buildQueryMatchPopulated
            : this._buildQueryMatch).bind(this);
        const extractItems = this._extractItems.bind(this);
        const tryAbort = streams => () => {
            streams.forEach(stream => {
                if (typeof stream.abort === 'function') {
                    stream.abort();
                }
            });
        };
        return Promise.map(options.queries, query => this.connector.$streamGremlinQuery(query, {
            timeout: Config.get('advanced.rawQueryTimeout'),
            allowForbiddenStatements: false,
            batchSize: 20,
            useDef: this.$gremlinOptions.useDef
        })).then(streams => Utils.safePipe(Utils.mergeStreams(streams), through(function (data) {
            const { nodes, edges, properties } = extractItems(data);
            this.queue(buildMatch(nodes, edges, properties));
        }), Utils.capStream(options.limit, tryAbort(streams))));
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * @param {string[]} nodeIds            IDs of the node
     * @param {number}   supernodeThreshold
     * @returns {Bluebird<Map<string, boolean>>}
     */
    $isSuperNode(nodeIds, supernodeThreshold) {
        const query = `g.V().hasId(within(nodeIds))
      .project('id', 'degree')
        .by(id)
        .by(both().limit(supernodeThreshold).count())`;
        const bindings = {
            nodeIds: nodeIds,
            supernodeThreshold: supernodeThreshold
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(result => {
            const superNodeResult = new Map();
            _.forEach(result, ({ id, degree }) => {
                superNodeResult.set(this.$encodeNodeId(id), degree >= supernodeThreshold);
            });
            return superNodeResult;
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param {string}   nodeId                  ID of the node
     * @param {object}   options
     * @param {string[]} [options.readableTypes] Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<LkEdgeDigestItem[]>}
     */
    $getEdgeDigest(nodeId, options) {
        let typeFilter = '';
        if (Utils.hasValue(options.readableTypes)) {
            typeFilter = '.has(label, within(readableTypes))';
        }
        const digestQuery = `g.V(nodeId).bothE()${typeFilter}.groupCount().by(label)`;
        const bindings = {
            nodeId: nodeId,
            readableTypes: options.readableTypes
        };
        return this.connector.$doGremlinQuery(digestQuery, { bindings: bindings }).then(([result]) => {
            const edgeDigest = [];
            _.forEach(result, (count, type) => {
                edgeDigest.push({ edgeType: type, edges: count });
            });
            return edgeDigest;
        });
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the first set of nodes
     * @param {string[]} otherNodeIds             IDs of the second set of nodes
     * @param {object}   options
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options) {
        let edgeTypeFilter = '';
        if (Utils.hasValue(options.edgeTypes)) {
            edgeTypeFilter = '.has(label, within(edgeTypes))';
        }
        let nodeCategoryFilter = '';
        if (Utils.hasValue(options.nodeCategories)) {
            nodeCategoryFilter = '.has(label, within(nodeCategories))';
        }
        const query = 'g.V()' +
            '  .has(id, within(nodeIds))' +
            `  .bothE()${edgeTypeFilter}` +
            `  .where(otherV().hasId(within(otherNodeIds))${nodeCategoryFilter})` +
            '  .dedup().by(id)';
        const bindings = {
            nodeIds: nodeIds,
            otherNodeIds: otherNodeIds,
            edgeTypes: options.edgeTypes,
            nodeCategories: options.nodeCategories
        };
        return this.connector.$doGremlinQuery(query, { bindings: bindings }).then(results => {
            return results.map(edge => this.rawEdgeToLkEdge(edge));
        });
    }
    /**
     * Return true is query is a write query.
     */
    $isWrite(query) {
        return GremlinUtils.isWrite(query);
    }
    /**
     * Check if a query is correct.
     *
     * @param {string}  query      The graph query
     * @returns {boolean} Whether the `query` will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    $checkQuery(query) {
        return GremlinUtils.checkQuery(query, false);
    }
}
module.exports = GremlinDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpbkRyaXZlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vZ3JhcGgvZ3JlbWxpbkRyaXZlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLDhCQUE4QixDQUFDLG1CQUFtQjtBQUVsRCxnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbkMsTUFBTSxFQUFDLGtCQUFrQixFQUFFLGlCQUFpQixFQUFDLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFakYsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUM3QyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUV0RCxNQUFNLGtCQUFrQixHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsU0FBUztBQUVwRCxNQUFNLGFBQWMsU0FBUSxXQUFXO0lBQ3JDOzs7Ozs7O09BT0c7SUFFSDs7T0FFRztJQUNILElBQUksZUFBZTtRQUNqQixPQUFPLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVO1FBQ3RCLFFBQVEsVUFBVSxFQUFFO1lBQ2xCLEtBQUssa0JBQWtCLENBQUMsSUFBSTtnQkFDMUIsTUFBTSxFQUFFLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ2hDLE9BQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNoQyxLQUFLLGtCQUFrQixDQUFDLFFBQVE7Z0JBQzlCLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEQsT0FBTyxZQUFZLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLEtBQUssa0JBQWtCLENBQUMsV0FBVyxDQUFDO1lBQ3BDLEtBQUssa0JBQWtCLENBQUMsZ0JBQWdCLENBQUM7WUFDekMsS0FBSyxrQkFBa0IsQ0FBQyxNQUFNO2dCQUM1QixPQUFPLFlBQVksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkM7Z0JBQ0UsT0FBTyxLQUFLLEdBQUcsRUFBRSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsYUFBYSxDQUFDLEtBQUs7UUFDakIsT0FBTyxHQUFHLEtBQUssRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGFBQWEsQ0FBQyxLQUFLO1FBQ2pCLE9BQU8sR0FBRyxLQUFLLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWU7UUFDYixPQUFPLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO0lBQzVDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsMkJBQTJCO1FBQ3pCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLE9BQU87UUFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7WUFDaEQsQ0FBQyxDQUFDLDhCQUE4QjtZQUNoQyxDQUFDLENBQUMsMkNBQTJDLENBQUM7UUFFaEQsTUFBTSxRQUFRLEdBQUc7WUFDZixPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUc7WUFDcEIsYUFBYSxFQUFFLE9BQU8sQ0FBQyxhQUFhO1NBQ3JDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoRixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDL0QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7WUFDaEQsQ0FBQyxDQUFDLGNBQWM7WUFDaEIsQ0FBQyxDQUFDLDJDQUEyQyxDQUFDO1FBRWhELE1BQU0sUUFBUSxHQUFHO1lBQ2YsT0FBTyxFQUFFLE9BQU8sQ0FBQyxHQUFHO1lBQ3BCLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYTtTQUNyQyxDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEYsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDaEMsSUFBSSxjQUFjLEdBQUcsU0FBUyxDQUFDO1FBQy9CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDckMsY0FBYyxHQUFHLDZDQUE2QyxDQUFDO1NBQ2hFO1FBRUQsSUFBSSxtQkFBbUIsR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUMxQyxtQkFBbUIsR0FBRyxpQ0FBaUMsQ0FBQztTQUN6RDtRQUVELElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLE9BQU8sQ0FBQyxTQUFTLEtBQUssSUFBSSxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7WUFDL0MsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLFNBQVMsS0FBSyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQ3JFLE1BQU0sR0FBRyxnQ0FBZ0MsS0FBSyxHQUFHLENBQUM7U0FDbkQ7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO1lBQ2pCLE1BQU0sR0FBRyx5QkFBeUIsQ0FBQztTQUNwQztRQUVELE1BQU0sS0FBSyxHQUFHO1FBQ1YsY0FBYyxHQUFHLG1CQUFtQjt5Q0FDSCxNQUFNLEdBQUcsTUFBTTtzQkFDbEMsQ0FBQztRQUVuQixNQUFNLFFBQVEsR0FBRztZQUNmLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYztZQUN0QyxVQUFVLEVBQUUsT0FBTyxDQUFDLGNBQWM7WUFDbEMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3hCLGVBQWUsRUFBRSxPQUFPLENBQUMsS0FBSztTQUMvQixDQUFDO1FBRUYsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFakQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDbkYsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILGNBQWMsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUM3QixPQUFPLG1EQUFtRCxDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWU7WUFDakYsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO1lBQ2hELENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsdUJBQXVCLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDdEMsSUFBSSxrQkFBa0IsR0FBRyxFQUFFLENBQUM7UUFDNUIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBRXhCLElBQUksT0FBTyxDQUFDLGtCQUFrQixFQUFFO1lBQzlCLGtCQUFrQixHQUFHLHlDQUF5QyxDQUFDO1NBQ2hFO1FBRUQsSUFBSSxPQUFPLENBQUMsYUFBYSxFQUFFO1lBQ3pCLGNBQWMsR0FBRyxvQ0FBb0MsQ0FBQztTQUN2RDtRQUVELE1BQU0sS0FBSyxHQUFHOzs7aUNBR2UsY0FBYzttQkFDNUIsa0JBQWtCOzs7a0JBR25CLENBQUM7UUFFZixNQUFNLFFBQVEsR0FBRztZQUNmLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxrQkFBa0I7WUFDOUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxhQUFhO1NBQ3JDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMvRSxNQUFNLGdCQUFnQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDbkMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUMsRUFBRSxFQUFFO2dCQUNqQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN2RCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sZ0JBQWdCLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILHVCQUF1QixDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQ3RDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztRQUU1QixJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7WUFDekIsY0FBYyxHQUFHLG9DQUFvQyxDQUFDO1NBQ3ZEO1FBRUQsSUFBSSxPQUFPLENBQUMsa0JBQWtCLEVBQUU7WUFDOUIsa0JBQWtCLEdBQUcseUNBQXlDLENBQUM7U0FDaEU7UUFFRCxNQUFNLEtBQUssR0FBRztnQkFDRixjQUFjO2lCQUNiLGtCQUFrQjs7O2VBR3BCLENBQUM7UUFFWixNQUFNLFFBQVEsR0FBRztZQUNmLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYTtZQUNwQyxrQkFBa0IsRUFBRSxPQUFPLENBQUMsa0JBQWtCO1NBQy9DLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pHLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxhQUFhLENBQUMsSUFBSTtRQUNoQixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQ2hDLGFBQWEsWUFBWSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQ3RFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsTUFBTSxLQUFLLEdBQUcsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFeEUsTUFBTSxRQUFRLEdBQUc7WUFDZixZQUFZLEVBQUUsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7U0FDcEMsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFDLENBQUM7YUFDbkYsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ25CLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFO2dCQUFFLE9BQU8sSUFBSSxDQUFDO2FBQUU7WUFDMUMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUFVO1FBQzVCLE9BQU8sNkJBQTZCLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxXQUFXLENBQUMsTUFBTTtRQUNoQixNQUFNLEtBQUssR0FBRyxtREFBbUQsQ0FBQztRQUVsRSxNQUFNLFFBQVEsR0FBRztZQUNmLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ25GLE9BQU8sVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGNBQWMsQ0FBQyxPQUFPO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFVBQVUsQ0FBQyxJQUFJLEVBQUUsT0FBTztRQUN0QixNQUFNLEdBQUcsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUN4QywrREFBK0Q7UUFDL0QsaUVBQWlFO1FBQ2pFLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDNUQsTUFBTSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssTUFBTSxFQUFFLENBQUM7UUFDcEMsTUFBTSxFQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUUvQyxNQUFNLFFBQVEsR0FBRztZQUNmLFFBQVEsRUFBRSxNQUFNO1NBQ2pCLENBQUM7UUFFRixJQUFJLE9BQU8sQ0FBQztRQUVaLDBIQUEwSDtRQUMxSCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUU7WUFDL0IsT0FBTyxHQUFHLGtCQUFrQixDQUFDLENBQUMsNERBQTREO1NBQzNGO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRTtZQUMvQyxPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRLEVBQUUsUUFBUTtZQUNsQixTQUFTLEVBQUUsU0FBUztZQUNwQixNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNO1NBQ3BDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDdEIsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdGLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQ2pDLE9BQU8sQ0FBQyxVQUFTLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsTUFBTSxLQUFLLEdBQUc7O3NCQUVJLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdEQsTUFBTSxRQUFRLEdBQUc7WUFDZixNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU07WUFDdEIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLFFBQVEsRUFBRSxPQUFPLENBQUMsSUFBSTtTQUN2QixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUMsQ0FBQzthQUNuRixJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUU7WUFDbEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMxQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDcEY7WUFFRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxtQkFBbUIsQ0FBQyxPQUFPO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3ZFLE1BQU0sS0FBSztRQUNULGlFQUFpRTtRQUNqRSx5Q0FBeUM7WUFDekMsa0JBQWtCO1lBQ2xCLG1CQUFtQjtZQUNuQiwwREFBMEQ7WUFFMUQsOENBQThDO1lBQzlDLFVBQVU7WUFDViw2Q0FBNkM7WUFDN0MsOEJBQThCO1lBQzlCLDhDQUE4QztZQUU5QyxnREFBZ0Q7WUFDaEQsa0RBQWtEO1lBQ2xELHNFQUFzRTtZQUN0RSx1Q0FBdUM7WUFDdkMsc0RBQXNEO1lBQ3RELHNDQUFzQyxHQUFHLElBQUksR0FBRyxXQUFXO1lBQzNELHNDQUFzQyxHQUFHLElBQUksR0FBRyxZQUFZO1lBQzVELFlBQVk7WUFDWixXQUFXO1lBQ1gsaUJBQWlCLENBQUM7UUFFcEIsTUFBTSxRQUFRLEdBQUc7WUFDZixPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsZUFBZSxDQUFDLE9BQU87UUFDckIsTUFBTSxDQUFDLEdBQUc7WUFDUixFQUFFLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ2xDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO1lBQ3BDLFVBQVUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDNUIsQ0FBQztRQUVGLE9BQU8sQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsZUFBZSxDQUFDLE9BQU87UUFDckIsT0FBTztZQUNMLEVBQUUsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDbEMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7WUFDcEMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ25CLE1BQU0sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7WUFDeEMsTUFBTSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztTQUN4QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxnQkFBZ0IsQ0FBQyxPQUFPO1FBQ3RCLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLE9BQU8sQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFO1lBQ3BDLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFFRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUU7WUFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUFFLFNBQVM7YUFBRTtZQUMxRCxJQUFJLEtBQUssR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7Z0JBQzdCLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2FBQ3hCO1lBRUQsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO2dCQUNsQixtQ0FBbUM7Z0JBQ25DLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDbkI7aUJBQU0sSUFBSSxPQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUNyQyxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO29CQUMxQixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BFO3FCQUFNO29CQUNMLEdBQUcsQ0FBQyxJQUFJLENBQUMsa0NBQWtDO3dCQUN6QyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7aUJBQ3RFO2FBQ0Y7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUNuQjtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUFVO1FBQzVCLE9BQU8sNkJBQTZCLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILFdBQVcsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLFVBQVU7UUFDdEMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQ3pELEdBQUcsQ0FBQyxFQUFFLENBQUMsYUFBYSxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQzVGLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNO1lBQzFELENBQUMsQ0FBQyxjQUFjLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsVUFBVTtZQUN0RixDQUFDLENBQUMsRUFBRSxDQUFDO1FBRVAsTUFBTSxLQUFLLEdBQUc7VUFDUixRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQzs7VUFFN0Qsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztVQUMzQixnQkFBZ0I7O0tBRXJCLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNyRixJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtnQkFDakQsT0FBTyxRQUFRLEtBQUssTUFBTTtvQkFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5QztZQUNELGdEQUFnRDtZQUNoRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE1BQU07UUFDaEIsTUFBTSxLQUFLLEdBQUcsbURBQW1ELENBQUM7UUFFbEUsTUFBTSxRQUFRLEdBQUc7WUFDZixNQUFNLEVBQUUsTUFBTTtTQUNmLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUNuRixPQUFPLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxhQUFhLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxLQUFLLEdBQUcsRUFBRSxFQUFFLFVBQVUsR0FBRyxFQUFFO1FBQ2xFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN4QixRQUFRLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDN0MsS0FBSyxNQUFNO29CQUNULEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDM0MsTUFBTTtnQkFDUixLQUFLLE1BQU07b0JBQ1QsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLE1BQU07Z0JBQ1IsS0FBSyxVQUFVO29CQUNiLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUM3QixNQUFNO2dCQUNSLEtBQUssU0FBUztvQkFDWixVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO29CQUN2QixNQUFNO2dCQUNSO29CQUNFLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFO3dCQUMvQixJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDN0QsQ0FBQyxDQUFDLENBQUM7YUFDTjtTQUNGO1FBRUQsT0FBTyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHlCQUF5QixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVTtRQUNoRCxPQUFPLEVBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGdCQUFnQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVTtRQUN2QyxPQUFPO1lBQ0wsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztZQUN6QixLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO1lBQ3pCLFVBQVUsRUFBRSxVQUFVO1NBQ3ZCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxTQUFTLENBQUMsT0FBTztRQUNmLE1BQU0sVUFBVSxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVM7WUFDbkMsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUI7WUFDaEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV0QyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVuRCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRTtZQUMvQixPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN2QixJQUFJLE9BQU8sTUFBTSxDQUFDLEtBQUssS0FBSyxVQUFVLEVBQUU7b0JBQ3RDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDaEI7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUU7WUFDckYsT0FBTyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUM7WUFDL0Msd0JBQXdCLEVBQUUsS0FBSztZQUMvQixTQUFTLEVBQUUsRUFBRTtZQUNiLE1BQU0sRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU07U0FDcEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxVQUFTLElBQUk7WUFFbkYsTUFBTSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztRQUVuRCxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFlBQVksQ0FBQyxPQUFPLEVBQUUsa0JBQWtCO1FBQ3RDLE1BQU0sS0FBSyxHQUFHOzs7c0RBR29DLENBQUM7UUFFbkQsTUFBTSxRQUFRLEdBQUc7WUFDZixPQUFPLEVBQUUsT0FBTztZQUNoQixrQkFBa0IsRUFBRSxrQkFBa0I7U0FDdkMsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQy9FLE1BQU0sZUFBZSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDbEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUMsRUFBRSxFQUFFO2dCQUNqQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxJQUFJLGtCQUFrQixDQUFDLENBQUM7WUFDNUUsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLGVBQWUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLE1BQU0sRUFBRSxPQUFPO1FBQzVCLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUVwQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3pDLFVBQVUsR0FBRyxvQ0FBb0MsQ0FBQztTQUNuRDtRQUVELE1BQU0sV0FBVyxHQUFHLHNCQUFzQixVQUFVLHlCQUF5QixDQUFDO1FBRTlFLE1BQU0sUUFBUSxHQUFHO1lBQ2YsTUFBTSxFQUFFLE1BQU07WUFDZCxhQUFhLEVBQUUsT0FBTyxDQUFDLGFBQWE7U0FDckMsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO1lBQ3pGLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztZQUN0QixDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRTtnQkFDaEMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLFVBQVUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxlQUFlLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQzVDLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUV4QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3JDLGNBQWMsR0FBRyxnQ0FBZ0MsQ0FBQztTQUNuRDtRQUVELElBQUksa0JBQWtCLEdBQUcsRUFBRSxDQUFDO1FBRTVCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDMUMsa0JBQWtCLEdBQUcscUNBQXFDLENBQUM7U0FDNUQ7UUFFRCxNQUFNLEtBQUssR0FBRyxPQUFPO1lBQ25CLDZCQUE2QjtZQUM3QixhQUFhLGNBQWMsRUFBRTtZQUM3QixnREFBZ0Qsa0JBQWtCLEdBQUc7WUFDckUsbUJBQW1CLENBQUM7UUFFdEIsTUFBTSxRQUFRLEdBQUc7WUFDZixPQUFPLEVBQUUsT0FBTztZQUNoQixZQUFZLEVBQUUsWUFBWTtZQUMxQixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDNUIsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO1NBQ3ZDLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoRixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDekQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRLENBQUMsS0FBSztRQUNaLE9BQU8sWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixPQUFPLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDIn0=