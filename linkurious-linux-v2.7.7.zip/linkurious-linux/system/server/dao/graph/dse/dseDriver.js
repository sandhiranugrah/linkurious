/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
// locals
const GremlinDriver = require('../gremlinDriver');
const DseUtils = require('../../utils/dseUtils');
const GremlinUtils = require('../../utils/gremlinUtils');
const { LkError } = require('../../../models/errors/LkError');
const MAX_CONCURRENT_GET_EDGES_BY_ID = 5;
class DseDriver extends GremlinDriver {
    /**
     * @param {GremlinConnector} connector     Connector used by the DAO
     * @param {any}              graphOptions  GraphDAO options
     * @param {any}              connectorData Data from the connector
     * @param {GraphFeatures}    graphFeatures Features of the Graph DAO
     */
    constructor(connector, graphOptions, connectorData, graphFeatures) {
        super(connector, graphOptions, connectorData, graphFeatures);
        this._schemaInfo = {
            propertyTypes: {},
            nodeSchema: {},
            edgeSchema: {},
            searchIndices: {},
            indexedProperties: []
        };
    }
    /**
     * @returns {GremlinOptions}
     */
    get $gremlinOptions() {
        return {
            disableTypeChecks: false,
            useDef: true,
            canFoldAndDedupById: true
        };
    }
    /**
     * @param {string}  key
     * @param {string}  id
     * @returns {any} The ID of the edge (encoded or not)
     * @throws {LkError} if the ID is not valid
     * @private
     */
    _decodeId(key, id) {
        if (/^{.*}$/.test(id)) {
            return id;
        }
        // @backward-compatibility ID is a base64 encoded string
        try {
            const parsedId = Buffer.from(id + '', 'base64').toString('ascii');
            let jsonId;
            if (/^\[.*\]$/.test(parsedId)) {
                // @backward-compatibility  ID is a DSE object string before base64 encoding
                jsonId = GremlinUtils.parseGroovyMapToJson(key, parsedId);
            }
            else {
                // @backward-compatibility ID is a JSON string before base64 encoding
                jsonId = JSON.parse(parsedId);
            }
            return this._encodeId(jsonId);
        }
        catch (e) {
            if (e instanceof LkError) {
                throw e;
            }
            throw Errors.business('invalid_parameter', `"${key}" must be a base64-encoded JSON string.`);
        }
    }
    /**
     * Check if the given edge ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkEdgeId(key, id) {
        Utils.check.string(key, id, true);
    }
    /**
     * Check if the given node ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkNodeId(key, id) {
        Utils.check.string(key, id, true);
    }
    /**
     * Order the keys of a dse graph item id.
     * The label is always first, the remaining key are sorted alphabetically
     *
     * @param {object} rawId
     * @returns {string[]}
     * @private
     */
    _getKeys(rawId) {
        const keys = _.keys(rawId).sort();
        const labelIndex = keys.indexOf('~label');
        if (labelIndex > 0) {
            keys.splice(labelIndex, 1);
            keys.unshift('~label');
        }
        return keys;
    }
    /**
     * @param {any} rawId
     * @returns {string}
     * @private
     */
    _encodeId(rawId) {
        if (typeof rawId === 'object') {
            const keys = this._getKeys(rawId);
            return `{${_.map(keys, k => `${this._encodeId(k)}=${this._encodeId(rawId[k])}`).join(', ')}}`;
        }
        return `${rawId}`;
    }
    /**
     * Encode a raw Node ID in an ID usable in an LkNode.
     *
     * @param {any} rawId
     * @returns {string}
     */
    $encodeNodeId(rawId) {
        return this._encodeId(rawId);
    }
    /**
     * Encode a raw Edge ID in an ID usable in an LkEdge.
     *
     * @param {any} rawId
     * @returns {string}
     */
    $encodeEdgeId(rawId) {
        return this._encodeId(rawId);
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        return Promise.resolve().then(() => {
            const nodeCategories = _.keys(this._schemaInfo.nodeSchema);
            const edgeTypes = _.keys(this._schemaInfo.edgeSchema);
            const nodeProperties = _.uniq.apply(_, _.values(this._schemaInfo.nodeSchema));
            const edgeProperties = _.uniq.apply(_, _.values(this._schemaInfo.edgeSchema));
            return {
                nodeCategories: nodeCategories,
                edgeTypes: edgeTypes,
                nodeProperties: nodeProperties,
                edgeProperties: edgeProperties
            };
        });
    }
    /**
     * Called at the begin of the internal indexation phase for additional initializations.
     * Not called for external indices.
     *
     * @returns {Bluebird<void>}
     */
    $onInternalIndexation() {
        const q = `inject(
      scan: graph.schema().config().option('graph.allow_scan').get()
    )`;
        return this.connector.$doGremlinQuery(q).get('0').then(r => {
            if (r.scan !== true) {
                return Errors.business('source_action_needed', '"graph.allow_scan" must be enabled to use DSE with internal indices.', true);
            }
            return this._refreshSchema();
        });
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param {object}   options
     * @param {string[]} options.ids             List of IDs to read
     * @param {string}   [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByID(options) {
        const $options = _.defaults({ ids: options.ids.map(id => this._decodeId('node id', id)) }, options);
        return super.$getNodesByID($options);
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param {object}   options
     * @param {string[]} options.ids List of IDs to read
     * @returns {Bluebird<LkEdge[]>}
     */
    $getEdgesByID(options) {
        // TODO #930 wait for a response from Datastax and find a fix for this. It could be optimized to a single query with a try catch in a loop
        return /**@type {Bluebird<LkEdge[]>}*/ (Promise.map(options.ids, id => {
            // option `alternativeId` is ignored because only alternative node ids are supported in DSE
            return super.$getEdgesByID({ ids: [this._decodeId('node id', id)] }).catch(e => {
                if (e && e.message && e.message.includes('full scan')) {
                    return; // a request for full scan occurs when the edge is not found
                }
                throw e;
            });
        }, { concurrency: MAX_CONCURRENT_GET_EDGES_BY_ID }).then(_.flatten));
    }
    /**
     * Refresh the schema info cached in the driver.
     *
     * @returns {Bluebird<void>}
     * @private
     */
    _refreshSchema() {
        return this.connector.$doGremlinQuery('schema.describe();').get('0').then(describeR => {
            this._schemaInfo = DseUtils.parseSchemaInfo(describeR);
        });
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        return super.$onAfterConnect().then(() => {
            const q = 'inject(autostart: graph.schema().config().option(\'graph.tx_autostart\').get())';
            return this.connector.$doGremlinQuery(q).get('0').then(r => {
                if (r.autostart !== true) {
                    return Errors.business('source_action_needed', '"graph.tx_autostart" must be enabled to use Linkurious with DSE.', true);
                }
                return this._refreshSchema();
            });
        });
    }
}
module.exports = DseDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9kc2UvZHNlRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ2xELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ2pELE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQ3pELE1BQU0sRUFBQyxPQUFPLEVBQUMsR0FBRyxPQUFPLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztBQUU1RCxNQUFNLDhCQUE4QixHQUFHLENBQUMsQ0FBQztBQUV6QyxNQUFNLFNBQVUsU0FBUSxhQUFhO0lBRW5DOzs7OztPQUtHO0lBQ0gsWUFBWSxTQUFTLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhO1FBQy9ELEtBQUssQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUU3RCxJQUFJLENBQUMsV0FBVyxHQUFHO1lBQ2pCLGFBQWEsRUFBRSxFQUFFO1lBQ2pCLFVBQVUsRUFBRSxFQUFFO1lBQ2QsVUFBVSxFQUFFLEVBQUU7WUFDZCxhQUFhLEVBQUUsRUFBRTtZQUNqQixpQkFBaUIsRUFBRSxFQUFFO1NBQ3RCLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLGVBQWU7UUFDakIsT0FBTztZQUNMLGlCQUFpQixFQUFFLEtBQUs7WUFDeEIsTUFBTSxFQUFFLElBQUk7WUFDWixtQkFBbUIsRUFBRSxJQUFJO1NBQzFCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsU0FBUyxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2YsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFO1lBQ3JCLE9BQU8sRUFBRSxDQUFDO1NBQ1g7UUFFRCx3REFBd0Q7UUFDeEQsSUFBSTtZQUNGLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEUsSUFBSSxNQUFNLENBQUM7WUFDWCxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzdCLDRFQUE0RTtnQkFDNUUsTUFBTSxHQUFHLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDM0Q7aUJBQU07Z0JBQ0wscUVBQXFFO2dCQUNyRSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUMvQjtZQUNELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvQjtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsSUFBSSxDQUFDLFlBQVksT0FBTyxFQUFFO2dCQUN4QixNQUFNLENBQUMsQ0FBQzthQUNUO1lBQ0QsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFBRSxJQUFJLEdBQUcseUNBQXlDLENBQ3RFLENBQUM7U0FDSDtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUU7UUFDbEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxRQUFRLENBQUMsS0FBSztRQUNaLE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDbEMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQyxJQUFJLFVBQVUsR0FBRyxDQUFDLEVBQUU7WUFDbEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUN4QjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxTQUFTLENBQUMsS0FBSztRQUNiLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1lBQzdCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbEMsT0FBTyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO1NBQy9GO1FBQ0QsT0FBTyxHQUFHLEtBQUssRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGFBQWEsQ0FBQyxLQUFLO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsS0FBSztRQUNqQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsZ0JBQWdCO1FBQ2QsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxNQUFNLGNBQWMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0QsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3RELE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUM5RSxNQUFNLGNBQWMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFFOUUsT0FBTztnQkFDTCxjQUFjLEVBQUUsY0FBYztnQkFDOUIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLGNBQWMsRUFBRSxjQUFjO2dCQUM5QixjQUFjLEVBQUUsY0FBYzthQUMvQixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxxQkFBcUI7UUFDbkIsTUFBTSxDQUFDLEdBQUc7O01BRVIsQ0FBQztRQUNILE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN6RCxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO2dCQUNuQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0QixzRUFBc0UsRUFDdEUsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUVELE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsYUFBYSxDQUFDLE9BQU87UUFDbkIsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUMsRUFDckYsT0FBTyxDQUFDLENBQUM7UUFDWCxPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQiwwSUFBMEk7UUFDMUksT0FBTywrQkFBK0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNwRSwyRkFBMkY7WUFDM0YsT0FBTyxLQUFLLENBQUMsYUFBYSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUMzRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUNyRCxPQUFPLENBQUMsNERBQTREO2lCQUNyRTtnQkFFRCxNQUFNLENBQUMsQ0FBQztZQUNWLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLDhCQUE4QixFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsY0FBYztRQUNaLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN6RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdkMsTUFBTSxDQUFDLEdBQUcsaUZBQWlGLENBQUM7WUFDNUYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUN6RCxJQUFJLENBQUMsQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO29CQUN4QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0QixrRUFBa0UsRUFDbEUsSUFBSSxDQUNMLENBQUM7aUJBQ0g7Z0JBRUQsT0FBTyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDIn0=