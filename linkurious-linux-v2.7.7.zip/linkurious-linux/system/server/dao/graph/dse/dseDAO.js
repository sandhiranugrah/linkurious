/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-01.
 */
'use strict';
// locals
const GraphDAO = require('../graphDAO');
const DseConnector = require('../../connector/dseConnector');
const DseDriver = require('./dseDriver');
class DseDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url               DSE Graph url
     * @param {string}  options.graphName         The name of the DSE graph to load
     * @param {string}  [options.user]            DSE Graph user
     * @param {string}  [options.password]        DSE Graph password
     * @param {boolean} [options.create]          Whether to create the graph if it does not exist
     * @param {boolean} [options.allowSelfSigned] Whether to allow self-signed certificates
     */
    constructor(options) {
        super('dse', ['url', 'graphName'], [
            'url',
            'graphName',
            'user',
            'password',
            'create',
            'allowSelfSigned',
            'sessionPool',
            'maxStale' // experimental
        ], options, {
            edgeProperties: true,
            immutableNodeCategories: true,
            minNodeCategories: 1,
            maxNodeCategories: 1,
            serializeArrayProperties: true,
            canCount: false,
            alerts: true,
            alternativeIds: false,
            emptyNodes: true,
            dialects: ['gremlin'],
            canStream: true,
            detectSupernodes: true,
            canDryRun: false
        }, DseConnector, [
            // Note: we are talking about gremlin versions
            { version: '3.3.3', driver: '[latest]' },
            { version: '3.2.6', driver: DseDriver }
            // We explicitly don't support DSE 5.0.x because it doesn't support fuzzy search
        ]);
    }
}
module.exports = DseDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9kc2UvZHNlREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUM3RCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFFekMsTUFBTSxNQUFPLFNBQVEsUUFBUTtJQUUzQjs7Ozs7Ozs7T0FRRztJQUNILFlBQVksT0FBTztRQUNqQixLQUFLLENBQUMsS0FBSyxFQUNULENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxFQUNwQjtZQUNFLEtBQUs7WUFDTCxXQUFXO1lBQ1gsTUFBTTtZQUNOLFVBQVU7WUFDVixRQUFRO1lBQ1IsaUJBQWlCO1lBQ2pCLGFBQWE7WUFDYixVQUFVLENBQUMsZUFBZTtTQUMzQixFQUNELE9BQU8sRUFDUDtZQUNFLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLHVCQUF1QixFQUFFLElBQUk7WUFDN0IsaUJBQWlCLEVBQUUsQ0FBQztZQUNwQixpQkFBaUIsRUFBRSxDQUFDO1lBQ3BCLHdCQUF3QixFQUFFLElBQUk7WUFDOUIsUUFBUSxFQUFFLEtBQUs7WUFDZixNQUFNLEVBQUUsSUFBSTtZQUNaLGNBQWMsRUFBRSxLQUFLO1lBQ3JCLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLFFBQVEsRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUNyQixTQUFTLEVBQUUsSUFBSTtZQUNmLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsU0FBUyxFQUFFLEtBQUs7U0FDakIsRUFDRCxZQUFZLEVBQ1o7WUFDRSw4Q0FBOEM7WUFDOUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUM7WUFDdEMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUM7WUFDckMsZ0ZBQWdGO1NBQ2pGLENBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDIn0=