"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-07-26.
 */
// external libs
const Bluebird = require("bluebird");
const Driver = require("../driver");
class GraphDriver extends Driver {
    /**
     * @param connector     Connector used by the DAO
     * @param graphOptions  GraphDAO options
     * @param connectorData Data from the connector
     * @param graphFeatures Features of the Graph DAO
     */
    constructor(connector, graphOptions, connectorData, graphFeatures) {
        super(connector, graphOptions, connectorData);
        this.graphFeatures = graphFeatures;
    }
    /**
     * Special properties that can't be read, created or updated.
     *
     * Optional to implement.
     */
    get $specialProperties() {
        return [];
    }
    /**
     * Called at the begin of the internal indexation phase for additional initializations.
     * Not called for external indices.
     *
     * Optional to implement.
     * Implement only if features.canStream is true.
     */
    $onInternalIndexation() {
        return Bluebird.resolve();
    }
    /**
     * Return a legal node id for the current vendor.
     */
    $getDummyNodeId() {
        return '0';
    }
}
module.exports = GraphDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2dyYXBoRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFRckMsb0NBQXFDO0FBRXJDLE1BQWUsV0FBaUMsU0FBUSxNQUFTO0lBRy9EOzs7OztPQUtHO0lBQ0gsWUFDRSxTQUFZLEVBQ1osWUFBb0MsRUFDcEMsYUFBcUMsRUFDckMsYUFBNEI7UUFFNUIsS0FBSyxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDOUMsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxJQUFJLGtCQUFrQjtRQUNwQixPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxxQkFBcUI7UUFDMUIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQVVEOztPQUVHO0lBQ0ksZUFBZTtRQUNwQixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7Q0EwVUY7QUFFRCxpQkFBUyxXQUFXLENBQUMifQ==