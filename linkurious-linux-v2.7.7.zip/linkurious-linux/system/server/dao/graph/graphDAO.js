"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-30.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// external libs
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const through = require("through");
// services
const CappedQueue = require("../../../lib/CappedQueue");
const LKE = require("../../services");
// locals
const DAO = require("../DAO");
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const NODE_STATISTICS_BATCH_SIZE = 20;
const READ_BY_ID_BATCH_SIZE = 50;
const SUPERNODE_CACHE_SIZE = 5000;
const MAX_GET_ADJACENT_NODES_LIMIT = 10000;
/**
 * GraphFeatures
 *
 * @property edgeProperties           Whether edge properties are allowed
 * @property immutableNodeCategories  Whether node categories are immutable for this vendor
 * @property minNodeCategories        Minimum number of categories for a node
 * @property [maxNodeCategories]      Maximum number of categories for a node
 * @property serializeArrayProperties Whether to serialize/parse property values that are arrays
 * @property canCount                 Whether the graph can count nodes and edges
 * @property alerts                   Whether alerts are supported
 * @property alternativeIds           Whether the DAO supports alternative ids
 * @property emptyNodes               Whether empty nodes are allowed (usually not allowed in RDF stores)
 * @property dialects                 List of supported dialects
 * @property canStream                Whether the DAO can stream all nodes and edges
 * @property detectSupernodes         Whether the DAO makes a difference between supernodes and regular nodes
 * @property canDryRun                Whether the DAO is able to perform a dryRun
 */
class GraphDAO extends DAO {
    /**
     * @param vendor           Name of the vendor for this DAO (e.g.: neo4j, elasticSearch)
     * @param requiredOptions  List of required option properties
     * @param availableOptions List of available option properties
     * @param options          DAO constructor options
     * @param features         Features of the Graph DAO
     * @param connectors       Connectors of the DAO
     * @param drivers          Driver to use from a given version
     */
    constructor(vendor, requiredOptions, availableOptions, options, features, connectors, drivers) {
        super('Graph', vendor, requiredOptions, availableOptions.concat([
            // name of the property used as alternative ID for node and edges
            'alternativeNodeId',
            'alternativeEdgeId',
            // name of the index to use to resolve nodes and edges by alternativeId
            'alternativeNodeIdIndex',
            'alternativeEdgeIdIndex',
            // node properties for latitude and longitude (for geographical layout)
            'latitudeProperty',
            'longitudeProperty'
        ]), options, undefined, connectors, drivers);
        if (!features) {
            throw Errors.technical('bug', 'Graph DAO: "features" is required');
        }
        this.features = features;
        Utils.check.properties('features', features, {
            edgeProperties: { required: true, type: 'boolean' },
            immutableNodeCategories: { required: true, type: 'boolean' },
            minNodeCategories: { required: true, check: ['integer', 0] },
            maxNodeCategories: { check: ['integer', 0] },
            serializeArrayProperties: { required: true, type: 'boolean' },
            canCount: { required: true, type: 'boolean' },
            alerts: { required: true, type: 'boolean' },
            alternativeIds: { required: true, type: 'boolean' },
            emptyNodes: { required: true, type: 'boolean' },
            dialects: { required: true, arrayItem: { check: 'nonEmpty' } },
            canStream: { required: true, type: 'boolean' },
            detectSupernodes: { required: true, type: 'boolean' },
            canDryRun: { required: true, type: 'boolean' }
        });
        if (Utils.noValue(this.features.edgeProperties) &&
            Utils.hasValue(this.features.alternativeIds)) {
            throw Errors.technical('bug', 'The feature alternativeIds can be true only if the feature edgeProperties is true.');
        }
        this.isSupernodeCache = new CappedQueue(SUPERNODE_CACHE_SIZE);
    }
    /**
     * Special properties that can't be read, created or updated.
     */
    get specialProperties() {
        return this.driver.$specialProperties;
    }
    /**
     * Create a GraphDAO instance.
     *
     * @param vendor  Vendor name
     * @param options GraphDAO constructor options
     */
    static createGraphDAOInstance(vendor, options) {
        return DAO.createDAOInstance('Graph', vendor, options);
    }
    /**
     * Throw if a property value is a non-array object.
     *
     * @param properties
     */
    normalizeProperties(properties) {
        const keys = Object.keys(properties);
        const normalized = {};
        let value;
        let key;
        for (let i = 0; i < keys.length; ++i) {
            key = keys[i];
            value = properties[key];
            // ignore null/undefined
            if (value === null || value === undefined) {
                continue;
            }
            // set basic types (string | number | boolean) as they are
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                normalized[key] = value;
                continue;
            }
            // serialize arrays if required
            if (Array.isArray(value)) {
                normalized[key] = this.features.serializeArrayProperties
                    ? JSON.stringify(value)
                    : _.map(value, v => '' + v);
                continue;
            }
            throw Errors.business('invalid_parameter', `Property "${keys[i]}" has an invalid type (${typeof value})`);
        }
        return normalized;
    }
    /**
     * Check if `dialect` is supported by this Graph DAO.
     *
     * @param dialect           Name of a query dialect
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    checkDialect(dialect, throwIfNot = true) {
        if (throwIfNot) {
            // this throws an error if dialect is not in this.features.dialect
            Utils.check.values('dialect', dialect, this.features.dialects);
            return true;
        }
        // non-throwing alternative
        for (let i = 0; i < this.features.dialects.length; ++i) {
            if (this.features.dialects[i] === dialect) {
                return true;
            }
        }
        return false;
    }
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param value
     * @param serializer
     */
    quote(value, serializer) {
        return this.driver.$quote(value, serializer);
    }
    /**
     * Check if the given edge ID is legal. Throw an error if not.
     *
     * @param key
     * @param id
     */
    checkEdgeId(key, id) {
        return this.driver.$checkEdgeId(key, id);
    }
    /**
     * Check if the given node ID is legal. Throw an error if not.
     *
     * @param key
     * @param id
     */
    checkNodeId(key, id) {
        return this.driver.$checkNodeId(key, id);
    }
    /**
     * Check if an array of node IDs is legal. Throw an error if not.
     *
     * @param key
     * @param nodeIds
     * @param [minSize]
     */
    checkNodeIds(key, nodeIds, minSize) {
        Utils.check.array(key, nodeIds, minSize);
        nodeIds.map((nodeId, i) => this.checkNodeId(key + '[' + i + ']', nodeId));
    }
    /**
     * Check if an array of edge IDs is legal. Throw an error if not.
     *
     * @param key
     * @param edgeIds
     * @param [minSize]
     */
    checkEdgeIds(key, edgeIds, minSize) {
        Utils.check.array(key, edgeIds, minSize);
        edgeIds.map((edgeId, i) => this.checkEdgeId(key + '[' + i + ']', edgeId));
    }
    /**
     * Check if an array of alternative IDs is legal.
     *
     * @param key       Field name of this array of IDs
     * @param ids       Array of alternative IDs to check
     * @param [minSize] Minimum size of the array of IDs
     */
    static checkAlternativeIds(key, ids, minSize) {
        Utils.check.stringArray(key, ids, minSize, undefined, true);
    }
    /**
     * Check if the given alternative ID is legal.
     *
     * @param key
     * @param id
     */
    static checkAlternativeId(key, id) {
        Utils.check.nonEmpty(key, id);
    }
    /**
     * Called at the begin of the internal indexation phase for additional initializations.
     * Not called for external indices.
     */
    onInternalIndexation() {
        if (!this.features.canStream) {
            return Errors.business('not_supported', 'Internal indices are not supported by ' + this.vendor + '.', true);
        }
        return this.driver.$onInternalIndexation();
    }
    /**
     * List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     */
    getSimpleSchema() {
        return this.driver.$getSimpleSchema();
    }
    /**
     * Count the number of nodes.
     *
     * @param [approx] Allow an approximated answer
     */
    getNodeCount(approx = false) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting nodes is not supported by ' + this.vendor + '.', true);
        }
        else {
            return this.driver.$getNodeCount(approx);
        }
    }
    /**
     * Count the number of edges.
     *
     * @param [approx] Allow an approximated answer
     */
    getEdgeCount(approx = false) {
        if (!this.features.canCount) {
            return Errors.business('not_supported', 'Counting edges is not supported by ' + this.vendor + '.', true);
        }
        else {
            return this.driver.$getEdgeCount(approx);
        }
    }
    /**
     * @param ids        IDs of the nodes to retrieve the statistics for
     * @param statistics Map indexed by nodeId of LkNodeStatistics where to add the supernode statistic
     */
    addSupernodeStatistic(ids, statistics) {
        // filter out nodes where the supernode statistic is already defined
        const uncheckedNodes = ids.filter(nodeId => Utils.noValue(statistics.get(nodeId).supernode));
        return this.isSuperNode(uncheckedNodes).then(superNodeResult => {
            uncheckedNodes.forEach(nodeId => {
                statistics.get(nodeId).supernode = superNodeResult.get(nodeId);
            });
        });
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param statistics                   Map indexed by nodeId of LkNodeStatistics where to add the digest
     * @param options
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addDigestStatistic(ids, statistics, options) {
        return this.addSupernodeStatistic(ids, statistics).then(() => {
            const [supernodes, ordinaryNodes] = _.partition(ids, id => statistics.get(id).supernode);
            // we add the edge digest only for supernodes
            const addEdgeDigest = Bluebird.map(supernodes, nodeId => {
                return this.getEdgeDigest(nodeId, { readableTypes: options.readableTypes }).then(digest => {
                    statistics.get(nodeId).supernodeDigest = digest;
                });
            });
            // we add the complete digest for other nodes
            const addAdjacencyDigest = Bluebird.map(ordinaryNodes, nodeId => {
                return this.getAdjacencyDigest([nodeId]).then(digest => {
                    statistics.get(nodeId).digest = digest;
                });
            });
            return Bluebird.join(addEdgeDigest, addAdjacencyDigest).return();
        });
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param statistics                   Map indexed by nodeId of LkNodeStatistics where to add the degree
     * @param options
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addDegreeStatistic(ids, statistics, options) {
        return this.addSupernodeStatistic(ids, statistics).then(() => {
            const [supernodes, ordinaryNodes] = _.partition(ids, id => statistics.get(id).supernode);
            const supernodeThreshold = Config.get('advanced.supernodeThreshold');
            // we add the supernodeThreshold for supernodes
            supernodes.forEach(superNodeId => {
                // TODO #1413 remove all unnecessary typescript casting (LkNodeStatistics)
                // map.get does not guarantee that the result is defined. Using an array of IDs
                // along a Map of these IDs is probably not the best way to do things here
                // use the following:
                // class NodeStats extends Map<string, LkNodeStats> {
                //   isSupernode(id: string): boolean {
                //     const s: LkNodeStats | undefined = this.get(id);
                //     return !!s && s.supernode;
                //   }
                // }
                statistics.get(superNodeId).supernodeDegree = supernodeThreshold;
            });
            if (ordinaryNodes.length === 0) {
                return;
            }
            // we add the degree for other nodes
            return this.getNodeDegree(ordinaryNodes, _.defaults({ discreteResults: true }, options)).then(nodeDegreeResult => {
                ordinaryNodes.forEach(nodeId => {
                    const degree = nodeDegreeResult.get(nodeId);
                    statistics.get(nodeId).degree = degree;
                });
            });
        });
    }
    /**
     * @param nodes                        Nodes without statistics
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    addStatistics(nodes, options) {
        if (!options.withDigest && !options.withDegree) {
            return Bluebird.resolve(nodes);
        }
        // we divide the input into slices of NODE_STATISTICS_BATCH_SIZE nodes for which we batch the statistics request
        return Utils.sliceMap(nodes, NODE_STATISTICS_BATCH_SIZE, currentBatch => {
            const nodeIds = currentBatch.map(node => node.id);
            // add statistics for each node slice then merge the slices
            return this.getStatistics(nodeIds, options)
                .then(statisticsByNodeId => {
                currentBatch.forEach(node => {
                    node.statistics = statisticsByNodeId.get(node.id);
                });
            })
                .return(currentBatch);
        }).then(batchesWithStatistics => _.flatten(batchesWithStatistics));
    }
    /**
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    getStatistics(ids, options) {
        if (_.isEmpty(ids)) {
            return Bluebird.resolve(new Map());
        }
        const statisticsByNodeId = ids.reduce((statistics, nodeId) => statistics.set(nodeId, {}), new Map());
        return Bluebird.resolve()
            .then(() => {
            if (options.withDigest) {
                return this.addDigestStatistic(ids, statisticsByNodeId, options);
            }
            return;
        })
            .then(() => {
            if (options.withDegree) {
                return this.addDegreeStatistic(ids, statisticsByNodeId, options);
            }
            return;
        })
            .return(statisticsByNodeId);
    }
    /**
     * Get a stream of all nodes.
     *
     * @param options
     * @param options.chunkSize
     * @param options.offset
     */
    getNodeStream(options) {
        if (!this.features.canStream) {
            return Errors.business('not_supported', 'Internal indices are not supported by ' + this.vendor + '.', true);
        }
        return this.driver.$getNodeStream(options);
    }
    /**
     * Get a list of nodes by ID.
     *
     * @param options
     * @param options.ids                  List of IDs to read
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.alternativeIdIndex] The index to use to resolve nodes by alternativeId
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    getNodesByID(options) {
        return Bluebird.resolve().then(() => {
            if (_.isEmpty(options.ids)) {
                return [];
            }
            // check IDs
            if (Utils.noValue(options.alternativeId)) {
                this.checkNodeIds('options.ids', options.ids);
            }
            else {
                if (!this.features.alternativeIds) {
                    throw Errors.business('not_supported', `Alternative ids are not supported by ${this.vendor}.`);
                }
                GraphDAO.checkAlternativeIds('options.ids', options.ids);
            }
            return Utils.sliceMap(options.ids, READ_BY_ID_BATCH_SIZE, batchIds => {
                const sliceOptions = Utils.clone(options);
                sliceOptions.ids = batchIds;
                return this.driver.$getNodesByID(sliceOptions);
            })
                .then(nodeBatches => _.flatten(nodeBatches))
                .then(nodes => {
                if (!options.ignoreMissing) {
                    Utils.checkMissing('node', options.ids, nodes, options.alternativeId);
                }
                return nodes;
            })
                .then(nodes => this.addStatistics(nodes, options));
        });
    }
    /**
     * Get a list of edges by ID.
     *
     * @param options
     * @param options.ids                  List of IDs to read
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.alternativeIdIndex] The index to use to resolve edges by alternativeId
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     */
    getEdgesByID(options) {
        return Bluebird.resolve().then(() => {
            if (_.isEmpty(options.ids)) {
                return [];
            }
            // check IDs
            if (Utils.noValue(options.alternativeId)) {
                this.checkEdgeIds('options.ids', options.ids);
            }
            else {
                if (!this.features.alternativeIds) {
                    throw Errors.business('not_supported', `Alternative ids are not supported by ${this.vendor}.`);
                }
                GraphDAO.checkAlternativeIds('options.ids', options.ids);
            }
            return Utils.sliceMap(options.ids, READ_BY_ID_BATCH_SIZE, batchIds => {
                const sliceOptions = Utils.clone(options);
                sliceOptions.ids = batchIds;
                return this.driver.$getEdgesByID(sliceOptions);
            })
                .then(edgeBatches => _.flatten(edgeBatches))
                .then(edges => {
                if (!options.ignoreMissing) {
                    Utils.checkMissing('edge', options.ids, edges, options.alternativeId);
                }
                return edges;
            });
        });
    }
    /**
     * Get all the adjacent nodes and edges to one or more source nodes (`nodeIds`).
     *
     * @param nodeIds                      IDs of the nodes to retrieve the neighbors for
     * @param options
     * @param [options.limit]              Maximum number of returned nodes
     * @param [options.limitType]          Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param [options.nodeCategories]     Exclusive list of node categories to restrict the result (used for the expand)
     * @param [options.edgeTypes]          Exclusive list of edge types to restrict the result (used for the expand)
     * @param [options.ignoredNodeIds]     IDs of nodes we do not want in the results
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree and the expand)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the expand)
     */
    getAdjacentNodes(nodeIds, options) {
        return Bluebird.resolve()
            .then(() => {
            // TODO #1424 check if is the best error message (maybe we need an ExpandOptions model?)
            this.checkNodeIds('nodeIds', nodeIds, 1);
            if (Utils.hasValue(options.ignoredNodeIds)) {
                this.checkNodeIds('ignoredNodeIds', options.ignoredNodeIds);
            }
            if (Utils.hasValue(options.nodeCategories)) {
                Utils.check.stringArray('nodeCategories', options.nodeCategories, 1, undefined, true);
            }
            else {
                // to filter the expand on the readable categories is just an optimization
                // the resulting subgraph will be filtered in the DataProxy anyway
                options.nodeCategories = options.readableCategories;
            }
            if (Utils.hasValue(options.edgeTypes)) {
                Utils.check.stringArray('edgeTypes', options.edgeTypes, 1, undefined, true);
            }
            else {
                options.edgeTypes = options.readableTypes;
            }
            if ((Utils.hasValue(options.nodeCategories) && _.isEmpty(options.nodeCategories)) ||
                (Utils.hasValue(options.edgeTypes) && _.isEmpty(options.edgeTypes))) {
                // nothing to expand
                return [];
            }
            if (Utils.hasValue(options.limit)) {
                Utils.check.integer('limit', options.limit, 1, MAX_GET_ADJACENT_NODES_LIMIT);
            }
            else {
                // #1628 if limit is not defined we set it at 10k nodes
                options.limit = MAX_GET_ADJACENT_NODES_LIMIT;
            }
            if (Utils.noValue(options.limitType)) {
                options.limitType = 'id';
            }
            Utils.check.values('limitType', options.limitType, ['id', 'lowestDegree', 'highestDegree']);
            const expandOptions = {
                limit: options.limit,
                limitType: options.limitType,
                nodeCategories: options.nodeCategories,
                edgeTypes: options.edgeTypes,
                ignoredNodeIds: options.ignoredNodeIds
            };
            return this.driver
                .$getNodesByID({ ids: nodeIds })
                .then(existingNodes => Utils.checkMissing('node', nodeIds, existingNodes))
                .then(() => this.driver.$getAdjacentNodes(nodeIds, expandOptions));
        })
            .then(nodes => this.addStatistics(nodes, options));
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param nodeIds                  IDs of the first set of nodes
     * @param otherNodeIds             IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     */
    getMutualEdges(nodeIds, otherNodeIds, options) {
        if (_.isEmpty(nodeIds) || _.isEmpty(otherNodeIds)) {
            return Bluebird.resolve([]);
        }
        if ((Utils.hasValue(options.edgeTypes) && _.isEmpty(options.edgeTypes)) ||
            (Utils.hasValue(options.nodeCategories) && _.isEmpty(options.nodeCategories))) {
            // no edge to retrieve
            return Bluebird.resolve([]);
        }
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds);
            this.checkNodeIds('otherNodeIds', otherNodeIds);
            return this.driver.$getMutualEdges(nodeIds, otherNodeIds, options, this.isSupernodeCache);
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param nodeId                  ID of the node
     * @param options
     * @param [options.readableTypes] Exclusive list of edge types to restrict the result
     */
    getEdgeDigest(nodeId, options) {
        return Bluebird.resolve().then(() => {
            this.checkNodeId('nodeId', nodeId);
            return this.driver.$getEdgeDigest(nodeId, options);
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param nodeIds IDs of the nodes
     */
    getAdjacencyDigest(nodeIds) {
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds, 1);
            return this.driver.$getAdjacencyDigest(nodeIds);
        });
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * @param nodeIds IDs of the nodes
     */
    isSuperNode(nodeIds) {
        if (!this.features.detectSupernodes) {
            const noSuperNode = nodeIds.reduce((nodeIsSuperNode, nodeId) => nodeIsSuperNode.set(nodeId, false), new Map());
            return Bluebird.resolve(noSuperNode);
        }
        if (_.isEmpty(nodeIds)) {
            return Bluebird.resolve(new Map());
        }
        const supernodeThreshold = Config.get('advanced.supernodeThreshold');
        this.checkNodeIds('nodeIds', nodeIds);
        return this.driver
            .$isSuperNode(nodeIds, supernodeThreshold)
            .then((supernodesMap) => {
            for (const [nodeId, isSuperNode] of supernodesMap.entries()) {
                // we cache every node that is a supernode (up to SUPERNODE_CACHE_SIZE nodes)
                if (isSuperNode) {
                    this.isSupernodeCache.add(nodeId);
                }
            }
            return supernodesMap;
        });
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param nodeIds                      IDs of the nodes
     * @param options
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     * @param [options.discreteResults]    Whether to return the degree of each node
     */
    getNodeDegree(nodeIds, options) {
        if ((Utils.hasValue(options.readableTypes) && _.isEmpty(options.readableTypes)) ||
            (Utils.hasValue(options.readableCategories) && _.isEmpty(options.readableCategories))) {
            // no readable type or category, we return a degree of 0 for every node
            const zeroDegree = nodeIds.reduce((acc, v) => acc.set(v, 0), new Map());
            return Bluebird.resolve(zeroDegree);
        }
        return Bluebird.resolve().then(() => {
            this.checkNodeIds('nodeIds', nodeIds, 1);
            return this.driver.$getNodeDegree(nodeIds, options);
        });
    }
    /**
     * Add a node to the graph.
     *
     * @param newNode
     */
    createNode(newNode) {
        return Bluebird.resolve().then(() => {
            // clone to avoid modifying the original parameter
            newNode = Utils.clone(newNode);
            newNode.data = this.normalizeProperties(newNode.data);
            // check amount of node category
            Utils.check.stringArray('categories', newNode.categories, this.features.minNodeCategories, this.features.maxNodeCategories);
            // if empty nodes are not allowed, check that we have some properties or categories
            if (!this.features.emptyNodes && this.isEmptyNode(newNode)) {
                throw Errors.business('invalid_parameter', 'A node must have at least one property or one category.');
            }
            return this.driver.$createNode(newNode);
        });
    }
    /**
     * Update the properties and categories of a node.
     * Check if the node exists and fail if it doesn't.
     *
     * @param nodeId                         ID of the node to update
     * @param nodeUpdate
     * @param [nodeUpdate.data]              Properties to update
     * @param [nodeUpdate.deletedProperties] Properties to delete
     * @param [nodeUpdate.addedCategories]   Categories to add
     * @param [nodeUpdate.deletedCategories] Categories to delete
     */
    updateNode(nodeId, nodeUpdate) {
        return Bluebird.resolve().then(() => {
            this.checkNodeId('nodeId', nodeId);
            // clone to avoid modifying the original parameter
            nodeUpdate = Utils.clone(nodeUpdate);
            // check added/updated properties (an empty property key is not allowed)
            if (Utils.noValue(nodeUpdate.data)) {
                nodeUpdate.data = {};
                // TODO 2.6.0 do it in normalizeProperties (also for updateEdge)
            }
            // TODO 2.6.0 checkEmptyPropertyKey (also for updateEdge)
            nodeUpdate.data = this.normalizeProperties(nodeUpdate.data);
            // check deleted properties
            if (Utils.noValue(nodeUpdate.deletedProperties)) {
                nodeUpdate.deletedProperties = [];
            }
            Utils.check.stringArray('deletedProperties', nodeUpdate.deletedProperties, 0, undefined, true);
            // check added categories
            if (Utils.noValue(nodeUpdate.addedCategories)) {
                nodeUpdate.addedCategories = [];
            }
            Utils.check.stringArray('addedCategories', nodeUpdate.addedCategories, 0, undefined, true);
            // check deleted categories
            if (Utils.noValue(nodeUpdate.deletedCategories)) {
                nodeUpdate.deletedCategories = [];
            }
            Utils.check.stringArray('deletedCategories', nodeUpdate.deletedCategories, 0, undefined, true);
            // check category immutability
            if (this.features.immutableNodeCategories) {
                if (nodeUpdate.addedCategories.length) {
                    throw Errors.business('not_implemented', 'Cannot add categories to a node (immutable).');
                }
                if (nodeUpdate.deletedCategories.length) {
                    throw Errors.business('not_implemented', 'Cannot delete categories from a node (immutable).');
                }
            }
            return this.driver
                .$updateNode(nodeId, nodeUpdate)
                .then(node => {
                if (!node) {
                    throw Errors.business('node_not_found', `Node #${nodeId} was not found.`);
                }
                return node;
            });
        });
    }
    /**
     * Delete a node and its adjacent edges from the graph.
     *
     * @param nodeId ID of the node to delete
     */
    deleteNode(nodeId) {
        return Bluebird.resolve().then(() => {
            this.checkNodeId('nodeId', nodeId);
            return this.driver.$deleteNode(nodeId).then(found => {
                if (found) {
                    return;
                }
                throw Errors.business('node_not_found', `Node #${nodeId} was not found.`);
            });
        });
    }
    /**
     * Get a stream of all edges.
     *
     * @param options
     * @param options.chunkSize
     * @param options.offset
     */
    getEdgeStream(options) {
        if (!this.features.canStream) {
            return Errors.business('not_supported', 'Internal indices are not supported by ' + this.vendor + '.', true);
        }
        return this.driver.$getEdgeStream(options);
    }
    /**
     * Add an edge to the graph.
     *
     * @param newEdge The edge to create
     */
    createEdge(newEdge) {
        return Bluebird.resolve().then(() => {
            // clone to avoid modifying the original parameter
            newEdge = Utils.clone(newEdge);
            // check if source and target are legal node ids
            this.checkNodeId('source', newEdge.source);
            this.checkNodeId('target', newEdge.target);
            newEdge.data = this.normalizeProperties(newEdge.data);
            if (!this.features.edgeProperties && !_.isEqual(newEdge.data, {})) {
                throw Errors.business('not_supported', 'Edge properties are not supported by ' + this.vendor + '.');
            }
            return this.driver.$createEdge(newEdge);
        });
    }
    /**
     * Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     *
     * @param edgeId                         ID of the edge to update
     * @param edgeUpdate
     * @param [edgeUpdate.data]              Properties updates
     * @param [edgeUpdate.deletedProperties] Properties to delete
     */
    updateEdge(edgeId, edgeUpdate) {
        return Bluebird.resolve().then(() => {
            if (!this.features.edgeProperties) {
                throw Errors.business('not_supported', 'Edge properties are not supported by ' + this.vendor + '.');
            }
            this.checkEdgeId('edgeId', edgeId);
            // clone to avoid modifying the original parameter
            edgeUpdate = Utils.clone(edgeUpdate);
            // check added/updated properties (an empty property key is not allowed)
            if (Utils.noValue(edgeUpdate.data)) {
                edgeUpdate.data = {};
            }
            edgeUpdate.data = this.normalizeProperties(edgeUpdate.data);
            // check edge type (immutable)
            // TODO #1424 edgeUpdate.type shouldn't have reach this point, this should have been checked at the route level
            // TODO 2.6.0 not working update edge type
            // tslint:disable-next-line:no-any
            if (Utils.hasValue(edgeUpdate.type)) {
                return Errors.business('not_implemented', 'Cannot change the type of an edge.', true);
            }
            // check deleted properties
            if (Utils.noValue(edgeUpdate.deletedProperties)) {
                edgeUpdate.deletedProperties = [];
            }
            Utils.check.stringArray('deletedProperties', edgeUpdate.deletedProperties, 0, undefined, true);
            return this.driver
                .$updateEdge(edgeId, edgeUpdate)
                .then(edge => {
                if (!edge) {
                    throw Errors.business('edge_not_found', `Edge #${edgeId} was not found.`);
                }
                return edge;
            });
        });
    }
    /**
     * Delete an edge from the graph.
     *
     * @param edgeId ID of the edge to delete
     */
    deleteEdge(edgeId) {
        return Bluebird.resolve().then(() => {
            this.checkEdgeId('edgeId', edgeId);
            return this.driver.$deleteEdge(edgeId).then(found => {
                if (found) {
                    return;
                }
                throw Errors.business('edge_not_found', `Edge #${edgeId} was not found.`);
            });
        });
    }
    /**
     * Check that the given graph query is syntactically correct.
     */
    dryRun(query) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.features.canDryRun) {
                return Promise.resolve();
            }
            return Promise.resolve().then(() => {
                return this.driver.$dryRun(query);
            });
        });
    }
    /**
     * Generate template data with dummy values to obtain a valid query for a dry run.
     */
    getDummyTemplateData(templateFields) {
        const templateData = {};
        const dummyString = '-';
        // TODO #1555 Generate dummy values for TemplateField Types
        for (const template of templateFields) {
            let dummyValue;
            switch (template.type) {
                case umd_1.TemplateFieldType.NODE:
                    dummyValue = this.driver.$getDummyNodeId();
                    break;
                case umd_1.TemplateFieldType.NODE_SET:
                    dummyValue = [this.driver.$getDummyNodeId()];
                    break;
                case umd_1.TemplateFieldType.BOOLEAN:
                    dummyValue = false;
                    break;
                case umd_1.TemplateFieldType.NUMBER:
                    dummyValue = (template.options && (template.options.min || template.options.max)) || 0;
                    break;
                case umd_1.TemplateFieldType.ENUM:
                    dummyValue = _.get(template.options, 'values.0.value');
                    break;
                case umd_1.TemplateFieldType.DATE:
                case umd_1.TemplateFieldType.DATE_TIME:
                    const date = ((template.options &&
                        (template.options.default || template.options.min || template.options.max)) ||
                        '1969-01-01');
                    dummyValue = new Date(date).toISOString();
                    break;
                default:
                    dummyValue = dummyString;
            }
            templateData[template.key] = dummyValue;
        }
        return templateData;
    }
    /**
     * Return true is the query is a write query.
     */
    isWrite(query) {
        return this.driver.$isWrite(query);
    }
    /**
     * Check if a query is correct.
     * Throw if the query is not valid or not authorized.
     * Return true if the query is a write query.
     */
    checkQuery(query) {
        return this.driver.$checkQuery(query);
    }
    /**
     * Return true if the node specified is empty.
     *
     * @param node
     */
    isEmptyNode(node) {
        return this.driver.$isEmptyNode(node);
    }
    rawQuery(options, populated = true) {
        return Bluebird.resolve()
            .then(() => {
            options = _.defaults(options);
            if (options.dialect === undefined || options.dialect === null) {
                options.dialect = this.features.dialects[0];
            }
            Utils.check.string('options.dialect', options.dialect, true);
            this.checkDialect(options.dialect);
            Utils.check.stringArray('options.queries', options.queries, 1, undefined, true);
            Utils.check.boolean('options.populated', populated);
            Utils.check.integer('options.limit', options.limit, 1);
            return this.driver.$rawQuery({
                dialect: options.dialect,
                queries: options.queries,
                populated: populated,
                limit: options.limit
            });
        })
            .then(readableStream => {
            if (!populated) {
                // we can't add statistics if the result is not populated
                return readableStream;
            }
            const self = this;
            let spool = [];
            return Utils.safePipe(readableStream, through(function (match) {
                spool.push(match);
                if (spool.length >= NODE_STATISTICS_BATCH_SIZE) {
                    // stop the flow to be able to retrieve the digest after collecting NODE_STATISTICS_BATCH_SIZE matches
                    // @ts-ignore
                    this.pause();
                    self
                        .addQueryMatchPopulatedStatistics(spool, options)
                        .then(matchesWithStatistics => {
                        matchesWithStatistics.forEach(matchWithStats => {
                            // @ts-ignore
                            this.emit('data', matchWithStats);
                        });
                        // spool = [] has to be called before this.resume()
                        // this.resume() may synchronously call this function again
                        spool = [];
                        // @ts-ignore
                        this.resume();
                    })
                        .catch(error => {
                        // @ts-ignore
                        this.emit('error', error);
                    });
                }
            }, function () {
                self
                    .addQueryMatchPopulatedStatistics(spool, options)
                    .then(matchesWithStatistics => {
                    matchesWithStatistics.forEach(match => {
                        // @ts-ignore
                        this.emit('data', match);
                    });
                    // @ts-ignore
                    this.emit('end');
                })
                    .catch(error => {
                    // @ts-ignore
                    this.emit('error', error);
                });
            }));
        });
    }
    /**
     * Add statistics to the nodes in each `QueryMatchPopulated`.
     *
     * We want to avoid to retrieve the statistics for the same node twice.
     * To avoid that, we extract all the nodes from the matches, we deduplicate them,
     * we retrieve the statistics for the deduplicated nodes and we set
     * the node statistics to the respective nodes in the matches.
     *
     * @param {QueryMatchPopulated[]} matches
     * @param {object}                options
     * @param {boolean}               [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param {boolean}               [options.withDegree]         Whether to include the degree in the returned nodes
     * @param {string[]}              [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param {string[]}              [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    addQueryMatchPopulatedStatistics(matches, options) {
        // 1) we extract all the nodes from the matches and we deduplicate them
        const nodesByNodeId = new Map();
        for (let i = 0; i < matches.length; i++) {
            for (let y = 0; y < matches[i].nodes.length; y++) {
                const node = matches[i].nodes[y];
                nodesByNodeId.set(node.id, node);
            }
        }
        // 2) we retrieve the statistics for the deduplicated nodes
        const nodes = Array.from(nodesByNodeId.values());
        return this.addStatistics(nodes, options).then(() => {
            for (let i = 0; i < matches.length; i++) {
                for (let y = 0; y < matches[i].nodes.length; y++) {
                    const node = matches[i].nodes[y];
                    // 3) we set the node statistics to the respective nodes in the matches
                    node.statistics = nodesByNodeId.get(node.id).statistics;
                }
            }
            return matches;
        });
    }
}
module.exports = GraphDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2dyYXBoREFPLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7Ozs7Ozs7O0FBRUgsZ0JBQWdCO0FBQ2hCLHFDQUFxQztBQUNyQywrQ0FLK0I7QUFDL0IsNEJBQTRCO0FBQzVCLG1DQUFtQztBQUVuQyxXQUFXO0FBQ1gsd0RBQXlEO0FBTXpELHNDQUF1QztBQUN2QyxTQUFTO0FBQ1QsOEJBQStCO0FBRS9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sMEJBQTBCLEdBQUcsRUFBRSxDQUFDO0FBQ3RDLE1BQU0scUJBQXFCLEdBQUcsRUFBRSxDQUFDO0FBQ2pDLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDO0FBWWxDLE1BQU0sNEJBQTRCLEdBQUcsS0FBSyxDQUFDO0FBRTNDOzs7Ozs7Ozs7Ozs7Ozs7O0dBZ0JHO0FBRUgsTUFBZSxRQUF3RCxTQUFRLEdBQVM7SUFLdEY7Ozs7Ozs7O09BUUc7SUFDSCxZQUNFLE1BQWMsRUFDZCxlQUF5QixFQUN6QixnQkFBMEIsRUFDMUIsT0FBK0IsRUFDL0IsUUFBdUIsRUFDdkIsVUFBMEQsRUFDMUQsT0FBMEU7UUFFMUUsS0FBSyxDQUNILE9BQU8sRUFDUCxNQUFNLEVBQ04sZUFBZSxFQUNmLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztZQUN0QixpRUFBaUU7WUFDakUsbUJBQW1CO1lBQ25CLG1CQUFtQjtZQUNuQix1RUFBdUU7WUFDdkUsd0JBQXdCO1lBQ3hCLHdCQUF3QjtZQUN4Qix1RUFBdUU7WUFDdkUsa0JBQWtCO1lBQ2xCLG1CQUFtQjtTQUNwQixDQUFDLEVBQ0YsT0FBTyxFQUNQLFNBQVMsRUFDVCxVQUFVLEVBQ1YsT0FBTyxDQUNSLENBQUM7UUFFRixJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxtQ0FBbUMsQ0FBQyxDQUFDO1NBQ3BFO1FBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDekIsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRTtZQUMzQyxjQUFjLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDakQsdUJBQXVCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDMUQsaUJBQWlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUMxRCxpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUMxQyx3QkFBd0IsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMzRCxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDM0MsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3pDLGNBQWMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUNqRCxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDN0MsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDLEVBQUM7WUFDMUQsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzVDLGdCQUFnQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ25ELFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztTQUM3QyxDQUFDLENBQUM7UUFFSCxJQUNFLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7WUFDM0MsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUM1QztZQUNBLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FDcEIsS0FBSyxFQUNMLG9GQUFvRixDQUNyRixDQUFDO1NBQ0g7UUFFRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxXQUFXLENBQVMsb0JBQW9CLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLGlCQUFpQjtRQUNuQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUM7SUFDeEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUNsQyxNQUFjLEVBQ2QsT0FBK0I7UUFFL0IsT0FBTyxHQUFHLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLENBR3BELENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLG1CQUFtQixDQUFDLFVBQWtDO1FBQzVELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsTUFBTSxVQUFVLEdBQW1DLEVBQUUsQ0FBQztRQUN0RCxJQUFJLEtBQUssQ0FBQztRQUNWLElBQUksR0FBRyxDQUFDO1FBRVIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDcEMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNkLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFeEIsd0JBQXdCO1lBQ3hCLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO2dCQUN6QyxTQUFTO2FBQ1Y7WUFFRCwwREFBMEQ7WUFDMUQsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLE9BQU8sS0FBSyxLQUFLLFNBQVMsRUFBRTtnQkFDeEYsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDeEIsU0FBUzthQUNWO1lBRUQsK0JBQStCO1lBQy9CLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDeEIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsd0JBQXdCO29CQUN0RCxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsU0FBUzthQUNWO1lBRUQsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsYUFBYSxJQUFJLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixPQUFPLEtBQUssR0FBRyxDQUM5RCxDQUFDO1NBQ0g7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxZQUFZLENBQUMsT0FBZSxFQUFFLGFBQXNCLElBQUk7UUFDOUQsSUFBSSxVQUFVLEVBQUU7WUFDZCxrRUFBa0U7WUFDbEUsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQy9ELE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFFRCwyQkFBMkI7UUFDM0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN0RCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtnQkFDekMsT0FBTyxJQUFJLENBQUM7YUFDYjtTQUNGO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxLQUFLLENBQUMsS0FBd0IsRUFBRSxVQUE4QjtRQUNuRSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXLENBQUMsR0FBVyxFQUFFLEVBQVU7UUFDeEMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksV0FBVyxDQUFDLEdBQVcsRUFBRSxFQUFVO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxZQUFZLENBQUMsR0FBVyxFQUFFLE9BQWlCLEVBQUUsT0FBZ0I7UUFDbEUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksWUFBWSxDQUFDLEdBQVcsRUFBRSxPQUFpQixFQUFFLE9BQWdCO1FBQ2xFLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxHQUFXLEVBQUUsR0FBYSxFQUFFLE9BQWdCO1FBQzVFLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsa0JBQWtCLENBQUMsR0FBVyxFQUFFLEVBQVU7UUFDdEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7O09BR0c7SUFDSSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFO1lBQzVCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLHdDQUF3QyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUM1RCxJQUFJLENBQ0wsQ0FBQztTQUNIO1FBRUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDN0MsQ0FBQztJQUVEOzs7T0FHRztJQUNJLGVBQWU7UUFDcEIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxZQUFZLENBQUMsU0FBa0IsS0FBSztRQUN6QyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFDM0IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2YscUNBQXFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQ3pELElBQUksQ0FDTCxDQUFDO1NBQ0g7YUFBTTtZQUNMLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUM7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFlBQVksQ0FBQyxTQUFrQixLQUFLO1FBQ3pDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUMzQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGVBQWUsRUFDZixxQ0FBcUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFDekQsSUFBSSxDQUNMLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxQztJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSyxxQkFBcUIsQ0FDM0IsR0FBYSxFQUNiLFVBQXlDO1FBRXpDLG9FQUFvRTtRQUNwRSxNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQ3pDLEtBQUssQ0FBQyxPQUFPLENBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsU0FBUyxDQUFDLENBQ3RFLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQzdELGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzdCLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFzQixDQUFDLFNBQVMsR0FBRyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxrQkFBa0IsQ0FDeEIsR0FBYSxFQUNiLFVBQXlDLEVBQ3pDLE9BRUM7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMzRCxNQUFNLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQzdDLEdBQUcsRUFDSCxFQUFFLENBQUMsRUFBRSxDQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFzQixDQUFDLFNBQVMsQ0FDekQsQ0FBQztZQUVGLDZDQUE2QztZQUM3QyxNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDdEQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ3JGLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFzQixDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUM7Z0JBQ3hFLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFFSCw2Q0FBNkM7WUFDN0MsTUFBTSxrQkFBa0IsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDOUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDcEQsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDL0QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxrQkFBa0IsQ0FDeEIsR0FBYSxFQUNiLFVBQXlDLEVBQ3pDLE9BR0M7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMzRCxNQUFNLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQzdDLEdBQUcsRUFDSCxFQUFFLENBQUMsRUFBRSxDQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFzQixDQUFDLFNBQVMsQ0FDekQsQ0FBQztZQUVGLE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBVyxDQUFDO1lBRS9FLCtDQUErQztZQUMvQyxVQUFVLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUMvQiwwRUFBMEU7Z0JBQzFFLCtFQUErRTtnQkFDL0UsMEVBQTBFO2dCQUMxRSxxQkFBcUI7Z0JBQ3JCLHFEQUFxRDtnQkFDckQsdUNBQXVDO2dCQUN2Qyx1REFBdUQ7Z0JBQ3ZELGlDQUFpQztnQkFDakMsTUFBTTtnQkFDTixJQUFJO2dCQUNILFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFzQixDQUFDLGVBQWUsR0FBRyxrQkFBa0IsQ0FBQztZQUN6RixDQUFDLENBQUMsQ0FBQztZQUVILElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQzlCLE9BQU87YUFDUjtZQUVELG9DQUFvQztZQUNwQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxlQUFlLEVBQUUsSUFBSSxFQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQ3pGLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ2pCLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzdCLE1BQU0sTUFBTSxHQUFJLGdCQUF3QyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDcEUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQXNCLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDL0QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxhQUFhLENBQ25CLEtBQWUsRUFDZixPQUtDO1FBRUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELGdIQUFnSDtRQUNoSCxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLDBCQUEwQixFQUFFLFlBQVksQ0FBQyxFQUFFO1lBQ3RFLE1BQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbEQsMkRBQTJEO1lBQzNELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO2lCQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDekIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNwRCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQztpQkFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLGFBQWEsQ0FDbEIsR0FBYSxFQUNiLE9BS0M7UUFFRCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbEIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztTQUNwQztRQUVELE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FDbkMsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFDbEQsSUFBSSxHQUFHLEVBQUUsQ0FDVixDQUFDO1FBRUYsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUU7Z0JBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNsRTtZQUNELE9BQU87UUFDVCxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO2dCQUN0QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDbEU7WUFDRCxPQUFPO1FBQ1QsQ0FBQyxDQUFDO2FBQ0QsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGFBQWEsQ0FBQyxPQUE0QztRQUMvRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7WUFDNUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2Ysd0NBQXdDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQzVELElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSSxZQUFZLENBQUMsT0FTbkI7UUFDQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzFCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCxZQUFZO1lBQ1osSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9DO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRTtvQkFDakMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixlQUFlLEVBQ2Ysd0NBQXdDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FDdkQsQ0FBQztpQkFDSDtnQkFFRCxRQUFRLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMxRDtZQUVELE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUNuRSxNQUFNLFlBQVksR0FJZCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN6QixZQUFZLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDNUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUM7aUJBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDM0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUMxQixLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQ3ZFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxZQUFZLENBQUMsT0FLbkI7UUFDQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzFCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCxZQUFZO1lBQ1osSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9DO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRTtvQkFDakMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixlQUFlLEVBQ2Ysd0NBQXdDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FDdkQsQ0FBQztpQkFDSDtnQkFFRCxRQUFRLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMxRDtZQUVELE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUNuRSxNQUFNLFlBQVksR0FJZCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN6QixZQUFZLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDNUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUM7aUJBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDM0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFO29CQUMxQixLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQ3ZFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNJLGdCQUFnQixDQUNyQixPQUFpQixFQUNqQixPQVVDO1FBRUQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRXpDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7Z0JBQzFDLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO2FBQzdEO1lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDMUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3ZGO2lCQUFNO2dCQUNMLDBFQUEwRTtnQkFDMUUsa0VBQWtFO2dCQUNsRSxPQUFPLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQzthQUNyRDtZQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3JDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0U7aUJBQU07Z0JBQ0wsT0FBTyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDO2FBQzNDO1lBRUQsSUFDRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUM3RSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQ25FO2dCQUNBLG9CQUFvQjtnQkFDcEIsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSw0QkFBNEIsQ0FBQyxDQUFDO2FBQzlFO2lCQUFNO2dCQUNMLHVEQUF1RDtnQkFDdkQsT0FBTyxDQUFDLEtBQUssR0FBRyw0QkFBNEIsQ0FBQzthQUM5QztZQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3BDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2FBQzFCO1lBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7WUFFNUYsTUFBTSxhQUFhLEdBQUc7Z0JBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSztnQkFDcEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFvRDtnQkFDdkUsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO2dCQUN0QyxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzVCLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYzthQUN2QyxDQUFDO1lBRUYsT0FBTyxJQUFJLENBQUMsTUFBTTtpQkFDZixhQUFhLENBQUMsRUFBQyxHQUFHLEVBQUUsT0FBTyxFQUFDLENBQUM7aUJBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztpQkFDekUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7UUFDdkUsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxjQUFjLENBQ25CLE9BQWlCLEVBQ2pCLFlBQXNCLEVBQ3RCLE9BR0M7UUFFRCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNqRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7UUFFRCxJQUNFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUM3RTtZQUNBLHNCQUFzQjtZQUN0QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7UUFFRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBRWhELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDNUYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksYUFBYSxDQUNsQixNQUFjLEVBQ2QsT0FFQztRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDbkMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGtCQUFrQixDQUFDLE9BQWlCO1FBQ3pDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQUMsT0FBaUI7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUU7WUFDbkMsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FDaEMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFDL0QsSUFBSSxHQUFHLEVBQUUsQ0FDVixDQUFDO1lBQ0YsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3RDO1FBRUQsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3RCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUM7U0FDcEM7UUFFRCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQVcsQ0FBQztRQUUvRSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN0QyxPQUFPLElBQUksQ0FBQyxNQUFNO2FBQ2YsWUFBWSxDQUFDLE9BQU8sRUFBRSxrQkFBa0IsQ0FBQzthQUN6QyxJQUFJLENBQUMsQ0FBQyxhQUFtQyxFQUFFLEVBQUU7WUFDNUMsS0FBSyxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxJQUFJLGFBQWEsQ0FBQyxPQUFPLEVBQUUsRUFBRTtnQkFDM0QsNkVBQTZFO2dCQUM3RSxJQUFJLFdBQVcsRUFBRTtvQkFDZixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUNuQzthQUNGO1lBRUQsT0FBTyxhQUFhLENBQUM7UUFDdkIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSSxhQUFhLENBQ2xCLE9BQWlCLEVBQ2pCLE9BSUM7UUFFRCxJQUNFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDM0UsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFDckY7WUFDQSx1RUFBdUU7WUFDdkUsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQztZQUN4RSxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDckM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN6QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksVUFBVSxDQUFDLE9BQXlCO1FBQ3pDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsa0RBQWtEO1lBQ2xELE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9CLE9BQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV0RCxnQ0FBZ0M7WUFDaEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3JCLFlBQVksRUFDWixPQUFPLENBQUMsVUFBVSxFQUNsQixJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUNoQyxDQUFDO1lBRUYsbUZBQW1GO1lBQ25GLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMxRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsQ0FDMUQsQ0FBQzthQUNIO1lBRUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFvQyxDQUFDLENBQUM7UUFDdkUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNJLFVBQVUsQ0FDZixNQUFjLEVBQ2QsVUFLQztRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFbkMsa0RBQWtEO1lBQ2xELFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXJDLHdFQUF3RTtZQUN4RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNsQyxVQUFVLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDckIsZ0VBQWdFO2FBQ2pFO1lBRUQseURBQXlEO1lBRXpELFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU1RCwyQkFBMkI7WUFDM0IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUMvQyxVQUFVLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO2FBQ25DO1lBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3JCLG1CQUFtQixFQUNuQixVQUFVLENBQUMsaUJBQWlCLEVBQzVCLENBQUMsRUFDRCxTQUFTLEVBQ1QsSUFBSSxDQUNMLENBQUM7WUFFRix5QkFBeUI7WUFDekIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDN0MsVUFBVSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7YUFDakM7WUFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsRUFBRSxVQUFVLENBQUMsZUFBZSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFFM0YsMkJBQTJCO1lBQzNCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDL0MsVUFBVSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQzthQUNuQztZQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUNyQixtQkFBbUIsRUFDbkIsVUFBVSxDQUFDLGlCQUFpQixFQUM1QixDQUFDLEVBQ0QsU0FBUyxFQUNULElBQUksQ0FDTCxDQUFDO1lBRUYsOEJBQThCO1lBQzlCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsRUFBRTtnQkFDekMsSUFBSSxVQUFVLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRTtvQkFDckMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFLDhDQUE4QyxDQUFDLENBQUM7aUJBQzFGO2dCQUNELElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRTtvQkFDdkMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixpQkFBaUIsRUFDakIsbURBQW1ELENBQ3BELENBQUM7aUJBQ0g7YUFDRjtZQUVELE9BQU8sSUFBSSxDQUFDLE1BQU07aUJBQ2YsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQU1wQixDQUFDO2lCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUNULE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLE1BQU0saUJBQWlCLENBQUMsQ0FBQztpQkFDM0U7Z0JBQ0QsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVLENBQUMsTUFBYztRQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5DLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLEtBQUssRUFBRTtvQkFDVCxPQUFPO2lCQUNSO2dCQUVELE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLE1BQU0saUJBQWlCLENBQUMsQ0FBQztZQUM1RSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGFBQWEsQ0FBQyxPQUE0QztRQUMvRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7WUFDNUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2Ysd0NBQXdDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQzVELElBQUksQ0FDTCxDQUFDO1NBQ0g7UUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksVUFBVSxDQUFDLE9BQXlCO1FBQ3pDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsa0RBQWtEO1lBQ2xELE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9CLGdEQUFnRDtZQUNoRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTNDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV0RCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ2pFLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsZUFBZSxFQUNmLHVDQUF1QyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUM1RCxDQUFDO2FBQ0g7WUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQW9DLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLFVBQVUsQ0FDZixNQUFjLEVBQ2QsVUFHQztRQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFO2dCQUNqQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLGVBQWUsRUFDZix1Q0FBdUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FDNUQsQ0FBQzthQUNIO1lBRUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFbkMsa0RBQWtEO1lBQ2xELFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXJDLHdFQUF3RTtZQUN4RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNsQyxVQUFVLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQzthQUN0QjtZQUNELFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUU1RCw4QkFBOEI7WUFDOUIsK0dBQStHO1lBQy9HLDBDQUEwQztZQUMxQyxrQ0FBa0M7WUFDbEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFFLFVBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzVDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxvQ0FBb0MsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN2RjtZQUVELDJCQUEyQjtZQUMzQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQy9DLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7YUFDbkM7WUFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDckIsbUJBQW1CLEVBQ25CLFVBQVUsQ0FBQyxpQkFBaUIsRUFDNUIsQ0FBQyxFQUNELFNBQVMsRUFDVCxJQUFJLENBQ0wsQ0FBQztZQUVGLE9BQU8sSUFBSSxDQUFDLE1BQU07aUJBQ2YsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUlwQixDQUFDO2lCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUNULE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLE1BQU0saUJBQWlCLENBQUMsQ0FBQztpQkFDM0U7Z0JBQ0QsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxVQUFVLENBQUMsTUFBYztRQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5DLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLEtBQUssRUFBRTtvQkFDVCxPQUFPO2lCQUNSO2dCQUVELE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLE1BQU0saUJBQWlCLENBQUMsQ0FBQztZQUM1RSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ1UsTUFBTSxDQUFDLEtBQWE7O1lBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtnQkFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDMUI7WUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNqQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDSSxvQkFBb0IsQ0FBQyxjQUErQjtRQUN6RCxNQUFNLFlBQVksR0FBMkIsRUFBRSxDQUFDO1FBQ2hELE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQztRQUV4QiwyREFBMkQ7UUFDM0QsS0FBSyxNQUFNLFFBQVEsSUFBSSxjQUFjLEVBQUU7WUFDckMsSUFBSSxVQUFVLENBQUM7WUFDZixRQUFRLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Z0JBQ3JCLEtBQUssdUJBQWlCLENBQUMsSUFBSTtvQkFDekIsVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQzNDLE1BQU07Z0JBQ1IsS0FBSyx1QkFBaUIsQ0FBQyxRQUFRO29CQUM3QixVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7b0JBQzdDLE1BQU07Z0JBQ1IsS0FBSyx1QkFBaUIsQ0FBQyxPQUFPO29CQUM1QixVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUNuQixNQUFNO2dCQUNSLEtBQUssdUJBQWlCLENBQUMsTUFBTTtvQkFDM0IsVUFBVSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3ZGLE1BQU07Z0JBQ1IsS0FBSyx1QkFBaUIsQ0FBQyxJQUFJO29CQUN6QixVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBQ3ZELE1BQU07Z0JBQ1IsS0FBSyx1QkFBaUIsQ0FBQyxJQUFJLENBQUM7Z0JBQzVCLEtBQUssdUJBQWlCLENBQUMsU0FBUztvQkFDOUIsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPO3dCQUM3QixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzNFLFlBQVksQ0FBVyxDQUFDO29CQUMxQixVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQzFDLE1BQU07Z0JBQ1I7b0JBQ0UsVUFBVSxHQUFHLFdBQVcsQ0FBQzthQUM1QjtZQUNELFlBQVksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsVUFBVSxDQUFDO1NBQ3pDO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQUVEOztPQUVHO0lBQ0ksT0FBTyxDQUFDLEtBQWE7UUFDMUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFVBQVUsQ0FBQyxLQUFhO1FBQzdCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxXQUFXLENBQUMsSUFBc0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBc0JNLFFBQVEsQ0FDYixPQUF3QixFQUN4QixZQUFxQixJQUFJO1FBRXpCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsT0FBTyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFOUIsSUFBSSxPQUFPLENBQUMsT0FBTyxLQUFLLFNBQVMsSUFBSSxPQUFPLENBQUMsT0FBTyxLQUFLLElBQUksRUFBRTtnQkFDN0QsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQXNCLENBQUM7YUFDbEU7WUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzdELElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25DLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNoRixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUNwRCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUV2RCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO2dCQUMzQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBQ3hCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSzthQUNyQixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDckIsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDZCx5REFBeUQ7Z0JBQ3pELE9BQU8sY0FBYyxDQUFDO2FBQ3ZCO1lBRUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBRWxCLElBQUksS0FBSyxHQUEwQixFQUFFLENBQUM7WUFDdEMsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUNuQixjQUFjLEVBQ2QsT0FBTyxDQUNMLFVBQVMsS0FBMEI7Z0JBQ2pDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSwwQkFBMEIsRUFBRTtvQkFDOUMsc0dBQXNHO29CQUN0RyxhQUFhO29CQUNiLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDYixJQUFJO3lCQUNELGdDQUFnQyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7eUJBQ2hELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO3dCQUM1QixxQkFBcUIsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUU7NEJBQzdDLGFBQWE7NEJBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7d0JBQ3BDLENBQUMsQ0FBQyxDQUFDO3dCQUNILG1EQUFtRDt3QkFDbkQsMkRBQTJEO3dCQUMzRCxLQUFLLEdBQUcsRUFBRSxDQUFDO3dCQUNYLGFBQWE7d0JBQ2IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNoQixDQUFDLENBQUM7eUJBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNiLGFBQWE7d0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzVCLENBQUMsQ0FBQyxDQUFDO2lCQUNOO1lBQ0gsQ0FBQyxFQUNEO2dCQUNFLElBQUk7cUJBQ0QsZ0NBQWdDLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztxQkFDaEQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUU7b0JBQzVCLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDcEMsYUFBYTt3QkFDYixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDM0IsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsYUFBYTtvQkFDYixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQixDQUFDLENBQUM7cUJBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNiLGFBQWE7b0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUNGLENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBeUQsQ0FBQztJQUMvRCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSyxnQ0FBZ0MsQ0FDdEMsT0FBOEIsRUFDOUIsT0FLQztRQUVELHVFQUF1RTtRQUN2RSxNQUFNLGFBQWEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEQsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2xDO1NBQ0Y7UUFFRCwyREFBMkQ7UUFDM0QsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNqRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDaEQsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDakMsdUVBQXVFO29CQUN2RSxJQUFJLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQztpQkFDekQ7YUFDRjtZQUVELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsaUJBQVMsUUFBUSxDQUFDIn0=