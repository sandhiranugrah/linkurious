/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-02.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../../services');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
// locals
const Neo4j300Driver = require('./neo4j300Driver');
const DaoUtils = require('../../utils/daoUtils');
const CypherUtils = require('../../utils/cypherUtils');
class Neo4jDriver320 extends Neo4j300Driver {
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds         IDs of the first set of nodes
     * @param {string[]} otherNodeIds    IDs of the second set of nodes
     * @param options
     * @param [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @param isSuperNodeCache         List of known supernodes
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options, isSuperNodeCache) {
        // TODO clean up this code
        const edgesBetweenSupernodes = Config.get('advanced.edgesBetweenSupernodes');
        if (edgesBetweenSupernodes) {
            return super.$getMutualEdges(nodeIds, otherNodeIds, options);
        }
        const sNodesIds = CypherUtils.encodeIDArray(nodeIds);
        const sOtherNodeIds = CypherUtils.encodeIDArray(otherNodeIds);
        let sEdgeTypeFilter = '';
        if (Utils.hasValue(options.edgeTypes)) {
            sEdgeTypeFilter = options.edgeTypes.map(type => ':' + CypherUtils.encodeName(type)).join('|');
        }
        let sReadableCategories1 = '';
        if (Utils.hasValue(options.nodeCategories)) {
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.nodeCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(category => 'a:' + CypherUtils.encodeName(category));
            // if we can read nodes with no categories
            if (options.nodeCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                readableCategories.push('size(labels(a)) = 0');
            }
            sReadableCategories1 = `AND (${readableCategories.join(' OR ')}) `;
        }
        let sReadableCategories2 = '';
        if (Utils.hasValue(options.nodeCategories)) {
            // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
            const readableCategories = _.filter(options.nodeCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(category => 'b:' + CypherUtils.encodeName(category));
            // if we can read nodes with no categories
            if (options.nodeCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                readableCategories.push('size(labels(b)) = 0');
            }
            sReadableCategories2 = `AND (${readableCategories.join(' OR ')}) `;
        }
        // The reason that variables are called 'a', 'b', 'e' is not casual
        // It's to hint to the planner to actually scan the list of nodes in `nodeIds` instead
        // of nodes in `otherNodeIds`. See #1462
        return Promise.resolve().then(() => {
            const nodeIdsWithoutSuperNode = _.filter(nodeIds, n => !isSuperNodeCache.has(n));
            const otherNodeIdsWithoutSuperNode = _.filter(otherNodeIds, n => !isSuperNodeCache.has(n));
            const sNodesIdsWithoutSuperNode = CypherUtils.encodeIDArray(nodeIdsWithoutSuperNode);
            const sOtherNodeIdsWithoutSuperNode = CypherUtils.encodeIDArray(otherNodeIdsWithoutSuperNode);
            const edgeQuery1 = `CYPHER 3.1 MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
                `WHERE id(b) IN ${sNodesIdsWithoutSuperNode} AND id(a) IN ${sOtherNodeIds} ` +
                sReadableCategories1 +
                'RETURN DISTINCT e';
            const edgeQuery2 = `CYPHER 3.1 MATCH (b)-[e${sEdgeTypeFilter}]-(a) ` +
                `WHERE id(b) IN ${sOtherNodeIdsWithoutSuperNode} AND id(a) IN ${sNodesIds}` +
                sReadableCategories2 +
                'RETURN DISTINCT e';
            return this.connector.$doCypherQuery(edgeQuery1).then(response1 => {
                const edges1 = _.map(response1.results, record => record.edges[0]);
                return this.connector.$doCypherQuery(edgeQuery2).then(response2 => {
                    const edges2 = _.map(response2.results, record => record.edges[0]);
                    return _.uniqBy(edges1.concat(edges2), 'id');
                });
            });
        });
    }
}
module.exports = Neo4jDriver320;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozMjBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzIwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsTUFBTSxjQUFjLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDbkQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDakQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFFdkQsTUFBTSxjQUFlLFNBQVEsY0FBYztJQUN6Qzs7Ozs7Ozs7OztPQVVHO0lBQ0gsZUFBZSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLGdCQUFnQjtRQUM5RCwwQkFBMEI7UUFDMUIsTUFBTSxzQkFBc0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDN0UsSUFBSSxzQkFBc0IsRUFBRTtZQUMxQixPQUFPLEtBQUssQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM5RDtRQUVELE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckQsTUFBTSxhQUFhLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM5RCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNyQyxlQUFlLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQ3JDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQzNDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2I7UUFFRCxJQUFJLG9CQUFvQixHQUFHLEVBQUUsQ0FBQztRQUM5QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzFDLDBEQUEwRDtZQUMxRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFDeEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLDRCQUE0QixDQUFDO2lCQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRTVELDBDQUEwQztZQUMxQyxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFO2dCQUMxRSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzthQUNoRDtZQUVELG9CQUFvQixHQUFHLFFBQVEsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDcEU7UUFFRCxJQUFJLG9CQUFvQixHQUFHLEVBQUUsQ0FBQztRQUM5QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQzFDLDBEQUEwRDtZQUMxRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFDeEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLDRCQUE0QixDQUFDO2lCQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRTVELDBDQUEwQztZQUMxQyxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxFQUFFO2dCQUMxRSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzthQUNoRDtZQUVELG9CQUFvQixHQUFHLFFBQVEsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDcEU7UUFFRCxtRUFBbUU7UUFDbkUsc0ZBQXNGO1FBQ3RGLHdDQUF3QztRQUV4QyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pGLE1BQU0sNEJBQTRCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNGLE1BQU0seUJBQXlCLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3JGLE1BQU0sNkJBQTZCLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO1lBRTlGLE1BQU0sVUFBVSxHQUFHLDBCQUEwQixlQUFlLFFBQVE7Z0JBQ2xFLGtCQUFrQix5QkFBeUIsaUJBQWlCLGFBQWEsR0FBRztnQkFDNUUsb0JBQW9CO2dCQUNwQixtQkFBbUIsQ0FBQztZQUV0QixNQUFNLFVBQVUsR0FBRywwQkFBMEIsZUFBZSxRQUFRO2dCQUNsRSxrQkFBa0IsNkJBQTZCLGlCQUFpQixTQUFTLEVBQUU7Z0JBQzNFLG9CQUFvQjtnQkFDcEIsbUJBQW1CLENBQUM7WUFFdEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ2hFLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFbkUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7b0JBQ2hFLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFbkUsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQy9DLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDIn0=