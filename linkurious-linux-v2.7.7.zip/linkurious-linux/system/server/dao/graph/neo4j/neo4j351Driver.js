/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-02.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
// locals
const Neo4j320Driver = require('./neo4j320Driver');
const CypherUtils = require('../../utils/cypherUtils');
class Neo4jDriver351 extends Neo4j320Driver {
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    $onAfterConnect() {
        return super.$onAfterConnect().then(() => {
            const expected = [];
            const alternativeNodeIdIndex = this.getGraphOption('alternativeNodeIdIndex');
            if (Utils.hasValue(alternativeNodeIdIndex)) {
                expected.push({ name: alternativeNodeIdIndex, type: 'node' });
            }
            const alternativeEdgeIdIndex = this.getGraphOption('alternativeEdgeIdIndex');
            if (Utils.hasValue(alternativeEdgeIdIndex)) {
                expected.push({ name: alternativeEdgeIdIndex, type: 'edge' });
            }
            return CypherUtils.checkIndicesExists(this.connector, expected);
        });
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param options
     * @param options.ids                  List of IDs to read
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.alternativeIdIndex] The index to use to resolve nodes by alternativeId
     */
    $getNodesByID(options) {
        // alternative IDs with full-text index optimization
        if (Utils.hasValue(options.alternativeId) && Utils.hasValue(options.alternativeIdIndex)) {
            const indexName = options.alternativeIdIndex;
            const values = options.ids.map(propValue => CypherUtils.encodeValue(propValue)).join(' ');
            const query = `CALL db.index.fulltext.queryNodes('${indexName}', '${values}') YIELD node RETURN node`;
            return this.connector.$doCypherQuery(query).then(response => {
                return _.flatMap(response.results, 'nodes');
            });
        }
        // regular resolution
        return super.$getNodesByID(options);
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param options
     * @param options.ids                  List of IDs to read
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.alternativeIdIndex] The index to use to resolve edges by alternativeId
     */
    $getEdgesByID(options) {
        // alternative IDs with full-text index optimization
        if (Utils.hasValue(options.alternativeId) && Utils.hasValue(options.alternativeIdIndex)) {
            const indexName = options.alternativeIdIndex;
            const values = options.ids.map(propValue => CypherUtils.encodeValue(propValue)).join(' ');
            const query = `CALL db.index.fulltext.queryRelationships('${indexName}', '${values}') ` +
                'YIELD relationship RETURN relationship';
            return this.connector.$doCypherQuery(query).then(response => {
                return _.flatMap(response.results, 'edges');
            });
        }
        // regular resolution
        return super.$getEdgesByID(options);
    }
}
module.exports = Neo4jDriver351;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozNTFEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzUxRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLFNBQVM7QUFDVCxNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNuRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUV2RCxNQUFNLGNBQWUsU0FBUSxjQUFjO0lBQ3pDOztPQUVHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdkMsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBRXBCLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBQzdFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO2dCQUMxQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO2FBQzdEO1lBRUQsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDN0UsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEVBQUU7Z0JBQzFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUM7YUFDN0Q7WUFFRCxPQUFPLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsYUFBYSxDQUFDLE9BQU87UUFDbkIsb0RBQW9EO1FBQ3BELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRTtZQUN2RixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUM7WUFDN0MsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFGLE1BQU0sS0FBSyxHQUNULHNDQUFzQyxTQUFTLE9BQU8sTUFBTSwyQkFBMkIsQ0FBQztZQUMxRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDMUQsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDOUMsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELHFCQUFxQjtRQUNyQixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsYUFBYSxDQUFDLE9BQU87UUFDbkIsb0RBQW9EO1FBQ3BELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRTtZQUN2RixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUM7WUFDN0MsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFGLE1BQU0sS0FBSyxHQUNULDhDQUE4QyxTQUFTLE9BQU8sTUFBTSxLQUFLO2dCQUN6RSx3Q0FBd0MsQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDMUQsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDOUMsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVELHFCQUFxQjtRQUNyQixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEMsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMifQ==