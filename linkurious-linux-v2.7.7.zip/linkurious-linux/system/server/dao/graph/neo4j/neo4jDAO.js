/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// locals
const GraphDAO = require('../graphDAO');
const Neo4jHTTPConnector = require('../../connector/neo4jHTTPConnector');
const Neo4jBoltConnector = require('../../connector/neo4jBoltConnector');
const Neo4jDriver = require('./neo4jDriver');
const Neo4j220Driver = require('./neo4j220Driver');
const Neo4j300Driver = require('./neo4j300Driver');
const Neo4j320Driver = require('./neo4j320Driver');
const Neo4j351Driver = require('./neo4j351Driver');
class Neo4jDAO extends GraphDAO {
    /**
     * @param {object}  options
     * @param {string}  options.url               Neo4j Bolt/HTTP/HTTPS url
     * @param {string}  [options.user]            Neo4j user
     * @param {string}  [options.password]        Neo4j password
     * @param {string}  [options.writeURL]        Neo4j HTTP/HTTPS Core Server url (not used for Bolt)
     * @param {string}  [options.proxy]           HTTP proxy (not used for Bolt)
     * @param {boolean} [options.allowSelfSigned] Whether to allow self-signed certificates (not used for Bolt)
     */
    constructor(options) {
        const useBolt = options.url.toLowerCase().startsWith('bolt');
        super('neo4j', ['url'], ['url', 'user', 'password', 'writeURL', 'proxy', 'allowSelfSigned'], options, {
            edgeProperties: true,
            immutableNodeCategories: false,
            minNodeCategories: 0,
            maxNodeCategories: undefined,
            serializeArrayProperties: false,
            canCount: true,
            alerts: true,
            alternativeIds: true,
            emptyNodes: true,
            dialects: ['cypher'],
            canStream: true,
            detectSupernodes: true,
            canDryRun: false // true from 2.2.0
        }, useBolt ? Neo4jBoltConnector : [Neo4jBoltConnector, Neo4jHTTPConnector], [
            { version: '3.5.7', driver: '[latest]' },
            { version: '3.5.1', driver: Neo4j351Driver },
            { version: '3.2.0', driver: Neo4j320Driver },
            { version: '3.0.0', driver: Neo4j300Driver },
            { version: '2.2.0', driver: Neo4j220Driver },
            { version: '2.1.5', driver: Neo4jDriver }
        ]);
    }
}
module.exports = Neo4jDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QyxNQUFNLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBQ3pFLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7QUFDekUsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBRW5ELE1BQU0sUUFBUyxTQUFRLFFBQVE7SUFFN0I7Ozs7Ozs7O09BUUc7SUFDSCxZQUFZLE9BQU87UUFDakIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFN0QsS0FBSyxDQUFDLE9BQU8sRUFDWCxDQUFDLEtBQUssQ0FBQyxFQUNQLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxFQUNuRSxPQUFPLEVBQ1A7WUFDRSxjQUFjLEVBQUUsSUFBSTtZQUNwQix1QkFBdUIsRUFBRSxLQUFLO1lBQzlCLGlCQUFpQixFQUFFLENBQUM7WUFDcEIsaUJBQWlCLEVBQUUsU0FBUztZQUM1Qix3QkFBd0IsRUFBRSxLQUFLO1lBQy9CLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLElBQUk7WUFDWixjQUFjLEVBQUUsSUFBSTtZQUNwQixVQUFVLEVBQUUsSUFBSTtZQUNoQixRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDcEIsU0FBUyxFQUFFLElBQUk7WUFDZixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLFNBQVMsRUFBRSxLQUFLLENBQUMsa0JBQWtCO1NBQ3BDLEVBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxrQkFBa0IsQ0FBQyxFQUN2RTtZQUNFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFDO1lBQzFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFDO1lBQzFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFDO1lBQzFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFDO1lBQzFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFDO1NBQ3hDLENBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDIn0=