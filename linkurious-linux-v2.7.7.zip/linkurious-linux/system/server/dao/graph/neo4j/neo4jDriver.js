"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../../../services");
const Errors = LKE.getErrors();
const CypherDriver = require('../cypherDriver');
// @ts-ignore Neo4jConnector needs to be written in TS
class Neo4jDriver extends CypherDriver {
    /**
     * Check if the given edge ID is legal.
     *
     * @param key
     * @param id
     */
    $checkEdgeId(key, id) {
        if (!/^\d+$/.test(id)) {
            throw Errors.business('invalid_parameter', '"' + key + '" must be a positive integer.');
        }
    }
    /**
     * Check if the given node ID is legal.
     *
     * @param key
     * @param id
     */
    $checkNodeId(key, id) {
        if (!/^\d+$/.test(id)) {
            throw Errors.business('invalid_parameter', '"' + key + '" must be a positive integer.');
        }
    }
    /**
     * Count the number of nodes.
     *
     * @param approx Allow an approximated answer
     */
    $getNodeCount(approx) {
        if (approx) {
            return this.connector.$queryJmx('org.neo4j', 'instance=kernel#0,name=Primitive count', 'NumberOfNodeIdsInUse');
        }
        return this.connector.$doCypherQuery('MATCH (n) RETURN count(n)').then(response => {
            return _.get(response, 'results.0.rows.0', 0);
        });
    }
    /**
     * Count the number of edges.
     *
     * @param approx Allow an approximated answer
     */
    $getEdgeCount(approx) {
        if (approx) {
            return this.connector.$queryJmx('org.neo4j', 'instance=kernel#0,name=Primitive count', 'NumberOfRelationshipIdsInUse');
        }
        return this.connector.$doCypherQuery('MATCH ()-->() RETURN COUNT(*)').then(response => {
            return _.get(response, 'results.0.rows.0', 0);
        });
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     */
    $getSimpleSchema() {
        return Bluebird.resolve(Bluebird.props({
            edgeTypes: this.$getEdgeTypes(),
            nodeCategories: this.connector.$doHTTPGetRequest('/db/data/labels'),
            nodeProperties: this.connector.$doHTTPGetRequest('/db/data/propertykeys'),
            edgeProperties: null
        }).then(r => {
            return {
                edgeTypes: r.edgeTypes,
                nodeCategories: r.nodeCategories,
                nodeProperties: r.nodeProperties,
                edgeProperties: r.nodeProperties
            };
        }));
    }
    /**
     * List all edgeTypes that exist in the graph database.
     */
    $getEdgeTypes() {
        return this.connector.$doHTTPGetRequest('/db/data/relationship/types');
    }
    /**
     * Called at the end of the connect phase for additional initializations.
     */
    $onAfterConnect() {
        // TODO #1436 check that alternative IDs are actually properties that exist in the graph
        // TODO #1337 check if HA is enabled and warn is writeURL is not set
        return super.$onAfterConnect();
    }
}
module.exports = Neo4jDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGpEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqRHJpdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBSS9CLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBaUMsQ0FBQztBQUVoRixzREFBc0Q7QUFDdEQsTUFBTSxXQUFzQyxTQUFRLFlBQVk7SUFDOUQ7Ozs7O09BS0c7SUFDSSxZQUFZLENBQUMsR0FBVyxFQUFFLEVBQVU7UUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDckIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsK0JBQStCLENBQUMsQ0FBQztTQUN6RjtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxHQUFXLEVBQUUsRUFBVTtRQUN6QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNyQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRywrQkFBK0IsQ0FBQyxDQUFDO1NBQ3pGO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxhQUFhLENBQUMsTUFBZ0I7UUFDbkMsSUFBSSxNQUFNLEVBQUU7WUFDVixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUM3QixXQUFXLEVBQ1gsd0NBQXdDLEVBQ3hDLHNCQUFzQixDQUNILENBQUM7U0FDdkI7UUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2hGLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGFBQWEsQ0FBQyxNQUFnQjtRQUNuQyxJQUFJLE1BQU0sRUFBRTtZQUNWLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQzdCLFdBQVcsRUFDWCx3Q0FBd0MsRUFDeEMsOEJBQThCLENBQ1gsQ0FBQztTQUN2QjtRQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsK0JBQStCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDcEYsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxrQkFBa0IsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSSxnQkFBZ0I7UUFDckIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUNyQixRQUFRLENBQUMsS0FBSyxDQUFDO1lBQ2IsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDL0IsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUM7WUFDbkUsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsdUJBQXVCLENBQUM7WUFDekUsY0FBYyxFQUFFLElBQUk7U0FDckIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNWLE9BQU87Z0JBQ0wsU0FBUyxFQUFFLENBQUMsQ0FBQyxTQUFTO2dCQUN0QixjQUFjLEVBQUUsQ0FBQyxDQUFDLGNBQTBCO2dCQUM1QyxjQUFjLEVBQUUsQ0FBQyxDQUFDLGNBQTBCO2dCQUM1QyxjQUFjLEVBQUUsQ0FBQyxDQUFDLGNBQTBCO2FBQzdDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ksYUFBYTtRQUNsQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsNkJBQTZCLENBQXVCLENBQUM7SUFDL0YsQ0FBQztJQUVEOztPQUVHO0lBQ0ksZUFBZTtRQUNwQix3RkFBd0Y7UUFDeEYsb0VBQW9FO1FBQ3BFLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7Q0FDRjtBQUVELGlCQUFTLFdBQVcsQ0FBQyJ9