/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-10-09.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// locals
const Neo4j220Driver = require('./neo4j220Driver');
/**
 * From Neo4j 3.0.0 we can use the following procedures instead of an HTTP request:
 * - db.relationshipTypes
 * - db.labels
 * - db.propertyKeys
 */
class Neo4jDriver300 extends Neo4j220Driver {
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        return Promise.props({
            edgeTypes: this.$getEdgeTypes(),
            nodeCategories: this.connector.$doCypherQuery('CALL db.labels()'),
            nodeProperties: this.connector.$doCypherQuery('CALL db.propertyKeys()')
        }).then(response => {
            return {
                edgeTypes: response.edgeTypes,
                nodeCategories: _.map(response.nodeCategories.results, r => r.rows[0]),
                nodeProperties: _.map(response.nodeProperties.results, r => r.rows[0]),
                edgeProperties: _.map(response.nodeProperties.results, r => r.rows[0]) // same as nodeProperties
            };
        });
    }
    /**
     * List all edgeTypes that exist in the graph database.
     *
     * @returns {Bluebird<string[]>}
     */
    $getEdgeTypes() {
        return this.connector.$doCypherQuery('CALL db.relationshipTypes()').then(response => {
            return _.map(response.results, r => r.rows[0]);
        });
    }
}
module.exports = Neo4jDriver300;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGozMDBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMzAwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsU0FBUztBQUNULE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBRW5EOzs7OztHQUtHO0FBQ0gsTUFBTSxjQUFlLFNBQVEsY0FBYztJQUV6Qzs7Ozs7T0FLRztJQUNILGdCQUFnQjtRQUNkLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQztZQUNuQixTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUMvQixjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUM7WUFDakUsY0FBYyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDO1NBQ3hFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDakIsT0FBTztnQkFDTCxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVM7Z0JBQzdCLGNBQWMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEUsY0FBYyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0RSxjQUFjLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUI7YUFDakcsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxhQUFhO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNsRixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDIn0=