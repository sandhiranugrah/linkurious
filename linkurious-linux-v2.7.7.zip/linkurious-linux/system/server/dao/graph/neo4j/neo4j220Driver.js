/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-02-19.
 */
'use strict';
// locals
const Neo4jDriver = require('./neo4jDriver');
const CypherUtils = require('../../utils/cypherUtils');
/**
 * From Neo4j 2.2.0 we can use the following statements:
 * - EXPLAIN
 * - PROFILE
 *
 * We need EXPLAIN to perform a dry run.
 */
class Neo4jDriver220 extends Neo4jDriver {
    /**
     * Called at the end of the connect phase for additional initializations.
     *
     * @returns {Bluebird<void>}
     */
    $onAfterConnect() {
        this.graphFeatures.canDryRun = true;
        return super.$onAfterConnect();
    }
    /**
     * Check that the given graph query is syntactically correct.
     *
     * @param {string} query
     * @returns {Bluebird<void>}
     */
    $dryRun(query) {
        const newQuery = CypherUtils.enforceExplainStatement(query);
        return this.connector.$doCypherQuery(newQuery).catch(error => {
            if (error.data && error.data.offset) {
                // Enforce explain adds 8 characters to the original query
                error.data.offset -= 8;
            }
            throw error;
        });
    }
}
module.exports = Neo4jDriver220;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVvNGoyMjBEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL25lbzRqL25lbzRqMjIwRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUM3QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUV2RDs7Ozs7O0dBTUc7QUFDSCxNQUFNLGNBQWUsU0FBUSxXQUFXO0lBRXRDOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3BDLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE9BQU8sQ0FBQyxLQUFLO1FBQ1gsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzNELElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDbkMsMERBQTBEO2dCQUMxRCxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7YUFDeEI7WUFDRCxNQUFNLEtBQUssQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMifQ==