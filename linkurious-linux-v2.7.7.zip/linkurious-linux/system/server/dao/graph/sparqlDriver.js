/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-21.
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// internal libs
const stream = require('stream');
// external libs
const shortid = require('shortid');
const _ = require('lodash');
const Promise = require('bluebird');
const { InputSerialization } = require('linkurious-shared/umd');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
// locals
const GraphDriver = require('./graphDriver');
const SparqlUtils = require('../utils/sparqlUtils');
const DaoUtils = require('../utils/daoUtils');
// timeout after which $getSimpleSchema will give up
const GET_SIMPLE_SCHEMA_TIMEOUT = 10000; // 10 seconds
/**
 * Notes:
 * If ?o is a literal, "?s ?p ?o" defines a property.
 * If ?o is a URI or a blank node, "?s ?p ?o" defines an edge.
 * Exception: if ?p is `categoryPredicate`, "?s ?p ?o" defines a category.
 * In a category statement, ?o can be a URI, a blank node or a literal.
 *
 * A node exists only if it has at least a property, a category or an edge.
 * You can create a new node only if it has at least a property or a category.
 * You CANNOT create edges "?s ?p ?o" if source and target don't exist already.
 * You CANNOT delete all properties and categories from a node (even if it has an edge).
 * If in the original dataset there is an edge that have as a target a node without
 * categories and properties, this node will appear empty.
 * Empty nodes are defined as the nodes that don't have any property or category.
 * In this case, if we try to delete the edge, the deletion will fail because it would result
 * in a deletion of the node too.
 * Empty nodes are not counted in getNodeCount and they are not emitted in getNodeStream.
 *
 * In this driver the encoded IDs are equal to the decoded ones.
 *
 *
 * This driver requires a SparqlConnector and the following graph options:
 * @property {string} [idPropertyName] Property name used to show the id in its short form
 *
 * A Driver that extends SparqlDriver has to:
 * - supportBlankNodeLabels, or
 * - implementGetStatements
 *
 * If the graph database supports blank node labels, $getStatements, on the connector, is never invoked.
 *
 * The SparqlConnector will pass the following data to the driver:
 * @property {Map<string, string>} prefixToURI       Mapping from prefixes to namespaces, e.g.:
 *                                                   'foaf' -> 'http://xmlns.com/foaf/0.1/'
 *                                                   'rdf'  -> 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
 * @property {string}              categoryPredicate Predicate (URI wrapped in angle brackets) that represents a category
 * @property {string}              defaultNamespace  Default namespace (namespace used for node IDs without any prefix)
 */
class SparqlDriver extends GraphDriver {
    /**
     * @param {SparqlConnector} connector                            Connector used by the DAO
     * @param {any}             graphOptions                         GraphDAO options
     * @param {any}             connectorData                        Data from the connector
     * @param {GraphFeatures}   graphFeatures                        Features of the Graph DAO
     * @param {object}          sparqlOptions
     * @param {boolean}         sparqlOptions.supportBlankNodeLabels Whether you can directly access a blank node from a sparql query by wrapping its ID in angle brackets
     * @param {boolean}         sparqlOptions.implementGetStatements Whether the connector can implement $getStatements (the graph database implements RDF4J APIs)
     * @param {boolean}         sparqlOptions.supportPropertyPaths   Whether the Graph Database supports SPARQL property paths
     */
    constructor(connector, graphOptions, connectorData, graphFeatures, sparqlOptions) {
        super(connector, graphOptions, connectorData, graphFeatures);
        this._idPropertyName = this.getGraphOption('idPropertyName');
        // each driver is responsible to validate its connectorData
        Utils.check.properties('connectorData', connectorData, {
            prefixToURI: { required: true, check: (k, prefixToURI) => {
                    prefixToURI.forEach((value, key) => {
                        Utils.check.string(k + '[' + key + ']', value, true);
                    });
                } },
            categoryPredicate: { required: true, check: 'nonEmpty' },
            defaultNamespace: { required: true, check: 'nonEmpty' }
        });
        this._utils = new SparqlUtils(connectorData.prefixToURI, connectorData.defaultNamespace, connectorData.categoryPredicate, this._idPropertyName);
        this._categoryPredicate = connectorData.categoryPredicate;
        this._fromClause = connector.$fromClause;
        if (!sparqlOptions.supportBlankNodeLabels && !sparqlOptions.implementGetStatements) {
            throw Errors.technical('bug', 'Graph database doesn\'t support blank node labels' +
                ' nor it can implement getStatements.');
        }
        this.supportBlankNodeLabels = sparqlOptions.supportBlankNodeLabels;
        this.supportPropertyPaths = sparqlOptions.supportPropertyPaths;
    }
    /**
     * Return a legal sparql node id.
     */
    $getDummyNodeId() {
        return '<http://linkurio.us/0>';
    }
    /**
     * Special properties that can't be read, created or updated.
     *
     * @type {Array<{key: string, read: boolean, create: boolean, update: boolean}>}
     */
    get $specialProperties() {
        if (Utils.noValue(this._idPropertyName)) {
            return [];
        }
        return [{
                key: this._idPropertyName,
                read: true,
                create: true,
                update: false
            }];
    }
    /**
     * Encode value in a string that can be inserted in a query template.
     *
     * @param {TemplateDataValue}  value
     * @param {InputSerialization} serializer
     * @returns {string}
     */
    $quote(value, serializer) {
        switch (serializer) {
            case InputSerialization.NODE:
                const id = value + '';
                this.$checkNodeId('nodeId', id);
                return id;
            case InputSerialization.NODE_SET:
                _.forEach(value, v => this.$checkNodeId('nodeId', v));
                return `(${value})`;
            case InputSerialization.NATIVE_DATE:
            case InputSerialization.NATIVE_DATE_TIME:
            case InputSerialization.STRING:
                return `'${value}'`;
            default:
                return value + '';
        }
    }
    /**
     * Check if the given edge ID is legal.
     *
     * Coding/decoding is used when the edge ID is not originally a string.
     * An encoded edge ID is an ID for Linkurious (ID in input).
     * A decoded edge ID is an ID for the graph database (ID in output).
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkEdgeId(key, id) {
        Utils.check.string(key, id, true, true);
        try {
            const edge = this._utils.getEdgeFromId(id);
            const source = /**@type {string}*/ (edge.source);
            const target = /**@type {string}*/ (edge.target);
            this.$checkNodeId('edge.source', source);
            this.$checkNodeId('edge.target', target);
            Utils.check.string('edge.type', edge.type, true);
        }
        catch (e) {
            throw Errors.business('invalid_parameter', '"' + id + '" doesn\'t decode to a valid edge ' +
                '(' + e.message + ').');
        }
    }
    /**
     * Check if the given node ID is legal.
     *
     * Coding/decoding is used when the node ID is not originally a string.
     * An encoded node ID is an ID for Linkurious (ID in input).
     * A decoded node ID is an ID for the graph database (ID in output).
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkNodeId(key, id) {
        Utils.check.string(key, id, true);
        if (!this._utils.isURI(id) && !this._utils.isBlankNode(id)) {
            throw Errors.business('invalid_parameter', '"' + key + '" must be a valid URI wrapped in ' +
                'angle brackets or a blank node.');
        }
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * This call may end up being really expensive.
     * It will timeout after GET_SIMPLE_SCHEMA_TIMEOUT and fallback to empty arrays.
     * The category predicate ('rdf:type' by default) is always included
     * in both `edgeTypes` and `nodeProperties`.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        const promises = {
            nodeCategories: this.connector.$doSparqlQuery(`select distinct ?class ${this._fromClause} {?resource ${this._categoryPredicate} ?class}`, { timeout: GET_SIMPLE_SCHEMA_TIMEOUT }).then(response => _.zip.apply(_, response)[0]).map(rawCategory => {
                return this._utils.parseCategoryValue(rawCategory);
            }).catch(() => {
                return []; // fallback to empty array
            }),
            edgeTypes: this.connector.$doSparqlQuery(`select distinct ?p ${this._fromClause} 
        {?s ?p ?o. filter(?p != ${this._categoryPredicate}) filter isURI(?o)}`, { timeout: GET_SIMPLE_SCHEMA_TIMEOUT }).then(response => _.zip.apply(_, response)[0]).map(rawType => {
                return this._utils.fullURIToShortName(rawType);
            }).catch(() => {
                return [];
            }),
            nodeProperties: this.connector.$doSparqlQuery(`select distinct ?p ${this._fromClause} 
        {?s ?p ?o. filter(?p != ${this._categoryPredicate}) filter isLiteral(?o)}`, { timeout: GET_SIMPLE_SCHEMA_TIMEOUT }).then(response => {
                return _.zip.apply(_, response)[0];
            }).map(rawPropertyName => {
                return this._utils.fullURIToShortName(rawPropertyName);
            }).catch(() => {
                return [];
            }),
            edgeProperties: []
        };
        return Promise.props(promises);
    }
    /**
     * Get a node by ID.
     *
     * @param {object}  options
     * @param {any}     options.id ID of the node
     * @returns {Bluebird<LkNode>} null if not found
     */
    _getNode(options) {
        return this.$getNodesByID({
            ids: [options.id]
        }).then(nodes => nodes[0]);
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids List of IDs to read
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByID(options) {
        return this.$getNodesByURI(options);
    }
    /**
     * Return for the given URIs all the node statements.
     * Nodes statements are:
     * - statements where the object is string literal (node property)
     * - statements where the predicate is the category predicate
     *
     * If those statements do not exist for a URI, a single edge statement for that URI.
     *
     * Blank nodes can't be used in this method (except if the driver support blank node labels).
     *
     * @param {object} options
     * @param {any[]}  options.ids         List of URIs to read
     * @param {string} [options.reasoning] 'enabled':  Allow inferred statements
     *                                     'disabled': Forbid inferred statements
     *                                     'default':  Use the configuration flag
     * @returns {Bluebird<string[][]>}
     * @private
     */
    _getNodeStatementsBySubjects(options) {
        const { ids, reasoning } = options;
        const subjects = this._utils.wrapBlankNodesInAngleBrackets(ids);
        const boundSubjects = subjects.map(value => `{BIND (${value} as ?s). ?s ?p ?o.}`)
            .join(' union ');
        const query = `SELECT ?s ?p ?o ${this._fromClause} WHERE { ${boundSubjects}` +
            ` FILTER(isLiteral(?o) || ?p = ${this._categoryPredicate}).}`;
        return this.connector.$doSparqlQuery(query, { reasoning: reasoning }).then(triples => {
            const uriFound = triples.map(t => t[0]);
            const uriNotFound = _.difference(subjects, uriFound);
            if (uriNotFound.length === 0) {
                return triples;
            }
            else {
                // A URI is not found if it has no property and no categories
                // In that case we return the first edge statement we can find
                const boundEdgeQuery = _.map(uriNotFound, uri => `{select ?s ?p ?o where {{BIND (${uri}` +
                    ` as ?s). ?s ?p ?o. FILTER(isURI(?o)) } union {BIND (${uri} as ?o). ?s ?p ?o}. ` +
                    `FILTER(?p != ${this._categoryPredicate})} limit 1}`)
                    .join(' union ');
                const singleEdgeQuery = `SELECT ?s ?p ?o { ${boundEdgeQuery} }`;
                return this.connector.$doSparqlQuery(singleEdgeQuery, { reasoning: reasoning })
                    .then(missingStatements => _.concat(triples, missingStatements));
            }
        });
    }
    /**
     * Get a list of nodes by ID.
     * This method should return nodes in the same order as the input ids.
     *
     * In additional to the options passed by the DAO we have the option reasoning used internally in the driver.
     *
     * @param {object}   options
     * @param {any[]}    options.ids              List of URIs to read
     * @param {string}   [options.reasoning]      'enabled':  Allow inferred statements
     *                                            'disabled': Forbid inferred statements
     *                                            'default':  Use the configuration flag
     * @returns {Bluebird<LkNode[]>}
     */
    $getNodesByURI(options) {
        /**
         * Give me all "?s ?p ?o" where ?s is in 'options.ids'
         * (It means "give me all property, category and edge statements of nodes with these ids")
         */
        const idsSet = new Set(options.ids);
        const ids = Array.from(idsSet);
        if (ids.length === 0) {
            return Promise.resolve([]);
        }
        return Promise.resolve().then(() => {
            if (!this.supportBlankNodeLabels) {
                const [blankNodes, concreteNodes] = _.partition(ids, this._utils.isBlankNode);
                if (blankNodes.length) {
                    return this.connector.$getStatementsBySubjects(blankNodes, { reasoning: options.reasoning })
                        .then(blankNodesStatements => {
                        // for concrete nodes, we query categories and properties of all nodes
                        // The sparql query can be optimised to only ask those statements
                        return this._getNodeStatementsBySubjects({ ids: concreteNodes, reasoning: options.reasoning }).then(concreteNodesStatements => concreteNodesStatements.concat(blankNodesStatements));
                    });
                }
            }
            // if blank nodes labels are supported or there is no blank node,
            // we only need to query categories and properties for all nodes
            return this._getNodeStatementsBySubjects({ ids: ids, reasoning: options.reasoning });
        }).then(statements => {
            // node statements are:
            //  - node with subj in idsSet &&
            //  - category statements || property statement (literal value)
            // if blank nodes labels are not supported, we query all the statements of a blank node
            // the non node statements should be filtered here as well
            const [nodeStatements, otherStatements] = _.partition(statements, s => idsSet.has(s[0]) && (s[1] === this._categoryPredicate || s[2].startsWith('"')));
            // This avoids returning rdf:type as an edge if a category is also a node
            const edgeStatements = _.filter(otherStatements, s => s[1] !== this._categoryPredicate);
            const nodeIdsSeenInEdges = new Set();
            _.forEach(edgeStatements, s => {
                nodeIdsSeenInEdges.add(s[0]);
                // ?o is a node if ?p is not a category predicate (possibility discarded earlier)
                nodeIdsSeenInEdges.add(s[2]);
            });
            const nodesMap = new Map();
            // Here we create nodes with the result of node statements (properties and categories)
            _.forEach(_.groupBy(nodeStatements, s => s[0]), (value, key) => {
                if (idsSet.has(key)) {
                    try {
                        const node = this._utils.parseStatementsForNode(value);
                        if (node !== null) {
                            nodesMap.set(key, node);
                        }
                    }
                    catch (e) {
                        Log.warn('While retrieving a node: ', e.message);
                    }
                }
            });
            // Here we create the empty nodes that occurred only as a source or target of an edge
            nodeIdsSeenInEdges.forEach(nodeId => {
                if (idsSet.has(nodeId) && !nodesMap.has(nodeId)) {
                    const data = {};
                    // empty nodes can have the id property as well
                    if (Utils.hasValue(this._idPropertyName)) {
                        data.id = this._utils.fullURIToShortName(nodeId);
                    }
                    nodesMap.set(nodeId, { id: nodeId, data, categories: [] });
                }
            });
            return Array.from(nodesMap.values());
        });
    }
    /**
     * Get a list of edges by ID.
     * This method should return edges in the same order as the input ids.
     *
     * @param {object} options
     * @param {any[]}  options.ids List of IDs to read
     * @returns {Bluebird<LkEdge[]>}
     */
    $getEdgesByID(options) {
        return Promise.map(options.ids, id => {
            const statement = this._utils.formatEdgeToStatement(this._utils.getEdgeFromId(id));
            return this.connector.$checkStatement(statement[0], statement[1], statement[2]).then(belongsToTripleStore => {
                if (belongsToTripleStore) {
                    return statement;
                }
            });
        }).then(statements => {
            statements = statements.filter(Utils.hasValue);
            const edges = [];
            _.forEach(statements, value => {
                try {
                    edges.push(this._utils.parseStatementForEdge(value));
                }
                catch (e) {
                    Log.warn('Could not parse edge statement: ', e.message);
                }
            });
            return edges;
        });
    }
    /**
     * Generate a SPARQL query that returns a list of pairs where the first elements are node ids
     * and the second elements are their cardinality.
     * The nodesIds are the ids of the nodes adjacent to `nodeId`.
     * If `edgeFilter` is defined only edges of this type are taken into account.
     * If `nodeCategoryFilter` is defined, only adjacent nodes of this category are taken into account.
     * Special case for `nodeCategoryFilter` === "[no_category]" where only adjacent nodes
     * with no categories are taken into account.
     * The cardinality column is populated only if `limitType` !== "id".
     *
     * If nodeId is a blank node, we assume that blank node labels are supported.
     *
     * Return undefined if the search query could not be built e.g. if no edge types or
     * node categories are readable.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Max number of nodes in result
     * @param {string}   options.limitType        "id", "lowestDegree" or "highestDegree" to sort results before limiting
     * @param {string[]} [options.nodeCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge-type to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {string | undefined}
     * @private
     */
    _generateAdjNodeSparqlQuery(nodeIds, options) {
        // For performance reasons in this function we prefer BIND and UNION over VALUES
        const { ignoredNodeIds, limit, limitType, nodeCategories } = options;
        const sourceIds = this._utils.wrapBlankNodesInAngleBrackets(nodeIds);
        let edgeTypes;
        if (Utils.hasValue(options.edgeTypes)) {
            edgeTypes = options.edgeTypes.map(t => this._utils.shortNameToFullURI(t));
        }
        // List for every valid edge type the statements where `nodeId` is the object
        const incomingRelations = nodeId => {
            if (Utils.hasValue(edgeTypes)) {
                return '{' + edgeTypes.map(predicateURI => `{?s ${predicateURI} ${nodeId}}`)
                    .join(' union ') + '}';
            }
            return `{?s ?p ${nodeId}}`;
        };
        // List for every valid edge type the statements where `nodeId` is the subject
        const outgoingRelations = nodeId => {
            if (Utils.hasValue(edgeTypes)) {
                return '{' + edgeTypes.map(predicateURI => `{${nodeId} ${predicateURI} ?s}`)
                    .join(' union ') + '}';
            }
            return `{${nodeId} ?p ?s}`;
        };
        // List for every valid edge type the statements where:
        // - `nodeId` is the object, or `nodeId` is the subject and the predicate is not "rdf:type"
        const neighborsOf = nodeId => {
            if (!this.supportPropertyPaths) {
                return `{ ${incomingRelations(nodeId)}
          union
          {
            ${outgoingRelations(nodeId)}.
            filter not exists {${nodeId} ${this._categoryPredicate} ?s}. 
          }
        }`;
            }
            if (Utils.hasValue(edgeTypes)) {
                const predicates = edgeTypes.map(edge => `${edge}|^${edge}`).join('|');
                return `{?s ${predicates} ${nodeId}}`;
            }
            return `{?s !(${this._categoryPredicate}|^${this._categoryPredicate}) ${nodeId}}`;
        };
        const adjacentNodesFilter = '{' + sourceIds.map(neighborsOf).join(' union ') + '}';
        let nodeCategoryFilter = '';
        if (Utils.hasValue(nodeCategories)) {
            // `[no_category]` cannot be expressed in a statement
            // Therefore we filter it out and handle it separately
            const concreteCategories = _.filter(nodeCategories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY).map(c => this._utils.formatCategoryValue(c));
            // To filter node categories, we list the statements that describe the valid categories
            // e.g.: `{?s rdf:type PERSON} union {?s rdf:type COMPANY}` => ?s can only be a person or a company
            let categoryFilters = concreteCategories
                .map(category => `{?s ${this._categoryPredicate} ${category}}`);
            // To filter nodes with `[no_category]`, we list all the valid statements
            // and filter out the statements where ?s belong to a category
            if (nodeCategories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                const neighborsWithNoCategory = nodeId => `{
            ${neighborsOf(nodeId)}.
            filter not exists {?s ${this._categoryPredicate} ?c}.
           }`;
                categoryFilters = _.concat(categoryFilters, sourceIds.map(neighborsWithNoCategory));
            }
            nodeCategoryFilter = '{' + categoryFilters.join(' union ') + '}';
        }
        const ignoredNodes = _.concat([], sourceIds, ignoredNodeIds);
        const limitModifier = Utils.hasValue(limit)
            ? `LIMIT ${limit}`
            : '';
        // We avoid using `VALUES` to bind multiple values because it isn't optimised by the graph database
        if (limitType !== 'id') {
            // unfortunately (because it's expensive), we need the cardinality of the neighbors of `nodeId`
            // We query all the adjacent nodes of `?s` and group by `?s the degree is the cardinality of each group`
            return `select ?s (COUNT(*) AS ?count) ${this._fromClause} {
        ${adjacentNodesFilter}
        {
          {
            ?s ?p2 ?o2.  
            filter not exists {?s ${this._categoryPredicate} ?o2}.
            filter isURI(?o2).
          }
          union
          {
            ?o2 ?p2 ?s.
          }
        }
        filter isURI(?s).
        filter (?s NOT IN (${ignoredNodes})).
        ${nodeCategoryFilter}
      }
      group by ?s
      order by ${limitType === 'lowestDegree' ? 'ASC' : 'DESC'}(?count)
      ${limitModifier}`;
        }
        else {
            return `select ?s ${this._fromClause} {
        ${adjacentNodesFilter}
        filter isURI(?s).
        filter (?s NOT IN (${ignoredNodes})).
        ${nodeCategoryFilter}
      }
      ${limitModifier}`;
        }
    }
    /**
     * Blank nodes can't be used in SPARQL queries (except if the driver support blank node labels)
     * so here we simulate the same request made for each node in $getAdjacentNodes.
     *
     * @param {string}   nodeId
     * @param {string}   [limitType]
     * @param {string[]} [categories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [types]      Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<string[][]>}
     * @private
     */
    _getAdjacentNodesBlankNodes(nodeId, limitType, categories, types) {
        let neighbors = []; // nodeId
        const edgeTypeFilter = Utils.hasValue(types)
            ? types.map(type => this._utils.shortNameToFullURI(type)) : undefined;
        return this.connector.$getStatements([nodeId], edgeTypeFilter).then(statementsSubj => {
            _.forEach(statementsSubj, s => {
                if ((s[1] !== this._categoryPredicate && s[2].indexOf('"') !== 0)) {
                    neighbors.push([s[2]]);
                }
            });
            return this.connector.$getStatements(undefined, edgeTypeFilter, [nodeId]);
        }).then(statementsObj => {
            _.forEach(statementsObj, s => {
                neighbors.push([s[0]]);
            });
            if (Utils.hasValue(categories)) {
                const noCategoryAllowed = categories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY);
                // we remove the special LABEL_NODES_WITH_NO_CATEGORY case
                categories = _.filter(categories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                    .map(category => this._utils.formatCategoryValue(category));
                const categoriesToRetrieve = _.uniqBy(neighbors, '0');
                return this.connector.$getStatements(categoriesToRetrieve, [this._categoryPredicate])
                    .then(categoryStatements => {
                    const categoryMap = new Map();
                    _.forEach(categoryStatements, s => {
                        if (!categoryMap.has(s[0])) {
                            categoryMap.set(s[0], []);
                        }
                        categoryMap.get(s[0]).push(s[2]);
                    });
                    neighbors = _.filter(neighbors, n => {
                        if (noCategoryAllowed && categoryMap.get(n[0]).length === 0) {
                            return true;
                        }
                        return _.intersection(categoryMap.get(n[0]), categories).length > 0;
                    });
                });
            }
        }).then(() => {
            if (Utils.noValue(limitType) || limitType === 'id') {
                return neighbors;
            }
            else {
                return Promise.map(neighbors, n => {
                    return this._getNodesDiscreteDegree([n[0]], {}).then(nodeDegree => {
                        // we convert the cardinality to a literal value just to match the same result
                        // of the equivalent SPARQL query in $getAdjacentNodes
                        return [n[0], this._utils.toLiteral(nodeDegree.get(n[0]))];
                    });
                });
            }
        });
    }
    /**
     * Slower implementation of $getAdjacentNodes, too slow for super nodes but compatible with
     * blank nodes.
     * We need to perform a query for every source node, so we can only perform limit and sort
     * in Linkurious directly.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Maximum number of returned nodes
     * @param {string}   options.limitType        Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     * @private
     */
    _getAdjacentNodesForMixedNodes(nodeIds, options) {
        const { ignoredNodeIds, limit, limitType } = options;
        // 1) Retrieve the ids of all the adjacent nodes (and their cardinality if required)
        return Promise.map(nodeIds, nodeId => {
            if (this._utils.isBlankNode(nodeId)) {
                // fallback to the most expensive solution for blank nodes
                return this._getAdjacentNodesBlankNodes(nodeId, limitType, options.nodeCategories, options.edgeTypes);
            }
            // The node ID is not a blank node so we can use a SPARQL query
            // But the generated sparql query should NOT limit the result
            const query = this._generateAdjNodeSparqlQuery([nodeId], {
                limitType: limitType,
                nodeCategories: options.nodeCategories,
                edgeTypes: options.edgeTypes,
                ignoredNodeIds: ignoredNodeIds
            });
            if (Utils.noValue(query)) {
                // query is undefined, nodeId don't have any neighbor
                return [];
            }
            return this.connector.$doSparqlQuery(query);
        }).then(adjacentNodesR => {
            let mergedAdjacentNodesR = [].concat.apply([], adjacentNodesR);
            if (options.limitType !== 'id') {
                // if the cardinality are returned, we convert them to numeric values
                mergedAdjacentNodesR = _.map(mergedAdjacentNodesR, r => [r[0],
                    Number(r[1].slice(1, r[1].indexOf('^') - 1))]);
            }
            // adjacentNodesR[][0] is a nodeId of an adjacent node
            // adjacentNodesR[][1] is (optionally, if `options.limitType` !== "id") its cardinality
            /**@type {Map<string, number | undefined>}*/
            const adjNodesCardinalityMap = new Map(); // if cardinality is undefined we just use this Map as a Set
            for (const pair of mergedAdjacentNodesR) {
                if (Utils.hasValue(pair[0])) { // if edgeType was specified and the edgeType was not found, the pair [null, 0] is returned
                    adjNodesCardinalityMap.set(pair[0], pair[1]);
                }
            }
            // 2) remove ignoredNodeIds
            for (const ignoredNodeId of ignoredNodeIds) {
                adjNodesCardinalityMap.delete(ignoredNodeId);
            }
            // 3) remove sourceNodeIds
            for (const sourceNodeId of nodeIds) {
                adjNodesCardinalityMap.delete(sourceNodeId);
            }
            // 4) decide which ones are the nodes to retrieve and will appear in the result
            let adjNodeIdsWithCardinality = Array.from(adjNodesCardinalityMap.entries());
            if (limitType === 'id') {
                // we sort the keys alphabetically
                adjNodeIdsWithCardinality = _.sortBy(adjNodeIdsWithCardinality, o => o[0]);
            }
            else if (limitType === 'highestDegree') {
                adjNodeIdsWithCardinality = _.sortBy(adjNodeIdsWithCardinality, o => -o[1]);
            }
            else { // lowestDegree
                adjNodeIdsWithCardinality = _.sortBy(adjNodeIdsWithCardinality, o => o[1]);
            }
            return _.map(adjNodeIdsWithCardinality.slice(0, limit), _.head);
        }).then(adjNodeIds => this.$getNodesByURI({ ids: adjNodeIds }));
    }
    /**
     * Faster implementation of $getAdjacentNodes that use only one SPARQL query.
     * If there are blank nodes in nodeIds, we assume that blank node labels are supported.
     * We define as concrete nodes, nodes that are not blank nodes.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Maximum number of returned nodes
     * @param {string}   options.limitType        Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     * @private
     */
    _getAdjacentNodesForConcreteNodes(nodeIds, options) {
        const query = this._generateAdjNodeSparqlQuery(nodeIds, options);
        return Promise.resolve().then(() => {
            if (Utils.noValue(query)) {
                // query is undefined, nodeIds don't have any neighbor
                return [];
            }
            return this.connector.$doSparqlQuery(query).then(adjacentNodesR => {
                return _.flatMap(adjacentNodesR, _.head);
            });
        }).then(adjNodeIds => this.$getNodesByURI({ ids: adjNodeIds }));
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the first set of nodes
     * @param {string[]} otherNodeIds             IDs of the second set of nodes
     * @param {object}   options
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdges(nodeIds, otherNodeIds, options) {
        // TODO do we remove duplicates from Sparql $getMutualEdges?
        if (!this.supportBlankNodeLabels &&
            _.some(nodeIds.concat(otherNodeIds), this._utils.isBlankNode)) {
            return this.$getMutualEdgesBlankNodes(nodeIds, otherNodeIds, options);
        }
        // helper to generate node category filters
        // if nodeCategories is defined, add a category filter statement for each node category
        const categoryFilter = name => {
            if (Utils.hasValue(options.nodeCategories)) {
                return options.nodeCategories
                    .map(c => `{${name} ${this._categoryPredicate} ${this._utils.formatCategoryValue(c)}}`)
                    .join(' union ');
            }
            return '';
        };
        // helper to generate edge type filters
        // if edgeType is defined, bind the predicate ?p to all edgeTypes
        const edgeFilter = mutualEdges => {
            if (Utils.hasValue(options.edgeTypes)) {
                return options.edgeTypes
                    .map(t => `{ BIND (${this._utils.shortNameToFullURI(t)} as ?p). ${mutualEdges} }`)
                    .join(' union ');
            }
            return mutualEdges;
        };
        const sources = this._utils.wrapBlankNodesInAngleBrackets(nodeIds);
        const targets = this._utils.wrapBlankNodesInAngleBrackets(otherNodeIds);
        const query = `select distinct ?source ?p ?target ${this._fromClause} {
      ${edgeFilter(`{
            select ?source ?p ?target {
                ?source ?p ?target.
                ${categoryFilter('?target')}
                filter (?source IN (${sources}) )
                filter (?target IN (${targets}) )
            }
        }
        union 
        {
            select ?source ?p ?target {
                ?source ?p ?target.
                ${categoryFilter('?source')}
                filter (?source IN (${targets}) )
                filter (?target IN (${sources}) )
            }
    
        }`)}
    }`;
        return this.connector.$doSparqlQuery(query).then(mutualEdges => {
            return _.map(mutualEdges, statement => this._utils.parseStatementForEdge(statement));
        });
    }
    /**
     * Get the edges between two set of nodes.
     * This implementation is for blank nodes in DAO that don't support blank node labels.
     *
     * @param {string[]} nodeIds                  IDs of the first set of nodes
     * @param {string[]} otherNodeIds             IDs of the second set of nodes
     * @param {object}   options
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     * @returns {Bluebird<LkEdge[]>}
     */
    $getMutualEdgesBlankNodes(nodeIds, otherNodeIds, options) {
        const edgeTypeFilter = Utils.hasValue(options.edgeTypes)
            ? options.edgeTypes.map(t => this._utils.shortNameToFullURI(t))
            : undefined;
        // 1) Filter otherNodeIds if necessary
        return Promise.resolve().then(() => {
            if (Utils.noValue(options.nodeCategories)) {
                return otherNodeIds;
            }
            const expectedCategories = options.nodeCategories
                .map(c => this._utils.formatCategoryValue(c));
            // Give me all category statements for otherNodeIds
            return this.connector.$getStatements(otherNodeIds, [this._categoryPredicate])
                .then(categoryStatements => {
                // filter the category statements and keep only ids with expected categories
                const filteredNodeIds = categoryStatements.filter(([, , category]) => {
                    return expectedCategories.includes(category);
                }).map(_.head);
                return _.uniq(filteredNodeIds);
            });
        }).then(filteredOtherNodes => {
            if (filteredOtherNodes.length === 0) {
                return [];
            }
            // 2) Give me all statements from nodeIds to otherNodesIds
            const toOthers = this.connector.$getStatements(nodeIds, edgeTypeFilter, filteredOtherNodes);
            // 3) Give me all statements from otherNodesIds to nodeIds
            const fromOthers = this.connector.$getStatements(filteredOtherNodes, edgeTypeFilter, nodeIds);
            return Promise.all([toOthers, fromOthers]).then(mutualEdgeStatements => {
                // 4) Merge all statements
                return _.flatten(mutualEdgeStatements)
                    .map(statement => this._utils.parseStatementForEdge(statement));
            });
        });
    }
    /**
     * Get the neighbors of a subset of nodes.
     *
     * @param {string[]} nodeIds                  IDs of the nodes to retrieve the neighbors for
     * @param {object}   options
     * @param {number}   [options.limit]          Maximum number of returned nodes
     * @param {string}   options.limitType        Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param {string[]} [options.nodeCategories] Exclusive list of node categories to restrict the result
     * @param {string[]} [options.edgeTypes]      Exclusive list of edge types to restrict the result
     * @param {string[]} [options.ignoredNodeIds] IDs of nodes we do not want in the results
     * @returns {Bluebird<LkNode[]>}
     */
    $getAdjacentNodes(nodeIds, options) {
        if (!this.supportBlankNodeLabels && _.some(nodeIds, this._utils.isBlankNode)) {
            return this._getAdjacentNodesForMixedNodes(nodeIds, options);
        }
        return this._getAdjacentNodesForConcreteNodes(nodeIds, options);
    }
    /**
     * Blank nodes can't be used in SPARQL queries (except if the driver support blank node labels)
     * so here we simulate the same request made for each node in $getAdjacencyDigest.
     *
     * Given a blank node, return all the id of the neighbors, their edgeType and nodeCategory
     * (if more than one category returns a triple for each).
     *
     * @param {string} nodeId
     * @returns {Bluebird<string[][]>} triples nodeId, edgeType, nodeCategory
     * @private
     */
    _getAdjacencyDigestBlankNodes(nodeId) {
        /**@type {Array<[string, string]>}*/
        const pairs = []; // nodeId, edgeType
        return this.connector.$getStatements([nodeId]).then(statementsSubj => {
            _.forEach(statementsSubj, s => {
                if ((s[1] !== this._categoryPredicate && s[2].indexOf('"') !== 0)) {
                    pairs.push([s[2], s[1]]);
                }
            });
            return this.connector.$getStatements(undefined, undefined, [nodeId]);
        }).then(statementsObj => {
            _.forEach(statementsObj, s => {
                pairs.push([s[0], s[1]]);
            });
            const categoriesToRetrieve = _.uniqBy(_.map(pairs, s => s[0]), _.identity);
            return this.connector.$getStatements(categoriesToRetrieve, [this._categoryPredicate]);
        }).then(categoryStatements => {
            const categoryMap = new Map();
            _.forEach(categoryStatements, s => {
                if (!categoryMap.has(s[0])) {
                    categoryMap.set(s[0], []);
                }
                categoryMap.get(s[0]).push(s[2]);
            });
            const triples = [];
            _.forEach(pairs, s => {
                const nodeCategories = categoryMap.get(s[0]);
                _.forEach(nodeCategories, nodeCategory => {
                    triples.push([s[0], s[1], nodeCategory]);
                });
            });
            return triples;
        });
    }
    /**
     * Provide a neighborhood digest of a specified subset of nodes.
     *
     * @param {any[]} nodeIds IDs of the nodes
     * @returns {Bluebird<LkDigestItem[]>}
     */
    $getAdjacencyDigest(nodeIds) {
        return Promise.map(nodeIds, nodeId => {
            if (!this.supportBlankNodeLabels && this._utils.isBlankNode(nodeId)) {
                // fallback to the most expensive solution for blank nodes
                return this._getAdjacencyDigestBlankNodes(nodeId);
            }
            if (this._utils.isBlankNode(nodeId)) {
                nodeId = '<' + nodeId + '>'; // wrap in angle bracket
            }
            // if there are no blank nodes or blank node labels are supported, we can use a SPARQL query
            return this.connector.$doSparqlQuery(`select ?s ?p ?c ${this._fromClause}` +
                ' {{?s ?p ' + nodeId + '} union {' + nodeId + ' ?p ?s. filter not exists {' + nodeId + ' ' +
                this._categoryPredicate + ' ?s}. filter isURI(?s).}. optional {?s ' +
                this._categoryPredicate + ' ?c}}');
        }).then(digestR => {
            // digestR is a string[][][], an array (1 entry per node) of array of statements (string[])
            /**@type {string[][]}*/
            const mergedDigestR = [].concat.apply([], digestR);
            // we merge all the triples nodeId, edgeType, nodeCategory in one array
            const result = new Map();
            const groupByEdge = _.groupBy(mergedDigestR, s => s[1]);
            for (const edgeType of _.keys(groupByEdge)) { // we group the statements by edgeType
                const edgeGroup = groupByEdge[edgeType];
                const subGroupByNodeId = _.groupBy(edgeGroup, s => s[0]); // this time we group the statements by nodeId
                for (const nodeId of _.keys(subGroupByNodeId)) {
                    const nodeGroup = subGroupByNodeId[nodeId];
                    let nodeCategories = _.sortBy(_.map(nodeGroup, s => s[2])); // categories for this nodeId
                    // we have 1 node entry for the pair nodeCategories, edgeType
                    // and as many edge entries as the number of duplicates nodeCategories
                    let numberOfEdgeEntries = 1;
                    if (nodeCategories.length >= 2 && nodeCategories[0] === nodeCategories[1]) {
                        const originalLength = nodeCategories.length;
                        nodeCategories = _.sortedUniq(nodeCategories);
                        // every time a node appears x times in the digest it has the same node categories x times
                        numberOfEdgeEntries = originalLength / nodeCategories.length;
                    }
                    const resultKey = '' + [edgeType].concat(nodeCategories);
                    if (!result.has(resultKey)) {
                        if (nodeCategories.indexOf(null) === 0 || nodeCategories.indexOf(undefined) === 0) {
                            nodeCategories = [];
                        }
                        else {
                            nodeCategories = _.map(nodeCategories, c => {
                                return this._utils.parseCategoryValue(c);
                            });
                        }
                        result.set(resultKey, {
                            nodeCategories,
                            edgeType: this._utils.fullURIToShortName(edgeType),
                            nodes: 0,
                            edges: 0
                        });
                    }
                    const resultCount = result.get(resultKey);
                    resultCount.nodes++;
                    resultCount.edges += numberOfEdgeEntries;
                }
            }
            return Array.from(result.values());
        });
    }
    /**
     * Faster implementation of $getNodeDegree that use a SPARQL query.
     * If there are blank nodes in nodeIds, we assume that blank node labels are supported.
     * We define as concrete nodes, nodes that are not blank nodes.
     *
     * @param {string[]} nodeIds
     * @param {object}   options
     * @param {string[]} [options.readableCategories]
     * @param {string[]} [options.readableTypes]
     * @returns {Bluebird<number>}
     * @private
     */
    $getNodeDegreeForConcreteNodes(nodeIds, options) {
        // For performance reasons in this function we prefer BIND and UNION over VALUES
        nodeIds = this._utils.wrapBlankNodesInAngleBrackets(nodeIds);
        let edgeTypes;
        if (Utils.hasValue(options.readableTypes)) {
            edgeTypes = options.readableTypes.map(t => this._utils.shortNameToFullURI(t));
        }
        // List for every valid edge type the statements where `nodeId` is the object
        const incomingRelations = nodeId => {
            if (Utils.hasValue(edgeTypes)) {
                return '{' + edgeTypes.map(predicateURI => `{?s ${predicateURI} ${nodeId}}`)
                    .join(' union ') + '}';
            }
            return `{?s ?p ${nodeId}}`;
        };
        // List for every valid edge type the statements where `nodeId` is the subject
        const outgoingRelations = nodeId => {
            if (Utils.hasValue(edgeTypes)) {
                return '{' + edgeTypes.map(predicateURI => `{${nodeId} ${predicateURI} ?s}`)
                    .join(' union ') + '}';
            }
            return `{${nodeId} ?p ?s}`;
        };
        // List for every valid edge type the statements where:
        // - `nodeId` is the object, or `nodeId` is the subject and the predicate is not "rdf:type"
        const neighborsOf = nodeId => {
            if (!this.supportPropertyPaths) {
                return `{ ${incomingRelations(nodeId)}
          union
          {
            ${outgoingRelations(nodeId)}.
            filter not exists {${nodeId} ${this._categoryPredicate} ?s}. 
          }
        }`;
            }
            if (Utils.hasValue(edgeTypes)) {
                const predicates = edgeTypes.map(edge => `${edge}|^${edge}`).join('|');
                return `{?s ${predicates} ${nodeId}}`;
            }
            return `{?s !(${this._categoryPredicate}|^${this._categoryPredicate}) ${nodeId}}`;
        };
        const adjacentNodesFilter = '{' + nodeIds.map(neighborsOf).join(' union ') + '}';
        const categories = options.readableCategories;
        let nodeCategoryFilter = '';
        if (Utils.hasValue(categories)) {
            // `[no_category]` cannot be expressed in a statement
            // Therefore we filter it out and handle it separately
            const nodeCategories = _.filter(categories, c => c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)
                .map(c => this._utils.formatCategoryValue(c));
            // To filter node categories, we list the statements that describe the valid categories
            // e.g.: `{?s rdf:type PERSON} union {?s rdf:type COMPANY}` => ?s can only be a person or a company
            let categoryFilters = nodeCategories
                .map(category => `{?s ${this._categoryPredicate} ${category}}`);
            // To filter nodes with `[no_category]`, we list all the valid statements
            // and filter out the statements where ?s belong to a category
            if (categories.includes(DaoUtils.LABEL_NODES_WITH_NO_CATEGORY)) {
                const neighborsWithNoCategory = nodeId => `{
            ${neighborsOf(nodeId)}.
            filter not exists {?s ${this._categoryPredicate} ?c}.
          }`;
                categoryFilters = _.concat(categoryFilters, nodeIds.map(neighborsWithNoCategory));
            }
            nodeCategoryFilter = '{' + categoryFilters.join(' union ') + '}';
        }
        // We exclude the source nodes from the possible neighbors in the count
        const sourceNodesFilter = nodeIds.map(id => `?s != ${id}`).join(' && ');
        const degreeSparqlQuery = `select (count(distinct ?s) as ?count)
       ${this._fromClause}
        {   
          ${adjacentNodesFilter}
          ${nodeCategoryFilter}
          filter isURI(?s).
          filter (${sourceNodesFilter}).
        }`;
        return this.connector.$doSparqlQuery(degreeSparqlQuery).then(degreeR => {
            return this._utils.revertLiteral(degreeR[0][0]);
        });
    }
    /**
     * Slower implementation of $getNodeDegree, too slow for super nodes but compatible with
     * blank nodes.
     *
     * @param {string[]} nodeIds
     * @param {object}   options
     * @param {string[]} [options.readableCategories]
     * @param {string[]} [options.readableTypes]
     * @returns {Bluebird<number>}
     * @private
     */
    _getNodeDegreeForBlankNodes(nodeIds, options) {
        return Promise.map(nodeIds, nodeId => {
            if (this._utils.isBlankNode(nodeId)) {
                return this._getAdjacencyDigestBlankNodes(nodeId);
            }
            else {
                return this.connector.$doSparqlQuery(`select ?s ?p ?c ${this._fromClause} {` +
                    '{?s ?p ' + nodeId + '} union {' + nodeId + ' ?p ?s. filter not exists {' + nodeId + ' ' +
                    this._categoryPredicate + ' ?s}. filter isURI(?s).}. optional {?s ' +
                    this._categoryPredicate + ' ?c}}');
            }
        }).then(digestR => {
            // digestR is a string[][][], an array (1 entry per node) of array of statements (string[])
            /**@type {string[][]}*/
            let mergedDigestR = [].concat.apply([], digestR);
            // we merge all the triples nodeId, edgeType, nodeCategory in one array
            // up to here the algorithm is the same of the digest response
            if (options.readableTypes) {
                const edgeTypes = options.readableTypes.map(t => this._utils.shortNameToFullURI(t));
                // remove all the statements where the edgeType is not included in readableTypes
                mergedDigestR = _.filter(mergedDigestR, stmt => edgeTypes.includes(stmt[1]));
            }
            if (options.readableCategories) {
                const nodeCategories = options.readableCategories.map(c => {
                    if (c !== DaoUtils.LABEL_NODES_WITH_NO_CATEGORY) {
                        return this._utils.formatCategoryValue(c);
                    }
                    else {
                        return null; // null is the "no categories" category in digestR
                    }
                });
                // remove all the statements where the nodeCategory is not included in readableCategories
                mergedDigestR = _.filter(mergedDigestR, stmt => nodeCategories.includes(stmt[2]));
            }
            return _.uniqBy(_.map(mergedDigestR, s => s[0]), _.identity).length;
        });
    }
    /**
     * Return the degrees of the specified nodes.
     * If `discreteResults` is false:
     *   Return the degree of the specified node if `nodeIds` has cardinality 1.
     *   If multiple `nodeIds` are specified, return the cardinality of the intersection
     *   of the neighbors of the nodes (not including the nodes in input themselves).
     * If `discreteResults` is true:
     *   Return a map indexed by id populated with the degree of each node.
     *
     * @param {any[]}    nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @param {boolean}  [options.discreteResults]    Whether to return the degree of each node
     * @returns {Bluebird<number | Map<string, number>>}
     */
    $getNodeDegree(nodeIds, options) {
        if (options.discreteResults) {
            return this._getNodesDiscreteDegree(nodeIds, options);
        }
        return this._getNodesCombinedDegree(nodeIds, options);
    }
    /**
     * Return a map indexed by id populated with the degree of each node.
     *
     * @param {any[]}    nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<Map<string, number>>}
     * @private
     */
    _getNodesDiscreteDegree(nodeIds, options) {
        return Promise.reduce(nodeIds, (nodesDegree, nodeId) => {
            return this._getNodesCombinedDegree([nodeId], options)
                .then(degree => nodesDegree.set(nodeId, degree));
        }, new Map());
    }
    /**
     * Return the degree of the specified node if `nodeIds` has cardinality 1.
     * If multiple `nodeIds` are specified, return the cardinality of the intersection
     * of the neighbors of the nodes (not including the nodes in input themselves).
     *
     * @param {any[]}    nodeIds                      IDs of the nodes
     * @param {object}   options
     * @param {string[]} [options.readableCategories] Exclusive list of node-categories to restrict the result
     * @param {string[]} [options.readableTypes]      Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<number>}
     * @private
     */
    _getNodesCombinedDegree(nodeIds, options) {
        if (!this.supportBlankNodeLabels && _.some(nodeIds, this._utils.isBlankNode)) {
            // fallback to the most expensive solution for blank nodes
            return this._getNodeDegreeForBlankNodes(nodeIds, options);
        }
        // if there are no blank nodes or blank node labels are supported, we can use a SPARQL query
        return this.$getNodeDegreeForConcreteNodes(nodeIds, options);
    }
    /**
     * Return a map indexed by id populated with `true` if the node is a supernode.
     * A supernode is a node with a number of relationships greater or equal than `supernodeThreshold`.
     * Return `false` if the node is not found.
     *
     * This implementation assumes that blank nodes are supported by the graph vendor.
     * If that's not the case, a different implementation should be used.
     *
     * @param {any[]}  nodeIds            IDs of the node
     * @param {number} supernodeThreshold
     * @returns {Bluebird<Map<string, boolean>>}
     */
    $isSuperNode(nodeIds, supernodeThreshold) {
        const superNodeResult = new Map();
        // 1) Wrap blank nodes if required
        const superNodeCandidates = this._utils.wrapBlankNodesInAngleBrackets(nodeIds);
        // 2) Count every statement with `nodeId` as subject or object
        // We do not filter out node properties statements because the ratio to relations statements
        // is very small in case of a supernode
        const toStatements = id => `
      {{BIND (${id} as ?s). ?s ?p ?o.} union {BIND (${id} as ?s). ?o ?p ?s.}}`;
        const isSuperNodeQuery = `select ?s (count(?o) as ?count) ${this._fromClause} where {
        ${superNodeCandidates.map(toStatements).join(' union ')}
    } group by ?s`;
        return this.connector.$doSparqlQuery(isSuperNodeQuery).then(result => {
            _.forEach(result, ([id, statementsCount]) => {
                superNodeResult.set(id, this._utils.revertLiteral(statementsCount) >= supernodeThreshold);
            });
            return superNodeResult;
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * This implementation assumes that blank nodes are supported by the graph vendor.
     * If that's not the case, a different implementation should be used.
     *
     * @param {any}      nodeId                  ID of the node
     * @param {object}   options
     * @param {string[]} [options.readableTypes] Exclusive list of edge-type to restrict the result
     * @returns {Bluebird<LkEdgeDigestItem[]>}
     */
    $getEdgeDigest(nodeId, options) {
        if (this._utils.isBlankNode(nodeId) && !this.supportBlankNodeLabels) {
            // TODO #1391 implement getEdgeDigest for blank nodes
            // we do not compute the edge digest for blank nodes if blank node labels are not supported.
            return [];
        }
        let edgeTypeFilter = '';
        // 1) Wrap blank nodes if required
        const [wrappedId] = this._utils.wrapBlankNodesInAngleBrackets([nodeId]);
        // 2) Build edge type filter if required
        if (Utils.hasValue(options.readableTypes)) {
            if (options.readableTypes.length === 0) {
                return Promise.resolve([]);
            }
            const filterClauses = options.readableTypes
                .map(type => `?p = ${this._utils.shortNameToFullURI(type)}`).join(' || ');
            edgeTypeFilter = `filter (${filterClauses})`;
        }
        // 3) Find every predicate with `nodeId` as subject or object, group count by predicate
        const edgeDigestQuery = `select ?p (count(?p) as ?count) ${this._fromClause}  where {
      {BIND (${wrappedId} as ?s). ?s ?p ?o filter isURI(?o).}
      union
      {BIND (${wrappedId} as ?s). ?o ?p ?s.}
      filter (?p != ${this._categoryPredicate})
      ${edgeTypeFilter}
    } group by ?p`;
        return this.connector.$doSparqlQuery(edgeDigestQuery).then(result => {
            // An empty edge list can still be grouped as ?p => undefined, ?count => 0
            const countByEdge = result.filter(([edge]) => Utils.hasValue(edge));
            return countByEdge.map(([edge, count]) => ({
                edgeType: this._utils.fullURIToShortName(edge),
                edges: this._utils.revertLiteral(count)
            }));
        });
    }
    /**
     * Create a node.
     *
     * @param {LkNodeAttributes} newNode
     * @returns {Bluebird<LkNode>}
     */
    $createNode(newNode) {
        const nodeWithId = Utils.clone(newNode);
        if (Utils.noValue(nodeWithId.id)) {
            if (Utils.hasValue(this._idPropertyName) &&
                Utils.hasValue(newNode.data[this._idPropertyName])) {
                // if the user has chosen an id, use it
                if (this._utils.isBlankNode(newNode.data[this._idPropertyName])) {
                    // we cannot let the user create new blank nodes, id will change and mess the indexation
                    return Errors.business('not_supported', 'Creation of blank nodes is not supported by Linkurious.', true);
                }
                nodeWithId.id = this._utils.shortNameToFullURI(nodeWithId.data[this._idPropertyName]);
                delete nodeWithId.data[this._idPropertyName];
            }
            else {
                // if not, pick one randomly
                nodeWithId.id = this._utils.shortNameToFullURI(shortid.generate());
            }
        }
        return this.connector.$addStatements(this._utils.formatNodeToStatements(nodeWithId)).return(nodeWithId);
    }
    /**
     * Update the properties and categories of a node.
     * Check if the node exists and fail if it doesn't.
     *
     * @param {any}      nodeId                       ID of the node to update
     * @param {object}   nodeUpdate
     * @param {any}      nodeUpdate.data              Properties to update
     * @param {string[]} nodeUpdate.deletedProperties Properties to delete
     * @param {string[]} nodeUpdate.addedCategories   Categories to add
     * @param {string[]} nodeUpdate.deletedCategories Categories to delete
     * @returns {Bluebird<LkNode>} null if not found
     */
    $updateNode(nodeId, nodeUpdate) {
        if (Utils.hasValue(this._idPropertyName) &&
            Utils.hasValue(nodeUpdate.data[this._idPropertyName])) {
            return Errors.business('not_supported', 'Updating the id is not supported in a triple store.', true);
        }
        const deleteArray = [];
        const newStatements = [];
        return this._getNode({ id: nodeId }).then(node => {
            if (Utils.noValue(node)) {
                return null;
            }
            const updatedProperties = [];
            for (const property in nodeUpdate.data) {
                if (nodeUpdate.data.hasOwnProperty(property) && node.data.hasOwnProperty(property)) {
                    updatedProperties.push(property);
                }
            }
            let afterEditStatementsCount = this._utils.formatNodeToStatements(node).length;
            // 1) delete updated properties
            _.forEach(updatedProperties, property => {
                afterEditStatementsCount--;
                deleteArray.push({
                    subject: nodeId,
                    predicate: this._utils.shortNameToFullURI(property),
                    object: undefined
                });
            });
            // 2) delete deleted properties
            _.forEach(nodeUpdate.deletedProperties, property => {
                afterEditStatementsCount--;
                deleteArray.push({
                    subject: nodeId,
                    predicate: this._utils.shortNameToFullURI(property),
                    object: undefined
                });
            });
            // 3) delete deleted categories
            _.forEach(nodeUpdate.deletedCategories, category => {
                afterEditStatementsCount--;
                deleteArray.push({
                    subject: nodeId,
                    predicate: this._categoryPredicate,
                    object: this._utils.formatCategoryValue(category)
                });
            });
            // 4) add new categories
            for (const category of nodeUpdate.addedCategories) {
                afterEditStatementsCount++;
                newStatements.push([
                    nodeId,
                    this._categoryPredicate,
                    this._utils.formatCategoryValue(category)
                ]);
            }
            // 5) add new properties
            for (const property of Object.keys(nodeUpdate.data)) {
                afterEditStatementsCount++;
                newStatements.push([
                    nodeId,
                    this._utils.shortNameToFullURI(property),
                    this._utils.toLiteral(nodeUpdate.data[property])
                ]);
            }
            if (afterEditStatementsCount === 0) {
                return Errors.business('invalid_parameter', 'A node must have at least one property or one category.', true);
            }
            return this.connector.$deleteMultipleStatements(deleteArray).then(() => {
                return this.connector.$addStatements(newStatements);
            }).then(() => {
                return this._getNode({ id: nodeId });
            });
        });
    }
    /**
     * Delete a node and all edges connected to it.
     *
     * @param {any} nodeId ID of the node to delete
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteNode(nodeId) {
        return this.connector.$deleteStatements(undefined, undefined, nodeId).then(resultObj => {
            return this.connector.$deleteStatements(nodeId).then(resultSubj => {
                return resultObj || resultSubj;
            });
        });
    }
    /**
     * Create an edge.
     *
     * This method is responsible to check that source and target nodes have been found.
     *
     * @param {LkEdgeAttributes} newEdge The edge to create
     * @returns {Bluebird<LkEdge>}
     */
    $createEdge(newEdge) {
        // first, verify that source and target exist
        return this.$getNodesByID({ ids: [newEdge.source, newEdge.target] }).then(nodes => {
            try {
                Utils.checkMissing('node', [newEdge.source, newEdge.target], nodes);
            }
            catch (e) {
                return Errors.business('node_not_found', 'Source or target node not found.', true);
            }
            const edgeWithId = Utils.clone(newEdge);
            edgeWithId.id = this._utils.getIdFromEdge(newEdge);
            return this.connector.$addStatements([this._utils.formatEdgeToStatement(edgeWithId)]).return(edgeWithId);
        });
    }
    /**
     * Delete an edge.
     *
     * @param {any} edgeId ID of the edge
     * @returns {Bluebird<boolean>} true if deleted
     */
    $deleteEdge(edgeId) {
        const edge = this._utils.getEdgeFromId(edgeId);
        const edgeTriple = this._utils.formatEdgeToStatement(edge);
        // we forbid the edge deletion if the source and/or target nodes are empty
        return this.$getNodesByID({ ids: [edge.source, edge.target] }).then(nodes => {
            try {
                Utils.checkMissing('node', [edge.source, edge.target], nodes);
            }
            catch (e) {
                return false;
            }
            if (this.$isEmptyNode(nodes[0]) || this.$isEmptyNode(nodes[1])) {
                return Errors.business('not_supported', 'Deleting an edge connected to an empty node is prohibited in a triple store', true);
            }
            return this.connector.$deleteStatements(edgeTriple[0], edgeTriple[1], edgeTriple[2]);
        });
    }
    /**
     * Run a raw query.
     *
     * If options.populated is true, return a Readable<QueryMatchPopulated>, otherwise a Readable<QueryMatch>.
     *
     * @param {object}   options
     * @param {string}   options.dialect   Supported graph query dialect
     * @param {string[]} options.queries   The graph queries
     * @param {boolean}  options.populated Whether to return QueryMatchPopulated or QueryMatch
     * @param {number}   options.limit     Maximum number of matched subgraphs
     * @returns {Promise<Readable<(QueryMatch | QueryMatchPopulated)>>}
     */
    $rawQuery(options) {
        const mockStream = new stream.PassThrough({ objectMode: true });
        const nodeCache = new Map();
        const run = (query) => __awaiter(this, void 0, void 0, function* () {
            const reasoning = this.$requiresReasoning(query) ? 'enabled' : 'default';
            // TODO #938 sparql rawQuery, use a stream
            const statements = yield this.connector.$doSparqlQuery(// each statement is a subgraph
            this._utils.enforceLimit(query, options.limit).query, {
                timeout: Config.get('advanced.rawQueryTimeout'),
                reasoning: reasoning
            });
            // 2) Collect all the URI I can find
            for (const statement of statements) {
                const candidateNodeIds = [];
                const fromCache = [];
                for (const element of statement) {
                    if (Utils.hasValue(element) && this._utils.isURI(element)) {
                        if (nodeCache.has(element)) {
                            fromCache.push(nodeCache.get(element));
                        }
                        else {
                            candidateNodeIds.push(element);
                        }
                    }
                }
                const edges = [];
                if (this._utils.statementIsATriple(statement) && this._utils.statementIsAnEdge(statement)) {
                    try {
                        edges.push(this._utils.parseStatementForEdge(statement));
                    }
                    catch (e) {
                        Log.warn('Could not parse edge statement: ', e.message);
                    }
                }
                // 3) Retrieve the nodes
                const nodes = yield this.$getNodesByURI({ ids: candidateNodeIds, reasoning: reasoning });
                nodes.forEach(node => nodeCache.set(node.id, node));
                mockStream.push({ nodes: fromCache.concat(nodes), edges: edges, properties: {} });
            }
        });
        Promise.map(options.queries, run)
            .catch(error => mockStream.emit('error', error))
            .finally(() => mockStream.end());
        return mockStream;
    }
    /**
     * Return true is query is a write query.
     */
    $isWrite(query) {
        return this._utils.isWrite(query);
    }
    /**
     * Check if a query is correct.
     *
     * @param {string}  query      The graph query
     * @returns {boolean} Whether the `query` will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    $checkQuery(query) {
        return this._utils.checkQuery(query);
    }
    /**
     * Return true if the node specified is empty.
     *
     * @param {LkNode | LkNodeAttributes} node
     * @returns {boolean}
     */
    $isEmptyNode(node) {
        let properties = Object.keys(node.data);
        if (Utils.hasValue(this._idPropertyName)) {
            // _idPropertyName is an artificial property not actually stored so it doesn't count
            properties = _.filter(properties, p => p !== this._idPropertyName);
        }
        // if it has no category and no property, it's empty
        return node.categories.length === 0 && properties.length === 0;
    }
    /**
     * Return true if `query` contains the directive to enable reasoning.
     *
     * @param {string} query
     * @returns {boolean}
     */
    $requiresReasoning(query) {
        return /(^|\n|\r)\s*#\s*REASONING=TRUE\s*($|\n|\r)/i.test(query);
    }
}
module.exports = SparqlDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BhcnFsRHJpdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby9ncmFwaC9zcGFycWxEcml2ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7Ozs7Ozs7OztBQUNiLGdCQUFnQjtBQUNoQixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFakMsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNuQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sRUFBQyxrQkFBa0IsRUFBQyxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRTlELFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLFNBQVM7QUFDVCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDN0MsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDcEQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFFOUMsb0RBQW9EO0FBQ3BELE1BQU0seUJBQXlCLEdBQUcsS0FBSyxDQUFDLENBQUMsYUFBYTtBQUV0RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBb0NHO0FBQ0gsTUFBTSxZQUFhLFNBQVEsV0FBVztJQUVwQzs7Ozs7Ozs7O09BU0c7SUFDSCxZQUFZLFNBQVMsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxhQUFhO1FBQzlFLEtBQUssQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUU3RCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUU3RCwyREFBMkQ7UUFDM0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBRTtZQUNyRCxXQUFXLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRTtvQkFDdEQsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRTt3QkFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkQsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxFQUFDO1lBQ0YsaUJBQWlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDdEQsZ0JBQWdCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7U0FDdEQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLFdBQVcsQ0FDM0IsYUFBYSxDQUFDLFdBQVcsRUFDekIsYUFBYSxDQUFDLGdCQUFnQixFQUM5QixhQUFhLENBQUMsaUJBQWlCLEVBQy9CLElBQUksQ0FBQyxlQUFlLENBQ3JCLENBQUM7UUFFRixJQUFJLENBQUMsa0JBQWtCLEdBQUcsYUFBYSxDQUFDLGlCQUFpQixDQUFDO1FBQzFELElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQztRQUV6QyxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixFQUFFO1lBQ2xGLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsbURBQW1EO2dCQUMvRSxzQ0FBc0MsQ0FBQyxDQUFDO1NBQzNDO1FBRUQsSUFBSSxDQUFDLHNCQUFzQixHQUFHLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQztRQUVuRSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsYUFBYSxDQUFDLG9CQUFvQixDQUFDO0lBQ2pFLENBQUM7SUFFRDs7T0FFRztJQUNILGVBQWU7UUFDYixPQUFPLHdCQUF3QixDQUFDO0lBQ2xDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSSxrQkFBa0I7UUFDcEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRTtZQUFFLE9BQU8sRUFBRSxDQUFDO1NBQUU7UUFFdkQsT0FBTyxDQUFDO2dCQUNOLEdBQUcsRUFBRSxJQUFJLENBQUMsZUFBZTtnQkFDekIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsTUFBTSxFQUFFLElBQUk7Z0JBQ1osTUFBTSxFQUFFLEtBQUs7YUFDZCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVO1FBQ3RCLFFBQVEsVUFBVSxFQUFFO1lBQ2xCLEtBQUssa0JBQWtCLENBQUMsSUFBSTtnQkFDMUIsTUFBTSxFQUFFLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ2hDLE9BQU8sRUFBRSxDQUFDO1lBQ1osS0FBSyxrQkFBa0IsQ0FBQyxRQUFRO2dCQUM5QixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RELE9BQU8sSUFBSSxLQUFLLEdBQUcsQ0FBQztZQUN0QixLQUFLLGtCQUFrQixDQUFDLFdBQVcsQ0FBQztZQUNwQyxLQUFLLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDO1lBQ3pDLEtBQUssa0JBQWtCLENBQUMsTUFBTTtnQkFDNUIsT0FBTyxJQUFJLEtBQUssR0FBRyxDQUFDO1lBQ3RCO2dCQUNFLE9BQU8sS0FBSyxHQUFHLEVBQUUsQ0FBQztTQUNyQjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUk7WUFDRixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUMzQyxNQUFNLE1BQU0sR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRCxNQUFNLE1BQU0sR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNsRDtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxFQUFFLEdBQUcsb0NBQW9DO2dCQUN4RixHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsQ0FBQztTQUMzQjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDMUQsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsbUNBQW1DO2dCQUN4RixpQ0FBaUMsQ0FBQyxDQUFDO1NBQ3RDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxnQkFBZ0I7UUFDZCxNQUFNLFFBQVEsR0FBRztZQUNmLGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FDM0MsMEJBQTBCLElBQUksQ0FBQyxXQUFXLGVBQWUsSUFBSSxDQUFDLGtCQUFrQixVQUFVLEVBQzFGLEVBQUMsT0FBTyxFQUFFLHlCQUF5QixFQUFDLENBQ3JDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUNoRSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDckQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRTtnQkFDWixPQUFPLEVBQUUsQ0FBQyxDQUFDLDBCQUEwQjtZQUN2QyxDQUFDLENBQUM7WUFFRixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQ3RDLHNCQUFzQixJQUFJLENBQUMsV0FBVztrQ0FDWixJQUFJLENBQUMsa0JBQWtCLHFCQUFxQixFQUN0RSxFQUFDLE9BQU8sRUFBRSx5QkFBeUIsRUFBQyxDQUNyQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDNUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDLENBQUM7WUFFRixjQUFjLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQzNDLHNCQUFzQixJQUFJLENBQUMsV0FBVztrQ0FDWixJQUFJLENBQUMsa0JBQWtCLHlCQUF5QixFQUMxRSxFQUFDLE9BQU8sRUFBRSx5QkFBeUIsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUN0RCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLEVBQUU7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN6RCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUNaLE9BQU8sRUFBRSxDQUFDO1lBQ1osQ0FBQyxDQUFDO1lBRUYsY0FBYyxFQUFFLEVBQUU7U0FDbkIsQ0FBQztRQUVGLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsUUFBUSxDQUFDLE9BQU87UUFDZCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDeEIsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztTQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhLENBQUMsT0FBTztRQUNuQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILDRCQUE0QixDQUFDLE9BQU87UUFDbEMsTUFBTSxFQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUMsR0FBRyxPQUFPLENBQUM7UUFDakMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoRSxNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxLQUFLLHFCQUFxQixDQUFDO2FBQzlFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVuQixNQUFNLEtBQUssR0FBRyxtQkFBbUIsSUFBSSxDQUFDLFdBQVcsWUFBWSxhQUFhLEVBQUU7WUFDMUUsaUNBQWlDLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxDQUFDO1FBRWhFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2pGLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QyxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNyRCxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUM1QixPQUFPLE9BQU8sQ0FBQzthQUNoQjtpQkFBTTtnQkFDTCw2REFBNkQ7Z0JBQzdELDhEQUE4RDtnQkFDOUQsTUFBTSxjQUFjLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxrQ0FBa0MsR0FBRyxFQUFFO29CQUN0Rix1REFBdUQsR0FBRyxzQkFBc0I7b0JBQ2hGLGdCQUFnQixJQUFJLENBQUMsa0JBQWtCLGFBQWEsQ0FBQztxQkFDcEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNuQixNQUFNLGVBQWUsR0FBRyxxQkFBcUIsY0FBYyxJQUFJLENBQUM7Z0JBQ2hFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDO3FCQUMxRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLGlCQUFpQixDQUFDLENBQUMsQ0FBQzthQUNwRTtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNILGNBQWMsQ0FBQyxPQUFPO1FBQ3BCOzs7V0FHRztRQUNILE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQyxNQUFNLEdBQUcsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRS9CLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDcEIsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzVCO1FBRUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVqQyxJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFO2dCQUNoQyxNQUFNLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzlFLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTtvQkFDckIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHdCQUF3QixDQUFDLFVBQVUsRUFBRSxFQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFDLENBQUM7eUJBQ3ZGLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO3dCQUMzQixzRUFBc0U7d0JBQ3RFLGlFQUFpRTt3QkFDakUsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQ3RDLEVBQUMsR0FBRyxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBQyxDQUNuRCxDQUFDLElBQUksQ0FDSix1QkFBdUIsQ0FBQyxFQUFFLENBQUMsdUJBQXVCLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQ2hGLENBQUM7b0JBQ0osQ0FBQyxDQUFDLENBQUM7aUJBQ047YUFDRjtZQUVELGlFQUFpRTtZQUNqRSxnRUFBZ0U7WUFDaEUsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUMsRUFBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQztRQUNyRixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFFbkIsdUJBQXVCO1lBQ3ZCLGlDQUFpQztZQUNqQywrREFBK0Q7WUFDL0QsdUZBQXVGO1lBQ3ZGLDBEQUEwRDtZQUMxRCxNQUFNLENBQUMsY0FBYyxFQUFFLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUM5RCxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXZGLHlFQUF5RTtZQUN6RSxNQUFNLGNBQWMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUV4RixNQUFNLGtCQUFrQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDckMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQzVCLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsaUZBQWlGO2dCQUNqRixrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7WUFFSCxNQUFNLFFBQVEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBRTNCLHNGQUFzRjtZQUN0RixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7Z0JBQzdELElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDbkIsSUFBSTt3QkFDRixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2RCxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7NEJBQ2pCLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO3lCQUN6QjtxQkFDRjtvQkFBQyxPQUFNLENBQUMsRUFBRTt3QkFDVCxHQUFHLENBQUMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDbEQ7aUJBQ0Y7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUVILHFGQUFxRjtZQUNyRixrQkFBa0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xDLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQy9DLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFFaEIsK0NBQStDO29CQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUN4QyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQ2xEO29CQUVELFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEVBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7aUJBQzFEO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGFBQWEsQ0FBQyxPQUFPO1FBQ25CLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ25DLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVuRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUNuQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FDekMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsRUFBRTtnQkFDNUIsSUFBSSxvQkFBb0IsRUFBRTtvQkFDeEIsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDbkIsVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQy9DLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUVqQixDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDNUIsSUFBSTtvQkFDRixLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztpQkFDdEQ7Z0JBQUMsT0FBTSxDQUFDLEVBQUU7b0JBQ1QsR0FBRyxDQUFDLElBQUksQ0FBQyxrQ0FBa0MsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQ3pEO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F3Qkc7SUFDSCwyQkFBMkIsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUMxQyxnRkFBZ0Y7UUFDaEYsTUFBTSxFQUFDLGNBQWMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLGNBQWMsRUFBQyxHQUFHLE9BQU8sQ0FBQztRQUNuRSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXJFLElBQUksU0FBUyxDQUFDO1FBQ2QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUVyQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDM0U7UUFFRCw2RUFBNkU7UUFDN0UsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQzdCLE9BQU8sR0FBRyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxPQUFPLFlBQVksSUFBSSxNQUFNLEdBQUcsQ0FBQztxQkFDekUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzthQUMxQjtZQUNELE9BQU8sVUFBVSxNQUFNLEdBQUcsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFFRiw4RUFBOEU7UUFDOUUsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQzdCLE9BQU8sR0FBRyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxJQUFJLE1BQU0sSUFBSSxZQUFZLE1BQU0sQ0FBQztxQkFDekUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsQ0FBQzthQUMxQjtZQUNELE9BQU8sSUFBSSxNQUFNLFNBQVMsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFFRix1REFBdUQ7UUFDdkQsMkZBQTJGO1FBQzNGLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxFQUFFO1lBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7Z0JBQzlCLE9BQU8sS0FBSyxpQkFBaUIsQ0FBQyxNQUFNLENBQUM7OztjQUcvQixpQkFBaUIsQ0FBQyxNQUFNLENBQUM7aUNBQ04sTUFBTSxJQUFJLElBQUksQ0FBQyxrQkFBa0I7O1VBRXhELENBQUM7YUFDSjtZQUNELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDN0IsTUFBTSxVQUFVLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN2RSxPQUFPLE9BQU8sVUFBVSxJQUFJLE1BQU0sR0FBRyxDQUFDO2FBQ3ZDO1lBQ0QsT0FBTyxTQUFTLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLENBQUMsa0JBQWtCLEtBQUssTUFBTSxHQUFHLENBQUM7UUFDcEYsQ0FBQyxDQUFDO1FBRUYsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBRW5GLElBQUksa0JBQWtCLEdBQUcsRUFBRSxDQUFDO1FBRTVCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUVsQyxxREFBcUQ7WUFDckQsc0RBQXNEO1lBQ3RELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FDakMsY0FBYyxFQUNkLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FDakQsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFL0MsdUZBQXVGO1lBQ3ZGLG1HQUFtRztZQUNuRyxJQUFJLGVBQWUsR0FBRyxrQkFBa0I7aUJBQ3JDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFFbEUseUVBQXlFO1lBQ3pFLDhEQUE4RDtZQUM5RCxJQUFJLGNBQWMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7Z0JBQ2xFLE1BQU0sdUJBQXVCLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FDdkM7Y0FDSSxXQUFXLENBQUMsTUFBTSxDQUFDO29DQUNHLElBQUksQ0FBQyxrQkFBa0I7YUFDOUMsQ0FBQztnQkFFTixlQUFlLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7YUFDckY7WUFDRCxrQkFBa0IsR0FBRyxHQUFHLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDbEU7UUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFFN0QsTUFBTSxhQUFhLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7WUFDekMsQ0FBQyxDQUFDLFNBQVMsS0FBSyxFQUFFO1lBQ2xCLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFUCxtR0FBbUc7UUFDbkcsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3RCLCtGQUErRjtZQUMvRix3R0FBd0c7WUFDeEcsT0FBTyxrQ0FBa0MsSUFBSSxDQUFDLFdBQVc7VUFDckQsbUJBQW1COzs7O29DQUlPLElBQUksQ0FBQyxrQkFBa0I7Ozs7Ozs7Ozs2QkFTOUIsWUFBWTtVQUMvQixrQkFBa0I7OztpQkFHWCxTQUFTLEtBQUssY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU07UUFDdEQsYUFBYSxFQUFFLENBQUM7U0FFbkI7YUFBTTtZQUNMLE9BQU8sYUFBYSxJQUFJLENBQUMsV0FBVztVQUNoQyxtQkFBbUI7OzZCQUVBLFlBQVk7VUFDL0Isa0JBQWtCOztRQUVwQixhQUFhLEVBQUUsQ0FBQztTQUNuQjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsMkJBQTJCLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsS0FBSztRQUM5RCxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsQ0FBQyxTQUFTO1FBRTdCLE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFeEUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNuRixDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtvQkFDakUsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3hCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzVFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN0QixDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDM0IsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekIsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQzlCLE1BQU0saUJBQWlCLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsNEJBQTRCLENBQUMsQ0FBQztnQkFFckYsMERBQTBEO2dCQUMxRCxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQzlCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQztxQkFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUU5RCxNQUFNLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUN0RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLG9CQUFvQixFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7cUJBQ2xGLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUN6QixNQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUU5QixDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxFQUFFO3dCQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDMUIsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7eUJBQzNCO3dCQUNELFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNuQyxDQUFDLENBQUMsQ0FBQztvQkFFSCxTQUFTLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUU7d0JBQ2xDLElBQUksaUJBQWlCLElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFOzRCQUMzRCxPQUFPLElBQUksQ0FBQzt5QkFDYjt3QkFDRCxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUN0RSxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQzthQUNOO1FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUNsRCxPQUFPLFNBQVMsQ0FBQzthQUNsQjtpQkFBTTtnQkFDTCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFO29CQUNoQyxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTt3QkFDaEUsOEVBQThFO3dCQUM5RSxzREFBc0Q7d0JBQ3RELE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzdELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2FBQ0o7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCw4QkFBOEIsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUM3QyxNQUFNLEVBQUMsY0FBYyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUMsR0FBRyxPQUFPLENBQUM7UUFDbkQsb0ZBQW9GO1FBQ3BGLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbkMsMERBQTBEO2dCQUMxRCxPQUFPLElBQUksQ0FBQywyQkFBMkIsQ0FDckMsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQzdELENBQUM7YUFDSDtZQUNELCtEQUErRDtZQUMvRCw2REFBNkQ7WUFFN0QsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3ZELFNBQVMsRUFBRSxTQUFTO2dCQUNwQixjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7Z0JBQ3RDLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsY0FBYyxFQUFFLGNBQWM7YUFDL0IsQ0FBQyxDQUFDO1lBRUgsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN4QixxREFBcUQ7Z0JBQ3JELE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN2QixJQUFJLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUUvRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUM5QixxRUFBcUU7Z0JBQ3JFLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzNELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xEO1lBRUQsc0RBQXNEO1lBQ3RELHVGQUF1RjtZQUV2Riw0Q0FBNEM7WUFDNUMsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMsNERBQTREO1lBRXRHLEtBQUssTUFBTSxJQUFJLElBQUksb0JBQW9CLEVBQUU7Z0JBQ3ZDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLDJGQUEyRjtvQkFDeEgsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDOUM7YUFDRjtZQUVELDJCQUEyQjtZQUMzQixLQUFLLE1BQU0sYUFBYSxJQUFJLGNBQWMsRUFBRTtnQkFDMUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQzlDO1lBRUQsMEJBQTBCO1lBQzFCLEtBQUssTUFBTSxZQUFZLElBQUksT0FBTyxFQUFFO2dCQUNsQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7YUFDN0M7WUFFRCwrRUFBK0U7WUFDL0UsSUFBSSx5QkFBeUIsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFFN0UsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUN0QixrQ0FBa0M7Z0JBQ2xDLHlCQUF5QixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RTtpQkFBTSxJQUFJLFNBQVMsS0FBSyxlQUFlLEVBQUU7Z0JBQ3hDLHlCQUF5QixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMseUJBQXlCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzdFO2lCQUFNLEVBQUUsZUFBZTtnQkFDdEIseUJBQXlCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVFO1lBRUQsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBQyxHQUFHLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILGlDQUFpQyxDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQ2hELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFakUsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3hCLHNEQUFzRDtnQkFDdEQsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUNoRSxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBQyxHQUFHLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxlQUFlLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQzVDLDREQUE0RDtRQUM1RCxJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQjtZQUM5QixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUUvRCxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3ZFO1FBRUQsMkNBQTJDO1FBQzNDLHVGQUF1RjtRQUN2RixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsRUFBRTtZQUM1QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUMxQyxPQUFPLE9BQU8sQ0FBQyxjQUFjO3FCQUMxQixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsa0JBQWtCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO3FCQUN0RixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDcEI7WUFDRCxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUMsQ0FBQztRQUVGLHVDQUF1QztRQUN2QyxpRUFBaUU7UUFDakUsTUFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLEVBQUU7WUFDL0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDckMsT0FBTyxPQUFPLENBQUMsU0FBUztxQkFDckIsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxZQUFZLFdBQVcsSUFBSSxDQUFDO3FCQUNqRixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDcEI7WUFDRCxPQUFPLFdBQVcsQ0FBQztRQUNyQixDQUFDLENBQUM7UUFFRixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ25FLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFeEUsTUFBTSxLQUFLLEdBQUcsc0NBQXNDLElBQUksQ0FBQyxXQUFXO1FBQ2hFLFVBQVUsQ0FDZDs7O2tCQUdjLGNBQWMsQ0FBQyxTQUFTLENBQUM7c0NBQ0wsT0FBTztzQ0FDUCxPQUFPOzs7Ozs7O2tCQU8zQixjQUFjLENBQUMsU0FBUyxDQUFDO3NDQUNMLE9BQU87c0NBQ1AsT0FBTzs7O1VBR25DLENBQ1A7TUFDRyxDQUFDO1FBRUgsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDN0QsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUN2RixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gseUJBQXlCLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPO1FBQ3RELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUN0RCxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9ELENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFZCxzQ0FBc0M7UUFDdEMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUN6QyxPQUFPLFlBQVksQ0FBQzthQUNyQjtZQUNELE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLGNBQWM7aUJBQzlDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVoRCxtREFBbUQ7WUFDbkQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztpQkFDMUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ3pCLDRFQUE0RTtnQkFDNUUsTUFBTSxlQUFlLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsUUFBUSxDQUFDLEVBQUUsRUFBRTtvQkFDbEUsT0FBTyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQy9DLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRWYsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDM0IsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNuQyxPQUFPLEVBQUUsQ0FBQzthQUNYO1lBRUQsMERBQTBEO1lBQzFELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztZQUU1RiwwREFBMEQ7WUFDMUQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEVBQUUsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRTlGLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO2dCQUNyRSwwQkFBMEI7Z0JBQzFCLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQztxQkFDbkMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ3BFLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDNUUsT0FBTyxJQUFJLENBQUMsOEJBQThCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzlEO1FBQ0QsT0FBTyxJQUFJLENBQUMsaUNBQWlDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsNkJBQTZCLENBQUMsTUFBTTtRQUNsQyxvQ0FBb0M7UUFDcEMsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsbUJBQW1CO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNuRSxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtvQkFDakUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMxQjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDdEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQzNCLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztZQUVILE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzRSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLG9CQUFvQixFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztRQUN4RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtZQUMzQixNQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBRTlCLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUMxQixXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDM0I7Z0JBQ0QsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7WUFFSCxNQUFNLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbkIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ25CLE1BQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxFQUFFO29CQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxPQUFPLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxtQkFBbUIsQ0FBQyxPQUFPO1FBQ3pCLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbkUsMERBQTBEO2dCQUMxRCxPQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUNuRDtZQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ25DLE1BQU0sR0FBRyxHQUFHLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLHdCQUF3QjthQUN0RDtZQUVELDRGQUE0RjtZQUM1RixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLG1CQUFtQixJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUN4RSxXQUFXLEdBQUcsTUFBTSxHQUFHLFdBQVcsR0FBRyxNQUFNLEdBQUcsNkJBQTZCLEdBQUcsTUFBTSxHQUFHLEdBQUc7Z0JBQzFGLElBQUksQ0FBQyxrQkFBa0IsR0FBRyx5Q0FBeUM7Z0JBQ25FLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxPQUFPLENBQUMsQ0FBQztRQUN2QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsMkZBQTJGO1lBRTNGLHVCQUF1QjtZQUN2QixNQUFNLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkQsdUVBQXVFO1lBRXZFLE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDekIsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4RCxLQUFLLE1BQU0sUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRSxzQ0FBc0M7Z0JBQ2xGLE1BQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDeEMsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsOENBQThDO2dCQUV4RyxLQUFLLE1BQU0sTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtvQkFDN0MsTUFBTSxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzNDLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsNkJBQTZCO29CQUN6Riw2REFBNkQ7b0JBQzdELHNFQUFzRTtvQkFDdEUsSUFBSSxtQkFBbUIsR0FBRyxDQUFDLENBQUM7b0JBQzVCLElBQUksY0FBYyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDekUsTUFBTSxjQUFjLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQzt3QkFDN0MsY0FBYyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBRTlDLDBGQUEwRjt3QkFDMUYsbUJBQW1CLEdBQUcsY0FBYyxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUM7cUJBQzlEO29CQUNELE1BQU0sU0FBUyxHQUFHLEVBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztvQkFDekQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQzFCLElBQUksY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksY0FBYyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7NEJBQ2pGLGNBQWMsR0FBRyxFQUFFLENBQUM7eUJBQ3JCOzZCQUFNOzRCQUNMLGNBQWMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRTtnQ0FDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUMzQyxDQUFDLENBQUMsQ0FBQzt5QkFDSjt3QkFDRCxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRTs0QkFDcEIsY0FBYzs0QkFDZCxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7NEJBQ2xELEtBQUssRUFBRSxDQUFDOzRCQUNSLEtBQUssRUFBRSxDQUFDO3lCQUNULENBQUMsQ0FBQztxQkFDSjtvQkFDRCxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMxQyxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ3BCLFdBQVcsQ0FBQyxLQUFLLElBQUksbUJBQW1CLENBQUM7aUJBQzFDO2FBQ0Y7WUFFRCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCw4QkFBOEIsQ0FBQyxPQUFPLEVBQUUsT0FBTztRQUM3QyxnRkFBZ0Y7UUFDaEYsT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFN0QsSUFBSSxTQUFTLENBQUM7UUFDZCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3pDLFNBQVMsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMvRTtRQUVELDZFQUE2RTtRQUM3RSxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxFQUFFO1lBQ2pDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDN0IsT0FBTyxHQUFHLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE9BQU8sWUFBWSxJQUFJLE1BQU0sR0FBRyxDQUFDO3FCQUN6RSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQzFCO1lBQ0QsT0FBTyxVQUFVLE1BQU0sR0FBRyxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUVGLDhFQUE4RTtRQUM5RSxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxFQUFFO1lBQ2pDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDN0IsT0FBTyxHQUFHLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLElBQUksTUFBTSxJQUFJLFlBQVksTUFBTSxDQUFDO3FCQUN6RSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQzFCO1lBQ0QsT0FBTyxJQUFJLE1BQU0sU0FBUyxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUVGLHVEQUF1RDtRQUN2RCwyRkFBMkY7UUFDM0YsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLEVBQUU7WUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRTtnQkFDOUIsT0FBTyxLQUFLLGlCQUFpQixDQUFDLE1BQU0sQ0FBQzs7O2NBRy9CLGlCQUFpQixDQUFDLE1BQU0sQ0FBQztpQ0FDTixNQUFNLElBQUksSUFBSSxDQUFDLGtCQUFrQjs7VUFFeEQsQ0FBQzthQUNKO1lBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM3QixNQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3ZFLE9BQU8sT0FBTyxVQUFVLElBQUksTUFBTSxHQUFHLENBQUM7YUFDdkM7WUFDRCxPQUFPLFNBQVMsSUFBSSxDQUFDLGtCQUFrQixLQUFLLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxNQUFNLEdBQUcsQ0FBQztRQUNwRixDQUFDLENBQUM7UUFFRixNQUFNLG1CQUFtQixHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLENBQUM7UUFFakYsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDO1FBQzlDLElBQUksa0JBQWtCLEdBQUcsRUFBRSxDQUFDO1FBRTVCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUM5QixxREFBcUQ7WUFDckQsc0RBQXNEO1lBQ3RELE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQztpQkFDMUYsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWhELHVGQUF1RjtZQUN2RixtR0FBbUc7WUFDbkcsSUFBSSxlQUFlLEdBQUcsY0FBYztpQkFDakMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztZQUVsRSx5RUFBeUU7WUFDekUsOERBQThEO1lBQzlELElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsNEJBQTRCLENBQUMsRUFBRTtnQkFDOUQsTUFBTSx1QkFBdUIsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUN2QztjQUNJLFdBQVcsQ0FBQyxNQUFNLENBQUM7b0NBQ0csSUFBSSxDQUFDLGtCQUFrQjtZQUMvQyxDQUFDO2dCQUNMLGVBQWUsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQzthQUNuRjtZQUNELGtCQUFrQixHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUNsRTtRQUVELHVFQUF1RTtRQUN2RSxNQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLE1BQU0saUJBQWlCLEdBQ3JCO1NBQ0csSUFBSSxDQUFDLFdBQVc7O1lBRWIsbUJBQW1CO1lBQ25CLGtCQUFrQjs7b0JBRVYsaUJBQWlCO1VBQzNCLENBQUM7UUFFUCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3JFLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILDJCQUEyQixDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQzFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbkMsT0FBTyxJQUFJLENBQUMsNkJBQTZCLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbkQ7aUJBQU07Z0JBQ0wsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsSUFBSSxDQUFDLFdBQVcsSUFBSTtvQkFDMUUsU0FBUyxHQUFHLE1BQU0sR0FBRyxXQUFXLEdBQUcsTUFBTSxHQUFHLDZCQUE2QixHQUFHLE1BQU0sR0FBRyxHQUFHO29CQUN4RixJQUFJLENBQUMsa0JBQWtCLEdBQUcseUNBQXlDO29CQUNuRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDdEM7UUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsMkZBQTJGO1lBRTNGLHVCQUF1QjtZQUN2QixJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDakQsdUVBQXVFO1lBQ3ZFLDhEQUE4RDtZQUU5RCxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7Z0JBQ3pCLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRixnRkFBZ0Y7Z0JBQ2hGLGFBQWEsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5RTtZQUVELElBQUksT0FBTyxDQUFDLGtCQUFrQixFQUFFO2dCQUM5QixNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUN4RCxJQUFJLENBQUMsS0FBSyxRQUFRLENBQUMsNEJBQTRCLEVBQUU7d0JBQy9DLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDM0M7eUJBQU07d0JBQ0wsT0FBTyxJQUFJLENBQUMsQ0FBQyxrREFBa0Q7cUJBQ2hFO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNILHlGQUF5RjtnQkFDekYsYUFBYSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25GO1lBRUQsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUN0RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxjQUFjLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDN0IsSUFBSSxPQUFPLENBQUMsZUFBZSxFQUFFO1lBQzNCLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN2RDtRQUNELE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsdUJBQXVCLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDdEMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyRCxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sQ0FBQztpQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyRCxDQUFDLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILHVCQUF1QixDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUM1RSwwREFBMEQ7WUFDMUQsT0FBTyxJQUFJLENBQUMsMkJBQTJCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzNEO1FBRUQsNEZBQTRGO1FBQzVGLE9BQU8sSUFBSSxDQUFDLDhCQUE4QixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxZQUFZLENBQUMsT0FBTyxFQUFFLGtCQUFrQjtRQUN0QyxNQUFNLGVBQWUsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2xDLGtDQUFrQztRQUNsQyxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFL0UsOERBQThEO1FBQzlELDRGQUE0RjtRQUM1Rix1Q0FBdUM7UUFDdkMsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDZixFQUFFLG9DQUFvQyxFQUFFLHNCQUFzQixDQUFDO1FBRTNFLE1BQU0sZ0JBQWdCLEdBQUcsbUNBQW1DLElBQUksQ0FBQyxXQUFXO1VBQ3RFLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2tCQUM3QyxDQUFDO1FBRWYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNuRSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLGVBQWUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxJQUFJLGtCQUFrQixDQUFDLENBQUM7WUFDNUYsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLGVBQWUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0gsY0FBYyxDQUFDLE1BQU0sRUFBRSxPQUFPO1FBQzVCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDbkUscURBQXFEO1lBQ3JELDRGQUE0RjtZQUM1RixPQUFPLEVBQUUsQ0FBQztTQUNYO1FBRUQsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3hCLGtDQUFrQztRQUNsQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFFeEUsd0NBQXdDO1FBQ3hDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDekMsSUFBSSxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ3RDLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUM1QjtZQUNELE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxhQUFhO2lCQUN4QyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM1RSxjQUFjLEdBQUcsV0FBVyxhQUFhLEdBQUcsQ0FBQztTQUM5QztRQUVELHVGQUF1RjtRQUN2RixNQUFNLGVBQWUsR0FBRyxtQ0FBbUMsSUFBSSxDQUFDLFdBQVc7ZUFDaEUsU0FBUzs7ZUFFVCxTQUFTO3NCQUNGLElBQUksQ0FBQyxrQkFBa0I7UUFDckMsY0FBYztrQkFDSixDQUFDO1FBRWYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEUsMEVBQTBFO1lBQzFFLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDcEUsT0FBTyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3pDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQztnQkFDOUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQzthQUN4QyxDQUFDLENBQUMsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFO1lBQ2hDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUN0QyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BELHVDQUF1QztnQkFDdkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFO29CQUMvRCx3RkFBd0Y7b0JBQ3hGLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQ3BDLHlEQUF5RCxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNwRTtnQkFDRCxVQUFVLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztnQkFDdEYsT0FBTyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzthQUM5QztpQkFBTTtnQkFDTCw0QkFBNEI7Z0JBQzVCLFVBQVUsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzthQUNwRTtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUMsQ0FDL0MsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUFVO1FBQzVCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQ3RDLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRTtZQUN2RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLHFEQUFxRCxFQUMzRixJQUFJLENBQUMsQ0FBQztTQUNUO1FBRUQsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUV6QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBQyxFQUFFLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUN2QixPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsTUFBTSxpQkFBaUIsR0FBRyxFQUFFLENBQUM7WUFDN0IsS0FBSyxNQUFNLFFBQVEsSUFBSSxVQUFVLENBQUMsSUFBSSxFQUFFO2dCQUN0QyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNsRixpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ2xDO2FBQ0Y7WUFFRCxJQUFJLHdCQUF3QixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO1lBRS9FLCtCQUErQjtZQUMvQixDQUFDLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUN0Qyx3QkFBd0IsRUFBRSxDQUFDO2dCQUMzQixXQUFXLENBQUMsSUFBSSxDQUFDO29CQUNmLE9BQU8sRUFBRSxNQUFNO29CQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztvQkFDbkQsTUFBTSxFQUFFLFNBQVM7aUJBQ2xCLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBRUgsK0JBQStCO1lBQy9CLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUNqRCx3QkFBd0IsRUFBRSxDQUFDO2dCQUMzQixXQUFXLENBQUMsSUFBSSxDQUFDO29CQUNmLE9BQU8sRUFBRSxNQUFNO29CQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztvQkFDbkQsTUFBTSxFQUFFLFNBQVM7aUJBQ2xCLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBRUgsK0JBQStCO1lBQy9CLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxFQUFFO2dCQUNqRCx3QkFBd0IsRUFBRSxDQUFDO2dCQUMzQixXQUFXLENBQUMsSUFBSSxDQUFDO29CQUNmLE9BQU8sRUFBRSxNQUFNO29CQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsa0JBQWtCO29CQUNsQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUM7aUJBQ2xELENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBRUgsd0JBQXdCO1lBQ3hCLEtBQUssTUFBTSxRQUFRLElBQUksVUFBVSxDQUFDLGVBQWUsRUFBRTtnQkFDakQsd0JBQXdCLEVBQUUsQ0FBQztnQkFDM0IsYUFBYSxDQUFDLElBQUksQ0FBQztvQkFDakIsTUFBTTtvQkFDTixJQUFJLENBQUMsa0JBQWtCO29CQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQztpQkFDMUMsQ0FBQyxDQUFDO2FBQ0o7WUFFRCx3QkFBd0I7WUFDeEIsS0FBSyxNQUFNLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbkQsd0JBQXdCLEVBQUUsQ0FBQztnQkFDM0IsYUFBYSxDQUFDLElBQUksQ0FBQztvQkFDakIsTUFBTTtvQkFDTixJQUFJLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztvQkFDeEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDakQsQ0FBQyxDQUFDO2FBQ0o7WUFFRCxJQUFJLHdCQUF3QixLQUFLLENBQUMsRUFBRTtnQkFDbEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIseURBQXlELEVBQ3pELElBQUksQ0FDTCxDQUFDO2FBQ0g7WUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDckUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxXQUFXLENBQUMsTUFBTTtRQUNoQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDckYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDaEUsT0FBTyxTQUFTLElBQUksVUFBVSxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVcsQ0FBQyxPQUFPO1FBQ2pCLDZDQUE2QztRQUM3QyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQ3ZCLEVBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FDeEMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDYixJQUFJO2dCQUNGLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDckU7WUFBQyxPQUFNLENBQUMsRUFBRTtnQkFDVCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDcEY7WUFFRCxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3hDLFVBQVUsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFbkQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FDbEMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQ2hELENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE1BQU07UUFDaEIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0MsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUUzRCwwRUFBMEU7UUFDMUUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUN4RSxJQUFJO2dCQUNGLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDL0Q7WUFBQyxPQUFNLENBQUMsRUFBRTtnQkFDVCxPQUFPLEtBQUssQ0FBQzthQUNkO1lBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzlELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLDZFQUE2RSxFQUM3RSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSCxTQUFTLENBQUMsT0FBTztRQUNmLE1BQU0sVUFBVSxHQUFHLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO1FBQzlELE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFNUIsTUFBTSxHQUFHLEdBQUcsQ0FBTSxLQUFLLEVBQUMsRUFBRTtZQUN4QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ3pFLDBDQUEwQztZQUMxQyxNQUFNLFVBQVUsR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLCtCQUErQjtZQUNwRixJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssRUFDcEQ7Z0JBQ0UsT0FBTyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUM7Z0JBQy9DLFNBQVMsRUFBRSxTQUFTO2FBQ3JCLENBQ0YsQ0FBQztZQUVGLG9DQUFvQztZQUNwQyxLQUFLLE1BQU0sU0FBUyxJQUFJLFVBQVUsRUFBRTtnQkFDbEMsTUFBTSxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7Z0JBQzVCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQztnQkFDckIsS0FBSyxNQUFNLE9BQU8sSUFBSSxTQUFTLEVBQUU7b0JBQy9CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTt3QkFDekQsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFOzRCQUMxQixTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzt5QkFDeEM7NkJBQU07NEJBQ0wsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO3lCQUNoQztxQkFDRjtpQkFDRjtnQkFFRCxNQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ2pCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxFQUFFO29CQUN6RixJQUFJO3dCQUNGLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO3FCQUMxRDtvQkFBQyxPQUFNLENBQUMsRUFBRTt3QkFDVCxHQUFHLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDekQ7aUJBQ0Y7Z0JBRUQsd0JBQXdCO2dCQUN4QixNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBQyxHQUFHLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUM7Z0JBQ3ZGLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFFcEQsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7YUFDakY7UUFDSCxDQUFDLENBQUEsQ0FBQztRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7YUFDOUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDL0MsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRW5DLE9BQU8sVUFBVSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7T0FFRztJQUNILFFBQVEsQ0FBQyxLQUFLO1FBQ1osT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLEtBQUs7UUFDZixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQVksQ0FBQyxJQUFJO1FBQ2YsSUFBSSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRTtZQUN4QyxvRkFBb0Y7WUFDcEYsVUFBVSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztTQUNwRTtRQUNELG9EQUFvRDtRQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxrQkFBa0IsQ0FBQyxLQUFLO1FBQ3RCLE9BQU8sNkNBQTZDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25FLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsWUFBWSxDQUFDIn0=