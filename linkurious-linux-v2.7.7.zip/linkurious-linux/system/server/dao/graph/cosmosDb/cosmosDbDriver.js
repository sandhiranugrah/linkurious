/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-06-29.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
// locals
const GremlinDriver = require('../gremlinDriver');
class CosmosDbDriver extends GremlinDriver {
    /**
     * @returns {GremlinOptions}
     */
    get $gremlinOptions() {
        return {
            disableTypeChecks: false,
            useDef: false,
            canFoldAndDedupById: false
        };
    }
    /**
     * Check if the given edge ID is legal.
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkEdgeId(key, id) {
        return this._checkId(key, id);
    }
    /**
     * Check if the given node ID is legal.
     *
     *
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     */
    $checkNodeId(key, id) {
        return this._checkId(key, id);
    }
    /**
     * @param {string}  key
     * @param {string}  id
     * @throws {LkError} if the ID is not valid
     * @private
     */
    _checkId(key, id) {
        // Cosmos db ids cannot be empty strings
        Utils.check.string(key, id.trim(), true);
    }
    /**
     * List all edgeTypes, nodeCategories, edgeProperties, nodeProperties
     * that exist in the graph database.
     *
     * @returns {Bluebird<SimpleGraphSchema>}
     */
    $getSimpleSchema() {
        // TODO #1421 Find a way to read Cosmos db schema. One solution could be to query the automatic index
        // https://docs.microsoft.com/en-us/azure/cosmos-db/indexing-policies
        return Promise.resolve({
            nodeCategories: [],
            edgeTypes: [],
            nodeProperties: [],
            edgeProperties: []
        });
    }
}
module.exports = CosmosDbDriver;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29zbW9zRGJEcml2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL2dyYXBoL2Nvc21vc0RiL2Nvc21vc0RiRHJpdmVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBRUgsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLFNBQVM7QUFDVCxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUVsRCxNQUFNLGNBQWUsU0FBUSxhQUFhO0lBQ3hDOztPQUVHO0lBQ0gsSUFBSSxlQUFlO1FBQ2pCLE9BQU87WUFDTCxpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsbUJBQW1CLEVBQUUsS0FBSztTQUMzQixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRTtRQUNsQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2Qsd0NBQXdDO1FBQ3hDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsZ0JBQWdCO1FBQ2QscUdBQXFHO1FBQ3JHLHFFQUFxRTtRQUNyRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckIsY0FBYyxFQUFFLEVBQUU7WUFDbEIsU0FBUyxFQUFFLEVBQUU7WUFDYixjQUFjLEVBQUUsRUFBRTtZQUNsQixjQUFjLEVBQUUsRUFBRTtTQUNuQixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsQ0FBQyJ9