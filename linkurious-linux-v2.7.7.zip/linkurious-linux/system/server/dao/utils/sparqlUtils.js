/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-22.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// Used to build literals, e.g: '"true"' + XML_SCHEMA_PREFIX + 'boolean' + '>'
const XML_SCHEMA_PREFIX = '"^^<http://www.w3.org/2001/XMLSchema#';
const SPARQL_WRITE_STATEMENTS = [
    'load', 'clear', 'drop', 'add', 'move', 'copy', 'create', 'insert', 'delete'
];
const SPARQL_WRITE_RE = new RegExp('(?:\\s|^)(' + SPARQL_WRITE_STATEMENTS.join('|') + ')(?:\\s|{)', 'i');
class SparqlUtils {
    /**
     * @param {Map<string, string>} prefixToURI
     * @param {string}              defaultNamespace
     * @param {string}              [categoryPredicate] Optional here, but required for some methods
     * @param {string}              [idPropertyName]
     */
    constructor(prefixToURI, defaultNamespace, categoryPredicate, idPropertyName) {
        this._prefixToURI = prefixToURI;
        this._defaultNamespace = defaultNamespace;
        this._categoryPredicate = categoryPredicate;
        this._idPropertyName = idPropertyName;
    }
    set categoryPredicate(c) {
        this._categoryPredicate = c;
    }
    /**
     * Return true if `str` follows the format 'prefix:something' with 'prefix' contained in
     * 'prefixToURI'.
     * The function will return false for blank nodes.
     *
     * @param {string} str
     * @returns {boolean}
     */
    isPrefixNotation(str) {
        return this._prefixToURI.has(str.split(':')[0]) && !this.isBlankNode(str);
    }
    /**
     * Return true if `str` is a blank node.
     *
     * @param {string} str
     * @returns {boolean}
     */
    isBlankNode(str) {
        return str.startsWith('_:');
    }
    /**
     * Return true if `str` is a valid URI wrapped in angle brackets.
     *
     * @param {string} str
     * @returns {boolean}
     */
    isURI(str) {
        return str.lastIndexOf('<') === 0 && str.indexOf('>') === str.length - 1;
    }
    /**
     * Return true if `str` is a literal.
     *
     * @param {string} str
     * @returns {boolean}
     */
    isLiteral(str) {
        return Utils.isNEString(str) && str.startsWith('"');
    }
    /**
     * Convert `str` to a valid URI wrapped in angle brackets or to a blank node.
     * Use `defaultNamespace` if `str` is not in prefix or URI form.
     *
     * @param {string} str
     * @returns {string}
     * @throws {LkError} if `str` has a prefix and this prefix is not defined in prefixToURI
     */
    shortNameToFullURI(str) {
        // identifiers can also be a URI or a blank node
        if (this.isURI(str) || this.isBlankNode(str)) {
            return str;
        }
        let namespace;
        // if the identifier doesn't have a prefix, we are going to use the default namespace
        if (str.indexOf(':') === -1) {
            namespace = this._defaultNamespace;
        }
        else {
            const splitStr = Utils.splitOnce(str, ':');
            namespace = this._prefixToURI.get(splitStr[0]);
            str = splitStr[1];
        }
        if (namespace !== undefined) {
            return '<' + namespace + encodeURIComponent(str) + '>';
        }
        else {
            throw Errors.business('invalid_parameter', '"' + str.split(':')[0] +
                '" isn\'t a valid namespace.');
        }
    }
    /**
     * Convert `str` to its short name.
     *
     * A short name can be:
     * - a URI if the namespace cannot be resolved, e.g: "<http://example.com/123>"
     * - a prefix notation (if the namespace is defined in the triple store), e.g: "company:123"
     * - a resource belonging to the default namespace defined for this instance, e.g: "123"
     * - a blank node, e.g: "_:a"
     *
     * @param {string} str
     * @returns {string}
     * @throws {LkError} if `str` is not a valid URI wrapped in angle brackets
     */
    fullURIToShortName(str) {
        if (this.isBlankNode(str)) {
            return str;
        }
        if (!this.isURI(str)) {
            throw Errors.technical('critical', 'SparqlUtils.fullURIToShortName called on "' + str +
                '" that is not a URI or a blank node.');
        }
        // does the resource belong to the default namespace?
        if (str.startsWith('<' + this._defaultNamespace)) {
            str = str.substr(1, str.length - 2);
            return decodeURIComponent(str.substr(this._defaultNamespace.length));
        }
        // does the resource belong to a namespace defined in the triple store?
        for (const key of this._prefixToURI.keys()) {
            const value = this._prefixToURI.get(key);
            if (str.startsWith('<' + value)) {
                str = str.substr(1, str.length - 2);
                return key + ':' + decodeURIComponent(str.substr(value.length));
            }
        }
        // the namespace wasn't recognized, return the URI itself
        return str;
    }
    /**
     * Encode `edge` (using its source, type and destination) to get its id.
     *
     * @param {LkEdge | LkEdgeAttributes} edge
     * @returns {string}
     */
    getIdFromEdge(edge) {
        const edgeTriple = [
            edge.source,
            this.shortNameToFullURI(edge.type),
            edge.target
        ];
        const edgeJson = JSON.stringify(edgeTriple);
        return this.shortNameToFullURI(Buffer.from(edgeJson).toString('base64'));
    }
    /**
     * Decode `id` to get its edge.
     *
     * @param {string} id
     * @returns {LkEdge}
     */
    getEdgeFromId(id) {
        id = this.fullURIToShortName(id);
        const edgeJson = Buffer.from(id, 'base64').toString('ascii');
        const edgeTriple = JSON.parse(edgeJson);
        return {
            id: id,
            type: this.fullURIToShortName(edgeTriple[1]),
            source: edgeTriple[0],
            target: edgeTriple[2],
            data: {}
        };
    }
    /**
     * Return an array of indices containing the positions of characters in `str` that match
     * an unescaped `char`. The escape character is `escapeChar`.
     *
     * @param {string} str
     * @param {string} char
     * @param {string} escapeChar
     * @returns {number[]}
     * @private
     */
    _findUnescapedChar(str, char, escapeChar) {
        // We assume that the escapeChar escapes itself
        const result = [];
        let countOfEscape = 0;
        let idx = 0;
        for (const c of str) {
            if (c === char) {
                if (countOfEscape % 2 === 0) {
                    result.push(idx);
                }
                else {
                    countOfEscape = 0;
                }
            }
            else if (c === escapeChar) {
                countOfEscape++;
            }
            else {
                countOfEscape = 0;
            }
            idx++;
        }
        return result;
    }
    /**
     * Convert `o` into a literal.
     *
     * Note:
     * NaN, +Infinity and -Infinity will be converted to "NaN", "+Infinity" and "-Infinity"
     * respectively. It means that _revertLiteral(_toLiteral(NaN)) will result in "NaN".
     *
     * @param {any} o
     * @returns {string}
     */
    toLiteral(o) {
        switch (typeof o) {
            case 'boolean':
                return '"' + o + XML_SCHEMA_PREFIX + 'boolean' + '>';
            case 'number':
                if (isFinite(o)) {
                    if (o % 1 === 0) {
                        return '"' + o + XML_SCHEMA_PREFIX + 'integer' + '>';
                    }
                    else {
                        return '"' + o + XML_SCHEMA_PREFIX + 'decimal' + '>';
                    }
                }
                return '"' + o + '"'; // NaN, +Infinity and -Infinity
            default:
                return JSON.stringify(o);
        }
    }
    /**
     * Convert `str` back to the right data type.
     *
     * @param {string} str
     * @returns {any}
     * @throws {LkError} if `str` is not a valid literal
     */
    revertLiteral(str) {
        if (str.indexOf('"') !== 0) {
            throw Errors.technical('critical', '"' + str + '" isn\'t a valid literal.');
        }
        // We need to match all unescaped quotes in `str`
        const quotes = this._findUnescapedChar(str, '"', '\\');
        const jsonLiteral = str.substring(quotes[0], quotes[1] + 1);
        // we look for a type ("boolean", "decimal" or "integer")
        const nsIndex = str.lastIndexOf(XML_SCHEMA_PREFIX);
        if (nsIndex === -1) {
            // it's just a string literal
            return JSON.parse(jsonLiteral);
        }
        // we have a type
        const nsLength = XML_SCHEMA_PREFIX.length;
        const offset = nsIndex + nsLength;
        const type = str.substr(offset).slice(0, -1);
        const strippedLiteral = str.substr(1, nsIndex - 1); // literal stripped of '"' and schema
        switch (type) {
            case 'string':
                return JSON.parse(jsonLiteral);
            case 'boolean':
                return strippedLiteral === 'true';
            case 'decimal':
            case 'integer': {
                const num = Number(strippedLiteral);
                if (num <= Number.MIN_SAFE_INTEGER || num >= Number.MAX_SAFE_INTEGER) {
                    return strippedLiteral;
                }
                else {
                    return num;
                }
            }
            default:
                return JSON.parse(jsonLiteral);
        }
    }
    /**
     * Convert `edge` into a single RDF statement.
     * The result is an array of size 3 of non-empty strings.
     *
     * @param {LkEdge} edge
     * @returns {string[]} statements
     */
    formatEdgeToStatement(edge) {
        return [
            /**@type {string}*/ (edge.source),
            this.shortNameToFullURI(edge.type),
            /**@type {string}*/ (edge.target)
        ];
    }
    /**
     * Parse `statement` into a linkurious edge. We assume that the statement represents an edge.
     *
     * @param {string[]} statement
     * @returns {LkEdge}
     */
    parseStatementForEdge(statement) {
        const edge = {
            id: '',
            source: statement[0],
            type: this.fullURIToShortName(statement[1]),
            target: statement[2],
            data: {}
        };
        edge.id = this.getIdFromEdge(edge);
        return edge;
    }
    /**
     * Convert `node` into multiple RDF statements.
     * The result is an array of array of size 3 of non-empty strings.
     *
     * @param {LkNode} node
     * @returns {string[][]} statements
     * @throws {LkError} if there are both no properties and no categories
     */
    formatNodeToStatements(node) {
        // create a triple for each property
        const triples = /**@type {string[][]}*/ (_.toPairs(node.data).map(kv => [
            node.id,
            this.shortNameToFullURI(kv[0]),
            this.toLiteral(kv[1])
        ]));
        // create a triple for each category
        _.each(node.categories, category => {
            triples.push([
                node.id,
                this._categoryPredicate,
                this.formatCategoryValue(category)
            ]);
        });
        return triples;
    }
    /**
     * Parse `statements` into a linkurious node.
     * `statements` has to be at least of size 1.
     * In case of error, this logs a warning and can return `null`.
     *
     * @param {string[][]} statements
     * @throws {LkError} if the statement is invalid (fullURIToShortName and revertLiteral throws)
     * @returns {LkNode}
     */
    parseStatementsForNode(statements) {
        if (statements.length === 0) {
            throw Errors.technical('bug', 'SparqlUtils.parseStatementsForNode: At least one statement is required.');
        }
        const node = { id: statements[0][0], data: {}, categories: [] };
        _.each(statements, statement => {
            if (this.statementIsAProperty(statement)) {
                node.data[this.fullURIToShortName(statement[1])] =
                    this.revertLiteral(statement[2]);
            }
            else if (this.statementIsACategory(statement)) {
                node.categories.push(this.parseCategoryValue(statement[2]));
            }
            else if (this.statementIsAnEdge(statement)) {
                // ignore edges
            }
            else {
                Log.warn('SparqlUtils.parseStatementsForNode: invalid statement: "' + statement + '"');
            }
        });
        // categories have to be sorted to be compliant to other DAOs
        node.categories.sort();
        if (Utils.hasValue(this._idPropertyName)) {
            node.data[this._idPropertyName] = this.fullURIToShortName(node.id);
        }
        return node;
    }
    /**
     * Return true if `statement` is an array of size 3 (or of size 4) of non-empty strings.
     * We allow size 4 to support statements with "graph".
     *
     * @param {string[]} statement RDF triple
     * @returns {boolean}
     */
    statementIsATriple(statement) {
        try {
            Utils.check.stringArray('statement', statement, 3, 4, true);
        }
        catch (e) {
            return false;
        }
        return true;
    }
    /**
     * Return true if `statement` represents an edge.
     *
     * We assume that the statement is a valid triple.
     *
     * @param {string[]} statement RDF triple
     * @returns {boolean}
     */
    statementIsAnEdge(statement) {
        return statement[1] !== this._categoryPredicate &&
            (this.isURI(statement[2]) || this.isBlankNode(statement[2]));
    }
    /**
     * Return true if `statement` represents a property.
     *
     * We assume that the statement is a valid triple.
     *
     * @param {string[]} statement RDF triple
     * @returns {boolean}
     */
    statementIsAProperty(statement) {
        return statement[1] !== this._categoryPredicate && this.isLiteral(statement[2]);
    }
    /**
     * Return true if `statement` represents a category.
     *
     * We assume that the statement is a valid triple.
     *
     * @param {string[]} statement RDF triple
     * @returns {boolean}
     */
    statementIsACategory(statement) {
        return statement[1] === this._categoryPredicate;
    }
    /**
     * Format `category` to a SPARQL statement object.
     *
     * @param {string} category
     * @returns {string}
     */
    formatCategoryValue(category) {
        if (this.isPrefixNotation(category)) {
            return this.shortNameToFullURI(category);
        }
        else if (this.isURI(category) || this.isBlankNode(category)) {
            return category;
        }
        else {
            // literal
            return this.toLiteral(category);
        }
    }
    /**
     * Parse `category` from a SPARQL statement object to an LkNode category.
     *
     * @param {string} category
     * @returns {string}
     */
    parseCategoryValue(category) {
        if (this.isLiteral(category)) {
            return this.revertLiteral(category);
        }
        else {
            return this.fullURIToShortName(category);
        }
    }
    /**
     * Iterate over an array of ids and wrap in angle brackets every blank node id found.
     *
     * @param {string[]} ids
     * @returns {string[]}
     */
    wrapBlankNodesInAngleBrackets(ids) {
        return ids.map(id => {
            if (this.isBlankNode(id)) {
                return '<' + id + '>'; // wrap in angle bracket
            }
            return id;
        });
    }
    /**
     * Return true is query is a write query.
     */
    isWrite(query) {
        // Remove string literals to reduce false positives
        const queryStatements = Utils.stripLiterals(query);
        return SPARQL_WRITE_RE.test(queryStatements);
    }
    /**
     * Check if a query is correct and if it wants to write data but it can't.
     *
     * @param {string} query The graph query
     * @returns {boolean}
     * @throws {LkError} if the query is not valid or not authorized
     */
    checkQuery(query) {
        // Remove string literals to reduce false positives
        const queryStatements = Utils.stripLiterals(query);
        return SPARQL_WRITE_RE.exec(queryStatements) !== null;
    }
    /**
     * Enforce a limit on the number of matched statements.
     *
     * @param {string} originalQuery The graph query
     * @param {number} limit         Maximum number of matched statements
     * @returns {{query: string, originalLimit?: number}}
     */
    enforceLimit(originalQuery, limit) {
        let originalLimit;
        const strippedQuery = Utils.stripLiterals(originalQuery);
        if (SPARQL_WRITE_RE.test(strippedQuery)) {
            // A limit clause is not allowed on write queries
            return { query: originalQuery };
        }
        if (!strippedQuery.includes('}')) {
            // The query is either a query without a where clause or wrong syntax
            // In both cases modifying the query might produce a confusing error message
            return { query: originalQuery };
        }
        // A sparql query can have several limit statements e.g: subqueries
        // We only want to modify the global solution modifier's limit
        const queryParts = originalQuery.trim().split('}');
        let solutionModifier = _.last(queryParts);
        let match;
        // detect explicit LIMIT statements, check the value against limit
        if ((match = /\sLIMIT\s+(\d+)/i.exec(solutionModifier)) !== null) {
            originalLimit = Utils.parseInt(match[1]);
            if ('' + originalLimit !== match[1]) {
                throw Errors.business('bad_graph_request', `The SPARQL query LIMIT value "${match[1]}" is invalid.`);
            }
            // fix the limit if greater than what the maximum limit
            if (originalLimit > limit) {
                // Possible false positive! `solutionModifier` may contain a matching string literal
                // TODO find a safer way to replace the limit
                solutionModifier = solutionModifier.replace(/\sLIMIT\s+\d+/gi, ' LIMIT ' + limit);
            }
        }
        else {
            // add an explicit limit if none was set
            solutionModifier += ' LIMIT ' + limit;
        }
        queryParts[queryParts.length - 1] = solutionModifier;
        return {
            query: queryParts.join('}'),
            originalLimit: originalLimit
        };
    }
}
module.exports = SparqlUtils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BhcnFsVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL3NwYXJxbFV0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLDhFQUE4RTtBQUM5RSxNQUFNLGlCQUFpQixHQUFHLHVDQUF1QyxDQUFDO0FBRWxFLE1BQU0sdUJBQXVCLEdBQUc7SUFDOUIsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxRQUFRO0NBQzdFLENBQUM7QUFDRixNQUFNLGVBQWUsR0FBRyxJQUFJLE1BQU0sQ0FDaEMsWUFBWSxHQUFHLHVCQUF1QixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxZQUFZLEVBQUUsR0FBRyxDQUNyRSxDQUFDO0FBRUYsTUFBTSxXQUFXO0lBRWY7Ozs7O09BS0c7SUFDSCxZQUFZLFdBQVcsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxjQUFjO1FBQzFFLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxnQkFBZ0IsQ0FBQztRQUMxQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsaUJBQWlCLENBQUM7UUFDNUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUM7SUFDeEMsQ0FBQztJQUVELElBQUksaUJBQWlCLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRztRQUNsQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLEdBQUc7UUFDYixPQUFPLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsS0FBSyxDQUFDLEdBQUc7UUFDUCxPQUFPLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsU0FBUyxDQUFDLEdBQUc7UUFDWCxPQUFPLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGtCQUFrQixDQUFDLEdBQUc7UUFDcEIsZ0RBQWdEO1FBQ2hELElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzVDLE9BQU8sR0FBRyxDQUFDO1NBQ1o7UUFFRCxJQUFJLFNBQVMsQ0FBQztRQUNkLHFGQUFxRjtRQUNyRixJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDM0IsU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztTQUNwQzthQUFNO1lBQ0wsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0MsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9DLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbkI7UUFFRCxJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUU7WUFDM0IsT0FBTyxHQUFHLEdBQUcsU0FBUyxHQUFHLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUN4RDthQUFNO1lBQ0wsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEUsNkJBQTZCLENBQUMsQ0FBQztTQUNsQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCxrQkFBa0IsQ0FBQyxHQUFHO1FBQ3BCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN6QixPQUFPLEdBQUcsQ0FBQztTQUNaO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDcEIsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFDL0IsNENBQTRDLEdBQUcsR0FBRztnQkFDbEQsc0NBQXNDLENBQUMsQ0FBQztTQUMzQztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQ2hELEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUN0RTtRQUVELHVFQUF1RTtRQUN2RSxLQUFLLE1BQU0sR0FBRyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEVBQUU7WUFDMUMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsRUFBRTtnQkFDL0IsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQ2pFO1NBQ0Y7UUFFRCx5REFBeUQ7UUFDekQsT0FBTyxHQUFHLENBQUM7SUFDYixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsSUFBSTtRQUNoQixNQUFNLFVBQVUsR0FBRztZQUNqQixJQUFJLENBQUMsTUFBTTtZQUNYLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxNQUFNO1NBQ1osQ0FBQztRQUVGLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUMzRSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsRUFBRTtRQUNkLEVBQUUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDakMsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEMsT0FBTztZQUNMLEVBQUUsRUFBRSxFQUFFO1lBQ04sSUFBSSxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDckIsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxFQUFFLEVBQUU7U0FDVCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGtCQUFrQixDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsVUFBVTtRQUN0QywrQ0FBK0M7UUFDL0MsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQztRQUN0QixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDWixLQUFLLE1BQU0sQ0FBQyxJQUFJLEdBQUcsRUFBRTtZQUNuQixJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUU7Z0JBQ2QsSUFBSSxhQUFhLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDM0IsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbEI7cUJBQU07b0JBQ0wsYUFBYSxHQUFHLENBQUMsQ0FBQztpQkFDbkI7YUFDRjtpQkFBTSxJQUFJLENBQUMsS0FBSyxVQUFVLEVBQUU7Z0JBQzNCLGFBQWEsRUFBRSxDQUFDO2FBQ2pCO2lCQUFNO2dCQUNMLGFBQWEsR0FBRyxDQUFDLENBQUM7YUFDbkI7WUFDRCxHQUFHLEVBQUUsQ0FBQztTQUNQO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFNBQVMsQ0FBQyxDQUFDO1FBQ1QsUUFBUSxPQUFPLENBQUMsRUFBRTtZQUNoQixLQUFLLFNBQVM7Z0JBQ1osT0FBTyxHQUFHLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixHQUFHLFNBQVMsR0FBRyxHQUFHLENBQUM7WUFDdkQsS0FBSyxRQUFRO2dCQUNYLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNmLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ2YsT0FBTyxHQUFHLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixHQUFHLFNBQVMsR0FBRyxHQUFHLENBQUM7cUJBQ3REO3lCQUFNO3dCQUNMLE9BQU8sR0FBRyxHQUFHLENBQUMsR0FBRyxpQkFBaUIsR0FBRyxTQUFTLEdBQUcsR0FBRyxDQUFDO3FCQUN0RDtpQkFDRjtnQkFDRCxPQUFPLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsK0JBQStCO1lBQ3ZEO2dCQUNFLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1QjtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxhQUFhLENBQUMsR0FBRztRQUNmLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDMUIsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLDJCQUEyQixDQUFDLENBQUM7U0FDN0U7UUFFRCxpREFBaUQ7UUFDakQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkQsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRTVELHlEQUF5RDtRQUN6RCxNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFbkQsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDbEIsNkJBQTZCO1lBQzdCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUNoQztRQUVELGlCQUFpQjtRQUNqQixNQUFNLFFBQVEsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUM7UUFDMUMsTUFBTSxNQUFNLEdBQUcsT0FBTyxHQUFHLFFBQVEsQ0FBQztRQUNsQyxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQ0FBcUM7UUFFekYsUUFBUSxJQUFJLEVBQUU7WUFDWixLQUFLLFFBQVE7Z0JBQ1gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2pDLEtBQUssU0FBUztnQkFDWixPQUFPLGVBQWUsS0FBSyxNQUFNLENBQUM7WUFDcEMsS0FBSyxTQUFTLENBQUM7WUFDZixLQUFLLFNBQVMsQ0FBQyxDQUFDO2dCQUNkLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxHQUFHLElBQUksTUFBTSxDQUFDLGdCQUFnQixJQUFJLEdBQUcsSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ3BFLE9BQU8sZUFBZSxDQUFDO2lCQUN4QjtxQkFBTTtvQkFDTCxPQUFPLEdBQUcsQ0FBQztpQkFDWjthQUNGO1lBQ0Q7Z0JBQ0UsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ2xDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHFCQUFxQixDQUFDLElBQUk7UUFDeEIsT0FBTztZQUNMLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUNqQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNsQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDbEMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHFCQUFxQixDQUFDLFNBQVM7UUFDN0IsTUFBTSxJQUFJLEdBQUc7WUFDWCxFQUFFLEVBQUUsRUFBRTtZQUNOLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLElBQUksRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLElBQUksRUFBRSxFQUFFO1NBQ1QsQ0FBQztRQUNGLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQyxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsc0JBQXNCLENBQUMsSUFBSTtRQUN6QixvQ0FBb0M7UUFDcEMsTUFBTSxPQUFPLEdBQUcsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztZQUN0RSxJQUFJLENBQUMsRUFBRTtZQUNQLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDdEIsQ0FBQyxDQUFDLENBQUM7UUFFSixvQ0FBb0M7UUFDcEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxFQUFFO1lBQ2pDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLEVBQUU7Z0JBQ1AsSUFBSSxDQUFDLGtCQUFrQjtnQkFDdkIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQzthQUNuQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILHNCQUFzQixDQUFDLFVBQVU7UUFDL0IsSUFBSSxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMzQixNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUMxQix5RUFBeUUsQ0FBQyxDQUFDO1NBQzlFO1FBRUQsTUFBTSxJQUFJLEdBQUcsRUFBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBQyxDQUFDO1FBRTlELENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxFQUFFO1lBQzdCLElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDOUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwQztpQkFBTSxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDN0Q7aUJBQU0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQzVDLGVBQWU7YUFDaEI7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQywwREFBMEQsR0FBRyxTQUFTLEdBQUcsR0FBRyxDQUFDLENBQUM7YUFDeEY7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILDZEQUE2RDtRQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO1FBRXZCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUNwRTtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGtCQUFrQixDQUFDLFNBQVM7UUFDMUIsSUFBSTtZQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUM3RDtRQUFDLE9BQU0sQ0FBQyxFQUFFO1lBQ1QsT0FBTyxLQUFLLENBQUM7U0FDZDtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxpQkFBaUIsQ0FBQyxTQUFTO1FBQ3pCLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0I7WUFDN0MsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILG9CQUFvQixDQUFDLFNBQVM7UUFDNUIsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEYsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxvQkFBb0IsQ0FBQyxTQUFTO1FBQzVCLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztJQUNsRCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxtQkFBbUIsQ0FBQyxRQUFRO1FBQzFCLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ25DLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFDO2FBQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDN0QsT0FBTyxRQUFRLENBQUM7U0FDakI7YUFBTTtZQUNMLFVBQVU7WUFDVixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDakM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxrQkFBa0IsQ0FBQyxRQUFRO1FBQ3pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDckM7YUFBTTtZQUNMLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsNkJBQTZCLENBQUMsR0FBRztRQUMvQixPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUU7WUFDbEIsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxFQUFFO2dCQUN4QixPQUFPLEdBQUcsR0FBRyxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsd0JBQXdCO2FBQ2hEO1lBRUQsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU8sQ0FBQyxLQUFLO1FBQ1gsbURBQW1EO1FBQ25ELE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkQsT0FBTyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxVQUFVLENBQUMsS0FBSztRQUNkLG1EQUFtRDtRQUNuRCxNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRW5ELE9BQU8sZUFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxJQUFJLENBQUM7SUFDeEQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFlBQVksQ0FBQyxhQUFhLEVBQUUsS0FBSztRQUMvQixJQUFJLGFBQWEsQ0FBQztRQUNsQixNQUFNLGFBQWEsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3pELElBQUksZUFBZSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN2QyxpREFBaUQ7WUFDakQsT0FBTyxFQUFDLEtBQUssRUFBRSxhQUFhLEVBQUMsQ0FBQztTQUMvQjtRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2hDLHFFQUFxRTtZQUNyRSw0RUFBNEU7WUFDNUUsT0FBTyxFQUFDLEtBQUssRUFBRSxhQUFhLEVBQUMsQ0FBQztTQUMvQjtRQUVELG1FQUFtRTtRQUNuRSw4REFBOEQ7UUFDOUQsTUFBTSxVQUFVLEdBQUcsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuRCxJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFMUMsSUFBSSxLQUFLLENBQUM7UUFDVixrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLEtBQUssR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTtZQUNoRSxhQUFhLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QyxJQUFJLEVBQUUsR0FBRyxhQUFhLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNuQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUFFLGlDQUFpQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDO2FBQ2xGO1lBRUQsdURBQXVEO1lBQ3ZELElBQUksYUFBYSxHQUFHLEtBQUssRUFBRTtnQkFDekIsb0ZBQW9GO2dCQUNwRiw2Q0FBNkM7Z0JBQzdDLGdCQUFnQixHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEdBQUcsS0FBSyxDQUFDLENBQUM7YUFDbkY7U0FDRjthQUFNO1lBQ0wsd0NBQXdDO1lBQ3hDLGdCQUFnQixJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDdkM7UUFFRCxVQUFVLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQztRQUVyRCxPQUFPO1lBQ0wsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO1lBQzNCLGFBQWEsRUFBRSxhQUFhO1NBQzdCLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyJ9