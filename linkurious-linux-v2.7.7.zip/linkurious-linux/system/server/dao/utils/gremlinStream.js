/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-02-18.
 */
'use strict';
// internal libs
const stream = require('stream');
// external Libs
const _ = require('lodash');
class GremlinStream extends stream.Readable {
    /**
     * @param {function(): Bluebird<any>} fetchNextPage
     * @param {function(): Bluebird<any>} [cleanup]
     * @constructor
     */
    constructor(fetchNextPage, cleanup) {
        // We maintain our own buffer for paging purposes.
        // It is different from the readable stream internal buffer.
        // That internal buffer fills up due to back-pressure otherwise it is consumed immediately
        // But for the abort signal to be immediate, we do not want anything queued in the internal buffer.
        // So we set highWaterMark to 0 to immediately emit any data pushed in.
        super({ objectMode: true, highWaterMark: 0 });
        this.buffer = [];
        this.fetchNextPage = fetchNextPage;
        this.cleanup = cleanup;
    }
    abort() {
        this.buffer = [null];
        this.cleanup && this.cleanup();
    }
    _read() {
        // The reader reads until the internal buffer is full
        // This method is not called again until `push` is called
        if (_.isEmpty(this.buffer)) {
            this.fetchNextPage().then(page => {
                if (_.isEmpty(page)) {
                    this.buffer.push(null);
                    this.cleanup && this.cleanup();
                }
                else {
                    if (_.isArray(page)) {
                        // Flatten the page
                        _.forEach(page, result => this.buffer.push(result));
                    }
                    else {
                        this.buffer.push(page);
                    }
                }
                // emit the next element in the buffer
                this.push(this.buffer.shift());
            }).catch(error => {
                const message = error.message || '';
                if (message.includes('No signature of method') ||
                    message.includes('Cannot invoke method hasNext()')) {
                    error.message = 'Please submit a gremlin traversal. Error: ' + message;
                }
                this.destroy(error);
            });
        }
        else {
            process.nextTick(() => this.push(this.buffer.shift()));
        }
    }
}
module.exports = GremlinStream;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpblN0cmVhbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9kYW8vdXRpbHMvZ3JlbWxpblN0cmVhbS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFakMsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixNQUFNLGFBQWMsU0FBUSxNQUFNLENBQUMsUUFBUTtJQUN6Qzs7OztPQUlHO0lBQ0gsWUFBWSxhQUFhLEVBQUUsT0FBTztRQUNoQyxrREFBa0Q7UUFDbEQsNERBQTREO1FBQzVELDBGQUEwRjtRQUMxRixtR0FBbUc7UUFDbkcsdUVBQXVFO1FBQ3ZFLEtBQUssQ0FBQyxFQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7UUFDbkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDekIsQ0FBQztJQUVELEtBQUs7UUFDSCxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckIsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELEtBQUs7UUFDSCxxREFBcUQ7UUFDckQseURBQXlEO1FBQ3pELElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDMUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNuQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDdkIsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7aUJBQ2hDO3FCQUFNO29CQUNMLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbkIsbUJBQW1CO3dCQUNuQixDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7cUJBQ3JEO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN4QjtpQkFDRjtnQkFFRCxzQ0FBc0M7Z0JBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDZixNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQztnQkFDcEMsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDO29CQUM1QyxPQUFPLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxDQUFDLEVBQUU7b0JBQ3BELEtBQUssQ0FBQyxPQUFPLEdBQUcsNENBQTRDLEdBQUcsT0FBTyxDQUFDO2lCQUN4RTtnQkFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztTQUN4RDtJQUNILENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDIn0=