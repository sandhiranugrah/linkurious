/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-08-23.
 */
'use strict';
// external libs
const _ = require('lodash');
// our libs
const StringUtils = require('../../../lib/StringUtils').StringUtils;
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
class DaoUtils {
    /**
     * @type {string}
     */
    get LABEL_NODES_WITH_NO_CATEGORY() {
        return '[no_category]';
    }
    /**
     * Choose the best string to represent an item (node or edge) with an heuristic.
     * `propertyKeys` are the candidate properties to be used as a representative.
     * If the first keyword is not found move to the next and so on.
     * Fallback to the id.
     *
     * @param {LkNode | LkEdge} item
     * @param {string[]}        propertyKeys
     * @returns {{field: string, value: string}}
     */
    getItemCaption(item, propertyKeys) {
        const itemProperties = _.keys(item.data);
        const lcItemProperties = new Map(); // we cache all lower case item properties
        _.each(itemProperties, itemProperty => {
            lcItemProperties.set(itemProperty, itemProperty.toLowerCase());
        });
        for (let i = 0; i < propertyKeys.length; ++i) {
            // ignore undefined/null values
            if (Utils.noValue(propertyKeys[i])) {
                continue;
            }
            const lcPropertyKey = propertyKeys[i].toLowerCase();
            for (const itemProperty of itemProperties) {
                if (lcItemProperties.get(itemProperty).indexOf(lcPropertyKey) >= 0) {
                    return { field: itemProperty, value: item.data[itemProperty] };
                }
            }
        }
        return { field: 'id', value: item.id + '' };
    }
    /**
     * Tokenize `searchString` and apply `fuzziness` to each token if required.
     * Depending on `useEditDistance` we use:
     * - The normalized edit similarity, e.g.: term~0.7
     * - The edit distance, e.g.: term~2
     *
     * The last token is considered as a prefix.
     *
     * If `fields` is defined, repeat the query for every field, e.g.:
     * `"miao" miao~0.7` becomes `field1:("miao" miao~0.7) field2:("miao" miao~0.7)`
     *
     * Reference:
     * http://lucene.apache.org/core/5_3_0/queryparser/org/apache/lucene/queryparser/classic/package-summary.html#package_description
     *
     * @param {string}   searchString
     * @param {number}   fuzziness                 Acceptable normalized edit distance among the query and the result. The edit distance is length(searchToken) * fuzziness
     * @param {object}   options
     * @param {string[]} [options.fields]          If defined, repeat the query for every field
     * @param {boolean}  [options.useEditDistance] Use edit distance in the query instead of normalized edit similarity
     * @param {number}   [options.minLengthPrefix]
     * @returns {string}
     */
    generateLuceneQuery(searchString, fuzziness, options) {
        options = _.defaults(options, { minLengthPrefix: 2 });
        const tokens = StringUtils.uniqTokenize(searchString);
        const searchClauses = [JSON.stringify(searchString)];
        const roundedFuzziness = Math.round(fuzziness * 10) / 10;
        const normalizedEditSimilarity = 1 - roundedFuzziness;
        for (let i = 0; i < tokens.length; i++) {
            const maxEditDistance = Math.round(tokens[i].length * fuzziness);
            if (roundedFuzziness === 0) {
                searchClauses.push(tokens[i]);
            }
            else {
                searchClauses.push(tokens[i] + '~' + (options.useEditDistance
                    ? maxEditDistance : normalizedEditSimilarity));
            }
            if (i === tokens.length - 1 && // last token has to be treated differently because it will be used also as a prefix
                (Utils.noValue(options.minLengthPrefix) || options.minLengthPrefix <= tokens[i].length)) {
                searchClauses.push(tokens[i] + '*');
            }
        }
        let query;
        if (Utils.noValue(options.fields)) {
            query = searchClauses.join(' ');
        }
        else {
            query = _.map(options.fields, field => `${field}:(${searchClauses.join(' ')})`).join(' ');
        }
        return query;
    }
    /**
     * If `validCategories` is defined, return `true` if the search item has to be skipped.
     *
     * At least one node category among `nodeCategories` has to be in `validCategories`.
     * If `LABEL_NODES_WITH_NO_CATEGORY` is in `validCategories`, then `nodeCategories` can be empty.
     *
     * @param {string[]} [validCategories]
     * @param {string[]} nodeCategories
     * @returns {boolean}
     */
    hasCategoriesFilter(validCategories, nodeCategories) {
        if (Utils.hasValue(validCategories)) {
            // the '[no_category]' category indicates a node with no category, so:
            // if node has a category or `categoriesOrTypes` doesn't include the '[no_category]' category
            if (nodeCategories.length !== 0 ||
                !validCategories.includes(this.LABEL_NODES_WITH_NO_CATEGORY)) {
                // if node doesn't have any of the categories in `categoriesOrTypes`
                if (!_.some(validCategories, category => nodeCategories.includes(category))) {
                    // we skip the node
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * If `filter` is defined, return `true` if the search item has to be skipped.
     *
     * For every entry in `filter`, the filter value, `entry[1]`, has to be contained in `data[filterKey]`
     * case insensitively.
     *
     * @param {string[][]} [filter]
     * @param {object}     data
     * @returns {boolean}
     */
    hasPropertyValuesFilter(filter, data) {
        if (Utils.hasValue(filter)) {
            for (let i = 0; i < filter.length; ++i) {
                // we apply case insensitive strict filtering
                const filterKey = filter[i][0];
                const filterValue = filter[i][1].toLowerCase();
                const testValue = ('' + data[filterKey]).toLowerCase(); // node.data[filterKey] is coerced to a string
                // if the filter is not contained case insensitively in the property value
                if (testValue.indexOf(filterValue) === -1) {
                    // we skip the node
                    return true;
                }
            }
        }
        return false;
    }
}
module.exports = new DaoUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGFvVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL2Rhb1V0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLDBCQUEwQixDQUFDLENBQUMsV0FBVyxDQUFDO0FBRXBFLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxRQUFRO0lBRVo7O09BRUc7SUFDSCxJQUFJLDRCQUE0QjtRQUM5QixPQUFPLGVBQWUsQ0FBQztJQUN6QixDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsY0FBYyxDQUFDLElBQUksRUFBRSxZQUFZO1FBQy9CLE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pDLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLDBDQUEwQztRQUM5RSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsRUFBRTtZQUNwQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQ2pFLENBQUMsQ0FBQyxDQUFDO1FBRUgsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDNUMsK0JBQStCO1lBQy9CLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDbEMsU0FBUzthQUNWO1lBQ0QsTUFBTSxhQUFhLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3BELEtBQUssTUFBTSxZQUFZLElBQUksY0FBYyxFQUFFO2dCQUN6QyxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNsRSxPQUFPLEVBQUMsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDO2lCQUM5RDthQUNGO1NBQ0Y7UUFFRCxPQUFPLEVBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXFCRztJQUNILG1CQUFtQixDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsT0FBTztRQUNsRCxPQUFPLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBQyxlQUFlLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUVwRCxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRXRELE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRXJELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3pELE1BQU0sd0JBQXdCLEdBQUcsQ0FBQyxHQUFHLGdCQUFnQixDQUFDO1FBRXRELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3RDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQztZQUVqRSxJQUFJLGdCQUFnQixLQUFLLENBQUMsRUFBRTtnQkFDMUIsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsZUFBZTtvQkFDM0QsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO2FBQ2xEO1lBRUQsSUFDRSxDQUFDLEtBQUssTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksb0ZBQW9GO2dCQUMvRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxlQUFlLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUN2RjtnQkFDQSxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQzthQUNyQztTQUNGO1FBRUQsSUFBSSxLQUFLLENBQUM7UUFDVixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2pDLEtBQUssR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2pDO2FBQU07WUFDTCxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzNGO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsbUJBQW1CLENBQUMsZUFBZSxFQUFFLGNBQWM7UUFDakQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO1lBQ25DLHNFQUFzRTtZQUN0RSw2RkFBNkY7WUFDN0YsSUFBSSxjQUFjLENBQUMsTUFBTSxLQUFLLENBQUM7Z0JBQzdCLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUMsRUFBRTtnQkFDOUQsb0VBQW9FO2dCQUNwRSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQ3pCLFFBQVEsQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFO29CQUNoRCxtQkFBbUI7b0JBQ25CLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2FBQ0Y7U0FDRjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILHVCQUF1QixDQUFDLE1BQU0sRUFBRSxJQUFJO1FBQ2xDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDdEMsNkNBQTZDO2dCQUM3QyxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDL0MsTUFBTSxTQUFTLEdBQUcsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyw4Q0FBOEM7Z0JBQ3RHLDBFQUEwRTtnQkFDMUUsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO29CQUN6QyxtQkFBbUI7b0JBQ25CLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2FBQ0Y7U0FDRjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDIn0=