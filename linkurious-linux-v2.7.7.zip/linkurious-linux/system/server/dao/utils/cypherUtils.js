/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-11-06.
 */
'use strict';
// our libs
const StringUtils = require('./../../../lib/StringUtils').StringUtils;
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const _ = require('lodash');
const CYPHER_WRITE_STATEMENTS = [
    'SET', 'CREATE', 'MERGE', 'DELETE', 'REMOVE', 'FOREACH', 'LOAD', 'DROP', 'CALL'
].sort();
const CYPHER_WRITE_RE = new RegExp('(?:\\s|^)(' + CYPHER_WRITE_STATEMENTS.join('|') + ')(?:\\s|\\()', 'i');
class CypherUtils {
    /**
     * Names in Cypher are wrapped in back-ticks ("`").
     * Escape is done with a double back-tick.
     *
     * @param {string} v
     * @returns {string}
     */
    encodeName(v) {
        return '`' + StringUtils.replaceAll(v, '`', '``') + '`';
    }
    /**
     * @param {any} v
     * @returns {string}
     */
    encodeValue(v) {
        return JSON.stringify(v);
    }
    /**
     * @param {string[]} ids
     * @returns {string}
     */
    encodeIDArray(ids) {
        return '[' + ids.join() + ']';
    }
    /**
     * Return true is query is a write query.
     */
    isWrite(query) {
        // trim, remove trailing ';' from query and
        // remove string literals from the query to avoid most false positives
        const queryStatements = Utils.stripLiterals(query.trim().replace(/[;]+$/, ''));
        return CYPHER_WRITE_RE.test(queryStatements);
    }
    /**
     * Check if a query is correct and if it wants to write data but it can't.
     *
     * @param {string}  query The graph query
     * @returns {boolean} Whether the query will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    checkQuery(query) {
        // trim, remove trailing ';' from query and
        // remove string literals from the query to avoid most false positives
        const queryStatements = Utils.stripLiterals(query.trim().replace(/[;]+$/, ''));
        if (!queryStatements.match(/RETURN/i)) {
            throw Errors.business('invalid_parameter', 'The Cypher query is missing a "RETURN" statement.');
        }
        const match = CYPHER_WRITE_RE.exec(queryStatements);
        const willWrite = match !== null;
        if (willWrite) {
            return true;
        }
        return false;
    }
    /**
     * Enforce a limit on the number of matched subgraphs.
     *
     * @param {string} query The graph query
     * @param {number} limit Maximum number of matched subgraphs
     * @returns {{query: string, originalLimit?: number}}
     */
    enforceLimit(query, limit) {
        // trim and remove trailing ';' from query
        let newQuery = query.trim().replace(/[;]+$/, '');
        let originalLimit;
        // remove string literals from the query to avoid most false positives
        const queryStatements = Utils.stripLiterals(newQuery);
        let match;
        // detect explicit LIMIT statements, check the value against limit
        if ((match = /\sLIMIT\s+(\d+)/i.exec(queryStatements)) !== null) {
            originalLimit = Utils.parseInt(match[1]);
            if ('' + originalLimit !== match[1]) {
                throw Errors.business('bad_graph_request', `The Cypher query LIMIT value "${match[1]}" is invalid.`);
            }
            // fix the limit if greater than what the maximum limit
            if (originalLimit > limit) {
                newQuery = newQuery.replace(/\sLIMIT\s+\d+/gi, ' LIMIT ' + limit);
            }
        }
        else {
            // add an explicit limit if none was set
            newQuery += ' LIMIT ' + limit;
        }
        return {
            query: newQuery,
            originalLimit: originalLimit
        };
    }
    /**
     * Enforce an EXPLAIN statement at the beginning of the query.
     *
     * @param {string} query
     * @returns {string}
     */
    enforceExplainStatement(query) {
        if (!query.match(/^\s*EXPLAIN\s/i)) {
            return `EXPLAIN ${query}`;
        }
        return query;
    }
    /**
     * Return the list of full text indices that exist in Neo4j (> v3.5.1).
     *
     * @param {Neo4jConnector}
     * @returns {Promise<{node: Map<string, FullTextIndex>, edge: Map<string, FullTextIndex>}>}
     */
    getFullTextIndices(connector) {
        // We are interested in the "indexName", "properties", "type", "progress"
        return connector.$doCypherQuery('CALL db.indexes() YIELD indexName, properties, type, progress').then(indexQueryResult => {
            const indices = _.map(indexQueryResult.results, 'rows');
            // indices: Array<[
            //   string,   // 0: indexName
            //   string[], // 1: properties
            //   string,   // 2: type
            //   number    // 3: progress
            // ]>;
            const fullTextIndices = {
                node: new Map(),
                edge: new Map()
            };
            // Each index is an array of properties:
            for (const [name, properties, indexType, progress] of indices) {
                if (indexType === 'node_fulltext') {
                    fullTextIndices.node.set(name, {
                        properties: properties,
                        progress: progress
                    });
                }
                if (indexType === 'relationship_fulltext') {
                    fullTextIndices.edge.set(name, {
                        properties: properties,
                        progress: progress
                    });
                }
            }
            return fullTextIndices;
        });
    }
    /**
     * Check that all listed indices are existing and ready.
     *
     * @param {Neo4jConnector}                                        connector
     * @param {Promise<Array<{name: string, type: 'node' | 'edge'}>>} indices
     */
    checkIndicesExists(connector, indices) {
        return this.getFullTextIndices(connector).then(existing => {
            for (const expectedIndex of indices) {
                const index = expectedIndex.type === 'node'
                    ? existing.node.get(expectedIndex.name)
                    : existing.edge.get(expectedIndex.name);
                if (!index) {
                    return Errors.business('source_action_needed', `${expectedIndex.type} index was not found (${expectedIndex.name})`, true);
                }
                if (index.progress !== 100) {
                    return Errors.business('source_action_needed', `${expectedIndex.type} index "${expectedIndex.name}" is not ready`, true);
                }
            }
        });
    }
}
module.exports = new CypherUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwaGVyVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL2N5cGhlclV0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsV0FBVztBQUNYLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUV0RSxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsTUFBTSx1QkFBdUIsR0FBRztJQUM5QixLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU07Q0FDaEYsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUVULE1BQU0sZUFBZSxHQUFHLElBQUksTUFBTSxDQUNoQyxZQUFZLEdBQUcsdUJBQXVCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGNBQWMsRUFBRSxHQUFHLENBQ3ZFLENBQUM7QUFFRixNQUFNLFdBQVc7SUFDZjs7Ozs7O09BTUc7SUFDSCxVQUFVLENBQUMsQ0FBQztRQUNWLE9BQU8sR0FBRyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7SUFDMUQsQ0FBQztJQUVEOzs7T0FHRztJQUNILFdBQVcsQ0FBQyxDQUFDO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxhQUFhLENBQUMsR0FBRztRQUNmLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUM7SUFDaEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTyxDQUFDLEtBQUs7UUFDWCwyQ0FBMkM7UUFDM0Msc0VBQXNFO1FBQ3RFLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUMvRSxPQUFPLGVBQWUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFVBQVUsQ0FBQyxLQUFLO1FBQ2QsMkNBQTJDO1FBQzNDLHNFQUFzRTtRQUN0RSxNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFL0UsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDckMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFBRSxtREFBbUQsQ0FBQyxDQUFDO1NBQzdFO1FBRUQsTUFBTSxLQUFLLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNwRCxNQUFNLFNBQVMsR0FBRyxLQUFLLEtBQUssSUFBSSxDQUFDO1FBRWpDLElBQUksU0FBUyxFQUFFO1lBQ2IsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFlBQVksQ0FBQyxLQUFLLEVBQUUsS0FBSztRQUN2QiwwQ0FBMEM7UUFDMUMsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDakQsSUFBSSxhQUFhLENBQUM7UUFFbEIsc0VBQXNFO1FBQ3RFLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFdEQsSUFBSSxLQUFLLENBQUM7UUFDVixrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLEtBQUssR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7WUFDL0QsYUFBYSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxFQUFFLEdBQUcsYUFBYSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDbkMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFBRSxpQ0FBaUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQzthQUNsRjtZQUVELHVEQUF1RDtZQUN2RCxJQUFJLGFBQWEsR0FBRyxLQUFLLEVBQUU7Z0JBQ3pCLFFBQVEsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLFNBQVMsR0FBRyxLQUFLLENBQUMsQ0FBQzthQUNuRTtTQUNGO2FBQU07WUFDTCx3Q0FBd0M7WUFDeEMsUUFBUSxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDL0I7UUFFRCxPQUFPO1lBQ0wsS0FBSyxFQUFFLFFBQVE7WUFDZixhQUFhLEVBQUUsYUFBYTtTQUM3QixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsdUJBQXVCLENBQUMsS0FBSztRQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ2xDLE9BQU8sV0FBVyxLQUFLLEVBQUUsQ0FBQztTQUMzQjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsa0JBQWtCLENBQ2hCLFNBQVM7UUFHVCx5RUFBeUU7UUFDekUsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUM3QiwrREFBK0QsQ0FDaEUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUN4QixNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUV4RCxtQkFBbUI7WUFDbkIsOEJBQThCO1lBQzlCLCtCQUErQjtZQUMvQix5QkFBeUI7WUFDekIsNkJBQTZCO1lBQzdCLE1BQU07WUFFTixNQUFNLGVBQWUsR0FBRztnQkFDdEIsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFO2dCQUNmLElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRTthQUNoQixDQUFDO1lBRUYsd0NBQXdDO1lBQ3hDLEtBQUssTUFBTSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxJQUFJLE9BQU8sRUFBRTtnQkFFN0QsSUFBSSxTQUFTLEtBQUssZUFBZSxFQUFFO29CQUNqQyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7d0JBQzdCLFVBQVUsRUFBRSxVQUFVO3dCQUN0QixRQUFRLEVBQUUsUUFBUTtxQkFDbkIsQ0FBQyxDQUFDO2lCQUNKO2dCQUNELElBQUksU0FBUyxLQUFLLHVCQUF1QixFQUFFO29CQUN6QyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7d0JBQzdCLFVBQVUsRUFBRSxVQUFVO3dCQUN0QixRQUFRLEVBQUUsUUFBUTtxQkFDbkIsQ0FBQyxDQUFDO2lCQUNKO2FBQ0Y7WUFFRCxPQUFPLGVBQWUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGtCQUFrQixDQUNoQixTQUFTLEVBQ1QsT0FBTztRQUVQLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4RCxLQUFLLE1BQU0sYUFBYSxJQUFJLE9BQU8sRUFBRTtnQkFDbkMsTUFBTSxLQUFLLEdBQUcsYUFBYSxDQUFDLElBQUksS0FBSyxNQUFNO29CQUN6QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztvQkFDdkMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDVixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0QixHQUFHLGFBQWEsQ0FBQyxJQUFJLHlCQUF5QixhQUFhLENBQUMsSUFBSSxHQUFHLEVBQ25FLElBQUksQ0FDTCxDQUFDO2lCQUNIO2dCQUNELElBQUksS0FBSyxDQUFDLFFBQVEsS0FBSyxHQUFHLEVBQUU7b0JBQzFCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsc0JBQXNCLEVBQ3RCLEdBQUcsYUFBYSxDQUFDLElBQUksV0FBVyxhQUFhLENBQUMsSUFBSSxnQkFBZ0IsRUFDbEUsSUFBSSxDQUNMLENBQUM7aUJBQ0g7YUFDRjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFdBQVcsRUFBRSxDQUFDIn0=