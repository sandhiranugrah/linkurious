/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-18.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../services');
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const GREMLIN_WRITE_STATEMENTS = [
    'addProperty', 'property', 'addE', 'addV', 'drop', 'remove', 'clear'
];
const GREMLIN_WRITE_RE = new RegExp('(' + GREMLIN_WRITE_STATEMENTS.join('|') + ')');
const GREMLIN_FORBIDDEN_STATEMENTS = [
    'close', 'openManagement', 'system\\s*\\.', 'graph\\s*\\.', 'g\\s*=', 'graph\\s*='
];
const GREMLIN_FORBIDDEN_RE = new RegExp('(' + GREMLIN_FORBIDDEN_STATEMENTS.join('|') + ')');
class GremlinUtils {
    /**
     * Return true is query is a write query.
     */
    isWrite(query) {
        const queryStatements = Utils.stripLiterals(query);
        return GREMLIN_WRITE_RE.test(queryStatements);
    }
    /**
     * Check that a query does not contain write statements or forbiden statements.
     *
     * @param {string}  query
     * @param {boolean} [allowForbiddenStatements=true] Whether the query can use forbidden statements
     * @returns {boolean} Whether the query will alter the data
     * @throws {LkError} if the query is not valid or not authorized
     */
    checkQuery(query, allowForbiddenStatements = true) {
        const queryStatements = Utils.stripLiterals(query);
        let match;
        if (allowForbiddenStatements === false) {
            if ((match = GREMLIN_FORBIDDEN_RE.exec(queryStatements)) !== null) {
                throw Errors.access('invalid_parameter', `"${match[1]}" is forbidden in Gremlin API.`);
            }
        }
        return GREMLIN_WRITE_RE.exec(queryStatements) !== null;
    }
    /**
     * Infer the type of a gremlin query result.
     *
     * @param {any} data
     * @returns {string} `literal`, `node`, `edge`, `property`, `object`
     */
    qualifyQueryResult(data) {
        if (!_.isObject(data)) {
            return 'literal';
        }
        if (data.type === 'vertex') {
            return 'node';
        }
        if (data.type === 'edge') {
            return 'edge';
        }
        // A node or edge property is an object with a value field
        if (Utils.hasValue(data.value) && !_.isObject(data.value)) {
            return 'property';
        }
        return 'object';
    }
    /**
     * Pack a gremlin message to the binary format as specified by the gremlin communication protocol.
     *
     * @param {GremlinMessage} message
     * @returns {Uint8Array}
     */
    toBinary(message) {
        const mime = message.args.accept || 'application/json';
        const messageWithMime = mime + JSON.stringify(message);
        // encode in UTF-8 https://stackoverflow.com/questions/619323/decodeuricomponent-vs-unescape-what-is-wrong-with-unescape
        const serializedMessage = unescape(encodeURIComponent(messageWithMime));
        const binaryMessage = new Uint8Array(1 + serializedMessage.length);
        binaryMessage[0] = mime.length;
        for (let i = 0; i < serializedMessage.length; i++) {
            binaryMessage[i + 1] = serializedMessage.charCodeAt(i);
        }
        return binaryMessage;
    }
    /**
     * Encode the credentials for SASL.
     *
     * @param {string} username
     * @param {string} password
     * @returns {string}
     */
    encodeSASLCredentials(username, password) {
        let str = '\0';
        str += username;
        str += '\0';
        str += password;
        return Buffer.from(str, 'ascii').toString('base64');
    }
    /**
     * Quote an ID or a property value to be inserted in a Gremlin expression.
     *
     * @param {any}     v
     * @param {boolean} [arrayAsArgs] If true, an array is not going to be wrapped in square brackets
     * @returns {string}
     */
    quote(v, arrayAsArgs) {
        if (v === null || v === undefined) {
            return 'null';
        }
        if (Array.isArray(v)) {
            return (!arrayAsArgs ? '[' : '') +
                v.map(v => this.quote(v)).join(', ') +
                (!arrayAsArgs ? ']' : '');
        }
        if (typeof v === 'object') {
            // We keep the object keys in alphabetical order so that
            // resulting encoded IDs are dependent on the object keys order
            const pairs = _.sortBy(_.toPairs(v), 0);
            return '[' + _.map(pairs, pair => this.quote(pair[0]) + ': ' + this.quote(pair[1]))
                .join(', ') + ']';
        }
        if (typeof v === 'number') {
            if (Number.isInteger(v)) {
                return v + 'L';
            }
            return v + 'D';
        }
        return JSON.stringify(v)
            // Escape $ to avoid gremlin injection.
            .replace(/\$/g, '\\$$');
    }
    /**
     * Parse a groovy map string to json.
     *
     * @param {string} key
     * @param {string} groovyObject
     * @returns {object}
     */
    parseGroovyMapToJson(key, groovyObject) {
        const valuesRx = /(?:["](.*?)["])|(\d+[GLIDF])/g;
        const illegalRx = /([^[\]:,\s])/g;
        // 1) Strip out strings and numbers
        // the only characters left should be  `[`, `]`, `:`, `,` and whitespaces
        const illegalValue = illegalRx.exec(groovyObject.replace(valuesRx, ''));
        if (Utils.hasValue(illegalValue)) {
            throw Errors.business('invalid_parameter', `"${key}" contains an invalid character ${illegalValue[1]}`);
        }
        // 2) Now we know that the string contains only key value pairs,
        // replace square brackets with curly brackets compatible with json
        // and finally re-inject the values
        const values = [];
        const jsonString = groovyObject.replace(valuesRx, (match, s, n) => {
            values.push(s ? s : n);
            return '@';
        }).replace(/[[]/g, '{')
            .replace(/[\]]/g, '}')
            .replace(/@/g, () => `"${values.shift()}"`);
        // 3) Parse the string to a json object
        // parsing the string will also validate that the format was correct before the transformation
        return JSON.parse(jsonString, (k, v) => {
            const groovyNumber = /^(\d+)[GLIDF]$/i.exec(v);
            if (Utils.hasValue(groovyNumber)) {
                return Number(groovyNumber[1]);
            }
            return v;
        });
    }
}
module.exports = new GremlinUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JlbWxpblV0aWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL2Rhby91dGlscy9ncmVtbGluVXRpbHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLE1BQU0sd0JBQXdCLEdBQUc7SUFDL0IsYUFBYSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTztDQUNyRSxDQUFDO0FBQ0YsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEdBQUcsd0JBQXdCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBRXBGLE1BQU0sNEJBQTRCLEdBQUc7SUFDbkMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxjQUFjLEVBQUUsUUFBUSxFQUFFLFlBQVk7Q0FDbkYsQ0FBQztBQUNGLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxNQUFNLENBQUMsR0FBRyxHQUFHLDRCQUE0QixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztBQUU1RixNQUFNLFlBQVk7SUFDaEI7O09BRUc7SUFDSCxPQUFPLENBQUMsS0FBSztRQUNYLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkQsT0FBTyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxVQUFVLENBQUMsS0FBSyxFQUFFLHdCQUF3QixHQUFHLElBQUk7UUFDL0MsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuRCxJQUFJLEtBQUssQ0FBQztRQUVWLElBQUksd0JBQXdCLEtBQUssS0FBSyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxLQUFLLEdBQUcsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUNqRSxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLG1CQUFtQixFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FDbEUsQ0FBQzthQUNIO1NBQ0Y7UUFFRCxPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxJQUFJLENBQUM7SUFDekQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsa0JBQWtCLENBQUMsSUFBSTtRQUNyQixJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyQixPQUFPLFNBQVMsQ0FBQztTQUNsQjtRQUVELElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDMUIsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUVELElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7WUFDeEIsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUVELDBEQUEwRDtRQUMxRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDekQsT0FBTyxVQUFVLENBQUM7U0FDbkI7UUFFRCxPQUFPLFFBQVEsQ0FBQztJQUNsQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxRQUFRLENBQUMsT0FBTztRQUNkLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLGtCQUFrQixDQUFDO1FBQ3ZELE1BQU0sZUFBZSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZELHdIQUF3SDtRQUN4SCxNQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBRXhFLE1BQU0sYUFBYSxHQUFHLElBQUksVUFBVSxDQUFDLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNuRSxhQUFhLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUUvQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pELGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hEO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDdkIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHFCQUFxQixDQUFDLFFBQVEsRUFBRSxRQUFRO1FBQ3RDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQztRQUNmLEdBQUcsSUFBSSxRQUFRLENBQUM7UUFDaEIsR0FBRyxJQUFJLElBQUksQ0FBQztRQUNaLEdBQUcsSUFBSSxRQUFRLENBQUM7UUFDaEIsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILEtBQUssQ0FBQyxDQUFDLEVBQUUsV0FBVztRQUNsQixJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUNqQyxPQUFPLE1BQU0sQ0FBQztTQUNmO1FBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BCLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQzlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDcEMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksT0FBTyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQ3pCLHdEQUF3RDtZQUN4RCwrREFBK0Q7WUFDL0QsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDaEYsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUNyQjtRQUVELElBQUksT0FBTyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQ3pCLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQ2hCO1lBQ0QsT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ2hCO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN4Qix1Q0FBdUM7YUFDcEMsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFlBQVk7UUFDcEMsTUFBTSxRQUFRLEdBQUcsK0JBQStCLENBQUM7UUFDakQsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDO1FBRWxDLG1DQUFtQztRQUNuQyx5RUFBeUU7UUFDekUsTUFBTSxZQUFZLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNoQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixJQUFJLEdBQUcsbUNBQW1DLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUM1RCxDQUFDO1NBQ0g7UUFFRCxnRUFBZ0U7UUFDaEUsbUVBQW1FO1FBQ25FLG1DQUFtQztRQUNuQyxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFFbEIsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLE9BQU8sR0FBRyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUM7YUFDcEIsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7YUFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFOUMsdUNBQXVDO1FBQ3ZDLDhGQUE4RjtRQUM5RixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3JDLE1BQU0sWUFBWSxHQUFHLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ2hDLE9BQU8sTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hDO1lBQ0QsT0FBTyxDQUFDLENBQUM7UUFDWCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQyJ9