/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-09-20.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../services');
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// our libs
const literalsParser = new (require('../../../lib/LiteralsParser'))(['"'], '\\');
// how to translate DSE field types
const MAPPING_DSE_TYPE = {
    'Text': 'string',
    'Bigint': 'integer',
    'Int': 'integer',
    'Smallint': 'integer',
    'Varint': 'integer',
    'Double': 'float',
    'Decimal': 'float',
    'Float': 'float',
    'Boolean': 'boolean',
    'Timestamp': 'date'
};
class DseUtils {
    /**
     * @example
     * Given:
     * ['schema.propertyKey("property").Text().single().create()']
     *
     * Return:
     * {
     *   property: 'string'
     * }
     *
     * @param {string[]} propertyLines
     * @returns {object}
     * @private
     */
    _parsePropertyTypesDetails(propertyLines) {
        const result = _.fromPairs(_.compact(_.map(propertyLines, line => {
            // first we use the literalsParser to get the name of the property
            const propertyKey = literalsParser.retrieveAllLiterals(line)[0];
            if (Utils.noValue(propertyKey)) {
                Log.warn(`Cannot parse the following line in schema.describe(): ${line}`);
                return; // undefined values (if the parsing failed) are removed with _.compact
            }
            // then we extract the type from a string in the following format:
            // schema.propertyKey("{propertyKey}").{type}().single().create()
            const prefix = `schema.propertyKey("${propertyKey}").`;
            const tmp = line.substring(prefix.length);
            const type = tmp.substring(0, tmp.indexOf('('));
            return [propertyKey, type];
        })));
        // for each mapping we translate the type to one that we recognize:
        // string, integer, float, boolean, date
        return _.mapValues(result, mapping => {
            const res = MAPPING_DSE_TYPE[mapping];
            if (res) {
                return res;
            }
            else {
                return 'string';
            }
        });
    }
    /**
     * @example
     * Given:
     * ['schema.vertexLabel("Person").properties("born", "name").create()',
     *  'schema.vertexLabel("NoPropertiesLabel").create()']
     *
     * Return:
     * {
     *   Person: ['born', 'name'],
     *   NoPropertiesLabel: []
     * }
     *
     * @param {string[]} schemaLines
     * @returns {object}
     * @private
     */
    _parseSchemaDetails(schemaLines) {
        const result = {};
        schemaLines.forEach(line => {
            const literals = literalsParser.retrieveAllLiterals(line);
            const label = literals[0];
            const properties = literals.slice(1);
            if (Utils.noValue(label)) {
                Log.warn(`Cannot parse the following line in schema.describe(): ${line}`);
                return;
            }
            result[label] = properties;
        });
        return result;
    }
    /**
     * @example
     * Given:
     * ['schema.vertexLabel("Person").index("search").search().by("name").asString().add()',
     *  'schema.vertexLabel("Employee").index("search").search().by("name").asString().by("resume").asText().add()',]
     *
     * Return:
     * {
     *   Person: {
     *     name: 'string'
     *   },
     *   Employee: {
     *     name: 'string',
     *     resume: 'text'
     *   }
     * }
     *
     * @param {string[]} searchIndexLines
     * @returns {object}
     * @private
     */
    _parseSearchIndexDetails(searchIndexLines) {
        const result = {};
        searchIndexLines.forEach(line => {
            // we first remove '.index("search")' so we don't get the index name as a literal
            line = line.replace('.index("search").', '.');
            const literals = literalsParser.retrieveAllLiterals(line);
            const label = literals[0];
            const properties = literals.slice(1);
            if (Utils.noValue(label)) {
                Log.warn(`Cannot parse the following line in schema.describe(): ${line}`);
                return;
            }
            // Now for each indexed property we have to discover if they were indexed asString or asText
            result[label] = {};
            properties.forEach(property => {
                const prefixStr = `.by("${property}")`;
                if (line.includes(prefixStr + '.asString()')) {
                    // if line contains 'by("{property}").asString()' is indexed as a string
                    result[label][property] = 'string';
                }
                else if (line.includes(prefixStr + '.asText()')) {
                    // if line contains 'by("{property}").asText()' is indexed as a text
                    result[label][property] = 'text';
                }
                else {
                    Log.warn(`Cannot parse the following line in schema.describe(): ${line}`);
                }
            });
        });
        return result;
    }
    /**
     * Return an array of property keys indexed for every node label
     * with a secondary or materialized index.
     *
     * @param {string[]} indexLines
     * @param {string[]} nodeLabels
     * @returns {string[]}
     * @private
     */
    _parseIndexedPropertiesDetails(indexLines, nodeLabels) {
        let labelPropertyPairs = indexLines.map(line => {
            const lineMatch = line.match(/schema\.vertexLabel\("(.*?)"\).*\.by\("(.*?)"\)/);
            if (lineMatch === null) {
                Log.warn(`Cannot parse the following line in schema.describe(): ${line}`);
                return;
            }
            return [lineMatch[1], lineMatch[2]];
        });
        labelPropertyPairs = _.compact(labelPropertyPairs);
        const groupedLabelPropertyPairs = _.groupBy(labelPropertyPairs, '1'); // we group by property key
        const result = [];
        for (const property of _.keys(groupedLabelPropertyPairs)) {
            const labelsIndexed = _.uniq(_.map(groupedLabelPropertyPairs[property], '0'));
            // if the property is indexed in every node label
            if (_.difference(nodeLabels, labelsIndexed).length === 0) {
                result.push(property);
            }
        }
        return result;
    }
    /**
     * Parse the schema info in DSE.
     *
     * Return an object with the following keys:
     * - propertyTypes     Given a property key, return the type (among the ones LK recognizes)
     * - nodeSchema        Given a node label, return the array of property keys
     * - edgeSchema        Given an edge label, return the array of property keys
     * - searchIndices     Given a node label, return an object describing which properties are indexed for full-text search
     * - indexedProperties Array of property keys indexed for every node label with a secondary or materialized index
     *
     * @param {string} schemaDescribe
     * @returns {{propertyTypes: object, nodeSchema: object, edgeSchema: object, searchIndices: object, indexedProperties: string[]}}
     */
    parseSchemaInfo(schemaDescribe) {
        const schemaDescribeLines = schemaDescribe.split('\n');
        // TODO refactor by parsing `graph.schemaModel()` instead of `schema.describe()`
        // 1) create the answer for $getPropertyTypes
        const schemaPropertyKeyLines = _.filter(schemaDescribeLines, l => l.startsWith('schema.propertyKey'));
        const propertyTypes = this._parsePropertyTypesDetails(schemaPropertyKeyLines);
        // 2) create the answer for $getSchema
        const schemaVertexLabelLines = _.filter(schemaDescribeLines, l => l.startsWith('schema.vertexLabel') && l.includes('.create()'));
        const schemaEdgeLabelLines = _.filter(schemaDescribeLines, l => l.startsWith('schema.edgeLabel') && l.includes('.create()'));
        const nodeSchema = this._parseSchemaDetails(schemaVertexLabelLines);
        const edgeSchema = this._parseSchemaDetails(schemaEdgeLabelLines);
        // 3) get search indices
        // a search index can only be called "search"
        const searchIndexLines = _.filter(schemaDescribeLines, l => l.startsWith('schema.vertexLabel') && l.includes('.search()'));
        const searchIndices = this._parseSearchIndexDetails(searchIndexLines);
        // 4) get all the properties indexed
        const indexLines = _.filter(schemaDescribeLines, l => l.startsWith('schema.vertexLabel') &&
            l.includes('.materialized()') || l.includes('.secondary()'));
        const indexedProperties = this._parseIndexedPropertiesDetails(indexLines, _.keys(nodeSchema));
        return {
            propertyTypes: propertyTypes,
            nodeSchema: nodeSchema,
            edgeSchema: edgeSchema,
            searchIndices: searchIndices,
            indexedProperties: indexedProperties
        };
    }
}
module.exports = new DseUtils();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHNlVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvZGFvL3V0aWxzL2RzZVV0aWxzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsV0FBVztBQUNYLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFFakYsbUNBQW1DO0FBQ25DLE1BQU0sZ0JBQWdCLEdBQUc7SUFDdkIsTUFBTSxFQUFFLFFBQVE7SUFDaEIsUUFBUSxFQUFFLFNBQVM7SUFDbkIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsVUFBVSxFQUFFLFNBQVM7SUFDckIsUUFBUSxFQUFFLFNBQVM7SUFDbkIsUUFBUSxFQUFFLE9BQU87SUFDakIsU0FBUyxFQUFFLE9BQU87SUFDbEIsT0FBTyxFQUFFLE9BQU87SUFDaEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsV0FBVyxFQUFFLE1BQU07Q0FDcEIsQ0FBQztBQUVGLE1BQU0sUUFBUTtJQUVaOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCwwQkFBMEIsQ0FBQyxhQUFhO1FBQ3RDLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUMvRCxrRUFBa0U7WUFDbEUsTUFBTSxXQUFXLEdBQUcsY0FBYyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWhFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsR0FBRyxDQUFDLElBQUksQ0FBQyx5REFBeUQsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDMUUsT0FBTyxDQUFDLHNFQUFzRTthQUMvRTtZQUVELGtFQUFrRTtZQUNsRSxpRUFBaUU7WUFFakUsTUFBTSxNQUFNLEdBQUcsdUJBQXVCLFdBQVcsS0FBSyxDQUFDO1lBQ3ZELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzFDLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUVoRCxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVMLG1FQUFtRTtRQUNuRSx3Q0FBd0M7UUFDeEMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRTtZQUNuQyxNQUFNLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN0QyxJQUFJLEdBQUcsRUFBRTtnQkFDUCxPQUFPLEdBQUcsQ0FBQzthQUNaO2lCQUFNO2dCQUNMLE9BQU8sUUFBUSxDQUFDO2FBQ2pCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsbUJBQW1CLENBQUMsV0FBVztRQUM3QixNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFFbEIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN6QixNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFckMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDLHlEQUF5RCxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUMxRSxPQUFPO2FBQ1I7WUFFRCxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9CRztJQUNILHdCQUF3QixDQUFDLGdCQUFnQjtRQUN2QyxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFFbEIsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlCLGlGQUFpRjtZQUNqRixJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM5QyxNQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFckMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDLHlEQUF5RCxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUMxRSxPQUFPO2FBQ1I7WUFFRCw0RkFBNEY7WUFDNUYsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUVuQixVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUM1QixNQUFNLFNBQVMsR0FBRyxRQUFRLFFBQVEsSUFBSSxDQUFDO2dCQUN2QyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxFQUFFO29CQUM1Qyx3RUFBd0U7b0JBQ3hFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7aUJBQ3BDO3FCQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLEVBQUU7b0JBQ2pELG9FQUFvRTtvQkFDcEUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLE1BQU0sQ0FBQztpQkFDbEM7cUJBQU07b0JBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyx5REFBeUQsSUFBSSxFQUFFLENBQUMsQ0FBQztpQkFDM0U7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsOEJBQThCLENBQUMsVUFBVSxFQUFFLFVBQVU7UUFDbkQsSUFBSSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsaURBQWlELENBQUMsQ0FBQztZQUNoRixJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3RCLEdBQUcsQ0FBQyxJQUFJLENBQUMseURBQXlELElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQzFFLE9BQU87YUFDUjtZQUVELE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFFSCxrQkFBa0IsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFbkQsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsMkJBQTJCO1FBRWpHLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUVsQixLQUFLLE1BQU0sUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsRUFBRTtZQUN4RCxNQUFNLGFBQWEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsUUFBUSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUU5RSxpREFBaUQ7WUFDakQsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUN4RCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3ZCO1NBQ0Y7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsZUFBZSxDQUFDLGNBQWM7UUFDNUIsTUFBTSxtQkFBbUIsR0FBRyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXZELGdGQUFnRjtRQUVoRiw2Q0FBNkM7UUFDN0MsTUFBTSxzQkFBc0IsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUN6RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO1FBRTNDLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBRTlFLHNDQUFzQztRQUN0QyxNQUFNLHNCQUFzQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQ3pELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUN0RSxNQUFNLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQ3ZELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUVwRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUNwRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUVsRSx3QkFBd0I7UUFDeEIsNkNBQTZDO1FBQzdDLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFDbkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXRFLG9DQUFvQztRQUNwQyxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQztZQUN0RixDQUFDLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1FBQy9ELE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFFOUYsT0FBTztZQUNMLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLGFBQWEsRUFBRSxhQUFhO1lBQzVCLGlCQUFpQixFQUFFLGlCQUFpQjtTQUNyQyxDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDIn0=