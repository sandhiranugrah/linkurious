"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-06-26.
 */
// external libs
const cla = require("commander");
class Options {
    constructor() {
        this.RESET_OPTION = 'reset-config';
    }
    // TODO #1424 move under models, rename to LKEOptions, parse should call the constructor and return an instance of it
    /**
     * Detect the application runtime mode from the `NODE_ENV` environment variable.
     * If not defined, fallback to the default mode 'production'.
     *
     * The application runtime mode can also be overwritten by command line arguments.
     * Parse also the reset config command line argument if specified.
     *
     * @param LKE
     */
    parse(LKE) {
        // read mode from shell environment
        let mode = process.env.NODE_ENV || '';
        if (!LKE.MODES.includes(mode)) {
            // if the detected mode does not exist in the list of modes, fallback to default mode
            mode = LKE.DEFAULT_MODE;
        }
        // read mode from command line arguments
        cla
            .option('-r, --' + this.RESET_OPTION, 'Reset the configuration to defaults')
            .option('-d, --' + LKE.MODE_DEV, 'Run app in ' + LKE.MODE_DEV + ' mode')
            .option('-p, --' + LKE.MODE_PROD, 'Run app in ' + LKE.MODE_PROD + ' mode')
            .option('-t, --' + LKE.MODE_TEST, 'Run app in ' + LKE.MODE_TEST + ' mode')
            .option('-a, --' + LKE.MODE_PRE_PROD, 'Run app in ' + LKE.MODE_PRE_PROD + ' mode')
            .parse(process.argv);
        LKE.MODES.forEach(m => {
            if (cla[m]) {
                mode = m;
            }
        });
        return {
            mode: mode,
            resetConfig: cla.resetConfig
        };
    }
}
module.exports = new Options();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NlcnZlci9vcHRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixpQ0FBaUM7QUFFakMsTUFBTSxPQUFPO0lBQWI7UUFDa0IsaUJBQVksR0FBRyxjQUFjLENBQUM7SUF5Q2hELENBQUM7SUF2Q0MscUhBQXFIO0lBRXJIOzs7Ozs7OztPQVFHO0lBQ0ksS0FBSyxDQUFDLEdBQW1CO1FBQzlCLG1DQUFtQztRQUNuQyxJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBSSxFQUFFLENBQUM7UUFDdEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdCLHFGQUFxRjtZQUNyRixJQUFJLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztTQUN6QjtRQUVELHdDQUF3QztRQUN4QyxHQUFHO2FBQ0EsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLHFDQUFxQyxDQUFDO2FBQzNFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxhQUFhLEdBQUcsR0FBRyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7YUFDdkUsTUFBTSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLGFBQWEsR0FBRyxHQUFHLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQzthQUN6RSxNQUFNLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsYUFBYSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO2FBQ3pFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRSxhQUFhLEdBQUcsR0FBRyxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUM7YUFDakYsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV2QixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNwQixJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDVixJQUFJLEdBQUcsQ0FBQyxDQUFDO2FBQ1Y7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSTtZQUNWLFdBQVcsRUFBRSxHQUFHLENBQUMsV0FBVztTQUM3QixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBRUQsaUJBQVMsSUFBSSxPQUFPLEVBQUUsQ0FBQyJ9