"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const InvalidParameter_1 = require("./InvalidParameter");
class MalformedQueryTemplate extends InvalidParameter_1.InvalidParameter {
    constructor(message, highlight) {
        super(message, highlight);
    }
}
exports.MalformedQueryTemplate = MalformedQueryTemplate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWFsZm9ybWVkUXVlcnlUZW1wbGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL01hbGZvcm1lZFF1ZXJ5VGVtcGxhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILFNBQVM7QUFDVCx5REFBb0Q7QUFFcEQsTUFBYSxzQkFBdUIsU0FBUSxtQ0FBZ0I7SUFDMUQsWUFBWSxPQUFlLEVBQUUsU0FBMEI7UUFDckQsS0FBSyxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztJQUM1QixDQUFDO0NBQ0Y7QUFKRCx3REFJQyJ9