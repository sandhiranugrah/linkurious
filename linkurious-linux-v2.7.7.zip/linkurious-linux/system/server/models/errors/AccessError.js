"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-01.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const LkError_1 = require("./LkError");
class AccessError extends LkError_1.LkError {
    constructor(key, message) {
        super(LkError_1.ErrorType.ACCESS, key, message);
    }
}
exports.AccessError = AccessError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWNjZXNzRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2Vycm9ycy9BY2Nlc3NFcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsU0FBUztBQUNULHVDQUE2QztBQUU3QyxNQUFhLFdBQVksU0FBUSxpQkFBTztJQUN0QyxZQUFZLEdBQVcsRUFBRSxPQUFlO1FBQ3RDLEtBQUssQ0FBQyxtQkFBUyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDeEMsQ0FBQztDQUNGO0FBSkQsa0NBSUMifQ==