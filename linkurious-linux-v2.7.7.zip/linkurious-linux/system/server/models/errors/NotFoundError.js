"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
// locals
const BusinessError_1 = require("./BusinessError");
class NotFoundError extends BusinessError_1.BusinessError {
    constructor(itemType, wantedId) {
        super(itemType + '_not_found', `${_.capitalize(itemType)} #${wantedId} was not found.`);
    }
}
exports.NotFoundError = NotFoundError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90Rm91bmRFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL05vdEZvdW5kRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGdCQUFnQjtBQUNoQiw0QkFBNEI7QUFFNUIsU0FBUztBQUNULG1EQUE4QztBQUU5QyxNQUFhLGFBQWMsU0FBUSw2QkFBYTtJQUM5QyxZQUFZLFFBQWdCLEVBQUUsUUFBeUI7UUFDckQsS0FBSyxDQUFDLFFBQVEsR0FBRyxZQUFZLEVBQUUsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQztJQUMxRixDQUFDO0NBQ0Y7QUFKRCxzQ0FJQyJ9