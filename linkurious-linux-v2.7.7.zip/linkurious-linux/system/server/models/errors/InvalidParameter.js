"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const BusinessError_1 = require("./BusinessError");
class InvalidParameter extends BusinessError_1.BusinessError {
    constructor(message, data) {
        super('invalid_parameter', message, data);
    }
}
exports.InvalidParameter = InvalidParameter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSW52YWxpZFBhcmFtZXRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0ludmFsaWRQYXJhbWV0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILFNBQVM7QUFDVCxtREFBOEM7QUFFOUMsTUFBYSxnQkFBaUIsU0FBUSw2QkFBYTtJQUNqRCxZQUFZLE9BQWUsRUFBRSxJQUE2QjtRQUN4RCxLQUFLLENBQUMsbUJBQW1CLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVDLENBQUM7Q0FDRjtBQUpELDRDQUlDIn0=