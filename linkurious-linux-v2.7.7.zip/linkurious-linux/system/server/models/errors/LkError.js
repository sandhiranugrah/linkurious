"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var ErrorType;
(function (ErrorType) {
    /**
     * A forbidden action (for business reasons)
     * e.g.:
     * - user A hasn't right to do action B
     */
    ErrorType["ACCESS"] = "ACCESS";
    /**
     * An invalid action (for business reasons)
     * e.g.:
     * - delete a node with an unknown node ID
     */
    ErrorType["BUSINESS"] = "BUSINESS";
    /**
     * Non-business internal errors that we cannot solve
     * e.g.:
     * - the SQLite database file is locked
     * - cannot listen on port 3000: already used
     */
    ErrorType["TECHNICAL"] = "TECHNICAL";
})(ErrorType = exports.ErrorType || (exports.ErrorType = {}));
class LkError extends Error {
    /**
     * @param type      Type of the error
     * @param key       Key of the error
     * @param [message] Human readable description of the error
     * @param [data]    Additional error information
     */
    constructor(type, key, message, data) {
        super(message === null || message === undefined ? '' : message);
        this.type = type;
        this.key = key;
        this.data = data;
        if (!LkError.isTechnicalType(type)) {
            this.stack = undefined;
        }
    }
    static get Type() {
        return ErrorType;
    }
    /**
     * Return true if `type` equals `ErrorType.ACCESS`.
     *
     * @param type
     */
    static isAccessType(type) {
        return type === ErrorType.ACCESS;
    }
    /**
     * Return true if `type` equals `ErrorType.BUSINESS`.
     *
     * @param type
     */
    static isBusinessType(type) {
        return type === ErrorType.BUSINESS;
    }
    /**
     * Return true if `type` equals `ErrorType.TECHNICAL`.
     *
     * @param type
     */
    static isTechnicalType(type) {
        return type === ErrorType.TECHNICAL;
    }
    /**
     * Return true if `type` equals `ErrorType.ACCESS`.
     */
    isAccess() {
        return LkError.isAccessType(this.type);
    }
    /**
     * Return true if `type` equals `ErrorType.BUSINESS`.
     */
    isBusiness() {
        return LkError.isBusinessType(this.type);
    }
    /**
     * Return true if `type` equals `ErrorType.TECHNICAL`.
     */
    isTechnical() {
        return LkError.isTechnicalType(this.type);
    }
}
exports.LkError = LkError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTGtFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0xrRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILElBQVksU0FzQlg7QUF0QkQsV0FBWSxTQUFTO0lBQ25COzs7O09BSUc7SUFDSCw4QkFBaUIsQ0FBQTtJQUVqQjs7OztPQUlHO0lBQ0gsa0NBQXFCLENBQUE7SUFFckI7Ozs7O09BS0c7SUFDSCxvQ0FBdUIsQ0FBQTtBQUN6QixDQUFDLEVBdEJXLFNBQVMsR0FBVCxpQkFBUyxLQUFULGlCQUFTLFFBc0JwQjtBQUVELE1BQWEsT0FBUSxTQUFRLEtBQUs7SUFLaEM7Ozs7O09BS0c7SUFDSCxZQUFZLElBQWUsRUFBRSxHQUFXLEVBQUUsT0FBZ0IsRUFBRSxJQUE2QjtRQUN2RixLQUFLLENBQUMsT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFFakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEMsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7U0FDeEI7SUFDSCxDQUFDO0lBRU0sTUFBTSxLQUFLLElBQUk7UUFDcEIsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxNQUFNLENBQUMsWUFBWSxDQUFDLElBQVk7UUFDckMsT0FBTyxJQUFJLEtBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQztJQUNuQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBWTtRQUN2QyxPQUFPLElBQUksS0FBSyxTQUFTLENBQUMsUUFBUSxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFZO1FBQ3hDLE9BQU8sSUFBSSxLQUFLLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDdEMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksUUFBUTtRQUNiLE9BQU8sT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksVUFBVTtRQUNmLE9BQU8sT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOztPQUVHO0lBQ0ksV0FBVztRQUNoQixPQUFPLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzVDLENBQUM7Q0FDRjtBQTFFRCwwQkEwRUMifQ==