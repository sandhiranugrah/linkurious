"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-01.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const LkError_1 = require("./LkError");
class BusinessError extends LkError_1.LkError {
    constructor(key, message, data) {
        super(LkError_1.ErrorType.BUSINESS, key, message, data);
    }
}
exports.BusinessError = BusinessError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnVzaW5lc3NFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0J1c2luZXNzRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILFNBQVM7QUFDVCx1Q0FBNkM7QUFFN0MsTUFBYSxhQUFjLFNBQVEsaUJBQU87SUFDeEMsWUFBWSxHQUFXLEVBQUUsT0FBZSxFQUFFLElBQTZCO1FBQ3JFLEtBQUssQ0FBQyxtQkFBUyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hELENBQUM7Q0FDRjtBQUpELHNDQUlDIn0=