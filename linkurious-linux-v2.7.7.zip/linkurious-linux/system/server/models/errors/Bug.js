"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const TechnicalError_1 = require("./TechnicalError");
class Bug extends TechnicalError_1.TechnicalError {
    constructor(message) {
        super('bug', message);
    }
}
exports.Bug = Bug;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnVnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9lcnJvcnMvQnVnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7QUFFSCxTQUFTO0FBQ1QscURBQWdEO0FBRWhELE1BQWEsR0FBSSxTQUFRLCtCQUFjO0lBQ3JDLFlBQVksT0FBZTtRQUN6QixLQUFLLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3hCLENBQUM7Q0FDRjtBQUpELGtCQUlDIn0=