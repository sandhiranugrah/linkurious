"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
// locals
const AccessError_1 = require("./AccessError");
class NotOwnerError extends AccessError_1.AccessError {
    constructor(itemType, itemId, userId) {
        super('forbidden', `${_.capitalize(itemType)} #${itemId} doesn't belong to user #${userId}.`);
    }
}
exports.NotOwnerError = NotOwnerError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90T3duZXJFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL05vdE93bmVyRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGdCQUFnQjtBQUNoQiw0QkFBNEI7QUFFNUIsU0FBUztBQUNULCtDQUEwQztBQUUxQyxNQUFhLGFBQWMsU0FBUSx5QkFBVztJQUM1QyxZQUFZLFFBQWdCLEVBQUUsTUFBYyxFQUFFLE1BQWM7UUFDMUQsS0FBSyxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEtBQUssTUFBTSw0QkFBNEIsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUNoRyxDQUFDO0NBQ0Y7QUFKRCxzQ0FJQyJ9