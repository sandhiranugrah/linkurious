"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-25.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const AccessError_1 = require("./AccessError");
class CantReadError extends AccessError_1.AccessError {
    constructor(itemType, itemId, userId) {
        super('forbidden', `User #${userId} isn't allowed to read ${itemType} #${itemId}.`);
    }
}
exports.CantReadError = CantReadError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2FudFJlYWRFcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0NhbnRSZWFkRXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILFNBQVM7QUFDVCwrQ0FBMEM7QUFFMUMsTUFBYSxhQUFjLFNBQVEseUJBQVc7SUFDNUMsWUFBWSxRQUFnQixFQUFFLE1BQWMsRUFBRSxNQUFjO1FBQzFELEtBQUssQ0FBQyxXQUFXLEVBQUUsU0FBUyxNQUFNLDBCQUEwQixRQUFRLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztJQUN0RixDQUFDO0NBQ0Y7QUFKRCxzQ0FJQyJ9