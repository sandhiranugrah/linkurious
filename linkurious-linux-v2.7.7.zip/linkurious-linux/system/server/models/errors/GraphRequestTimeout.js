"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-11.
 */
const BusinessError_1 = require("./BusinessError");
var Vendor;
(function (Vendor) {
    Vendor["NEO4J"] = "Neo4j";
    Vendor["GREMLIN_SERVER"] = "Gremlin Server";
    Vendor["STARDOG"] = "Stardog";
    Vendor["ALLEGRO"] = "Allegro Graph";
    Vendor["LINKURIOUS"] = "Linkurious";
})(Vendor = exports.Vendor || (exports.Vendor = {}));
const VendorConfig = {
    NEO4J: 'dbms.transaction.timeout',
    GREMLIN_SERVER: 'scriptEvaluationTimeout',
    STARDOG: 'query.timeout',
    ALLEGRO: '',
    LINKURIOUS: 'advanced.rawQueryTimeout'
};
class GraphRequestTimeout extends BusinessError_1.BusinessError {
    constructor(vendor) {
        const key = VendorConfig[vendor];
        const message = 'The query failed to execute within the limit of the timeout';
        const debug = key ? `, Increase the value of "${key}" in the ${vendor} configuration.` : '.';
        super('graph_request_timeout', message + debug);
    }
}
exports.GraphRequestTimeout = GraphRequestTimeout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3JhcGhSZXF1ZXN0VGltZW91dC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvZXJyb3JzL0dyYXBoUmVxdWVzdFRpbWVvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7R0FLRztBQUNILG1EQUE4QztBQUU5QyxJQUFZLE1BTVg7QUFORCxXQUFZLE1BQU07SUFDaEIseUJBQWUsQ0FBQTtJQUNmLDJDQUFpQyxDQUFBO0lBQ2pDLDZCQUFtQixDQUFBO0lBQ25CLG1DQUF5QixDQUFBO0lBQ3pCLG1DQUF5QixDQUFBO0FBQzNCLENBQUMsRUFOVyxNQUFNLEdBQU4sY0FBTSxLQUFOLGNBQU0sUUFNakI7QUFFRCxNQUFNLFlBQVksR0FBMEI7SUFDMUMsS0FBSyxFQUFFLDBCQUEwQjtJQUNqQyxjQUFjLEVBQUUseUJBQXlCO0lBQ3pDLE9BQU8sRUFBRSxlQUFlO0lBQ3hCLE9BQU8sRUFBRSxFQUFFO0lBQ1gsVUFBVSxFQUFFLDBCQUEwQjtDQUN2QyxDQUFDO0FBRUYsTUFBYSxtQkFBb0IsU0FBUSw2QkFBYTtJQUNwRCxZQUFZLE1BQWM7UUFDeEIsTUFBTSxHQUFHLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLE1BQU0sT0FBTyxHQUFHLDZEQUE2RCxDQUFDO1FBQzlFLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsNEJBQTRCLEdBQUcsWUFBWSxNQUFNLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDN0YsS0FBSyxDQUFDLHVCQUF1QixFQUFFLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQztJQUNsRCxDQUFDO0NBQ0Y7QUFQRCxrREFPQyJ9