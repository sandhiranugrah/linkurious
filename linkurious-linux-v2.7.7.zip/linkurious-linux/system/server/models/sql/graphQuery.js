"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-24.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
// TODO add types to DBFields
const DBFields = require("../../lib/DBFields");
exports.currentGraphQueryVersion = 2;
function default_1(sequelize, DataTypes) {
    const graphQuery = sequelize.define('graphQuery', {
        sourceKey: {
            allowNull: false,
            type: DataTypes.STRING(8)
        },
        name: {
            // @backward-compatibility
            // The field is required on CreateGraphQueryParams but before 2.7.0 null was allowed
            allowNull: true,
            type: DataTypes.STRING(200)
        },
        dialect: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        content: {
            allowNull: false,
            type: DataTypes.TEXT
        },
        description: {
            allowNull: true,
            type: DataTypes.TEXT,
            get: function () {
                const v = this.getDataValue('description');
                // @backward-compatibility
                // The field is required starting from 2.7.0 but before `null` was allowed
                if (v === null || v === undefined) {
                    return '';
                }
                return v;
            }
        },
        sharing: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        type: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        version: {
            // @backward-compatibility
            // On Linkurious 2.7.0 we changed the format of `templateFields`
            // Every query created before 2.7.0 and not yet migrated is version 1,
            // New or migrated queries are version 2
            allowNull: true,
            type: DataTypes.INTEGER,
            defaultValue: exports.currentGraphQueryVersion
        },
        templateFields: DBFields.generateJsonField('templateFields')
    }, {
        charset: 'utf8',
        classMethods: {
            associate: (models) => {
                graphQuery.belongsTo(models.user, { foreignKey: 'userId' });
                graphQuery.belongsToMany(models.group, { through: 'queryGroups' });
            }
        }
    });
    return graphQuery;
}
exports.default = default_1;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvc3FsL2dyYXBoUXVlcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQU9ILFNBQVM7QUFDVCw2QkFBNkI7QUFDN0IsK0NBQWdEO0FBb0NuQyxRQUFBLHdCQUF3QixHQUFXLENBQUMsQ0FBQztBQUVsRCxtQkFDRSxTQUE4QixFQUM5QixTQUE4QjtJQUU5QixNQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUNqQyxZQUFZLEVBQ1o7UUFDRSxTQUFTLEVBQUU7WUFDVCxTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDMUI7UUFFRCxJQUFJLEVBQUU7WUFDSiwwQkFBMEI7WUFDMUIsb0ZBQW9GO1lBQ3BGLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1NBQzVCO1FBRUQsT0FBTyxFQUFFO1lBQ1AsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxFQUFFO1lBQ1AsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO1NBQ3JCO1FBRUQsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUk7WUFDcEIsR0FBRyxFQUFFO2dCQUNILE1BQU0sQ0FBQyxHQUFJLElBQTJCLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNuRSwwQkFBMEI7Z0JBQzFCLDBFQUEwRTtnQkFDMUUsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxTQUFTLEVBQUU7b0JBQ2pDLE9BQU8sRUFBRSxDQUFDO2lCQUNYO2dCQUVELE9BQU8sQ0FBQyxDQUFDO1lBQ1gsQ0FBQztTQUNGO1FBRUQsT0FBTyxFQUFFO1lBQ1AsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBRUQsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxFQUFFO1lBQ1AsMEJBQTBCO1lBQzFCLGdFQUFnRTtZQUNoRSxzRUFBc0U7WUFDdEUsd0NBQXdDO1lBQ3hDLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1lBQ3ZCLFlBQVksRUFBRSxnQ0FBd0I7U0FDdkM7UUFFRCxjQUFjLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDO0tBQzdELEVBQ0Q7UUFDRSxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxDQUFDLE1BQW1CLEVBQUUsRUFBRTtnQkFDakMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7Z0JBQzFELFVBQVUsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxhQUFhLEVBQUMsQ0FBQyxDQUFDO1lBQ25FLENBQUM7U0FDRjtLQUNGLENBQ0YsQ0FBQztJQUNGLE9BQVEsVUFBeUMsQ0FBQztBQUNwRCxDQUFDO0FBN0VELDRCQTZFQyJ9