"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-02-02.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
// locals
const apiParams_1 = require("./apiParams");
/**
 * @apiDefine DataSourceParams
 *
 * @apiParam {string} dataSource Key of the data-source
 */
class DataSourceParams extends apiParams_1.ApiParams {
    getParamsDefinition() {
        return {
            dataSource: { required: true, check: (key, value) => Utils.checkSourceKey(value, key) }
        };
    }
}
__decorate([
    apiParams_1.ApiParam('path')
], DataSourceParams.prototype, "dataSource", void 0);
exports.DataSourceParams = DataSourceParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YVNvdXJjZVBhcmFtcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvcGFyYW1ldGVycy9kYXRhU291cmNlUGFyYW1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7Ozs7Ozs7QUFFSCxXQUFXO0FBQ1gsc0NBQXVDO0FBQ3ZDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsMkNBQTJFO0FBRTNFOzs7O0dBSUc7QUFDSCxNQUFhLGdCQUFpQixTQUFRLHFCQUFTO0lBSW5DLG1CQUFtQjtRQUMzQixPQUFPO1lBQ0wsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBQztTQUN0RixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBUEM7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztvREFDVTtBQUY3Qiw0Q0FTQyJ9