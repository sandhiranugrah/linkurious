"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
// locals
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
const graphQueryParams_1 = require("./graphQueryParams");
const LKE = require("../../services");
const Utils = LKE.getUtils();
var COLUMN_TYPE_VALUES;
(function (COLUMN_TYPE_VALUES) {
    COLUMN_TYPE_VALUES["STRING"] = "string";
    COLUMN_TYPE_VALUES["NUMBER"] = "number";
})(COLUMN_TYPE_VALUES = exports.COLUMN_TYPE_VALUES || (exports.COLUMN_TYPE_VALUES = {}));
/**
 * @apiDefine GraphParams
 *
 * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
 * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
 * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
 * @apiParam {boolean}  [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
 */
class GraphParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            edgesTo: { required: false, check: ['stringArray', undefined, undefined, true] },
            withDigest: { required: false, type: 'boolean' },
            withDegree: { required: false, type: 'boolean' },
            withAccess: { required: false, type: 'boolean' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], GraphParams.prototype, "edgesTo", void 0);
__decorate([
    apiParams_1.ApiParam('query', Utils.parseBoolean.bind(Utils))
], GraphParams.prototype, "withDigest", void 0);
__decorate([
    apiParams_1.ApiParam('query', Utils.parseBoolean.bind(Utils))
], GraphParams.prototype, "withDegree", void 0);
__decorate([
    apiParams_1.ApiParam('query', Utils.parseBoolean.bind(Utils))
], GraphParams.prototype, "withAccess", void 0);
exports.GraphParams = GraphParams;
/**
 * @apiDefine RunGraphQueryParams
 *
 * @apiParam {string="cypher","gremlin","sparql"} [dialect]      Dialect of the graph query (defaults to the first supported dialect of the data-source)
 * @apiParam {number}                             [limit]        Maximum number of matched subgraphs
 * @apiParam {number}                             [timeout]      Maximum execution time in milliseconds
 * @apiParam {object}                             [templateData] Key/value pair data to be filled in the template
 */
class RunGraphQueryParams extends GraphParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            dialect: { required: false, values: _.values(graphQueryParams_1.GraphQueryDialect) },
            limit: { required: false, type: 'number' },
            timeout: { required: false, type: 'number' },
            templateData: { required: false, type: 'object' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], RunGraphQueryParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], RunGraphQueryParams.prototype, "limit", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], RunGraphQueryParams.prototype, "timeout", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], RunGraphQueryParams.prototype, "templateData", void 0);
/**
 * @apiDefine RunGraphQueryByContentParams
 *
 * @apiParam {string} query The graph query
 */
class RunGraphQueryByContentParams extends RunGraphQueryParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            query: { required: true, type: 'string' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], RunGraphQueryByContentParams.prototype, "query", void 0);
exports.RunGraphQueryByContentParams = RunGraphQueryByContentParams;
/**
 * @apiDefine RunGraphQueryByIdParams
 *
 * @apiParam {number} id ID of the graph query
 */
class RunGraphQueryByIdParams extends RunGraphQueryParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            // negative IDs are allowed and refer to builtin queries
            id: { required: true, type: 'number' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('path', Utils.tryParseNumber.bind(Utils))
], RunGraphQueryByIdParams.prototype, "id", void 0);
exports.RunGraphQueryByIdParams = RunGraphQueryByIdParams;
/**
 * @apiDefine CheckGraphQueryParams
 *
 * @apiParam {string}                             query     The graph query
 * @apiParam {string="cypher","gremlin","sparql"} [dialect] Dialect of the graph query (defaults to the first supported dialect of the data-source)
 */
class CheckGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            query: { required: true, type: 'string' },
            dialect: { required: false, values: _.values(graphQueryParams_1.GraphQueryDialect) }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], CheckGraphQueryParams.prototype, "query", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CheckGraphQueryParams.prototype, "dialect", void 0);
exports.CheckGraphQueryParams = CheckGraphQueryParams;
/**
 * @apiDefine AlertPreviewParams
 *
 * @apiParam {string}                             query                 The graph query
 * @apiParam {string="cypher","gremlin","sparql"} [dialect]             Dialect of the graph query (defaults to the first supported dialect of the data-source)
 * @apiParam {object[]}                           [columns]             Columns among the returned values of the query to return as scalar values
 * @apiParam {string="number","string"}           columns.type          Type of the column
 * @apiParam {string}                             columns.columnName    Name of the column in the query
 * @apiParam {string}                             [columns.columnTitle] Tolerated for homogeneity with other alert APIs
 * @apiParam {number}                             [limit]               Maximum number of matched subgraphs
 * @apiParam {number}                             [timeout]             Maximum execution time in milliseconds
 */
class AlertPreviewParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            query: { required: true, type: 'string' },
            dialect: { required: false, values: _.values(graphQueryParams_1.GraphQueryDialect) },
            columns: {
                required: false,
                arrayItem: {
                    properties: {
                        columnName: { required: true, check: 'nonEmpty' },
                        columnTitle: { required: false, check: 'nonEmpty' },
                        type: { required: true, values: _.values(COLUMN_TYPE_VALUES) }
                    }
                }
            },
            limit: { required: false, type: 'number' },
            timeout: { required: false, type: 'number' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], AlertPreviewParams.prototype, "query", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], AlertPreviewParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], AlertPreviewParams.prototype, "columns", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], AlertPreviewParams.prototype, "limit", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], AlertPreviewParams.prototype, "timeout", void 0);
exports.AlertPreviewParams = AlertPreviewParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhQYXJhbXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL3BhcmFtZXRlcnMvZ3JhcGhQYXJhbXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOzs7Ozs7OztBQUVILGdCQUFnQjtBQUNoQiw0QkFBNEI7QUFFNUIsU0FBUztBQUNULDJDQUFnRTtBQUNoRSx5REFBb0Q7QUFDcEQseURBQXFEO0FBSXJELHNDQUF1QztBQUN2QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsSUFBWSxrQkFHWDtBQUhELFdBQVksa0JBQWtCO0lBQzVCLHVDQUFpQixDQUFBO0lBQ2pCLHVDQUFpQixDQUFBO0FBQ25CLENBQUMsRUFIVyxrQkFBa0IsR0FBbEIsMEJBQWtCLEtBQWxCLDBCQUFrQixRQUc3QjtBQUVEOzs7Ozs7O0dBT0c7QUFDSCxNQUFzQixXQUFZLFNBQVEsbUNBQWdCO0lBaUI5QyxtQkFBbUI7UUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFO1lBQzFDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUM7WUFDOUUsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzlDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM5QyxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7U0FDL0MsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBdkJDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7NENBQ1M7QUFHMUI7SUFEQyxvQkFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzsrQ0FDdEI7QUFHNUI7SUFEQyxvQkFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzsrQ0FDdEI7QUFHNUI7SUFEQyxvQkFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzsrQ0FDdEI7QUFYOUIsa0NBeUJDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILE1BQWUsbUJBQW9CLFNBQVEsV0FBVztJQWdCMUMsbUJBQW1CO1FBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsRUFBRTtZQUMxQyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLG9DQUFpQixDQUFDLEVBQUM7WUFDL0QsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO1lBQ3hDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBQztZQUMxQyxZQUFZLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7U0FDaEQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBdEJDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7b0RBQ2tCO0FBR25DO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7a0RBQ0s7QUFHdEI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQztvREFDTztBQUd4QjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO3lEQUM0QjtBQWUvQzs7OztHQUlHO0FBQ0gsTUFBYSw0QkFBNkIsU0FBUSxtQkFBbUI7SUFJekQsbUJBQW1CO1FBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsRUFBRTtZQUMxQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7U0FDeEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBUEM7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzsyREFDSztBQUZ4QixvRUFTQztBQUdEOzs7O0dBSUc7QUFDSCxNQUFhLHVCQUF3QixTQUFRLG1CQUFtQjtJQUlwRCxtQkFBbUI7UUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFO1lBQzFDLHdEQUF3RDtZQUN4RCxFQUFFLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7U0FDckMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBUkM7SUFEQyxvQkFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzttREFDaEM7QUFGckIsMERBVUM7QUFFRDs7Ozs7R0FLRztBQUNILE1BQWEscUJBQXNCLFNBQVEsbUNBQWdCO0lBTy9DLG1CQUFtQjtRQUMzQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEVBQUU7WUFDMUMsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO1lBQ3ZDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsb0NBQWlCLENBQUMsRUFBQztTQUNoRSxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFYQztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO29EQUNLO0FBR3RCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7c0RBQ2tCO0FBTHJDLHNEQWFDO0FBRUQ7Ozs7Ozs7Ozs7O0dBV0c7QUFDSCxNQUFhLGtCQUFtQixTQUFRLG1DQUFnQjtJQWdCNUMsbUJBQW1CO1FBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsRUFBRTtZQUMxQyxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7WUFDdkMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQ0FBaUIsQ0FBQyxFQUFDO1lBQy9ELE9BQU8sRUFBRTtnQkFDUCxRQUFRLEVBQUUsS0FBSztnQkFDZixTQUFTLEVBQUU7b0JBQ1QsVUFBVSxFQUFFO3dCQUNWLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQzt3QkFDL0MsV0FBVyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO3dCQUNqRCxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUM7cUJBQzdEO2lCQUNGO2FBQ0Y7WUFDRCxLQUFLLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7WUFDeEMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO1NBQzNDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQWhDQztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO2lEQUNLO0FBR3RCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7bURBQ2tCO0FBR25DO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7bURBQzRFO0FBRzdGO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7aURBQ0s7QUFHdEI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzttREFDTztBQWQxQixnREFrQ0MifQ==