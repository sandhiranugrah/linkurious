"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS
 *
 * Created on 2018-12-28.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
require("reflect-metadata");
// services
const LKE = require("../../services/index");
const Utils = LKE.getUtils();
// locals
const Bug_1 = require("../errors/Bug");
const InvalidParameter_1 = require("../errors/InvalidParameter");
const METADATA_KEY = Symbol('ApiParameterMetadata');
/**
 * Annotation.
 */
function ApiParam(source = 'body', parser) {
    return (target, propertyKey) => {
        const className = target.constructor.name;
        // check that target inherits from ApiParameters
        if (!(target instanceof ApiParams)) {
            throw new Bug_1.Bug(`Annotation @${ApiParam.name} can only used on instances of class ${ApiParams.name} (${className}.${propertyKey})`);
        }
        // Pull the existing stored metadata (or create an empty object)
        // WARNING: Cloning here is necessary to avoid sharing metadata across several classes
        // that inherit from a shared annotated class.
        const metadata = _.cloneDeep(Reflect.getMetadata(METADATA_KEY, target) || {});
        if (!metadata.apiParameters) {
            metadata.apiParameters = {};
        }
        const newMetadata = {
            source: source,
            parser: parser
        };
        const existingMetadata = metadata.apiParameters[propertyKey];
        if (existingMetadata !== undefined) {
            throw new Bug_1.Bug(`Annotation @ApiParam is declared several times for field ${className}.${propertyKey}: ${existingMetadata.source}, ${newMetadata.source}`);
        }
        // Update the metadata with anything from updates
        metadata.apiParameters[propertyKey] = newMetadata;
        // Update the stored metadata
        Reflect.defineMetadata(METADATA_KEY, metadata, target);
    };
}
exports.ApiParam = ApiParam;
class ApiParams {
    setFieldsFromHttpRequest(req) {
        const metadata = Reflect.getMetadata(METADATA_KEY, this);
        if (!metadata || !metadata.apiParameters) {
            throw new Bug_1.Bug(`Class ${this.constructor.name} has no @ApiParam annotation.`);
        }
        for (const key of Object.keys(req.params)) {
            this.parseParam(key, req.params[key], 'path', metadata.apiParameters[key]);
        }
        for (const key of Object.keys(req.query)) {
            if (key === '_' || key === 'guest') {
                // we want to ignore the `_` query parameter, used by the frontend to prevent API responses to be cached
                // we also want to ignore the `guest` query parameter, used by the access service to use the API as a guest user
                continue;
            }
            // we convert query parameters in snake_case to camelCase
            const tokens = _.map(key.split('_'));
            let snakeKey = tokens[0];
            for (let i = 1; i < tokens.length; i++) {
                snakeKey += tokens[i].charAt(0).toUpperCase() + tokens[i].slice(1);
            }
            this.parseParam(snakeKey, req.query[key], 'query', metadata.apiParameters[snakeKey]);
        }
        for (const key of Object.keys(req.body)) {
            this.parseParam(key, req.body[key], 'body', metadata.apiParameters[key]);
        }
    }
    parseParam(key, value, source, expected) {
        if (!expected) {
            throw new InvalidParameter_1.InvalidParameter(`Unexpected parameter "${key}" (found in ${source})`);
        }
        if (expected.source !== source) {
            throw new InvalidParameter_1.InvalidParameter(`Parameter "${key}" is expected in ${expected.source} (found in ${source})`);
        }
        // apply the parser if it is defined
        if (expected.parser) {
            try {
                value = expected.parser(value, key);
            }
            catch (e) {
                throw new InvalidParameter_1.InvalidParameter(`Parser of ${source} parameter "${key}" failed: ${e.message}`);
            }
        }
        // Not changing the value when it is undefined allows to preserve the default field values
        // defined at the field initialization (e.g. `public foo: number = 12;`).
        if (value === undefined) {
            return;
        }
        // @ts-ignore we know key exists because it's an expected api param
        this[key] = value;
    }
    fromRequest(req) {
        this.setFieldsFromHttpRequest(req);
        this.validate();
        return this;
    }
    validate() {
        // policy is inclusive because we don't want to validate additional
        // fields that are set internally and not from an API request
        Utils.check.properties(this.constructor.name, this, this.getParamsDefinition());
    }
}
exports.ApiParams = ApiParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpUGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL21vZGVscy9wYXJhbWV0ZXJzL2FwaVBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBRUgsZ0JBQWdCO0FBQ2hCLDRCQUE0QjtBQUM1Qiw0QkFBMEI7QUFHMUIsV0FBVztBQUNYLDRDQUE2QztBQUM3QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULHVDQUFrQztBQUNsQyxpRUFBNEQ7QUFFNUQsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFrQnBEOztHQUVHO0FBQ0gsU0FBZ0IsUUFBUSxDQUN0QixTQUF5QixNQUFNLEVBQy9CLE1BQXVCO0lBRXZCLE9BQU8sQ0FBQyxNQUFjLEVBQUUsV0FBbUIsRUFBRSxFQUFFO1FBQzdDLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRTFDLGdEQUFnRDtRQUNoRCxJQUFJLENBQUMsQ0FBQyxNQUFNLFlBQVksU0FBUyxDQUFDLEVBQUU7WUFDbEMsTUFBTSxJQUFJLFNBQUcsQ0FDWCxlQUFlLFFBQVEsQ0FBQyxJQUFJLHdDQUMxQixTQUFTLENBQUMsSUFDWixLQUFLLFNBQVMsSUFBSSxXQUFXLEdBQUcsQ0FDakMsQ0FBQztTQUNIO1FBRUQsZ0VBQWdFO1FBQ2hFLHNGQUFzRjtRQUN0Riw4Q0FBOEM7UUFDOUMsTUFBTSxRQUFRLEdBQW9CLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFFL0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUU7WUFDM0IsUUFBUSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7U0FDN0I7UUFFRCxNQUFNLFdBQVcsR0FBRztZQUNsQixNQUFNLEVBQUUsTUFBTTtZQUNkLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztRQUVGLE1BQU0sZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM3RCxJQUFJLGdCQUFnQixLQUFLLFNBQVMsRUFBRTtZQUNsQyxNQUFNLElBQUksU0FBRyxDQUNYLDREQUE0RCxTQUFTLElBQUksV0FBVyxLQUNsRixnQkFBZ0IsQ0FBQyxNQUNuQixLQUFLLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FDMUIsQ0FBQztTQUNIO1FBRUQsaURBQWlEO1FBQ2pELFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDO1FBRWxELDZCQUE2QjtRQUM3QixPQUFPLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDekQsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQTdDRCw0QkE2Q0M7QUFFRCxNQUFzQixTQUFTO0lBQ3JCLHdCQUF3QixDQUFDLEdBQW9CO1FBQ25ELE1BQU0sUUFBUSxHQUFvQixPQUFPLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUxRSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRTtZQUN4QyxNQUFNLElBQUksU0FBRyxDQUFDLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLCtCQUErQixDQUFDLENBQUM7U0FDOUU7UUFFRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUM1RTtRQUNELEtBQUssTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDeEMsSUFBSSxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxPQUFPLEVBQUU7Z0JBQ2xDLHdHQUF3RztnQkFDeEcsZ0hBQWdIO2dCQUNoSCxTQUFTO2FBQ1Y7WUFFRCx5REFBeUQ7WUFDekQsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDckMsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN0QyxRQUFRLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BFO1lBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1NBQ3RGO1FBQ0QsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN2QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDMUU7SUFDSCxDQUFDO0lBRU8sVUFBVSxDQUNoQixHQUFXLEVBQ1gsS0FBYyxFQUNkLE1BQXNCLEVBQ3RCLFFBQW9DO1FBRXBDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDYixNQUFNLElBQUksbUNBQWdCLENBQUMseUJBQXlCLEdBQUcsZUFBZSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQ2xGO1FBQ0QsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUM5QixNQUFNLElBQUksbUNBQWdCLENBQ3hCLGNBQWMsR0FBRyxvQkFBb0IsUUFBUSxDQUFDLE1BQU0sY0FBYyxNQUFNLEdBQUcsQ0FDNUUsQ0FBQztTQUNIO1FBRUQsb0NBQW9DO1FBQ3BDLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRTtZQUNuQixJQUFJO2dCQUNGLEtBQUssR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQzthQUNyQztZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE1BQU0sSUFBSSxtQ0FBZ0IsQ0FBQyxhQUFhLE1BQU0sZUFBZSxHQUFHLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDM0Y7U0FDRjtRQUVELDBGQUEwRjtRQUMxRix5RUFBeUU7UUFDekUsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3ZCLE9BQU87U0FDUjtRQUVELG1FQUFtRTtRQUNuRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0lBQ3BCLENBQUM7SUFFTSxXQUFXLENBQUMsR0FBb0I7UUFDckMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUVoQixPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFJTyxRQUFRO1FBQ2QsbUVBQW1FO1FBQ25FLDZEQUE2RDtRQUM3RCxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQztJQUNsRixDQUFDO0NBQ0Y7QUFoRkQsOEJBZ0ZDIn0=