"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-22.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const _ = require("lodash");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
// locals
const apiParams_1 = require("./apiParams");
const dataSourceParams_1 = require("./dataSourceParams");
var GraphQuerySharingMode;
(function (GraphQuerySharingMode) {
    GraphQuerySharingMode["PRIVATE"] = "private";
    GraphQuerySharingMode["SOURCE"] = "source";
    GraphQuerySharingMode["GROUPS"] = "groups";
})(GraphQuerySharingMode = exports.GraphQuerySharingMode || (exports.GraphQuerySharingMode = {}));
var GraphQueryDialect;
(function (GraphQueryDialect) {
    GraphQueryDialect["CYPHER"] = "cypher";
    GraphQueryDialect["GREMLIN"] = "gremlin";
    GraphQueryDialect["SPARQL"] = "sparql";
})(GraphQueryDialect = exports.GraphQueryDialect || (exports.GraphQueryDialect = {}));
var GraphQueryType;
(function (GraphQueryType) {
    GraphQueryType["STATIC"] = "static";
    GraphQueryType["TEMPLATE"] = "template";
})(GraphQueryType = exports.GraphQueryType || (exports.GraphQueryType = {}));
const CREATE_UPDATE_PARAMS_DEFINITION = (onCreate) => {
    const paramsDefinition = {
        name: { required: onCreate, check: ['string', true, undefined, undefined, 200] },
        content: { required: onCreate, check: 'nonEmpty' },
        dialect: { required: false, values: _.values(GraphQueryDialect) },
        description: { required: false, check: 'string' },
        sharing: { required: onCreate, values: _.values(GraphQuerySharingMode) }
    };
    if (!onCreate) {
        paramsDefinition.id = { required: true, check: 'posInt' };
    }
    return paramsDefinition;
};
/**
 * @apiDefine CreateGraphQueryParams
 *
 * @apiParam {string}                             name               Name of the graph query
 * @apiParam {string}                             content            Content of the graph query
 * @apiParam {string="cypher","gremlin","sparql"} [dialect]          Dialect of the graph query
 * @apiParam {string}                             description        Description of the graph query
 * @apiParam {string="private","source","groups"} sharing            Sharing policy of the graph query
 * @apiParam {number[]}                           [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 */
class CreateGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        const rules = CREATE_UPDATE_PARAMS_DEFINITION(true);
        // if sharing is defined, also sharedWithGroups must be defined
        if (this.sharing === GraphQuerySharingMode.GROUPS) {
            rules.sharedWithGroups = { required: true, arrayItem: { check: 'posInt' } };
        }
        return _.merge(super.getParamsDefinition(), rules);
    }
}
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "name", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "content", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "description", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "sharing", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], CreateGraphQueryParams.prototype, "sharedWithGroups", void 0);
exports.CreateGraphQueryParams = CreateGraphQueryParams;
/**
 * @apiDefine GetGraphQueryParams
 *
 * @apiParam {number} id ID of the graph query
 */
class GetGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            // negative IDs are allowed and refer to builtin queries
            id: { required: true, check: 'number' }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('path', Utils.tryParseNumber.bind(Utils))
], GetGraphQueryParams.prototype, "id", void 0);
exports.GetGraphQueryParams = GetGraphQueryParams;
/**
 * @apiDefine DeleteGraphQueryParams
 *
 * @apiParam {number} id ID of the graph query
 */
class DeleteGraphQueryParams extends GetGraphQueryParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            // negative IDs refer to builtin queries not allowed on delete
            id: { required: true, check: 'posInt' }
        });
    }
}
exports.DeleteGraphQueryParams = DeleteGraphQueryParams;
/**
 * @apiDefine GetAllGraphQueriesParams
 *
 * @apiParam {string="static","template"} [type=static] Type of the graph queries
 */
class GetAllGraphQueriesParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        return _.merge(super.getParamsDefinition(), {
            type: { required: false, values: _.values(GraphQueryType) }
        });
    }
}
__decorate([
    apiParams_1.ApiParam('query')
], GetAllGraphQueriesParams.prototype, "type", void 0);
exports.GetAllGraphQueriesParams = GetAllGraphQueriesParams;
/**
 * @apiDefine UpdateGraphQueryParams
 *
 * @apiParam {number}                             id                 ID of the graph query
 * @apiParam {string}                             [name]             New name of the graph query
 * @apiParam {string}                             [content]          New content of the graph query
 * @apiParam {string="cypher","gremlin","sparql"} [dialect]          New dialect of the graph query
 * @apiParam {string}                             [description]      New description of the graph query
 * @apiParam {string="private","source","groups"} [sharing]          New sharing policy of the graph query
 * @apiParam {number[]}                           [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 */
class UpdateGraphQueryParams extends dataSourceParams_1.DataSourceParams {
    getParamsDefinition() {
        const rules = CREATE_UPDATE_PARAMS_DEFINITION(false);
        // if sharing is defined, also sharedWithGroups must be defined
        if (this.sharing === 'groups') {
            rules.sharedWithGroups = { required: true, arrayItem: { check: 'posInt' } };
        }
        return _.merge(super.getParamsDefinition(), rules);
    }
}
__decorate([
    apiParams_1.ApiParam('path', Utils.tryParsePosInt.bind(Utils))
], UpdateGraphQueryParams.prototype, "id", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "name", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "content", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "dialect", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "description", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "sharing", void 0);
__decorate([
    apiParams_1.ApiParam('body')
], UpdateGraphQueryParams.prototype, "sharedWithGroups", void 0);
exports.UpdateGraphQueryParams = UpdateGraphQueryParams;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeVBhcmFtcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvcGFyYW1ldGVycy9ncmFwaFF1ZXJ5UGFyYW1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7Ozs7Ozs7QUFFSCxnQkFBZ0I7QUFDaEIsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCxzQ0FBdUM7QUFDdkMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLFNBQVM7QUFDVCwyQ0FBZ0U7QUFDaEUseURBQW9EO0FBRXBELElBQVkscUJBSVg7QUFKRCxXQUFZLHFCQUFxQjtJQUMvQiw0Q0FBbUIsQ0FBQTtJQUNuQiwwQ0FBaUIsQ0FBQTtJQUNqQiwwQ0FBaUIsQ0FBQTtBQUNuQixDQUFDLEVBSlcscUJBQXFCLEdBQXJCLDZCQUFxQixLQUFyQiw2QkFBcUIsUUFJaEM7QUFFRCxJQUFZLGlCQUlYO0FBSkQsV0FBWSxpQkFBaUI7SUFDM0Isc0NBQWlCLENBQUE7SUFDakIsd0NBQW1CLENBQUE7SUFDbkIsc0NBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUpXLGlCQUFpQixHQUFqQix5QkFBaUIsS0FBakIseUJBQWlCLFFBSTVCO0FBRUQsSUFBWSxjQUdYO0FBSEQsV0FBWSxjQUFjO0lBQ3hCLG1DQUFpQixDQUFBO0lBQ2pCLHVDQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFIVyxjQUFjLEdBQWQsc0JBQWMsS0FBZCxzQkFBYyxRQUd6QjtBQUVELE1BQU0sK0JBQStCLEdBQUcsQ0FBQyxRQUFpQixFQUFvQixFQUFFO0lBQzlFLE1BQU0sZ0JBQWdCLEdBQXFCO1FBQ3pDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUFDO1FBQzlFLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztRQUNoRCxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUM7UUFDL0QsV0FBVyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1FBQy9DLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsRUFBQztLQUN2RSxDQUFDO0lBRUYsSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUNiLGdCQUFnQixDQUFDLEVBQUUsR0FBRyxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQyxDQUFDO0tBQ3pEO0lBRUQsT0FBTyxnQkFBZ0IsQ0FBQztBQUMxQixDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7O0dBU0c7QUFDSCxNQUFhLHNCQUF1QixTQUFRLG1DQUFnQjtJQW1CaEQsbUJBQW1CO1FBQzNCLE1BQU0sS0FBSyxHQUFHLCtCQUErQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXBELCtEQUErRDtRQUMvRCxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUsscUJBQXFCLENBQUMsTUFBTSxFQUFFO1lBQ2pELEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBQyxFQUFDLENBQUM7U0FDekU7UUFFRCxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckQsQ0FBQztDQUNGO0FBM0JDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7b0RBQ0k7QUFHckI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzt1REFDTztBQUd4QjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO3VEQUNrQjtBQUduQztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDOzJEQUNXO0FBRzVCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7dURBQ3NCO0FBR3ZDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7Z0VBQ2tCO0FBakJyQyx3REE2QkM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBYSxtQkFBb0IsU0FBUSxtQ0FBZ0I7SUFJN0MsbUJBQW1CO1FBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsRUFBRTtZQUMxQyx3REFBd0Q7WUFDeEQsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1NBQ3RDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQVJDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7K0NBQ2hDO0FBRnJCLGtEQVVDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQWEsc0JBQXVCLFNBQVEsbUJBQW1CO0lBQ25ELG1CQUFtQjtRQUMzQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEVBQUU7WUFDMUMsOERBQThEO1lBQzlELEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBQztTQUN0QyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFQRCx3REFPQztBQUlEOzs7O0dBSUc7QUFDSCxNQUFhLHdCQUF5QixTQUFRLG1DQUFnQjtJQUlsRCxtQkFBbUI7UUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxFQUFFO1lBQzFDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUM7U0FDMUQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBUEM7SUFEQyxvQkFBUSxDQUFDLE9BQU8sQ0FBQztzREFDVztBQUYvQiw0REFTQztBQUVEOzs7Ozs7Ozs7O0dBVUc7QUFDSCxNQUFhLHNCQUF1QixTQUFRLG1DQUFnQjtJQXNCaEQsbUJBQW1CO1FBQzNCLE1BQU0sS0FBSyxHQUFHLCtCQUErQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJELCtEQUErRDtRQUMvRCxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBUSxFQUFFO1lBQzdCLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBQyxFQUFDLENBQUM7U0FDekU7UUFFRCxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckQsQ0FBQztDQUNGO0FBOUJDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7a0RBQ2hDO0FBR25CO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7b0RBQ0k7QUFHckI7SUFEQyxvQkFBUSxDQUFDLE1BQU0sQ0FBQzt1REFDTztBQUd4QjtJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDO3VEQUNrQjtBQUduQztJQURDLG9CQUFRLENBQUMsTUFBTSxDQUFDOzJEQUNXO0FBRzVCO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7dURBQ3NCO0FBR3ZDO0lBREMsb0JBQVEsQ0FBQyxNQUFNLENBQUM7Z0VBQ2tCO0FBcEJyQyx3REFnQ0MifQ==