"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-22.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
const graphQueryParams_1 = require("../parameters/graphQueryParams");
// services
const LKE = require("../../services");
const Utils = LKE.getUtils();
var RIGHT_VALUES;
(function (RIGHT_VALUES) {
    RIGHT_VALUES["OWNER"] = "owner";
    RIGHT_VALUES["READ"] = "read";
})(RIGHT_VALUES = exports.RIGHT_VALUES || (exports.RIGHT_VALUES = {}));
/**
 * @apiDefine GraphQueryResponse
 *
 * @apiSuccess {number}                                     id                 ID of the graph query
 * @apiSuccess {string}                                     sourceKey          Key of the data-source
 * @apiSuccess {string}                                     name               Name of the graph query
 * @apiSuccess {string}                                     content            Content of the graph query
 * @apiSuccess {string="cypher","gremlin","sparql"}         dialect            Dialect of the graph query
 * @apiSuccess {string}                                     description        Description of the graph query
 * @apiSuccess {string="private","source","groups"}         sharing            Sharing policy of the graph query
 * @apiSuccess {number[]}                                   [sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 * @apiSuccess {boolean}                                    write              Whether the query may write the database
 * @apiSuccess {string="none","1-node","2-nodes","nodeset"} [graphInput]       Type of inputs to the template query (if `type="template"`)
 * @apiSuccess {boolean}                                    builtin            Whether the query is builtin
 * @apiSuccess {object}                                     [templateFields]   Parsed template fields (if `type="template"`)
 * @apiSuccess {string="static","template"}                 type               Type of the graph query
 * @apiSuccess {string="owner","read"}                      right              Current user's right on the query
 * @apiSuccess {string}                                     createdAt          Creation date in ISO-8601 format
 * @apiSuccess {string}                                     updatedAt          Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
/**
 * @apiDefine GetAllGraphQueriesResponse
 * @apiSuccess {object[]}                                   queries                    Graph queries
 * @apiSuccess {number}                                     queries.id                 ID of the graph query
 * @apiSuccess {string}                                     queries.sourceKey          Key of the data-source
 * @apiSuccess {string}                                     queries.name               Name of the graph query
 * @apiSuccess {string}                                     queries.content            Content of the graph query
 * @apiSuccess {string="cypher","gremlin","sparql"}         queries.dialect            Dialect of the graph query
 * @apiSuccess {string}                                     queries.description        Description of the graph query
 * @apiSuccess {string="private","source","groups"}         queries.sharing            Sharing policy of the graph query
 * @apiSuccess {number[]}                                   queries.[sharedWithGroups] IDs of the groups the graph query is shared with (if `sharing="groups"`)
 * @apiSuccess {boolean}                                    queries.write              Whether the query may write the database
 * @apiSuccess {string="none","1-node","2-nodes","nodeset"} queries.[graphInput]       Type of inputs to the template query (if `type="template"`)
 * @apiSuccess {boolean}                                    queries.builtin            Whether the query is builtin
 * @apiSuccess {object}                                     queries.[templateFields]   Parsed template fields (if `type="template"`)
 * @apiSuccess {string="static","template"}                 queries.type               Type of the graph query
 * @apiSuccess {string="owner","read"}                      queries.right              Current user's right on the query
 * @apiSuccess {string}                                     queries.createdAt          Creation date in ISO-8601 format
 * @apiSuccess {string}                                     queries.updatedAt          Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *
 *   }
 */
class GraphQueryResponse {
    static fromInstance(graphQueryInstance, ownership, isWrite, groupInstances) {
        const graphQuery = graphQueryInstance.toJSON();
        return {
            id: graphQuery.id,
            sourceKey: graphQuery.sourceKey,
            name: graphQuery.name,
            content: graphQuery.content,
            dialect: graphQuery.dialect,
            description: graphQuery.description,
            sharing: graphQuery.sharing,
            sharedWithGroups: Utils.hasValue(groupInstances) ? _.map(groupInstances, 'id') : undefined,
            type: graphQuery.type,
            // fallback to undefined here to avoid returning a null templateFields
            templateFields: graphQuery.templateFields || undefined,
            graphInput: Utils.hasValue(graphQuery.templateFields)
                ? umd_1.QueryTemplateParser.getInputType(graphQuery.templateFields)
                : undefined,
            write: isWrite,
            createdAt: graphQuery.createdAt,
            updatedAt: graphQuery.updatedAt,
            builtin: false,
            right: ownership ? RIGHT_VALUES.OWNER : RIGHT_VALUES.READ
        };
    }
    static fromBuiltin(query) {
        return {
            id: query.id,
            sourceKey: query.sourceKey,
            name: query.name,
            content: query.content,
            dialect: query.dialect,
            description: query.description,
            sharing: graphQueryParams_1.GraphQuerySharingMode.SOURCE,
            type: query.type || graphQueryParams_1.GraphQueryType.STATIC,
            templateFields: query.templateFields,
            graphInput: query.graphInput,
            write: query.write,
            builtin: true,
            right: RIGHT_VALUES.READ
        };
    }
}
exports.GraphQueryResponse = GraphQueryResponse;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeVJlc3BvbnNlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9tb2RlbHMvYXBpUmVzcG9uc2VzL2dyYXBoUXVlcnlSZXNwb25zZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHOztBQUVILGdCQUFnQjtBQUNoQiwrQ0FBeUY7QUFDekYsNEJBQTRCO0FBSTVCLHFFQUl3QztBQUd4QyxXQUFXO0FBQ1gsc0NBQXVDO0FBQ3ZDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixJQUFZLFlBR1g7QUFIRCxXQUFZLFlBQVk7SUFDdEIsK0JBQWUsQ0FBQTtJQUNmLDZCQUFhLENBQUE7QUFDZixDQUFDLEVBSFcsWUFBWSxHQUFaLG9CQUFZLEtBQVosb0JBQVksUUFHdkI7QUEwQkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F5Qkc7QUFFSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXlCRztBQUNILE1BQWEsa0JBQWtCO0lBQ3RCLE1BQU0sQ0FBQyxZQUFZLENBQ3hCLGtCQUFzQyxFQUN0QyxTQUFrQixFQUNsQixPQUFnQixFQUNoQixjQUFnQztRQUVoQyxNQUFNLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMvQyxPQUFPO1lBQ0wsRUFBRSxFQUFFLFVBQVUsQ0FBQyxFQUFFO1lBQ2pCLFNBQVMsRUFBRSxVQUFVLENBQUMsU0FBUztZQUMvQixJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUk7WUFDckIsT0FBTyxFQUFFLFVBQVUsQ0FBQyxPQUFPO1lBQzNCLE9BQU8sRUFBRSxVQUFVLENBQUMsT0FBTztZQUMzQixXQUFXLEVBQUUsVUFBVSxDQUFDLFdBQVc7WUFDbkMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxPQUFPO1lBQzNCLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQzFGLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTtZQUNyQixzRUFBc0U7WUFDdEUsY0FBYyxFQUFFLFVBQVUsQ0FBQyxjQUFjLElBQUksU0FBUztZQUN0RCxVQUFVLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO2dCQUNuRCxDQUFDLENBQUMseUJBQW1CLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUM7Z0JBQzdELENBQUMsQ0FBQyxTQUFTO1lBQ2IsS0FBSyxFQUFFLE9BQU87WUFDZCxTQUFTLEVBQUUsVUFBVSxDQUFDLFNBQVM7WUFDL0IsU0FBUyxFQUFFLFVBQVUsQ0FBQyxTQUFTO1lBQy9CLE9BQU8sRUFBRSxLQUFLO1lBQ2QsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUk7U0FDMUQsQ0FBQztJQUNKLENBQUM7SUFFTSxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQW1CO1FBQzNDLE9BQU87WUFDTCxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDWixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7WUFDMUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO1lBQ2hCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87WUFDdEIsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO1lBQzlCLE9BQU8sRUFBRSx3Q0FBcUIsQ0FBQyxNQUFNO1lBQ3JDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxJQUFJLGlDQUFjLENBQUMsTUFBTTtZQUN6QyxjQUFjLEVBQUUsS0FBSyxDQUFDLGNBQWM7WUFDcEMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO1lBQzVCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztZQUNsQixPQUFPLEVBQUUsSUFBSTtZQUNiLEtBQUssRUFBRSxZQUFZLENBQUMsSUFBSTtTQUN6QixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBaERELGdEQWdEQyJ9