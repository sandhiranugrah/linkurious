"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @apiDefine SimpleSchemaResponse
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *     "nodeCategories": [
 *       "Movie",
 *       "Person"
 *     ],
 *     "edgeTypes": [
 *       "ACTED_IN",
 *       "DIRECTED"
 *     ],
 *     "nodeProperties": [
 *       "title",
 *       "name",
 *       "released"
 *     ],
 *     "edgeProperties": [
 *       "role"
 *     ]
 *   }
 */
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2ltcGxlU2NoZW1hUmVzcG9uc2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvbW9kZWxzL2FwaVJlc3BvbnNlcy9zaW1wbGVTY2hlbWFSZXNwb25zZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBU0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBdUJHIn0=