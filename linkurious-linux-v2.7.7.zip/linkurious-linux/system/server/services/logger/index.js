/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
'use strict';
// external libs
const fs = require('fs-extra');
// our libs
const Log4JS = require('../../../lib/log4js');
// services
const LKE = require('../index');
// locals
const { LkError } = require('../../models/errors/LkError');
class LoggerService extends Log4JS {
    constructor() {
        // read logger configuration
        let config = {};
        try {
            config = fs.readJsonSync(LKE.dataFile('config/logger.json'));
        }
        catch (e) {
            console.log('Using default logger configuration');
            config = require('./logger.json');
        }
        super({
            projectRoot: LKE.systemFile(''),
            logDirPath: LKE.dataFile('logs'),
            logFileName: 'linkurious',
            logLevel: config.logLevel,
            customLevels: config.customLevels,
            addPrefix: config.addPrefix
        });
    }
    error() {
        const newArgs = [];
        for (let i = 0; i < arguments.length; ++i) {
            let arg = arguments[i];
            /**
             * for each argument that is an error with a stack,
             * we add the stack trace as a string array along
             * the error in the logged object
             */
            if (arg && arg instanceof LkError && !arg.isTechnical()) {
                // non technical LkError
                arg = arg.message;
            }
            else if (typeof arg === 'object' && arg instanceof Error && arg.stack) {
                // raw error or technical LkError
                // clone the error so we don't modify the original argument
                arg = {
                    key: arg instanceof LkError ? arg.key : 'critical',
                    message: arg.message,
                    trace: arg.stack.split(/\s*\n\s*/)
                };
                // remove the first line of the stack trace: it repeats the error name etc.
                if (arg.trace.length > 0) {
                    arg.trace = arg.trace.splice(1);
                }
            }
            newArgs.push(arg);
        }
        super.error.apply(this, newArgs);
    }
}
module.exports = new LoggerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvbG9nZ2VyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFL0IsV0FBVztBQUNYLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBRTlDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFaEMsU0FBUztBQUNULE1BQU0sRUFBQyxPQUFPLEVBQUMsR0FBRyxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQztBQUV6RCxNQUFNLGFBQWMsU0FBUSxNQUFNO0lBQ2hDO1FBQ0UsNEJBQTRCO1FBQzVCLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJO1lBQ0YsTUFBTSxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7U0FDOUQ7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztZQUNsRCxNQUFNLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1NBQ25DO1FBRUQsS0FBSyxDQUFDO1lBQ0osV0FBVyxFQUFFLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQy9CLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUNoQyxXQUFXLEVBQUUsWUFBWTtZQUN6QixRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVE7WUFDekIsWUFBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO1lBQ2pDLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztTQUM1QixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsS0FBSztRQUNILE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNuQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN6QyxJQUFJLEdBQUcsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkI7Ozs7ZUFJRztZQUNILElBQUksR0FBRyxJQUFJLEdBQUcsWUFBWSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3ZELHdCQUF3QjtnQkFDeEIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUM7YUFDbkI7aUJBQU0sSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksR0FBRyxZQUFZLEtBQUssSUFBSSxHQUFHLENBQUMsS0FBSyxFQUFFO2dCQUN2RSxpQ0FBaUM7Z0JBRWpDLDJEQUEyRDtnQkFDM0QsR0FBRyxHQUFHO29CQUNKLEdBQUcsRUFBRSxHQUFHLFlBQVksT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFVO29CQUNsRCxPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU87b0JBQ3BCLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7aUJBQ25DLENBQUM7Z0JBQ0YsMkVBQTJFO2dCQUMzRSxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDeEIsR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDakM7YUFDRjtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkI7UUFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDbkMsQ0FBQztDQUVGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGFBQWEsRUFBRSxDQUFDIn0=