"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-31.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// locals
const graphQueryParams_1 = require("../../models/parameters/graphQueryParams");
exports.default = {
    // We use a getter here so that we can easily mock the builtin queries in the tests.
    get all() {
        return [
            {
                key: 'Find Shortest Path Neo4j',
                name: 'Find Shortest Path',
                content: 'MATCH (a), (b), p = allShortestPaths((a)-' +
                    '[*..{{"Maximum path length":number:{"default": 4, "min": 1, "max": 10}}}]-(b)) ' +
                    `WHERE id(a) = {{"Source":node}} AND id(b) = {{"Target":node}} RETURN p ` +
                    `LIMIT {{"Maximum number of paths":number:{"default": 5, "min": 1, "max": 50}}}`,
                dialect: graphQueryParams_1.GraphQueryDialect.CYPHER,
                description: 'Find the shortest path between two nodes.',
                compatibleDAOs: [
                    {
                        graphDAO: 'neo4j'
                    }
                ]
            },
            {
                key: 'Expand non-leaf nodes Neo4j',
                name: 'Expand non-leaf nodes',
                content: 'MATCH (a)-[]-(b)-[]-(c) WHERE id(a) = {{"Source":node}} and a <> c RETURN distinct b',
                dialect: graphQueryParams_1.GraphQueryDialect.CYPHER,
                description: 'Expand non-leaf nodes.',
                compatibleDAOs: [
                    {
                        graphDAO: 'neo4j'
                    }
                ]
            }
        ];
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVpbHRpblF1ZXJpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZ3JhcGhRdWVyeS9idWlsdGluUXVlcmllcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7O0FBS0gsU0FBUztBQUNULCtFQUEyRjtBQTRCM0Ysa0JBQWU7SUFDYixvRkFBb0Y7SUFDcEYsSUFBSSxHQUFHO1FBQ0wsT0FBTztZQUNMO2dCQUNFLEdBQUcsRUFBRSwwQkFBMEI7Z0JBQy9CLElBQUksRUFBRSxvQkFBb0I7Z0JBQzFCLE9BQU8sRUFDTCwyQ0FBMkM7b0JBQzNDLGlGQUFpRjtvQkFDakYseUVBQXlFO29CQUN6RSxnRkFBZ0Y7Z0JBQ2xGLE9BQU8sRUFBRSxvQ0FBaUIsQ0FBQyxNQUFNO2dCQUNqQyxXQUFXLEVBQUUsMkNBQTJDO2dCQUN4RCxjQUFjLEVBQUU7b0JBQ2Q7d0JBQ0UsUUFBUSxFQUFFLE9BQU87cUJBQ2xCO2lCQUNGO2FBQ0Y7WUFDRDtnQkFDRSxHQUFHLEVBQUUsNkJBQTZCO2dCQUNsQyxJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixPQUFPLEVBQ0wsc0ZBQXNGO2dCQUN4RixPQUFPLEVBQUUsb0NBQWlCLENBQUMsTUFBTTtnQkFDakMsV0FBVyxFQUFFLHdCQUF3QjtnQkFDckMsY0FBYyxFQUFFO29CQUNkO3dCQUNFLFFBQVEsRUFBRSxPQUFPO3FCQUNsQjtpQkFDRjthQUNGO1NBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRixDQUFDIn0=