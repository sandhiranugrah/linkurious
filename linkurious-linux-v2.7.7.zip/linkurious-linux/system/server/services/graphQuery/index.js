"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-23.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// external libs
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
// locals
const graphQueryDAO_1 = require("../../dao/sql/graphQueryDAO");
const groupDAO_1 = require("../../dao/sql/groupDAO");
const graphQueryResponses_1 = require("../../models/apiResponses/graphQueryResponses");
const Bug_1 = require("../../models/errors/Bug");
const CantReadError_1 = require("../../models/errors/CantReadError");
const MalformedQueryTemplate_1 = require("../../models/errors/MalformedQueryTemplate");
const NotFoundError_1 = require("../../models/errors/NotFoundError");
const NotOwnerError_1 = require("../../models/errors/NotOwnerError");
const graphQueryParams_1 = require("../../models/parameters/graphQueryParams");
const builtinQueries_1 = require("./builtinQueries");
// services
const LKE = require("../index");
const Access = LKE.getAccess();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Data = LKE.getData();
const DataProxy = LKE.getDataProxy();
const Db = LKE.getSqlDb();
// TODO #1507 add tests for shared queries with groups
// TODO #1569 Add BuiltQueries unit tests
class GraphQueryService {
    constructor() {
        this.graphQueryDAO = new graphQueryDAO_1.GraphQueryDAO();
        this.groupDAO = new groupDAO_1.GroupDAO();
        this.queryTemplateParser = new umd_1.QueryTemplateParser((validationMessage, highlight) => {
            throw new MalformedQueryTemplate_1.MalformedQueryTemplate(validationMessage, highlight);
        }, (bugMessage) => {
            throw new Bug_1.Bug(bugMessage);
        });
        this.builtinQueryCache = new Map();
    }
    /**
     * Create a graph query for user.
     */
    createGraphQuery(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentUser = yield Access.checkAuth(user, 'savedGraphQuery.create');
            const source = Data.resolveSource(params.dataSource);
            const dialect = _.get(source.graph.features, 'dialects.0');
            const isWrite = source.graph.isWrite(params.content);
            if (!isWrite) {
                yield currentUser.hasAction('rawReadQuery', params.dataSource);
            }
            else {
                yield currentUser.hasAction('rawWriteQuery', params.dataSource);
            }
            let queryType = graphQueryParams_1.GraphQueryType.STATIC;
            let templateFields;
            if (umd_1.QueryTemplateParser.isTemplate(params.content)) {
                queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
                templateFields = this.queryTemplateParser.parse(params.content);
            }
            const graphQueryInstance = yield this.graphQueryDAO.createGraphQuery({
                sourceKey: params.dataSource,
                name: params.name,
                content: params.content,
                dialect: dialect,
                description: params.description,
                sharing: params.sharing,
                type: queryType,
                templateFields: templateFields
            }, currentUser.id);
            let groupInstances;
            if (Utils.hasValue(params.sharedWithGroups)) {
                groupInstances = yield this.groupDAO.getGroups(params.dataSource, params.sharedWithGroups);
                Utils.checkMissing('group', params.sharedWithGroups, groupInstances);
                yield this.graphQueryDAO.shareGraphQueryWithGroups(graphQueryInstance, groupInstances);
            }
            return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, true, isWrite, groupInstances);
        });
    }
    /**
     * Get all the graph queries owned by user or shared with it.
     */
    getAllGraphQueries(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentUser = yield Access.checkAuth(user, 'savedGraphQuery.read', true);
            yield currentUser.hasAction('runQuery', params.dataSource);
            const source = Data.resolveSource(params.dataSource);
            const graphQueriesFromSource = yield this.graphQueryDAO.getGraphQueriesSharedWithSource(params.dataSource);
            const graphQueriesOwned = yield this.graphQueryDAO.getGraphQueriesOwnedByUser(params.dataSource, currentUser.id);
            const graphQueriesFromGroups = yield this.graphQueryDAO.getGraphQueriesSharedWithGroups(params.dataSource, _.map(currentUser.groups, 'id'));
            let readableGraphQueries = _.unionBy(graphQueriesOwned, graphQueriesFromSource, graphQueriesFromGroups, 'id');
            let builtinGraphQueries = this.getBuiltinQueries(params.dataSource);
            if (Utils.hasValue(params.type)) {
                readableGraphQueries = _.filter(readableGraphQueries, query => query.type === params.type);
                builtinGraphQueries = _.filter(builtinGraphQueries, query => query.type === params.type);
            }
            return Promise.all(_.map(readableGraphQueries, (graphQueryInstance) => __awaiter(this, void 0, void 0, function* () {
                const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
                let groupInstances;
                if (yield this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) {
                    groupInstances = yield this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
                }
                const isWrite = source.graph.isWrite(graphQueryInstance.content);
                return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, isOwner, isWrite, groupInstances);
            }))).then(savedGraphQueries => _.concat(savedGraphQueries, builtinGraphQueries));
        });
    }
    /**
     * Generate the negative hashCode of a string.
     */
    negativeHashCode(s) {
        let hash = 0;
        if (s.length === 0) {
            return hash;
        }
        for (let i = 0; i < s.length; i++) {
            const char = s.charCodeAt(i);
            // tslint:disable-next-line:no-bitwise
            hash = (hash << 5) - hash + char;
            // convert to 32bit integer
            // tslint:disable-next-line:no-bitwise
            hash = hash & hash;
        }
        return hash < 0 ? hash : -hash;
    }
    /**
     * Return true if `version` is between `minVersion` and `maxVersion`.
     * Returns true if `version` is `[unknown]`
     *
     * @param version    semVer
     * @param minVersion earliest semVer
     * @param maxVersion latest semVer
     */
    matchVersion(version, minVersion, maxVersion) {
        if (version === '[unknown]') {
            return true;
        }
        let matchMinVersion = true;
        if (minVersion) {
            matchMinVersion = Utils.compareSemVer(version, minVersion) >= 0;
        }
        let matchMaxVersion = true;
        if (maxVersion) {
            matchMaxVersion = Utils.compareSemVer(version, maxVersion) <= 0;
        }
        return matchMinVersion && matchMaxVersion;
    }
    /**
     * Get all builtin queries for a given source.
     */
    getBuiltinQueries(sourceKey) {
        const cachedQueries = this.builtinQueryCache.get(sourceKey);
        if (Utils.hasValue(cachedQueries)) {
            return cachedQueries;
        }
        const source = Data.resolveSource(sourceKey);
        const computedIds = new Set();
        const compatibleQueries = builtinQueries_1.default.all.filter(builtinQuery => {
            return _.some(builtinQuery.compatibleDAOs, ({ graphDAO, firstVersion, lastVersion }) => {
                return (graphDAO === source.graph.vendor &&
                    this.matchVersion(source.graphVersion, firstVersion, lastVersion));
            });
        });
        const builtinGraphQueries = compatibleQueries.map((query) => {
            const type = umd_1.QueryTemplateParser.isTemplate(query.content)
                ? graphQueryParams_1.GraphQueryType.TEMPLATE
                : graphQueryParams_1.GraphQueryType.STATIC;
            const builtinQuery = {
                // we compute negative ids from the key to avoid conflicts with regular queries that have positive ids.
                id: this.negativeHashCode(query.key),
                sourceKey: sourceKey,
                type: type,
                write: source.graph.isWrite(query.content),
                name: query.name,
                content: query.content,
                dialect: query.dialect,
                description: query.description
            };
            if (computedIds.has(builtinQuery.id)) {
                Log.warn(`A builtin query with id ${builtinQuery.id} was already added.`);
            }
            computedIds.add(builtinQuery.id);
            if (type === graphQueryParams_1.GraphQueryType.TEMPLATE) {
                builtinQuery.templateFields = this.queryTemplateParser.parse(query.content);
                builtinQuery.graphInput = umd_1.QueryTemplateParser.getInputType(builtinQuery.templateFields);
            }
            return graphQueryResponses_1.GraphQueryResponse.fromBuiltin(builtinQuery);
        });
        this.builtinQueryCache.set(sourceKey, builtinGraphQueries);
        return builtinGraphQueries;
    }
    /**
     * Find a builtin query by Id.
     */
    findBuiltinQueryById(sourceKey, id) {
        return _.find(this.getBuiltinQueries(sourceKey), ['id', id]);
    }
    /**
     * Get a graph query owned by user or shared with it.
     */
    getGraphQuery(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentUser = yield Access.checkAuth(user, 'savedGraphQuery.read', true);
            yield currentUser.hasAction('runQuery', params.dataSource);
            const source = Data.resolveSource(params.dataSource);
            const builtinQuery = this.findBuiltinQueryById(params.dataSource, params.id);
            if (Utils.hasValue(builtinQuery)) {
                return builtinQuery;
            }
            const graphQueryInstance = yield this.graphQueryDAO.getGraphQuery(params.id);
            if (Utils.noValue(graphQueryInstance)) {
                throw new NotFoundError_1.NotFoundError('query', params.id);
            }
            const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
            const isSharedWithDataSource = this.graphQueryDAO.isSharedWithDataSource(graphQueryInstance, params.dataSource);
            const isSharedWithGroups = yield this.graphQueryDAO.isSharedWithGroups(graphQueryInstance, _.map(currentUser.groups, 'id'));
            if (!isOwner && !isSharedWithDataSource && !isSharedWithGroups) {
                throw new CantReadError_1.CantReadError('query', params.id, currentUser.id);
            }
            let groupInstances;
            if (yield this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) {
                groupInstances = yield this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
            }
            const isWrite = source.graph.isWrite(graphQueryInstance.content);
            return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, isOwner, isWrite, groupInstances);
        });
    }
    /**
     * Get all the nodes and edges matching the given saved graph query by ID.
     */
    runGraphQueryById(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentUser = yield Access.checkAuth(user, 'graph.runQuery', true);
            const query = yield this.getGraphQuery(params, currentUser);
            return DataProxy.runGraphQuery(_.merge(params, { query: query.content }), currentUser);
        });
    }
    /**
     * Delete a graph query owned by user.
     */
    deleteGraphQuery(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentUser = yield Access.checkAuth(user, 'savedGraphQuery.delete');
            const graphQueryInstance = yield this.graphQueryDAO.getGraphQuery(params.id);
            if (Utils.noValue(graphQueryInstance)) {
                throw new NotFoundError_1.NotFoundError('query', params.id);
            }
            const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
            if (!isOwner) {
                throw new NotOwnerError_1.NotOwnerError('query', params.id, currentUser.id);
            }
            return this.graphQueryDAO.deleteGraphQuery(graphQueryInstance);
        });
    }
    /**
     * Update a graph query owned by user.
     */
    updateGraphQuery(params, user) {
        return __awaiter(this, void 0, void 0, function* () {
            // 1) Check if the user is authenticated, and, if an application
            // acts on behalf of the user, if it has the correct API right
            const currentUser = yield Access.checkAuth(user, 'savedGraphQuery.edit');
            const source = Data.resolveSource(params.dataSource);
            // 2) Retrieve the query
            let graphQueryInstance = yield this.graphQueryDAO.getGraphQuery(params.id);
            if (Utils.noValue(graphQueryInstance)) {
                throw new NotFoundError_1.NotFoundError('query', params.id);
            }
            const updatedFields = {
                name: params.name,
                content: params.content,
                dialect: params.dialect,
                description: params.description,
                sharing: params.sharing
            };
            // 3) If the content has changed, re-parse the query
            if (Utils.hasValue(params.content)) {
                const isNewWrite = source.graph.isWrite(params.content);
                if (!isNewWrite) {
                    yield currentUser.hasAction('rawReadQuery', params.dataSource);
                }
                else {
                    yield currentUser.hasAction('rawWriteQuery', params.dataSource);
                }
                let queryType = graphQueryParams_1.GraphQueryType.STATIC;
                let templateFields;
                if (umd_1.QueryTemplateParser.isTemplate(params.content)) {
                    queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
                    templateFields = this.queryTemplateParser.parse(params.content);
                }
                updatedFields.type = queryType;
                updatedFields.templateFields = templateFields;
            }
            // 4) Check if the user is the owner of the query
            const isOwner = this.graphQueryDAO.isOwner(graphQueryInstance, currentUser.id);
            if (!isOwner) {
                throw new NotOwnerError_1.NotOwnerError('query', params.id, currentUser.id);
            }
            // 5) Update the query <-> groups associations
            let groupInstances;
            if (Utils.hasValue(params.sharing)) {
                yield this.graphQueryDAO.unshareGraphQueryWithAllGroups(graphQueryInstance);
                if (Utils.hasValue(params.sharedWithGroups)) {
                    groupInstances = yield this.groupDAO.getGroups(params.dataSource, params.sharedWithGroups);
                    Utils.checkMissing('group', params.sharedWithGroups, groupInstances);
                    yield this.graphQueryDAO.shareGraphQueryWithGroups(graphQueryInstance, groupInstances);
                }
            }
            // 6) Update the query attributes
            graphQueryInstance = yield this.graphQueryDAO.updateGraphQuery(graphQueryInstance, updatedFields);
            // 7) Get the groups which the graph query is shared with
            if ((yield this.graphQueryDAO.isSharedWithGroups(graphQueryInstance)) &&
                Utils.noValue(groupInstances)) {
                groupInstances = yield this.graphQueryDAO.getGraphQueryGroups(graphQueryInstance);
            }
            const isWrite = source.graph.isWrite(graphQueryInstance.content);
            // 8) Return a GraphQueryResponse
            return graphQueryResponses_1.GraphQueryResponse.fromInstance(graphQueryInstance, true, isWrite, groupInstances);
        });
    }
    /**
     * Duplicate legacy static queries to all the data-sources where the dialect matches.
     * A legacy static query is a query that, originally, was saved for multiple data-sources.
     */
    migrateRawQueries(dataSourceStates) {
        // TODO move this code in the migration service
        // 1) find all configured data-sources
        const sourceStates = dataSourceStates.filter(source => Utils.hasValue(source.key));
        // 2) find all graph queries with no source key (legacy static queries)
        return Promise.resolve().then(() => {
            return (Db.models.graphQuery
                .findAll({ where: { sourceKey: '*' } })
                .then(staticQueries => {
                // compute the list of source keys for every dialect
                // @ts-ignore
                const sourcesByDialect = _.groupBy(sourceStates, source => source.features.dialects[0]);
                // 3) duplicate the GraphQuery instance for each data-source that supports its dialect
                return Bluebird.map(staticQueries, query => {
                    const sourcesWithQueryDialect = sourcesByDialect[query.get('dialect')];
                    // if the list is empty, duplicate the GraphQuery for every known sourceKey
                    if (Utils.noValue(sourcesWithQueryDialect)) {
                        // @ts-ignore
                        return this._migrateQuery(query, sourceStates.map(source => source.key));
                    }
                    // duplicate the query for each sourceKey that supports it's dialect
                    // @ts-ignore
                    return this._migrateQuery(query, sourcesWithQueryDialect.map(source => source.key));
                }).then(duplicates => _.flatten(duplicates));
            })
                // @ts-ignore
                .then(duplicatedQueries => {
                if (duplicatedQueries.length > 0) {
                    return Db.models.graphQuery.bulkCreate(duplicatedQueries);
                }
            })
                .return());
        });
    }
    /**
     * @param {GraphQueryInstance} query
     * @param {string[]}           sourceKeys
     */
    _migrateQuery(query, sourceKeys) {
        const newGraphQueries = sourceKeys.map(key => _.merge({
            sourceKey: key,
            name: '',
            type: graphQueryParams_1.GraphQueryType.STATIC,
            sharing: graphQueryParams_1.GraphQuerySharingMode.PRIVATE
        }, _.pick(query, ['name', 'content', 'dialect', 'userId'])));
        return query.destroy().return(newGraphQueries);
    }
    migrateQueriesToV2() {
        // TODO move this code in the migration service
        return Promise.resolve().then(() => {
            return Db.models.graphQuery
                .findAll({ where: { version: 1 } })
                .map((query) => {
                try {
                    let queryType = graphQueryParams_1.GraphQueryType.STATIC;
                    let templateFields;
                    if (umd_1.QueryTemplateParser.isTemplate(query.content)) {
                        queryType = graphQueryParams_1.GraphQueryType.TEMPLATE;
                        templateFields = this.queryTemplateParser.parse(query.content);
                    }
                    query.type = queryType;
                    query.templateFields = templateFields;
                    query.version = 2;
                    return query.save().return();
                }
                catch (e) {
                    Log.warn('Failed to migrate query #' +
                        query.id +
                        ': ' +
                        query.content +
                        ' . Reason: ' +
                        e.message);
                }
                return Bluebird.resolve();
            }, { concurrency: 1 })
                .return();
        });
    }
}
module.exports = new GraphQueryService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZ3JhcGhRdWVyeS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7OztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsK0NBQTBEO0FBQzFELDRCQUE0QjtBQUU1QixTQUFTO0FBQ1QsK0RBQTBEO0FBQzFELHFEQUFnRDtBQUNoRCx1RkFHdUQ7QUFFdkQsaURBQTRDO0FBQzVDLHFFQUFnRTtBQUNoRSx1RkFBa0Y7QUFDbEYscUVBQWdFO0FBQ2hFLHFFQUFnRTtBQUVoRSwrRUFPa0Q7QUFHbEQscURBQXNGO0FBRXRGLFdBQVc7QUFDWCxnQ0FBaUM7QUFDakMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUMzQixNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDckMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTFCLHNEQUFzRDtBQUN0RCx5Q0FBeUM7QUFFekMsTUFBTSxpQkFBaUI7SUFNckI7UUFDRSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksNkJBQWEsRUFBRSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxtQkFBUSxFQUFFLENBQUM7UUFFL0IsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUkseUJBQW1CLENBQ2hELENBQUMsaUJBQXlCLEVBQUUsU0FBMEIsRUFBRSxFQUFFO1lBQ3hELE1BQU0sSUFBSSwrQ0FBc0IsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUNqRSxDQUFDLEVBQ0QsQ0FBQyxVQUFrQixFQUFFLEVBQUU7WUFDckIsTUFBTSxJQUFJLFNBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsRUFBaUMsQ0FBQztJQUNwRSxDQUFDO0lBRUQ7O09BRUc7SUFDVSxnQkFBZ0IsQ0FDM0IsTUFBOEIsRUFDOUIsSUFBa0I7O1lBRWxCLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztZQUUzRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVyRCxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQzNELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVyRCxJQUFJLENBQUMsT0FBTyxFQUFFO2dCQUNaLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ2hFO2lCQUFNO2dCQUNMLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ2pFO1lBRUQsSUFBSSxTQUFTLEdBQW1CLGlDQUFjLENBQUMsTUFBTSxDQUFDO1lBQ3RELElBQUksY0FBYyxDQUFDO1lBQ25CLElBQUkseUJBQW1CLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDbEQsU0FBUyxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO2dCQUNwQyxjQUFjLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDakU7WUFFRCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FDbEU7Z0JBQ0UsU0FBUyxFQUFFLE1BQU0sQ0FBQyxVQUFVO2dCQUM1QixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7Z0JBQ2pCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztnQkFDdkIsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztnQkFDL0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO2dCQUN2QixJQUFJLEVBQUUsU0FBUztnQkFDZixjQUFjLEVBQUUsY0FBYzthQUMvQixFQUNELFdBQVcsQ0FBQyxFQUFFLENBQ2YsQ0FBQztZQUVGLElBQUksY0FBYyxDQUFDO1lBQ25CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDM0MsY0FBYyxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFDM0YsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO2dCQUVyRSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMseUJBQXlCLENBQUMsa0JBQWtCLEVBQUUsY0FBYyxDQUFDLENBQUM7YUFDeEY7WUFFRCxPQUFPLHdDQUFrQixDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzVGLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1Usa0JBQWtCLENBQzdCLE1BQWdDLEVBQ2hDLElBQWtCOztZQUVsQixNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHNCQUFzQixFQUFFLElBQUksQ0FBQyxDQUFDO1lBRS9FLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRTNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXJELE1BQU0sc0JBQXNCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLCtCQUErQixDQUNyRixNQUFNLENBQUMsVUFBVSxDQUNsQixDQUFDO1lBRUYsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsMEJBQTBCLENBQzNFLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLFdBQVcsQ0FBQyxFQUFFLENBQ2YsQ0FBQztZQUVGLE1BQU0sc0JBQXNCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLCtCQUErQixDQUNyRixNQUFNLENBQUMsVUFBVSxFQUNqQixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQ2hDLENBQUM7WUFFRixJQUFJLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQ2xDLGlCQUFpQixFQUNqQixzQkFBc0IsRUFDdEIsc0JBQXNCLEVBQ3RCLElBQUksQ0FDTCxDQUFDO1lBRUYsSUFBSSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXBFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQy9CLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0YsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzFGO1lBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUNoQixDQUFDLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLENBQU0sa0JBQWtCLEVBQUMsRUFBRTtnQkFDckQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUMvRSxJQUFJLGNBQWMsQ0FBQztnQkFDbkIsSUFBSSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDbkUsY0FBYyxHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2lCQUNuRjtnQkFFRCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDakUsT0FBTyx3Q0FBa0IsQ0FBQyxZQUFZLENBQ3BDLGtCQUFrQixFQUNsQixPQUFPLEVBQ1AsT0FBTyxFQUNQLGNBQWMsQ0FDZixDQUFDO1lBQ0osQ0FBQyxDQUFBLENBQUMsQ0FDSCxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7UUFDaEYsQ0FBQztLQUFBO0lBRUQ7O09BRUc7SUFDSyxnQkFBZ0IsQ0FBQyxDQUFTO1FBQ2hDLElBQUksSUFBSSxHQUFXLENBQUMsQ0FBQztRQUVyQixJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ2xCLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFFRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqQyxNQUFNLElBQUksR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdCLHNDQUFzQztZQUN0QyxJQUFJLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztZQUNqQywyQkFBMkI7WUFDM0Isc0NBQXNDO1lBQ3RDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1NBQ3BCO1FBRUQsT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssWUFBWSxDQUFDLE9BQWUsRUFBRSxVQUFtQixFQUFFLFVBQW1CO1FBQzVFLElBQUksT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUMzQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksVUFBVSxFQUFFO1lBQ2QsZUFBZSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqRTtRQUVELElBQUksZUFBZSxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLFVBQVUsRUFBRTtZQUNkLGVBQWUsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakU7UUFFRCxPQUFPLGVBQWUsSUFBSSxlQUFlLENBQUM7SUFDNUMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssaUJBQWlCLENBQUMsU0FBaUI7UUFDekMsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDakMsT0FBTyxhQUFhLENBQUM7U0FDdEI7UUFFRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTdDLE1BQU0sV0FBVyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFOUIsTUFBTSxpQkFBaUIsR0FBRyx3QkFBYyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDakUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxFQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFDLEVBQUUsRUFBRTtnQkFDbkYsT0FBTyxDQUNMLFFBQVEsS0FBSyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU07b0JBQ2hDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxZQUFZLEVBQUUsV0FBVyxDQUFDLENBQ2xFLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxtQkFBbUIsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUE2QixFQUFFLEVBQUU7WUFDbEYsTUFBTSxJQUFJLEdBQUcseUJBQW1CLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQ3hELENBQUMsQ0FBQyxpQ0FBYyxDQUFDLFFBQVE7Z0JBQ3pCLENBQUMsQ0FBQyxpQ0FBYyxDQUFDLE1BQU0sQ0FBQztZQUMxQixNQUFNLFlBQVksR0FBaUI7Z0JBQ2pDLHVHQUF1RztnQkFDdkcsRUFBRSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2dCQUNwQyxTQUFTLEVBQUUsU0FBUztnQkFDcEIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtnQkFDaEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzthQUMvQixDQUFDO1lBRUYsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBRTtnQkFDcEMsR0FBRyxDQUFDLElBQUksQ0FBQywyQkFBMkIsWUFBWSxDQUFDLEVBQUUscUJBQXFCLENBQUMsQ0FBQzthQUMzRTtZQUVELFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRWpDLElBQUksSUFBSSxLQUFLLGlDQUFjLENBQUMsUUFBUSxFQUFFO2dCQUNwQyxZQUFZLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM1RSxZQUFZLENBQUMsVUFBVSxHQUFHLHlCQUFtQixDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDekY7WUFDRCxPQUFPLHdDQUFrQixDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLG1CQUFtQixDQUFDLENBQUM7UUFFM0QsT0FBTyxtQkFBbUIsQ0FBQztJQUM3QixDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0IsQ0FBQyxTQUFpQixFQUFFLEVBQVU7UUFDeEQsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFRDs7T0FFRztJQUNVLGFBQWEsQ0FDeEIsTUFBNEIsRUFDNUIsSUFBa0I7O1lBRWxCLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFFL0UsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFM0QsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFckQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRTdFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDaEMsT0FBTyxZQUFZLENBQUM7YUFDckI7WUFFRCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzdFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUNyQyxNQUFNLElBQUksNkJBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQzdDO1lBRUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9FLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FDdEUsa0JBQWtCLEVBQ2xCLE1BQU0sQ0FBQyxVQUFVLENBQ2xCLENBQUM7WUFDRixNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FDcEUsa0JBQWtCLEVBQ2xCLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FDaEMsQ0FBQztZQUVGLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxDQUFDLGtCQUFrQixFQUFFO2dCQUM5RCxNQUFNLElBQUksNkJBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDN0Q7WUFFRCxJQUFJLGNBQWMsQ0FBQztZQUNuQixJQUFJLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUNuRSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLGtCQUFrQixDQUFDLENBQUM7YUFDbkY7WUFFRCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNqRSxPQUFPLHdDQUFrQixDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQy9GLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1UsaUJBQWlCLENBQzVCLE1BQStCLEVBQy9CLElBQWtCOztZQUVsQixNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO1lBRXpFLE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFFNUQsT0FBTyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQ3ZGLENBQUM7S0FBQTtJQUVEOztPQUVHO0lBQ1UsZ0JBQWdCLENBQUMsTUFBNEIsRUFBRSxJQUFrQjs7WUFDNUUsTUFBTSxXQUFXLEdBQUcsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO1lBRTNFLE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDN0UsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ3JDLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDN0M7WUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDL0UsSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDWixNQUFNLElBQUksNkJBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDN0Q7WUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNqRSxDQUFDO0tBQUE7SUFFRDs7T0FFRztJQUNVLGdCQUFnQixDQUMzQixNQUE4QixFQUM5QixJQUFrQjs7WUFFbEIsZ0VBQWdFO1lBQ2hFLDhEQUE4RDtZQUM5RCxNQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLHNCQUFzQixDQUFDLENBQUM7WUFFekUsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFckQsd0JBQXdCO1lBQ3hCLElBQUksa0JBQWtCLEdBQUcsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDM0UsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ3JDLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDN0M7WUFFRCxNQUFNLGFBQWEsR0FBeUI7Z0JBQzFDLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtnQkFDakIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO2dCQUN2QixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87Z0JBQ3ZCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztnQkFDL0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO2FBQ3hCLENBQUM7WUFFRixvREFBb0Q7WUFDcEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDbEMsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUV4RCxJQUFJLENBQUMsVUFBVSxFQUFFO29CQUNmLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUNoRTtxQkFBTTtvQkFDTCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDakU7Z0JBRUQsSUFBSSxTQUFTLEdBQW1CLGlDQUFjLENBQUMsTUFBTSxDQUFDO2dCQUN0RCxJQUFJLGNBQWMsQ0FBQztnQkFDbkIsSUFBSSx5QkFBbUIsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUNsRCxTQUFTLEdBQUcsaUNBQWMsQ0FBQyxRQUFRLENBQUM7b0JBQ3BDLGNBQWMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDakU7Z0JBRUQsYUFBYSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7Z0JBQy9CLGFBQWEsQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO2FBQy9DO1lBRUQsaURBQWlEO1lBQ2pELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsT0FBTyxFQUFFO2dCQUNaLE1BQU0sSUFBSSw2QkFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUM3RDtZQUVELDhDQUE4QztZQUM5QyxJQUFJLGNBQWMsQ0FBQztZQUNuQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNsQyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsOEJBQThCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztnQkFFNUUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO29CQUMzQyxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO29CQUUzRixLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBRXJFLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyx5QkFBeUIsQ0FBQyxrQkFBa0IsRUFBRSxjQUFjLENBQUMsQ0FBQztpQkFDeEY7YUFDRjtZQUVELGlDQUFpQztZQUNqQyxrQkFBa0IsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQzVELGtCQUFrQixFQUNsQixhQUFhLENBQ2QsQ0FBQztZQUVGLHlEQUF5RDtZQUN6RCxJQUNFLENBQUMsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ2pFLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEVBQzdCO2dCQUNBLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUNuRjtZQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pFLGlDQUFpQztZQUNqQyxPQUFPLHdDQUFrQixDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzVGLENBQUM7S0FBQTtJQUVEOzs7T0FHRztJQUNJLGlCQUFpQixDQUFDLGdCQUFtQztRQUMxRCwrQ0FBK0M7UUFDL0Msc0NBQXNDO1FBQ3RDLE1BQU0sWUFBWSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFbkYsdUVBQXVFO1FBQ3ZFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxDQUNMLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVTtpQkFDakIsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBQyxFQUFDLENBQUM7aUJBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDcEIsb0RBQW9EO2dCQUNwRCxhQUFhO2dCQUNiLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4RixzRkFBc0Y7Z0JBQ3RGLE9BQU8sUUFBUSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ3pDLE1BQU0sdUJBQXVCLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUV2RSwyRUFBMkU7b0JBQzNFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO3dCQUMxQyxhQUFhO3dCQUNiLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUMxRTtvQkFFRCxvRUFBb0U7b0JBQ3BFLGFBQWE7b0JBQ2IsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdEYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQy9DLENBQUMsQ0FBQztnQkFDRixhQUFhO2lCQUNaLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO2dCQUN4QixJQUFJLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ2hDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7aUJBQzNEO1lBQ0gsQ0FBQyxDQUFDO2lCQUNELE1BQU0sRUFBRSxDQUNaLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSSxhQUFhLENBQUMsS0FBeUIsRUFBRSxVQUFvQjtRQUNsRSxNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQzNDLENBQUMsQ0FBQyxLQUFLLENBQ0w7WUFDRSxTQUFTLEVBQUUsR0FBRztZQUNkLElBQUksRUFBRSxFQUFFO1lBQ1IsSUFBSSxFQUFFLGlDQUFjLENBQUMsTUFBTTtZQUMzQixPQUFPLEVBQUUsd0NBQXFCLENBQUMsT0FBTztTQUN2QyxFQUNELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FDeEQsQ0FDRixDQUFDO1FBRUYsT0FBTyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFTSxrQkFBa0I7UUFDdkIsK0NBQStDO1FBQy9DLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVU7aUJBQ3hCLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUMsRUFBQyxDQUFDO2lCQUM5QixHQUFHLENBQ0YsQ0FBQyxLQUF5QixFQUFrQixFQUFFO2dCQUM1QyxJQUFJO29CQUNGLElBQUksU0FBUyxHQUFtQixpQ0FBYyxDQUFDLE1BQU0sQ0FBQztvQkFDdEQsSUFBSSxjQUFjLENBQUM7b0JBQ25CLElBQUkseUJBQW1CLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTt3QkFDakQsU0FBUyxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO3dCQUNwQyxjQUFjLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ2hFO29CQUNELEtBQUssQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDO29CQUN2QixLQUFLLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztvQkFDdEMsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7b0JBQ2xCLE9BQU8sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUM5QjtnQkFBQyxPQUFPLENBQUMsRUFBRTtvQkFDVixHQUFHLENBQUMsSUFBSSxDQUNOLDJCQUEyQjt3QkFDekIsS0FBSyxDQUFDLEVBQUU7d0JBQ1IsSUFBSTt3QkFDSixLQUFLLENBQUMsT0FBTzt3QkFDYixhQUFhO3dCQUNiLENBQUMsQ0FBQyxPQUFPLENBQ1osQ0FBQztpQkFDSDtnQkFDRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM1QixDQUFDLEVBQ0QsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQ2pCO2lCQUNBLE1BQU0sRUFBRSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLGlCQUFpQixFQUFFLENBQUMifQ==