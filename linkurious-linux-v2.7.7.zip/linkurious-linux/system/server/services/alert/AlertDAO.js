/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-12.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Log = LKE.getLogger(__filename);
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Data = LKE.getData();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
//locals
const { GraphRequestTimeout, Vendor } = require('../../models/errors/GraphRequestTimeout');
// by default, an alert can generate 5000 new matches
const DEFAULT_MAX_MATCHES = 5000;
// by default, an alert query can run for 10 minutes
const DEFAULT_MAX_RUNTIME = 10 * 60 * 1000;
// by default, a match as a TTL of 0 days
const DEFAULT_MAX_MATCH_TTL = 0;
// we insert/update matches one hundred at a time
const SLICE_SIZE = 100;
// Biggest representable date
// http://www.ecma-international.org/ecma-262/5.1/#sec-15.9.1.1
const DATE_MAX_VALUE = new Date(8640000000000000);
// MatchAction.action to Match.status
const ACTION_TO_STATUS = new Map();
ACTION_TO_STATUS.set('confirm', 'confirmed');
ACTION_TO_STATUS.set('unconfirm', 'unconfirmed');
ACTION_TO_STATUS.set('dismiss', 'dismissed');
class AlertDAO {
    /**
     * Return the list of fields to show to a simple user.
     *
     * @param {boolean} keepAllFields Whether to return undefined (representing all fields) or the array of alert fields readable by non-admin users
     *
     * @returns {string[] | undefined} undefined if `keepAllFields` is true
     * @private
     */
    static _alertAttributes(keepAllFields) {
        if (keepAllFields) {
            // in sequelize, {attributes: undefined} returns all attributes
            return undefined;
        }
        else {
            return ['id', 'title', 'sourceKey', 'columns', 'enabled',
                'lastRun', 'updatedAt', 'createdAt'];
        }
    }
    /**
     * Get an alert by id.
     * Fields are masked for non-admin users if `keepAllFields` is false.
     *
     * @param {number}  alertId
     * @param {boolean} keepAllFields Whether to return an alert instance with all the fields or only the ones readable by non-admin users
     * @returns {Bluebird<AlertInstance>}
     */
    getAlert(alertId, keepAllFields) {
        Utils.check.posInt('id', alertId);
        const options = { where: { id: alertId }, attributes: AlertDAO._alertAttributes(keepAllFields) };
        return Db.models.alert.findOne(options).then(alert => {
            if (!alert) {
                return Errors.business('not_found', `Alert #${alertId} was not found.`, true);
            }
            return alert;
        });
    }
    /**
     * Validate an alert at creation or update.
     *
     * @param {AlertAttributes} alert
     * @param {boolean}         creating  Whether the check is for creating (true), or updating (false)
     * @param {string}          sourceKey Key of the data-source of the created/updated alert
     */
    static _checkAlert(alert, creating, sourceKey) {
        const maxMatchTTL = Config.get('alerts.maxMatchTTL', DEFAULT_MAX_MATCH_TTL);
        const maxMatches = Config.get('alerts.maxMatchesLimit', DEFAULT_MAX_MATCHES);
        const rules = {
            title: { required: creating, check: ['string', true, false, 1, 200] },
            sourceKey: { required: creating, check: (key, value) => Utils.checkSourceKey(value) },
            query: { required: creating, check: 'nonEmpty' },
            enabled: { required: creating, type: 'boolean' },
            columns: { required: false, check: (key, value) => {
                    Utils.check.array(key, value, 0, 5);
                    value.forEach((v, i) => {
                        Utils.check.properties(key + '[' + i + ']', v, {
                            type: { required: true, values: ['number', 'string'] },
                            columnName: { required: true, check: 'nonEmpty' },
                            columnTitle: { required: true, check: 'nonEmpty' }
                        });
                    });
                } },
            cron: { required: creating, check: 'cronExpression' },
            matchTTL: { required: creating, check: ['integer', 0, maxMatchTTL] },
            maxMatches: { required: creating, check: ['integer', 0, maxMatches] },
            dialect: { required: creating, values: Data.resolveSource(sourceKey).graph.features.dialects }
        };
        Utils.check.properties('alert', alert, rules);
    }
    /**
     * Create a new alert.
     *
     * @param {AlertAttributes} alert
     * @param {WrappedUser}     currentUser
     * @returns {Bluebird<AlertInstance>}
     */
    createAlert(alert, currentUser) {
        Utils.check.object('alert', alert);
        alert = _.defaults(alert, {
            maxMatches: Config.get('alerts.maxMatchesLimit', DEFAULT_MAX_MATCHES),
            matchTTL: Config.get('alerts.maxMatchTTL', DEFAULT_MAX_MATCH_TTL)
        });
        Utils.check.exist('currentUser', currentUser);
        AlertDAO._checkAlert(alert, true, alert.sourceKey);
        return Db.models.alert.create({
            title: alert.title,
            sourceKey: alert.sourceKey,
            query: alert.query,
            dialect: alert.dialect,
            enabled: alert.enabled,
            columns: alert.columns,
            cron: alert.cron,
            matchTTL: alert.matchTTL,
            lastRun: null,
            lastRunProblem: null,
            maxMatches: alert.maxMatches,
            userId: currentUser.id
        });
    }
    /**
     * Get all the alerts within a given source if `sourceKey` is defined, otherwise,
     * get all the alerts from any data-source.
     * Fields are masked for non-admin users if `keepAllFields` is false.
     *
     * @param {string}  sourceKey     Key of the data-source. `null` to get alerts from all data-source
     * @param {boolean} keepAllFields Whether to return an alert instance with all the fields or only the ones readable by non-admin users
     * @returns {Bluebird<AlertInstance[]>}
     */
    getAlerts(sourceKey, keepAllFields) {
        const where = {};
        if (Utils.hasValue(sourceKey)) {
            Utils.checkSourceKey(sourceKey);
            where.sourceKey = sourceKey;
        }
        return Db.models.alert.findAll({
            where: where,
            attributes: AlertDAO._alertAttributes(keepAllFields),
            order: [['id', 'desc']]
        });
    }
    /**
     * Delete all the matches and match actions of a given alert.
     * Match actions are deleted automatically with on delete cascade.
     *
     * @param {number} alertId
     * @returns {Bluebird<void>}
     */
    deleteMatchAndActions(alertId) {
        return Db.models.match.destroy({
            where: { alertId: alertId }
        }).return();
    }
    /**
     * Delete an alert, all its matches and match actions.
     *
     * @param {number} alertId
     * @returns {Bluebird<void>}
     */
    deleteAlert(alertId) {
        Utils.check.posInt('id', alertId);
        return this.deleteMatchAndActions(alertId).then(() => {
            return Db.models.alert.destroy({ where: { id: alertId } });
        }).return();
    }
    /**
     * Update an alert.
     *
     * `id`, `sourceKey`, `userId`, `lastRun` and `lastRunProblem` cannot be updated and
     * will be silently ignored.
     *
     * @param {number}          alertId
     * @param {AlertAttributes} newProperties
     * @returns {Bluebird<AlertInstance>}
     */
    updateAlert(alertId, newProperties) {
        Utils.check.posInt('id', alertId);
        Utils.check.object('newProperties', newProperties);
        // ignored fields from newProperties (they cannot be changed)
        ['id', 'sourceKey', 'userId', 'lastRun', 'lastRunProblem'].forEach(key => {
            delete newProperties[key];
        });
        return this.getAlert(alertId, true).then(alert => {
            // check the new properties
            AlertDAO._checkAlert(newProperties, false, alert.sourceKey);
            _.forEach(newProperties, (value, key) => {
                alert[key] = value;
            });
            return alert.save();
        });
    }
    /**
     * Do an action on a match.
     *
     * @param {MatchInstance} match
     * @param {string}        action ("open", "confirm", "dismiss", "unconfirm")
     * @param {WrappedUser}   currentUser
     * @returns {Bluebird<MatchActionInstance>}
     */
    doMatchAction(match, action, currentUser) {
        Utils.check.object('match', match);
        Utils.check.values('action', action, Db.models.matchAction.ACTION_VALUES);
        Utils.check.exist('currentUser', currentUser);
        return Db.sequelize.transaction(t => {
            // some actions don't change the status, in that case `newStatus` is undefined
            const newStatus = ACTION_TO_STATUS.get(action);
            // check if the match already has this status, fail if so
            if (newStatus !== undefined && match.status === newStatus) {
                return Errors.business('redundant_action', `The match already has this status (${newStatus}).`, true);
            }
            // create the new match action
            const newAction = { action: action, userId: currentUser.id, matchId: match.id };
            return Db.models.matchAction.create(newAction, { transaction: t }).then(newAction => {
                // update the match status (if needed)
                if (newStatus === undefined) {
                    return newAction;
                }
                match.status = newStatus;
                match.statusUserId = currentUser.id;
                return match.save({ transaction: t })
                    .return(newAction);
            });
        });
    }
    /**
     * Get all the matches for a given alert.
     * The user that performed the last action is populated.
     * The actions are populated and filtered (only open actions of the non-current user are returned).
     * The users of the open actions are populated.
     *
     * @param {number}      alertId
     * @param {WrappedUser} currentUser
     * @param {object}      options
     * @param {string}      [options.sortDirection]
     * @param {string}      [options.sortBy]
     * @param {number}      [options.offset=0]
     * @param {number}      [options.limit=20]
     * @param {string}      [options.status]
     * @returns {Bluebird<MatchInstance[]>}
     */
    getMatches(alertId, currentUser, options) {
        Utils.check.posInt('alertId', alertId);
        options = _.defaults(options, { offset: 0, limit: 20 });
        Utils.check.properties('options', options, {
            offset: { required: true, check: 'posInt' },
            limit: { required: true, check: 'posInt' },
            sortDirection: { required: false, values: ['asc', 'desc'] },
            // sortBy can be 'date' or a given column index from 0 to 4
            sortBy: { required: false, values: ['date', '0', '1', '2', '3', '4'] },
            status: { required: false, values: Db.models.match.STATUS_VALUES }
        });
        const where = { alertId: alertId };
        if (Utils.hasValue(options.status)) {
            where.status = options.status;
        }
        return this.getAlert(alertId, true).then(alert => {
            // if no sortDirection is given, sort by 'desc'
            const sortDirection = options.sortDirection ? options.sortDirection : 'desc';
            // if no sortBy is given, sort by creation date
            let sortBy = options.sortBy ? options.sortBy : 'date';
            let orderOptions;
            if (sortBy === 'date') {
                // creation date
                orderOptions = [['id', sortDirection]];
            }
            else {
                // we sort by a column
                // 1) check that the column exist in the alert
                const columnDefinition = alert.columns[sortBy];
                if (Utils.hasValue(columnDefinition)) {
                    sortBy = columnDefinition.type === 'string'
                        ? 'columnString' + sortBy : 'columnNumber' + sortBy;
                    orderOptions = [[sortBy, sortDirection], ['id', 'desc']];
                }
                else {
                    // don't fail, just sort by creation date
                    orderOptions = [['id', 'desc']];
                }
            }
            return Db.models.match.findAll({
                where: where,
                order: orderOptions,
                offset: options.offset,
                limit: options.limit,
                include: [Db.models.user, {
                        model: Db.models.matchAction,
                        required: false,
                        where: {
                            userId: { $ne: currentUser.id },
                            action: 'open'
                        },
                        include: [Db.models.user]
                    }]
            });
        }).map(match => {
            return this._updateMatchToVersion2(match);
        });
    }
    /**
     * Get the count for each possible status of all the matches for a given alert.
     *
     * @param {number} alertId
     * @returns {Bluebird<{unconfirmed: number, confirmed: number, dismissed: number}>}
     */
    getMatchCount(alertId) {
        return Db.models.match.findAll({
            where: {
                alertId: alertId
            },
            attributes: [
                'status',
                [Db.sequelize.fn('count', Db.sequelize.col('id')), 'actionCount']
            ],
            group: ['match.status']
        }).then(rows => {
            const queryResultMap = new Map();
            _.forEach(rows, row => {
                queryResultMap.set(row.status, row.get().actionCount);
            });
            return {
                unconfirmed: queryResultMap.get('unconfirmed') || 0,
                confirmed: queryResultMap.get('confirmed') || 0,
                dismissed: queryResultMap.get('dismissed') || 0
            };
        });
    }
    /**
     * If the match is version 1, update it to version 2 and return it.
     *
     * Since matches v2, node and edge ids are stored exclusively as strings.
     *
     * @param {MatchInstance} matchInstance
     * @returns {Bluebird<MatchInstance>}
     * @private
     * @backward-compatibility
     */
    _updateMatchToVersion2(matchInstance) {
        if (matchInstance.version > 1) {
            return Promise.resolve(matchInstance);
        }
        // originally node and edge ids in Linkurious could have been both string and numbers
        // we force them to be string now
        matchInstance.nodes = _.map(matchInstance.nodes, nodeId => '' + nodeId);
        matchInstance.edges = _.map(matchInstance.edges, edgeId => '' + edgeId);
        // Recompute the hash because nodes and edges ids have changed
        matchInstance.hash = Utils.hashMatch(matchInstance.nodes, matchInstance.edges, matchInstance.alertId);
        matchInstance.version = 2;
        return matchInstance.save();
    }
    /**
     * Get a match by id. Reject if the match is not found.
     * The user model is populated.
     *
     * @param {number}      matchId
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<MatchInstance>}
     */
    getMatch(matchId, currentUser) {
        Utils.check.posInt('id', matchId);
        return Db.models.match.findOne({
            where: { id: matchId },
            include: [Db.models.user, {
                    model: Db.models.matchAction,
                    required: false,
                    where: {
                        userId: { $ne: currentUser.id },
                        action: 'open'
                    },
                    include: [Db.models.user]
                }]
        }).then(match => {
            if (!match) {
                return Errors.business('not_found', `Match #${matchId} was not found.`, true);
            }
            return this._updateMatchToVersion2(match);
        });
    }
    /**
     * This function will create matches. It will throw an LkError if there was a problem not
     * depending on a single match. It will return an AlertRunProblem if there were problems with the
     * individual matches. It won't return anything if there were no problems.
     *
     * It won't create duplicate matches. (the unique key is the hash)
     * It also won't create new matches if `alert.maxMatches` was reached.
     *
     * @param {Readable<QueryMatch>} queryMatchStream
     * @param {AlertInstance}        alert
     * @returns {Bluebird<AlertRunProblem | null>} null, if there were no problems
     */
    createMatchesInBulk(queryMatchStream, alert) {
        Utils.check.object('alert', alert);
        const timeout = Config.get('alerts.maxRuntimeLimit', DEFAULT_MAX_RUNTIME);
        return Utils.mergeReadable(queryMatchStream, timeout).then(mergedStream => {
            const matches = mergedStream.result;
            const queryTimedOut = mergedStream.timeout;
            if (matches.length === 0) {
                return null;
            }
            // count the matches of this alert
            return Db.models.match.count({ where: { alertId: alert.id } }).catch(err => {
                throw Errors.technical('critical', 'Couldn\'t query the DB (count): ' + err);
            }).then(matchCount => {
                // getDate returns the day in the current month (1-31), setDate will handle overflow by itself
                let expirationDate = new Date();
                if (alert.matchTTL !== 0) {
                    expirationDate.setDate(expirationDate.getDate() + alert.matchTTL);
                }
                else {
                    // if matchTTL is 0 the expiration date is the next run of the alert
                    // here we set an infinite expiration date
                    expirationDate = DATE_MAX_VALUE;
                }
                let runError;
                const matchesToCreate = new Map();
                for (const match of matches) {
                    try {
                        Utils.check.array('nodes', match.nodes);
                        Utils.check.array('edges', match.edges);
                        Utils.check.exist('properties', match.properties);
                        const hash = Utils.hashMatch(match.nodes, match.edges, alert.id);
                        const matchAttributes = {
                            sourceKey: alert.sourceKey,
                            alertId: alert.id,
                            hash: hash,
                            nodes: match.nodes,
                            edges: match.edges,
                            status: 'unconfirmed',
                            expirationDate: expirationDate,
                            version: 2
                        };
                        if (Utils.hasValue(alert.columns)) {
                            alert.columns.forEach((column, idx) => {
                                const scalarValue = match.properties[column.columnName];
                                if (column.type === 'number' && typeof scalarValue === 'number') {
                                    matchAttributes['columnNumber' + idx] = scalarValue;
                                }
                                else if (column.type === 'string' && Utils.isNEString(scalarValue)) {
                                    matchAttributes['columnString' + idx] = scalarValue;
                                } // else we silently ignore that the scalar value is undefined or of an incorrect type
                            });
                        }
                        matchesToCreate.set(hash, matchAttributes);
                    }
                    catch (err) {
                        runError = err;
                    }
                }
                const duplicateHashes = [];
                const currentTime = new Date();
                // TODO when we update sequelize to the latest version we can remove the following line
                // The following line fix is needed because when we compare currentTime with updatedAt
                // we need to be sure that currentTime comes before in time than the updateAt of the just inserted matches
                // `updatedAt`, though, under some particular dialects (MySQL and MSSQL) loses the milliseconds
                // https://github.com/sequelize/sequelize/blob/75c1fdbc676d73a28a5e0bca49b2a6d4a9f8708c/lib/utils.js#L382
                // #1652
                currentTime.setSeconds(currentTime.getSeconds() - 1);
                // 1) find all match hashes that are already in database
                return Utils.sliceMap(Array.from(matchesToCreate.keys()), SLICE_SIZE, hashesSlice => {
                    return Db.models.match.findAll({
                        where: { hash: hashesSlice, alertId: alert.id },
                        attributes: ['hash']
                    }).catch(err => {
                        throw Errors.technical('critical', 'Couldn\'t query the DB (find duplicates): ' + err);
                    }).map(match => match.hash).then(hashes => {
                        duplicateHashes.push.apply(duplicateHashes, hashes);
                    });
                }).then(() => {
                    // 2) remove all duplicates from the "matches to create" map
                    for (const hash of duplicateHashes) {
                        matchesToCreate.delete(hash);
                    }
                    let newMatchesToCreate = Array.from(matchesToCreate.values());
                    newMatchesToCreate = _.uniqBy(newMatchesToCreate, 'hash');
                    // 3) enforce "maxMatches" and report an error if the max was reached
                    if (matchCount + newMatchesToCreate.length > alert.maxMatches) {
                        // if we reach the maximum, we report the error
                        runError = Errors.business('creation_failed', 'Match couldn\'t be created because "alert.maxMatches" was reached.');
                    }
                    newMatchesToCreate = newMatchesToCreate.slice(0, alert.maxMatches - matchCount);
                    // 4) update the expiration date of existing matches
                    return Utils.sliceMap(duplicateHashes, SLICE_SIZE, hashesSlice => {
                        return Db.models.match.update({ expirationDate: expirationDate }, { where: { hash: hashesSlice } }).catch(err => {
                            throw Errors.technical('critical', 'Couldn\'t query the DB (update expirationDate): ' + err);
                        });
                    }).return(newMatchesToCreate);
                }).then(newMatchesToCreate => {
                    let problem = null;
                    if (queryTimedOut) {
                        problem = {
                            error: new GraphRequestTimeout(Vendor.LINKURIOUS),
                            // the error is partial if at least 1 match was updated OR created
                            partial: matchesToCreate.size > 0
                        };
                    }
                    // A run error is more worth to show than a timeout
                    if (runError) {
                        problem = {
                            error: runError,
                            // the error is partial if at least 1 match was updated OR created
                            partial: matchesToCreate.size > 0
                        };
                        Log.error('Could not create matches in bulk: ', runError);
                    }
                    // 5) actually create the new matches
                    return Utils.sliceMap(newMatchesToCreate, SLICE_SIZE, matchesSlice => {
                        return Db.models.match.bulkCreate(matchesSlice).catch(err => {
                            throw Errors.technical('critical', 'Couldn\'t query the DB (create matches): ' + err);
                        });
                    }).then(() => {
                        // if matchTTL is 0, we will delete all the unconfirmed matches that were not updated
                        if (alert.matchTTL === 0) {
                            return Db.models.match.destroy({
                                where: {
                                    updatedAt: {
                                        $lt: currentTime
                                    },
                                    status: {
                                        $not: 'confirmed'
                                    },
                                    alertId: alert.id
                                }
                            });
                        }
                    }).return(problem);
                });
            });
        });
    }
    /**
     * Get all the actions for a given match.
     * The user is populated.
     *
     * @param {number} matchId
     * @param {object} [options]
     * @param {number} [options.offset=0]
     * @param {number} [options.limit=20]
     * @returns {Bluebird<MatchActionInstance[]>}
     */
    getMatchActions(matchId, options) {
        Utils.check.posInt('matchId', matchId);
        options = _.defaults(options, { offset: 0, limit: 20 });
        Utils.check.posInt('offset', options.offset);
        Utils.check.posInt('limit', options.limit);
        return Db.models.matchAction.findAll({
            where: { matchId: matchId },
            offset: options.offset,
            limit: options.limit,
            order: [['id', 'desc']],
            include: [Db.models.user]
        });
    }
    /**
     * Deletes unconfirmed matches that lived beyond their expiration date (creation date + TTL).
     *
     * @returns {Bluebird<void>}
     */
    cleanUpOldMatches() {
        return Promise.resolve().then(() => {
            return Db.models.match.destroy({
                where: {
                    expirationDate: {
                        $lt: new Date().getTime()
                    },
                    status: {
                        $not: 'confirmed'
                    }
                }
            });
        }).return();
    }
    /**
     * Delete confirmed duplicate matches.
     * The migration to matches v2 was broken because the hashes were not recomputed.
     * To fix that, we recompute the hashes and we remove duplicate matches.
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    cleanUpDuplicateMatches() {
        return Db.models.match.findAll({ where: { status: 'confirmed' } })
            .map(confirmedMatch => {
            // 1) Recompute the hash
            const hash = Utils
                .hashMatch(confirmedMatch.nodes, confirmedMatch.edges, confirmedMatch.alertId);
            if (confirmedMatch.hash !== hash) {
                // We want to remove the duplicates of confirmed matches created before v2 migration
                // 2) Find a duplicate (at most one duplicate exists since the hash is unique)
                return Db.models.match.findOne({ where: { hash: hash } })
                    .then(duplicateMatch => {
                    if (Utils.hasValue(duplicateMatch)) {
                        // 3) Remove the duplicate if exists
                        return duplicateMatch.destroy();
                    }
                }).then(() => {
                    // 4) Update the hash
                    confirmedMatch.hash = hash;
                    return confirmedMatch.save();
                });
            }
        }).return();
    }
}
module.exports = new AlertDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWxlcnREQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWxlcnQvQWxlcnREQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixRQUFRO0FBQ1IsTUFBTSxFQUFDLG1CQUFtQixFQUFFLE1BQU0sRUFBQyxHQUFHLE9BQU8sQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO0FBRXpGLHFEQUFxRDtBQUNyRCxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQztBQUVqQyxvREFBb0Q7QUFDcEQsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztBQUUzQyx5Q0FBeUM7QUFDekMsTUFBTSxxQkFBcUIsR0FBRyxDQUFDLENBQUM7QUFFaEMsaURBQWlEO0FBQ2pELE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQztBQUV2Qiw2QkFBNkI7QUFDN0IsK0RBQStEO0FBQy9ELE1BQU0sY0FBYyxHQUFHLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFFbEQscUNBQXFDO0FBQ3JDLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUNuQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0FBQzdDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUM7QUFDakQsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztBQUU3QyxNQUFNLFFBQVE7SUFDWjs7Ozs7OztPQU9HO0lBQ0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGFBQWE7UUFDbkMsSUFBSSxhQUFhLEVBQUU7WUFDakIsK0RBQStEO1lBQy9ELE9BQU8sU0FBUyxDQUFDO1NBQ2xCO2FBQU07WUFDTCxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLFNBQVM7Z0JBQ3RELFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDeEM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFFBQVEsQ0FBQyxPQUFPLEVBQUUsYUFBYTtRQUM3QixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbEMsTUFBTSxPQUFPLEdBQUcsRUFBQyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsT0FBTyxFQUFDLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsRUFBQyxDQUFDO1FBQzdGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNuRCxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNWLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBVSxPQUFPLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQy9FO1lBQ0QsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUztRQUMzQyxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLHFCQUFxQixDQUFDLENBQUM7UUFDNUUsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBRTdFLE1BQU0sS0FBSyxHQUFHO1lBQ1osS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUM7WUFDbkUsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFDO1lBQ25GLEtBQUssRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUM5QyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDOUMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7b0JBQy9DLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNwQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNyQixLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFOzRCQUM3QyxJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsRUFBQzs0QkFDcEQsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDOzRCQUMvQyxXQUFXLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7eUJBQ2pELENBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLEVBQUM7WUFDRixJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxnQkFBZ0IsRUFBQztZQUNuRCxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLEVBQUUsV0FBVyxDQUFDLEVBQUM7WUFDbEUsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxFQUFDO1lBQ25FLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUM7U0FDN0YsQ0FBQztRQUVGLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxLQUFLLEVBQUUsV0FBVztRQUM1QixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbkMsS0FBSyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO1lBQ3hCLFVBQVUsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLG1CQUFtQixDQUFDO1lBQ3JFLFFBQVEsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLHFCQUFxQixDQUFDO1NBQ2xFLENBQUMsQ0FBQztRQUVILEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU5QyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRW5ELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQzVCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztZQUNsQixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7WUFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ2xCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87WUFDdEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1lBQ3RCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtZQUNoQixRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7WUFDeEIsT0FBTyxFQUFFLElBQUk7WUFDYixjQUFjLEVBQUUsSUFBSTtZQUNwQixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7WUFDNUIsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO1NBQ3ZCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFNBQVMsQ0FBQyxTQUFTLEVBQUUsYUFBYTtRQUNoQyxNQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzdCLEtBQUssQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEMsS0FBSyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7U0FDN0I7UUFFRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUM3QixLQUFLLEVBQUUsS0FBSztZQUNaLFVBQVUsRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO1lBQ3BELEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQ3hCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxxQkFBcUIsQ0FBQyxPQUFPO1FBQzNCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQzdCLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUM7U0FDMUIsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsV0FBVyxDQUFDLE9BQU87UUFDakIsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDbkQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsT0FBTyxFQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ3pELENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFdBQVcsQ0FBQyxPQUFPLEVBQUUsYUFBYTtRQUNoQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDbEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRW5ELDZEQUE2RDtRQUM3RCxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN2RSxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQy9DLDJCQUEyQjtZQUMzQixRQUFRLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTVELENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO2dCQUN0QyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO1lBQ3JCLENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGFBQWEsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFdBQVc7UUFDdEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ25DLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDMUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTlDLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDbEMsOEVBQThFO1lBQzlFLE1BQU0sU0FBUyxHQUFHLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvQyx5REFBeUQ7WUFDekQsSUFBSSxTQUFTLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFO2dCQUN6RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGtCQUFrQixFQUFFLHNDQUFzQyxTQUFTLElBQUksRUFBRSxJQUFJLENBQzlFLENBQUM7YUFDSDtZQUVELDhCQUE4QjtZQUM5QixNQUFNLFNBQVMsR0FBRyxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUMsQ0FBQztZQUM5RSxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBRWhGLHNDQUFzQztnQkFDdEMsSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFO29CQUFFLE9BQU8sU0FBUyxDQUFDO2lCQUFFO2dCQUNsRCxLQUFLLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztnQkFDekIsS0FBSyxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsRUFBRSxDQUFDO2dCQUNwQyxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDLENBQUM7cUJBQ2hDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN2QixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILFVBQVUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE9BQU87UUFDdEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXZDLE9BQU8sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7UUFFdEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTtZQUN6QyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFDekMsS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1lBQ3hDLGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFDO1lBQ3pELDJEQUEyRDtZQUMzRCxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUM7WUFDcEUsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFDO1NBQ2pFLENBQUMsQ0FBQztRQUVILE1BQU0sS0FBSyxHQUFHLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxDQUFDO1FBQ2pDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEMsS0FBSyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1NBQy9CO1FBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDL0MsK0NBQStDO1lBQy9DLE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUU3RSwrQ0FBK0M7WUFDL0MsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBRXRELElBQUksWUFBWSxDQUFDO1lBRWpCLElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtnQkFDckIsZ0JBQWdCO2dCQUNoQixZQUFZLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDO2FBQ3hDO2lCQUFNO2dCQUNMLHNCQUFzQjtnQkFDdEIsOENBQThDO2dCQUM5QyxNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQy9DLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO29CQUNwQyxNQUFNLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxLQUFLLFFBQVE7d0JBQ3pDLENBQUMsQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDO29CQUV0RCxZQUFZLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO2lCQUMxRDtxQkFBTTtvQkFDTCx5Q0FBeUM7b0JBQ3pDLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7aUJBQ2pDO2FBQ0Y7WUFFRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDN0IsS0FBSyxFQUFFLEtBQUs7Z0JBQ1osS0FBSyxFQUFFLFlBQVk7Z0JBQ25CLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtnQkFDdEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUNwQixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTt3QkFDeEIsS0FBSyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVzt3QkFDNUIsUUFBUSxFQUFFLEtBQUs7d0JBQ2YsS0FBSyxFQUFFOzRCQUNMLE1BQU0sRUFBRSxFQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsRUFBRSxFQUFDOzRCQUM3QixNQUFNLEVBQUUsTUFBTTt5QkFDZjt3QkFDRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztxQkFBQyxDQUFDO2FBQzlCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsYUFBYSxDQUFDLE9BQU87UUFDbkIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7WUFDN0IsS0FBSyxFQUFFO2dCQUNMLE9BQU8sRUFBRSxPQUFPO2FBQ2pCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLFFBQVE7Z0JBQ1IsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUM7YUFDbEU7WUFDRCxLQUFLLEVBQUUsQ0FBQyxjQUFjLENBQUM7U0FDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLE1BQU0sY0FBYyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDakMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLEVBQUU7Z0JBQ3BCLGNBQWMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDeEQsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPO2dCQUNMLFdBQVcsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBQ25ELFNBQVMsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7Z0JBQy9DLFNBQVMsRUFBRSxjQUFjLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7YUFDaEQsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILHNCQUFzQixDQUFDLGFBQWE7UUFDbEMsSUFBSSxhQUFhLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRTtZQUM3QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDdkM7UUFDRCxxRkFBcUY7UUFDckYsaUNBQWlDO1FBQ2pDLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLDhEQUE4RDtRQUM5RCxhQUFhLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxhQUFhLENBQUMsS0FBSyxFQUMzRSxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekIsYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFFMUIsT0FBTyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxRQUFRLENBQUMsT0FBTyxFQUFFLFdBQVc7UUFDM0IsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQzdCLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUM7WUFDcEIsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7b0JBQ3hCLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVc7b0JBQzVCLFFBQVEsRUFBRSxLQUFLO29CQUNmLEtBQUssRUFBRTt3QkFDTCxNQUFNLEVBQUUsRUFBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLEVBQUUsRUFBQzt3QkFDN0IsTUFBTSxFQUFFLE1BQU07cUJBQ2Y7b0JBQ0QsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7aUJBQUMsQ0FBQztTQUM5QixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2QsSUFBSSxDQUFDLEtBQUssRUFBRTtnQkFDVixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQVUsT0FBTyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMvRTtZQUVELE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsbUJBQW1CLENBQUMsZ0JBQWdCLEVBQUUsS0FBSztRQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbkMsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBRTFFLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDeEUsTUFBTSxPQUFPLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztZQUNwQyxNQUFNLGFBQWEsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDO1lBRTNDLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ3hCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxrQ0FBa0M7WUFDbEMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JFLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsa0NBQWtDLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDL0UsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUVuQiw4RkFBOEY7Z0JBQzlGLElBQUksY0FBYyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ2hDLElBQUksS0FBSyxDQUFDLFFBQVEsS0FBSyxDQUFDLEVBQUU7b0JBQ3hCLGNBQWMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDbkU7cUJBQU07b0JBQ0wsb0VBQW9FO29CQUNwRSwwQ0FBMEM7b0JBQzFDLGNBQWMsR0FBRyxjQUFjLENBQUM7aUJBQ2pDO2dCQUVELElBQUksUUFBUSxDQUFDO2dCQUNiLE1BQU0sZUFBZSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBRWxDLEtBQUssTUFBTSxLQUFLLElBQUksT0FBTyxFQUFFO29CQUMzQixJQUFJO3dCQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3hDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3hDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBRWxELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFFakUsTUFBTSxlQUFlLEdBQUc7NEJBQ3RCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUzs0QkFDMUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFOzRCQUNqQixJQUFJLEVBQUUsSUFBSTs0QkFDVixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7NEJBQ2xCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSzs0QkFDbEIsTUFBTSxFQUFFLGFBQWE7NEJBQ3JCLGNBQWMsRUFBRSxjQUFjOzRCQUM5QixPQUFPLEVBQUUsQ0FBQzt5QkFDWCxDQUFDO3dCQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUU7NEJBQ2pDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxFQUFFO2dDQUNwQyxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDeEQsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxPQUFPLFdBQVcsS0FBSyxRQUFRLEVBQUU7b0NBQy9ELGVBQWUsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO2lDQUNyRDtxQ0FBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLEVBQUU7b0NBQ3BFLGVBQWUsQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO2lDQUNyRCxDQUFDLHFGQUFxRjs0QkFDekYsQ0FBQyxDQUFDLENBQUM7eUJBQ0o7d0JBRUQsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUM7cUJBQzVDO29CQUFDLE9BQU0sR0FBRyxFQUFFO3dCQUNYLFFBQVEsR0FBRyxHQUFHLENBQUM7cUJBQ2hCO2lCQUNGO2dCQUVELE1BQU0sZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFFM0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDL0IsdUZBQXVGO2dCQUN2RixzRkFBc0Y7Z0JBQ3RGLDBHQUEwRztnQkFDMUcsK0ZBQStGO2dCQUMvRix5R0FBeUc7Z0JBQ3pHLFFBQVE7Z0JBQ1IsV0FBVyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBRXJELHdEQUF3RDtnQkFDeEQsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUNsRixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQzt3QkFDN0IsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBQzt3QkFDN0MsVUFBVSxFQUFFLENBQUMsTUFBTSxDQUFDO3FCQUNyQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNiLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsNENBQTRDLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ3pGLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ3hDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDdEQsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFFWCw0REFBNEQ7b0JBQzVELEtBQUssTUFBTSxJQUFJLElBQUksZUFBZSxFQUFFO3dCQUNsQyxlQUFlLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM5QjtvQkFFRCxJQUFJLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7b0JBQzlELGtCQUFrQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBRTFELHFFQUFxRTtvQkFDckUsSUFBSSxVQUFVLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxVQUFVLEVBQUU7d0JBQzdELCtDQUErQzt3QkFDL0MsUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQ3hCLGlCQUFpQixFQUNqQixvRUFBb0UsQ0FDckUsQ0FBQztxQkFDSDtvQkFDRCxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLENBQUM7b0JBRWhGLG9EQUFvRDtvQkFDcEQsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDLEVBQUU7d0JBQy9ELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUMzQixFQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUMsRUFDaEMsRUFBQyxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsV0FBVyxFQUFDLEVBQUMsQ0FDN0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7NEJBQ1osTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixVQUFVLEVBQUUsa0RBQWtELEdBQUcsR0FBRyxDQUNyRSxDQUFDO3dCQUNKLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFFM0IsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUVuQixJQUFJLGFBQWEsRUFBRTt3QkFDakIsT0FBTyxHQUFHOzRCQUNSLEtBQUssRUFBRSxJQUFJLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7NEJBQ2pELGtFQUFrRTs0QkFDbEUsT0FBTyxFQUFFLGVBQWUsQ0FBQyxJQUFJLEdBQUcsQ0FBQzt5QkFDbEMsQ0FBQztxQkFDSDtvQkFFRCxtREFBbUQ7b0JBQ25ELElBQUksUUFBUSxFQUFFO3dCQUNaLE9BQU8sR0FBRzs0QkFDUixLQUFLLEVBQUUsUUFBUTs0QkFDZixrRUFBa0U7NEJBQ2xFLE9BQU8sRUFBRSxlQUFlLENBQUMsSUFBSSxHQUFHLENBQUM7eUJBQ2xDLENBQUM7d0JBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDM0Q7b0JBRUQscUNBQXFDO29CQUNyQyxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsa0JBQWtCLEVBQUUsVUFBVSxFQUFFLFlBQVksQ0FBQyxFQUFFO3dCQUNuRSxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7NEJBQzFELE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsMkNBQTJDLEdBQUcsR0FBRyxDQUFDLENBQUM7d0JBQ3hGLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7d0JBQ1gscUZBQXFGO3dCQUNyRixJQUFJLEtBQUssQ0FBQyxRQUFRLEtBQUssQ0FBQyxFQUFFOzRCQUN4QixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQ0FDN0IsS0FBSyxFQUFFO29DQUNMLFNBQVMsRUFBRTt3Q0FDVCxHQUFHLEVBQUUsV0FBVztxQ0FDakI7b0NBQ0QsTUFBTSxFQUFFO3dDQUNOLElBQUksRUFBRSxXQUFXO3FDQUNsQjtvQ0FDRCxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7aUNBQ2xCOzZCQUNGLENBQUMsQ0FBQzt5QkFDSjtvQkFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDOUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRXZDLE9BQU8sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7UUFFdEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTNDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDO1lBQ25DLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUM7WUFDekIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSztZQUNwQixLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN2QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztTQUMxQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGlCQUFpQjtRQUNmLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzdCLEtBQUssRUFBRTtvQkFDTCxjQUFjLEVBQUU7d0JBQ2QsR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFO3FCQUMxQjtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sSUFBSSxFQUFFLFdBQVc7cUJBQ2xCO2lCQUNGO2FBQ0YsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILHVCQUF1QjtRQUNyQixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUMsRUFBQyxDQUFDO2FBQzNELEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNwQix3QkFBd0I7WUFDeEIsTUFBTSxJQUFJLEdBQUcsS0FBSztpQkFDZixTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNqRixJQUFJLGNBQWMsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO2dCQUNoQyxvRkFBb0Y7Z0JBQ3BGLDhFQUE4RTtnQkFDOUUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsSUFBSSxFQUFDLEVBQUMsQ0FBQztxQkFDbEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUNyQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUU7d0JBQ2xDLG9DQUFvQzt3QkFDcEMsT0FBTyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUM7cUJBQ2pDO2dCQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1gscUJBQXFCO29CQUNyQixjQUFjLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFDM0IsT0FBTyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQy9CLENBQUMsQ0FBQyxDQUFDO2FBQ047UUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNoQixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksUUFBUSxFQUFFLENBQUMifQ==