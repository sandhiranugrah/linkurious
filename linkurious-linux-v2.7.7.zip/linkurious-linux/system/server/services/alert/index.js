/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-16.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Scheduler = LKE.getScheduler();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Data = LKE.getData();
const Db = LKE.getSqlDb();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
// locals
const AlertDAO = require('./AlertDAO');
const ALERT_GROUP = 'alert';
const DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES = 7;
/**
 * It will delete old unconfirmed matches that lived beyond their expiration date.
 *
 * @returns {Bluebird<void>}
 */
function cleanUpOldMatches() {
    return AlertDAO.cleanUpOldMatches();
}
class AlertService {
    constructor() {
        this._alertIdToSchedulerTaskId = new Map();
        this._semaphores = new Map();
    }
    /**
     * Format an alert instance to a public alert:
     * - Add `nextRun` if `isAdmin` is true
     *
     * @param {AlertInstance} alertInstance
     * @param {boolean}       isAdmin
     * @returns {PublicAlert}
     * @private
     */
    _formatToPublicAlert(alertInstance, isAdmin) {
        const publicAlert = Db.models.alert.instanceToPublicAttributes(alertInstance);
        if (isAdmin) {
            const schedulerTaskId = this._alertIdToSchedulerTaskId.get(alertInstance.id);
            // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
            if (Utils.hasValue(schedulerTaskId)) {
                const nextRun = new Date(Scheduler.getTimeToSchedule(schedulerTaskId));
                const currentTime = new Date();
                // nextRun can be a date of the past, e.g. if the scheduler failed or it has yet to schedule
                if (nextRun < currentTime) {
                    // in that case, we set it as the current time
                    publicAlert.nextRun = currentTime;
                }
                else {
                    publicAlert.nextRun = nextRun;
                }
            }
            else {
                publicAlert.nextRun = null;
            }
        }
        return publicAlert;
    }
    /**
     * Format a match instance to a public match:
     * - Create the `columns` property (if `columnsDescription` is defined)
     * - Filter the `user` property
     * - Create the `viewers` property
     *
     * @param {MatchInstance} matchInstance
     * @param {Array<{type: string, columnName: string, columnTitle: string}>} [columnsDescription]
     * @returns {PublicMatch}
     * @private
     */
    _formatToPublicMatch(matchInstance, columnsDescription) {
        const publicMatch = Db.models.match.instanceToPublicAttributes(matchInstance, columnsDescription);
        // 1) filter the `user` property
        if (Utils.hasValue(matchInstance.user)) {
            publicMatch.user = {
                id: matchInstance.user.id,
                username: matchInstance.user.username,
                email: matchInstance.user.email
            };
        }
        else {
            publicMatch.user = null;
        }
        if (Utils.noValue(matchInstance.matchActions)) {
            publicMatch.viewers = [];
            return /**@type {PublicMatch}*/ (publicMatch);
        }
        // 2) discover who are the viewers and their infos
        // viewers are users who performed an "open" match action on the match
        /**@type {Map<number, Date>}*/
        const viewerToDateMap = new Map();
        const viewerToUserObject = new Map();
        for (const action of matchInstance.matchActions) {
            const previousTime = viewerToDateMap.get(action.userId);
            if (Utils.noValue(previousTime) || previousTime < action.createdAt) {
                viewerToDateMap.set(action.userId, action.createdAt);
            }
            if (!viewerToUserObject.has(action.userId)) {
                viewerToUserObject.set(action.userId, {
                    id: action.user.id,
                    username: action.user.username,
                    email: action.user.email
                });
            }
        }
        // 3) sort viewers by date and limit the number of viewers
        let viewerToDate = Array.from(viewerToDateMap.entries());
        viewerToDate = _.orderBy(viewerToDate, item => item[1], ['desc']);
        viewerToDate.slice(0, DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES);
        // 4) populate the match object with the viewers
        publicMatch.viewers = _.map(viewerToDate, item => {
            const viewer = viewerToUserObject.get(item[0]);
            viewer.date = item[1];
            return viewer;
        });
        return /**@type {PublicMatch}*/ (publicMatch);
    }
    /**
     * Format a match action instance to a public match action:
     * - Filter the `user` property
     *
     * @param {MatchActionInstance} matchActionInstance
     * @returns {PublicMatchAction}
     * @private
     */
    _formatToPublicMatchAction(matchActionInstance) {
        const publicMatchAction = Db.models.matchAction.instanceToPublicAttributes(matchActionInstance);
        // 1) filter the `user` property
        if (Utils.hasValue(matchActionInstance.user)) {
            publicMatchAction.user = {
                id: matchActionInstance.user.id,
                username: matchActionInstance.user.username,
                email: matchActionInstance.user.email
            };
        }
        else {
            publicMatchAction.user = null;
        }
        return publicMatchAction;
    }
    /**
     * Schedule all the alerts in the system.
     * For each enabled alert, if lastRun is null, it will execute the query the next time compatible
     * with `alert.cron`. If lastRun isn't null, it will check if it should have executed in the past.
     * If true, it will execute the query immediately.
     */
    start() {
        if (!Config.get('alerts.enabled')) {
            Log.info('Alerts are disabled');
            return;
        }
        try {
            Scheduler.setGroupConcurrency(ALERT_GROUP, Config.get('alerts.maxConcurrency', 1));
            // cleanup old matches everyday at 00:00 (local timezone)
            Scheduler.scheduleTask(cleanUpOldMatches, '0 0 * * *', { group: ALERT_GROUP });
            return AlertDAO.getAlerts(null, true).then(alerts => {
                for (const alert of alerts) {
                    if (alert.enabled) {
                        const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, {
                            group: ALERT_GROUP,
                            lastRun: alert.lastRun ? alert.lastRun : new Date(alert.createdAt)
                        });
                        this._alertIdToSchedulerTaskId.set(alert.id, id);
                    }
                }
                this._isAlertServiceStarted = true;
            });
        }
        catch (err) {
            Log.error('The alert manager couldn\'t schedule alerts due to invalid arguments.', err);
        }
    }
    /**
     * Run the alert.
     * It will query the db, generate the matches and update `alert.lastRun` to new Date().
     *
     * @param {AlertInstance} alert
     * @returns {Bluebird<AlertRunProblem | null>} null, if there were no problems
     */
    runAlert(alert) {
        return Data.alertQuery({
            dialect: alert.dialect,
            query: alert.query,
            sourceKey: alert.sourceKey,
            limit: alert.maxMatches
        }).then(queryMatchStream => {
            /**
             * If at least one match is created, partial will be set to true so that if we have a problem
             * we know that it depends on some particular matches.
             */
            return this.createMatchesInBulk(queryMatchStream, alert);
        }).catch(err => {
            if (err instanceof Promise.CancellationError) {
                throw err;
            }
            Log.error('RunAlert: Could not create matches in bulk: ', err);
            if (Utils.hasValue(err.message)) {
                return { error: err.message, partial: false };
            }
            return { error: err, partial: false };
        }).then(problem => {
            // "problem" is null if there wasn't any problem
            alert.lastRunProblem = problem;
            alert.lastRun = new Date();
            return alert.save().catch(err => {
                if (!(err instanceof Promise.CancellationError)) {
                    Log.error(`RunAlert: Could not update alert #${alert.id} in the database.`, err);
                }
            }).return(problem);
        });
    }
    /**
     * AlertDAO.createMatchesInBulk under semaphore lock for the alert.
     *
     * @param {Readable<QueryMatch>} queryMatchStream
     * @param {AlertInstance}        alert
     * @returns {Bluebird<AlertRunProblem | null>} null, if there were no problems
     */
    createMatchesInBulk(queryMatchStream, alert) {
        return this._acquireAlertSemaphore(alert.id).then(() => {
            return AlertDAO.createMatchesInBulk(queryMatchStream, alert);
        }).finally(() => this._releaseAlertSemaphore(alert.id));
    }
    /**
     * Create a new alert and schedule its first run.
     *
     * @param {AlertAttributes} newAlert
     * @param {WrappedUser}     currentUser
     * @returns {Bluebird<PublicAlert>}
     */
    createAlert(newAlert, currentUser) {
        return AlertDAO.createAlert(newAlert, currentUser).then(alert => {
            if (alert.enabled && this._isAlertServiceStarted) {
                const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, { group: ALERT_GROUP, lastRun: new Date(0) } // new alerts will schedule immediately
                );
                this._alertIdToSchedulerTaskId.set(alert.id, id);
            }
            return this._formatToPublicAlert(alert, true);
        });
    }
    /**
     * Get all the alerts within a given source.
     * Fields are masked for non-admin users if `allFields` is false.
     *
     * @param {string}      sourceKey
     * @param {boolean}     allFields
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<PublicAlert[]>}
     */
    getAlerts(sourceKey, allFields, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        return AlertDAO.getAlerts(sourceKey, allFields)
            .map(alert => this._formatToPublicAlert(alert, allFields))
            .filter(alert => currentUser.canReadAlert(sourceKey, alert.id, false));
    }
    /**
     * Get an alert by id.
     * Fields are masked for non-admin users if `allFields` is false.
     *
     * @param {string}      sourceKey
     * @param {number}      alertId
     * @param {boolean}     allFields
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<PublicAlert>}
     */
    getAlert(sourceKey, alertId, allFields, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        return currentUser.canReadAlert(sourceKey, alertId).then(() => {
            return AlertDAO.getAlert(alertId, allFields);
        }).then(alert => this._formatToPublicAlert(alert, allFields));
    }
    /**
     * Create/acquire the semaphore for the given alert.
     *
     * @param {number} alertId
     * @returns {Bluebird<void>} resolved when the slot is available
     * @private
     */
    _acquireAlertSemaphore(alertId) {
        if (!this._semaphores.has(alertId)) {
            this._semaphores.set(alertId, Utils.semaphore(1));
        }
        return this._semaphores.get(alertId).acquire();
    }
    /**
     * Release/destroy the semaphore for the given alert.
     *
     * @param {number} alertId
     * @private
     */
    _releaseAlertSemaphore(alertId) {
        const semaphore = this._semaphores.get(alertId);
        semaphore.release();
        if (semaphore.queue.length === 0 && semaphore.active === 0) {
            this._semaphores.delete(alertId);
        }
    }
    /**
     * Delete an alert.
     *
     * @param {number}      id
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<void>}
     */
    deleteAlert(id, currentUser) {
        return this._acquireAlertSemaphore(id).then(() => {
            Utils.check.exist('currentUser', currentUser);
            const schedulerTaskId = this._alertIdToSchedulerTaskId.get(id);
            // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
            if (Utils.hasValue(schedulerTaskId)) {
                Scheduler.cancel(schedulerTaskId);
            }
            return AlertDAO.deleteAlert(id).then(() => {
                this._alertIdToSchedulerTaskId.delete(id);
            });
        }).finally(() => this._releaseAlertSemaphore(id));
    }
    /**
     * Update an alert.
     *
     * id, sourceKey, userId, lastRun and lastRunProblem cannot be updated and will be silently
     * ignored.
     *
     * @param {number}          alertId
     * @param {AlertAttributes} newProperties
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<PublicAlert>}
     */
    updateAlert(alertId, newProperties, currentUser) {
        return this._acquireAlertSemaphore(alertId).then(() => {
            Utils.check.exist('currentUser', currentUser);
            return AlertDAO.updateAlert(alertId, newProperties).then(alert => {
                // if the columns field was changed, all the matches and actions
                // of the update alert are deleted and the alert, if enabled, rescheduled immediately
                const needCleanAlert = Utils.hasValue(newProperties.columns);
                // if the cron field was changed, we reschedule immediately
                const needReschedule = Utils.hasValue(newProperties.cron);
                return Promise.resolve().then(() => {
                    if (needCleanAlert) {
                        Log.info(`Update of alert #${alertId} required to delete all previous matches.`);
                        return AlertDAO.deleteMatchAndActions(alertId);
                    }
                }).then(() => {
                    const schedulerTaskId = this._alertIdToSchedulerTaskId.get(alert.id);
                    // schedulerTaskId doesn't exist if the alert is not enabled or the alert service is not started
                    if (Utils.hasValue(schedulerTaskId)) {
                        Scheduler.cancel(schedulerTaskId);
                    }
                    if (alert.enabled) {
                        const id = Scheduler.scheduleTask(this.runAlert.bind(this, alert), alert.cron, {
                            group: ALERT_GROUP,
                            lastRun: (needCleanAlert || needReschedule) ? new Date(0) : alert.lastRun
                        });
                        if (this._isAlertServiceStarted) {
                            this._alertIdToSchedulerTaskId.set(alert.id, id);
                        }
                    }
                    else {
                        this._alertIdToSchedulerTaskId.delete(alert.id);
                    }
                    return this._formatToPublicAlert(alert, true);
                });
            });
        }).finally(() => this._releaseAlertSemaphore(alertId));
    }
    /**
     * Get all the matches for a given alert.
     *
     * All the matches have an addition field called 'viewers'.
     * It shows the last `DEFAULT_NUMBER_OF_VIEWERS_IN_GET_MATCHES` unique viewers (excluding the
     * current user) ordered by date.
     *
     * @param {string}      sourceKey
     * @param {number}      alertId
     * @param {object}      options
     * @param {string}      [options.sortDirection]
     * @param {string}      [options.sortBy]
     * @param {number}      [options.offset=0]
     * @param {number}      [options.limit=20]
     * @param {string}      [options.status]
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<PublicMatch[]>}
     */
    getMatches(sourceKey, alertId, options, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        let columnsDescription;
        return currentUser.canReadAlert(sourceKey, alertId).then(() => {
            return AlertDAO.getAlert(alertId, true).then(alert => {
                columnsDescription = alert.columns;
            });
        }).then(() => {
            return AlertDAO.getMatches(alertId, currentUser, options);
        }).map(match => this._formatToPublicMatch(match, columnsDescription));
    }
    /**
     * Get the count for each possible status of all the matches for a given alert.
     *
     * @param {string} sourceKey
     * @param {number} alertId
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<{unconfirmed: number, confirmed: number, dismissed: number}>}
     */
    getMatchCount(sourceKey, alertId, currentUser) {
        Utils.check.exist('currentUser', currentUser);
        return currentUser.canReadAlert(sourceKey, alertId).then(() => {
            return AlertDAO.getMatchCount(alertId);
        });
    }
    /**
     * @param {number}      matchId
     * @param {WrappedUser} currentUser
     * @param {string}      [sourceKey]
     * @param {number}      [alertId]
     * @returns {Bluebird<MatchInstance>}
     * @private
     */
    _getMatch(matchId, currentUser, sourceKey, alertId) {
        Utils.check.posInt('matchId', matchId);
        Utils.check.exist('currentUser', currentUser);
        return AlertDAO.getMatch(matchId, currentUser).then(match => {
            if (Utils.hasValue(alertId) && alertId !== match.alertId) {
                return Errors.business('invalid_parameter', `Match #${matchId} doesn't belong to alert #${alertId}.`, true);
            }
            if (Utils.hasValue(sourceKey) && sourceKey !== match.sourceKey) {
                return Errors.business('invalid_parameter', `Match #${matchId} doesn't belong to data-source "${sourceKey}".`, true);
            }
            return currentUser.canReadAlert(match.sourceKey, match.alertId).return(match);
        });
    }
    /**
     * Get a match by id.
     *
     * @param {number}      matchId
     * @param {WrappedUser} currentUser
     * @param {string}      [sourceKey]
     * @param {number}      [alertId]
     * @returns {Bluebird<PublicMatch>}
     */
    getMatch(matchId, currentUser, sourceKey, alertId) {
        let columnsDescription;
        return Promise.resolve().then(() => {
            if (Utils.hasValue(alertId)) {
                return AlertDAO.getAlert(alertId, true).then(alert => {
                    columnsDescription = alert.columns;
                });
            } // else we don't populate the columns property in the match
            // This case occurs in populate sandbox by match id (where the alert id is not immediately available)
        }).then(() => {
            return this._getMatch(matchId, currentUser, sourceKey, alertId);
        }).then(match => this._formatToPublicMatch(match, columnsDescription));
    }
    /**
     * Do an action on a match.
     *
     * @param {string}      sourceKey
     * @param {number}      alertId
     * @param {number}      matchId
     * @param {string}      action
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<void>}
     */
    doMatchAction(sourceKey, alertId, matchId, action, currentUser) {
        return this._getMatch(matchId, currentUser, sourceKey, alertId).then(match => {
            return AlertDAO.doMatchAction(match, action, currentUser).return();
        });
    }
    /**
     * Get all the actions for a given match.
     *
     * @param {string}      sourceKey
     * @param {number}      alertId
     * @param {number}      matchId
     * @param {object}      options
     * @param {number}      [options.offset=0]
     * @param {number}      [options.limit=20]
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<PublicMatchAction[]>}
     */
    getMatchActions(sourceKey, alertId, matchId, options, currentUser) {
        /**
         * _getMatch is used for access control.
         * We need to retrieve the match to be sure that `alertId` is equal to `match.alertId`
         */
        return this._getMatch(matchId, currentUser, sourceKey, alertId).then(() => {
            return AlertDAO.getMatchActions(matchId, options)
                .map(action => this._formatToPublicMatchAction(action));
        });
    }
    /**
     * Get the promise of the next execution of a given alert by id.
     *
     * @param {number} alertId
     * @returns {Bluebird<void>}
     */
    getPromise(alertId) {
        return Scheduler.getPromise(this._alertIdToSchedulerTaskId.get(alertId)).return();
    }
    /**
     * Delete confirmed duplicate matches.
     * The migration to matches v2 was broken because the hashes were not recomputed.
     * To fix that, we recompute the hashes and we remove duplicate matches.
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    cleanUpDuplicateMatches() {
        return AlertDAO.cleanUpDuplicateMatches();
    }
}
module.exports = new AlertService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWxlcnQvaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUNyQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUV2QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUM7QUFDNUIsTUFBTSx3Q0FBd0MsR0FBRyxDQUFDLENBQUM7QUFFbkQ7Ozs7R0FJRztBQUNILFNBQVMsaUJBQWlCO0lBQ3hCLE9BQU8sUUFBUSxDQUFDLGlCQUFpQixFQUFFLENBQUM7QUFDdEMsQ0FBQztBQUVELE1BQU0sWUFBWTtJQUVoQjtRQUNFLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzNDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxvQkFBb0IsQ0FBQyxhQUFhLEVBQUUsT0FBTztRQUN6QyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU5RSxJQUFJLE9BQU8sRUFBRTtZQUNYLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRTdFLGdHQUFnRztZQUNoRyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7Z0JBQ25DLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FDbEQsZUFBZSxDQUNoQixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFFL0IsNEZBQTRGO2dCQUM1RixJQUFJLE9BQU8sR0FBRyxXQUFXLEVBQUU7b0JBQ3pCLDhDQUE4QztvQkFDOUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUM7aUJBQ25DO3FCQUFNO29CQUNMLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2lCQUMvQjthQUNGO2lCQUFNO2dCQUNMLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2FBQzVCO1NBQ0Y7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILG9CQUFvQixDQUFDLGFBQWEsRUFBRSxrQkFBa0I7UUFDcEQsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQzVELGFBQWEsRUFBRSxrQkFBa0IsQ0FDbEMsQ0FBQztRQUVGLGdDQUFnQztRQUNoQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLFdBQVcsQ0FBQyxJQUFJLEdBQUc7Z0JBQ2pCLEVBQUUsRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3pCLFFBQVEsRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQ3JDLEtBQUssRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUs7YUFDaEMsQ0FBQztTQUNIO2FBQU07WUFDTCxXQUFXLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztTQUN6QjtRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDN0MsV0FBVyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDekIsT0FBTyx3QkFBd0IsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQy9DO1FBRUQsa0RBQWtEO1FBQ2xELHNFQUFzRTtRQUV0RSw4QkFBOEI7UUFDOUIsTUFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNsQyxNQUFNLGtCQUFrQixHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFckMsS0FBSyxNQUFNLE1BQU0sSUFBSSxhQUFhLENBQUMsWUFBWSxFQUFFO1lBQy9DLE1BQU0sWUFBWSxHQUFHLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXhELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDbEUsZUFBZSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUN0RDtZQUVELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUMxQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtvQkFDcEMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUTtvQkFDOUIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSztpQkFDekIsQ0FBQyxDQUFDO2FBQ0o7U0FDRjtRQUVELDBEQUEwRDtRQUMxRCxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELFlBQVksR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbEUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsd0NBQXdDLENBQUMsQ0FBQztRQUVoRSxnREFBZ0Q7UUFDaEQsV0FBVyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsRUFBRTtZQUMvQyxNQUFNLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0MsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEIsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLHdCQUF3QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCwwQkFBMEIsQ0FBQyxtQkFBbUI7UUFDNUMsTUFBTSxpQkFBaUIsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBRWhHLGdDQUFnQztRQUNoQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDNUMsaUJBQWlCLENBQUMsSUFBSSxHQUFHO2dCQUN2QixFQUFFLEVBQUUsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQy9CLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUTtnQkFDM0MsS0FBSyxFQUFFLG1CQUFtQixDQUFDLElBQUksQ0FBQyxLQUFLO2FBQ3RDLENBQUM7U0FDSDthQUFNO1lBQ0wsaUJBQWlCLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztTQUMvQjtRQUVELE9BQU8saUJBQWlCLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsS0FBSztRQUNILElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDakMsR0FBRyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBQ2hDLE9BQU87U0FDUjtRQUNELElBQUk7WUFDRixTQUFTLENBQUMsbUJBQW1CLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVuRix5REFBeUQ7WUFDekQsU0FBUyxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFDLENBQUMsQ0FBQztZQUU3RSxPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbEQsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUU7b0JBQzFCLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTt3QkFDakIsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLFlBQVksQ0FDL0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUMvQixLQUFLLENBQUMsSUFBSSxFQUNWOzRCQUNFLEtBQUssRUFBRSxXQUFXOzRCQUNsQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQzt5QkFDbkUsQ0FDRixDQUFDO3dCQUNGLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztxQkFDbEQ7aUJBQ0Y7Z0JBQ0QsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQztTQUNKO1FBQUMsT0FBTSxHQUFHLEVBQUU7WUFDWCxHQUFHLENBQUMsS0FBSyxDQUFDLHVFQUF1RSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3pGO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFFBQVEsQ0FBQyxLQUFLO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3JCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0QixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7WUFDbEIsU0FBUyxFQUFFLEtBQUssQ0FBQyxTQUFTO1lBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMsVUFBVTtTQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDekI7OztlQUdHO1lBQ0gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsSUFBSSxHQUFHLFlBQVksT0FBTyxDQUFDLGlCQUFpQixFQUFFO2dCQUM1QyxNQUFNLEdBQUcsQ0FBQzthQUNYO1lBRUQsR0FBRyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUUvRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMvQixPQUFPLEVBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBQyxDQUFDO2FBQzdDO1lBRUQsT0FBTyxFQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQixnREFBZ0Q7WUFDaEQsS0FBSyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFDL0IsS0FBSyxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLE9BQU8sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDOUIsSUFBSSxDQUFDLENBQUMsR0FBRyxZQUFZLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO29CQUMvQyxHQUFHLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxLQUFLLENBQUMsRUFBRSxtQkFBbUIsRUFBRSxHQUFHLENBQUMsQ0FBQztpQkFDbEY7WUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsbUJBQW1CLENBQUMsZ0JBQWdCLEVBQUUsS0FBSztRQUN6QyxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNyRCxPQUFPLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxXQUFXLENBQUMsUUFBUSxFQUFFLFdBQVc7UUFDL0IsT0FBTyxRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDOUQsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtnQkFDaEQsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLFlBQVksQ0FDL0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUMvQixLQUFLLENBQUMsSUFBSSxFQUNWLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyx1Q0FBdUM7aUJBQ25GLENBQUM7Z0JBQ0YsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQ2xEO1lBQ0QsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsU0FBUyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVztRQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUMsT0FBTyxRQUFRLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUM7YUFDNUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQzthQUN6RCxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFFBQVEsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxXQUFXO1FBQ2pELEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM5QyxPQUFPLFdBQVcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDNUQsT0FBTyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUMvQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHNCQUFzQixDQUFDLE9BQU87UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDbkQ7UUFDRCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ2pELENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHNCQUFzQixDQUFDLE9BQU87UUFDNUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEQsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3BCLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzFELElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2xDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxFQUFFLEVBQUUsV0FBVztRQUN6QixPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQy9DLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM5QyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRS9ELGdHQUFnRztZQUNoRyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7Z0JBQ25DLFNBQVMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDbkM7WUFDRCxPQUFPLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILFdBQVcsQ0FBQyxPQUFPLEVBQUUsYUFBYSxFQUFFLFdBQVc7UUFDN0MsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNwRCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDOUMsT0FBTyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQy9ELGdFQUFnRTtnQkFDaEUscUZBQXFGO2dCQUNyRixNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDN0QsMkRBQTJEO2dCQUMzRCxNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFMUQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDakMsSUFBSSxjQUFjLEVBQUU7d0JBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLE9BQU8sMkNBQTJDLENBQUMsQ0FBQzt3QkFDakYsT0FBTyxRQUFRLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ2hEO2dCQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1gsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBRXJFLGdHQUFnRztvQkFDaEcsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUNuQyxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO3FCQUNuQztvQkFDRCxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7d0JBQ2pCLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxZQUFZLENBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFDL0IsS0FBSyxDQUFDLElBQUksRUFDVjs0QkFDRSxLQUFLLEVBQUUsV0FBVzs0QkFDbEIsT0FBTyxFQUFFLENBQUMsY0FBYyxJQUFJLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU87eUJBQzFFLENBQ0YsQ0FBQzt3QkFDRixJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTs0QkFDL0IsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO3lCQUNsRDtxQkFDRjt5QkFBTTt3QkFDTCxJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztxQkFDakQ7b0JBRUQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFDSCxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsV0FBVztRQUNqRCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUMsSUFBSSxrQkFBa0IsQ0FBQztRQUN2QixPQUFPLFdBQVcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDNUQsT0FBTyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ25ELGtCQUFrQixHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDNUQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxXQUFXO1FBQzNDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM5QyxPQUFPLFdBQVcsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDNUQsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxTQUFTLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTztRQUNoRCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdkMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTlDLE9BQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzFELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDeEQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFBRSxVQUFVLE9BQU8sNkJBQTZCLE9BQU8sR0FBRyxFQUFFLElBQUksQ0FDcEYsQ0FBQzthQUNIO1lBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsS0FBSyxLQUFLLENBQUMsU0FBUyxFQUFFO2dCQUM5RCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixVQUFVLE9BQU8sbUNBQW1DLFNBQVMsSUFBSSxFQUNqRSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsT0FBTyxXQUFXLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoRixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFFBQVEsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPO1FBQy9DLElBQUksa0JBQWtCLENBQUM7UUFDdkIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQzNCLE9BQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNuRCxrQkFBa0IsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUNyQyxDQUFDLENBQUMsQ0FBQzthQUNKLENBQUMsMkRBQTJEO1lBQzdELHFHQUFxRztRQUN2RyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxhQUFhLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFdBQVc7UUFDNUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUMzRSxPQUFPLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNyRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNILGVBQWUsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsV0FBVztRQUMvRDs7O1dBR0c7UUFDSCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUN4RSxPQUFPLFFBQVEsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztpQkFDOUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDNUQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxVQUFVLENBQUMsT0FBTztRQUNoQixPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ3BGLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsdUJBQXVCO1FBQ3JCLE9BQU8sUUFBUSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDNUMsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDIn0=