"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-30.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../index");
const Errors = LKE.getErrors();
const Data = LKE.getData();
const Utils = LKE.getUtils();
const Db = LKE.getSqlDb();
const AccessRightDAO = LKE.getAccessRightDAO();
const VisualizationShareDAO = LKE.getVisualizationShareDAO();
// locals
const Actions = require("./actions");
const ACCESS = {
    READABLE: 'readable',
    EDITABLE: 'editable',
    WRITABLE: 'writable',
    NONE: 'none'
};
class WrappedUser {
    /**
     * Create a WrappedUser starting from a PublicUserWithGroups.
     *
     * @param user A user without its private fields, with groups and actions
     */
    constructor(user, application) {
        if (Utils.noValue(user)) {
            throw Errors.technical('bug', 'Can not wrap a user that is null or undefined');
        }
        this.resultCache = new Map();
        // copy basic fields
        this.id = user.id;
        this.username = user.username;
        this.email = user.email;
        this.source = user.source;
        this.preferences = user.preferences;
        this.actions = user.actions;
        this.accessRights = user.accessRights;
        this.groups = user.groups;
        this.createdAt = user.createdAt;
        this.updatedAt = user.updatedAt;
        // if defined, an application is acting on behalf of the user
        this.application = application;
        // builtinAccessRights: quick way to check for access rights on a data-source
        this.builtinAccessRights = {};
        this.admin = false;
        // visibleSourceKeys: used to see if the user belongs to any group of the data-source
        this.visibleSourceKeys = new Set();
        _.forEach(this.groups, group => {
            this.visibleSourceKeys.add(group.sourceKey);
            // skip the group if not builtin
            if (!group.builtin) {
                return;
            }
            // we infer the access rights from the name of the builtin group
            switch (group.name) {
                case Db.models.group.READ_ONLY_GROUP_NAME:
                case Db.models.group.READ_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'read';
                    break;
                case Db.models.group.READ_AND_EDIT_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'edit';
                    break;
                case Db.models.group.READ_EDIT_AND_DELETE_GROUP_NAME:
                case Db.models.group.SOURCE_MANAGER_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'write';
                    break;
                case Db.models.group.ADMIN_GROUP_NAME:
                    this.builtinAccessRights[group.sourceKey] = 'write';
                    this.admin = true;
                    break;
            }
        });
    }
    /**
     * Get the access statistic of a node: "readable", "editable" or "writable".
     *
     * @param sourceKey Key of the data-source
     * @param node
     */
    nodeAccess(sourceKey, node) {
        return Bluebird.join(this.canDeleteNode(sourceKey, node.id, false), this.canEditNode(sourceKey, node.id, false), (canDelete, canEdit) => {
            if (canDelete) {
                return ACCESS.WRITABLE;
            }
            else if (canEdit) {
                return ACCESS.EDITABLE;
            }
            else {
                return ACCESS.READABLE;
            }
        });
    }
    /**
     * Get the access statistic of an edge: "readable", "editable" or "writable".
     *
     * @param sourceKey Key of the data-source
     * @param edge
     */
    edgeAccess(sourceKey, edge) {
        return Bluebird.join(this.canDeleteEdge(sourceKey, edge.id, false), this.canEditEdge(sourceKey, edge.id, false), (canDelete, canEdit) => {
            if (canDelete) {
                return ACCESS.WRITABLE;
            }
            else if (canEdit) {
                return ACCESS.EDITABLE;
            }
            else {
                return ACCESS.READABLE;
            }
        });
    }
    /**
     * Populate each node statistic with the access statistic: "readable", "editable" or "writable".
     *
     * @param sourceKey Key of the data-source
     * @param nodes
     */
    addNodesAccess(sourceKey, nodes) {
        return Bluebird.map(nodes, node => {
            node.statistics = node.statistics || {};
            return this.nodeAccess(sourceKey, node)
                .then(nodeAccess => {
                node.statistics.access = nodeAccess;
            })
                .return(node);
        });
    }
    /**
     * Populate each edge statistic with the access statistic: "readable", "editable" or "writable".
     *
     * @param sourceKey Key of the data-source
     * @param edges
     */
    addEdgesAccess(sourceKey, edges) {
        return Bluebird.map(edges, edge => {
            edge.statistics = edge.statistics || {};
            return this.edgeAccess(sourceKey, edge)
                .then(access => {
                edge.statistics.access = access;
            })
                .return(edge);
        });
    }
    /**
     * Return a resolved promise if the user can manage users on at least one data-source or
     * on a particular data-source if `sourceKey` is defined.
     *
     * @param [sourceKey]
     */
    canManageUsers(sourceKey) {
        return Bluebird.resolve()
            .then(() => {
            return this.hasAction('admin.users', sourceKey);
        })
            .return();
    }
    /**
     * Return true if the user is an admin.
     */
    isAdmin() {
        return this.admin;
    }
    /**
     * Return true if the user belongs to at least 1 group of the data-source.
     * Throw if the user doesn't belong to any group of the data-source and `throwIfNot` is true.
     *
     * @param sourceKey         Key of the data-source
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canSeeDataSource(sourceKey, throwIfNot = true) {
        const canSee = this.visibleSourceKeys.has(sourceKey) || this.visibleSourceKeys.has('*');
        if (canSee || !throwIfNot) {
            return canSee;
        }
        throw Errors.access('forbidden', 'You can\'t read data-source ' + sourceKey + '.');
    }
    /**
     * Cache of the result of `promiseFunction` indexed by `key`.
     *
     * @param key
     * @param promiseFunction
     */
    cached(key, promiseFunction) {
        if (this.resultCache.has(key)) {
            return Bluebird.resolve(this.resultCache.get(key));
        }
        else {
            return promiseFunction().then(result => {
                this.resultCache.set(key, result);
                return result;
            });
        }
    }
    /**
     * Get the list of target names (access rights) filtered by sourceKey, targetType and type.
     * If `type` is "read", targetNames where "read" is allowed implicitly (e.g. when type is "edit")
     * are returned as well.
     * A returned value of `["*"]` means all the target names.
     * If sourceKey is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * @param [sourceKey] Key of the data-source
     * @param targetType  Type of the target ("edgeType", "nodeCategory", "action", etc.)
     * @param type        Type of the right ("read", "write", etc.)
     */
    accessRightTargetNames(sourceKey, targetType, type) {
        if (Utils.noValue(sourceKey) && targetType !== 'action') {
            // only targetType 'actions' can span over multiple data-sources
            return Errors.technical('bug', 'sourceKey can\'t be null in accessRightTargetNames ' +
                'for targetType "nodeCategory", "edgeType" or "alert".', true);
        }
        return this.cached('AR/' + sourceKey + '/' + targetType + '/' + type, () => {
            return AccessRightDAO.getRights(this, targetType, type, sourceKey);
        });
    }
    /**
     * Return true if the current user can read everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canReadAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write', 'edit', 'read'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Return true if the current user can edit everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canEditAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write', 'edit'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Return true if the current user can write everything on the data-source given by `sourceKey`.
     *
     * @param sourceKey Key of the data-source
     */
    canDeleteAll(sourceKey) {
        return (this.builtinAccessRights['*'] === 'write' ||
            ['write'].includes(this.builtinAccessRights[sourceKey]));
    }
    /**
     * Get a list of the node categories readable by the current user.
     * Return `["*"]` if all categories are readable.
     *
     * @param sourceKey Key of the data-source
     */
    readableCategories(sourceKey) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'nodeCategory', 'read');
    }
    /**
     * Check if a list of node categories contains one (or all) readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to read all categories if true
     */
    hasReadableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the list of node categories contains a least one category readable by the user
        return this.readableCategories(sourceKey).then(readable => {
            if (readable[0] === '*') {
                return true;
            }
            if (nodeCategories.length === 0 &&
                readable.includes(AccessRightDAO.NO_CATEGORY_TARGET_NAME)) {
                return true;
            }
            const readableIntersect = _.intersection(nodeCategories, readable);
            const canRead = all
                ? readableIntersect.length === nodeCategories.length
                : readableIntersect.length > 0;
            if (canRead || !throwIfNot) {
                return canRead;
            }
            throw Errors.access('read_forbidden', `Cannot read node (${all ? 'some non-readable categories' : 'no readable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.cached('RN/' + sourceKey + '/' + WrappedUser.itemId(nodeOrNodeId), () => {
            return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
                return this.hasReadableCategory(sourceKey, node.categories, throwIfNot);
            });
        });
    }
    /**
     * Check if the given nodes (by node or id) are readable by the current user.
     *
     * @param sourceKey      Key of the data-source
     * @param nodesOrNodeIds Nodes or IDs of nodes
     */
    canReadNodes(sourceKey, nodesOrNodeIds) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve();
        }
        return Bluebird.map(nodesOrNodeIds, nodeOrNodeId => this.canReadNode(sourceKey, nodeOrNodeId)).return();
    }
    /**
     * Map node/edge types to the correct access level.
     *
     * @param sourceKey Key of the data-source
     * @param type      'node' or 'edge'
     */
    getAccessLevelByType(sourceKey, type) {
        return Bluebird.resolve()
            .then(() => {
            if (type === 'node') {
                return Bluebird.props({
                    [ACCESS.READABLE]: this.readableCategories(sourceKey),
                    [ACCESS.EDITABLE]: this.editableCategories(sourceKey),
                    [ACCESS.WRITABLE]: this.deletableCategories(sourceKey)
                });
            }
            else {
                return Bluebird.props({
                    [ACCESS.READABLE]: this.readableTypes(sourceKey),
                    [ACCESS.EDITABLE]: this.editableTypes(sourceKey),
                    [ACCESS.WRITABLE]: this.deletableTypes(sourceKey)
                });
            }
        })
            .then(accessToCategoryOrType => {
            const categoryOrTypeToAccess = new Map();
            for (const accessLevel of [ACCESS.READABLE, ACCESS.EDITABLE, ACCESS.WRITABLE]) {
                // access levels should be populated from readable to writable
                // this ensures that the rights are overwritten correctly
                const categoriesOrTypes = accessToCategoryOrType[accessLevel];
                if (_.isEqual(categoriesOrTypes, ['*'])) {
                    categoryOrTypeToAccess.set('*', accessLevel);
                }
                else {
                    _.forEach(categoriesOrTypes, categoryOrType => {
                        categoryOrTypeToAccess.set(categoryOrType, accessLevel);
                    });
                }
            }
            return categoryOrTypeToAccess;
        });
    }
    /**
     * Assign the correct access level to node or edge types.
     *
     * @param sourceKey Key of the data-source
     * @param type      'node' or 'edge'
     * @param schema
     */
    getSchemaWithAccess(sourceKey, type, schema) {
        return this.getAccessLevelByType(sourceKey, type).then(accessLevelByType => {
            const defaultAccess = accessLevelByType.get('*') || ACCESS.NONE;
            const schemaWithAccess = schema.results.map(schemaType => {
                return {
                    name: schemaType.name,
                    access: accessLevelByType.get(schemaType.name) || defaultAccess,
                    count: schemaType.count,
                    properties: schemaType.properties
                };
            });
            if (type === 'node') {
                // add a schema entry for nodes with no category
                schemaWithAccess.push({
                    name: null,
                    access: accessLevelByType.get(AccessRightDAO.NO_CATEGORY_TARGET_NAME) || defaultAccess,
                    count: 1,
                    properties: []
                });
            }
            return {
                any: {
                    access: defaultAccess
                },
                results: schemaWithAccess
            };
        });
    }
    /**
     * Get a list of the node categories editable by the current user.
     * Return `["*"]` if all categories are editable.
     *
     * @param sourceKey Key of the data-source
     */
    editableCategories(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'nodeCategory', 'edit');
    }
    /**
     * Check if a list of node categories contains one (or all) editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to edit all categories if true
     */
    hasEditableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the list of node categories contains a least one category editable by the user
        return this.editableCategories(sourceKey).then(editable => {
            if (editable[0] === '*') {
                return true;
            }
            if (nodeCategories.length === 0 &&
                editable.includes(AccessRightDAO.NO_CATEGORY_TARGET_NAME)) {
                return true;
            }
            const editableIntersect = _.intersection(nodeCategories, editable);
            const canEdit = all
                ? editableIntersect.length === nodeCategories.length
                : editableIntersect.length > 0;
            if (canEdit || !throwIfNot) {
                return canEdit;
            }
            throw Errors.access('write_forbidden', `Cannot edit node (${all ? 'some non-editable categories' : 'no editable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
            return this.hasEditableCategory(sourceKey, node.categories, throwIfNot);
        });
    }
    /**
     * Check if a list of node categories are all editable by the current user.
     *
     * @param sourceKey  Key of the data-source
     * @param categories A list of node categories
     */
    canEditCategories(sourceKey, categories) {
        return this.hasEditableCategory(sourceKey, categories, true, true).return();
    }
    /**
     * Get a list of the node categories deletable by the current user.
     * Return `["*"]` if all categories are deletable.
     *
     * @param sourceKey Key of the data-source
     */
    deletableCategories(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'nodeCategory', 'write');
    }
    /**
     * Check if a list of node categories contains one (or all) deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeCategories    A list of node categories
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     * @param [all]             Must be able to delete all categories if true
     */
    hasDeletableCategory(sourceKey, nodeCategories, throwIfNot = true, all) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the list of node categories contains a least one category deletable by the user
        return this.deletableCategories(sourceKey).then(deletable => {
            if (deletable[0] === '*') {
                return true;
            }
            if (nodeCategories.length === 0 &&
                deletable.includes(AccessRightDAO.NO_CATEGORY_TARGET_NAME)) {
                return true;
            }
            const deletableIntersect = _.intersection(nodeCategories, deletable);
            const canDelete = all
                ? deletableIntersect.length === nodeCategories.length
                : deletableIntersect.length > 0;
            if (canDelete || !throwIfNot) {
                return canDelete;
            }
            throw Errors.access('write_forbidden', `Cannot delete node (${all ? 'some non-deletable categories' : 'no deletable category'}).`);
        });
    }
    /**
     * Check if the given node (by node or id) is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param nodeOrNodeId      A node or the ID of a node
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteNode(sourceKey, nodeOrNodeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveNodeWithEdgeDigest(sourceKey, nodeOrNodeId).then(node => {
            return this.hasDeletableCategory(sourceKey, node.categories, throwIfNot).then(canDeleteCategory => {
                if (!canDeleteCategory) {
                    return false;
                }
                return this.deletableTypes(sourceKey).then(deletableTypes => {
                    if (deletableTypes[0] === '*') {
                        return true;
                    }
                    const canDelete = _.chain(node)
                        .get('statistics.supernodeDigest')
                        .map('edgeType')
                        .difference(deletableTypes)
                        .isEmpty()
                        .value();
                    if (!canDelete && throwIfNot) {
                        throw Errors.access('write_forbidden', 'Cannot delete edge.');
                    }
                    return canDelete;
                });
            });
        });
    }
    /**
     * If `nodeOrNodeId` is an LkNode resolve immediately with it.
     * If it's an ID, retrieve and resolve the LkNode.
     *
     * @param sourceKey    Key of the data-source
     * @param nodeOrNodeId A node or the ID of a node
     */
    static resolveNode(sourceKey, nodeOrNodeId) {
        if (typeof nodeOrNodeId === 'string') {
            // it was an ID
            return Data.getNodesByID({
                ids: [nodeOrNodeId],
                sourceKey: sourceKey
            }).get(0);
        }
        else {
            // it was already a node
            return Bluebird.resolve(nodeOrNodeId);
        }
    }
    /**
     * Get a node of the graph with a neighborhood edge digest in statistics.
     *
     * @param sourceKey    Key of the data-source
     * @param nodeOrNodeId A node or the ID of a node
     */
    static resolveNodeWithEdgeDigest(sourceKey, nodeOrNodeId) {
        return WrappedUser.resolveNode(sourceKey, nodeOrNodeId).then(node => {
            return Data.getEdgeDigest(sourceKey, node.id).then(edgeDigest => {
                node.statistics = node.statistics || {};
                node.statistics.supernodeDigest = edgeDigest;
                return node;
            });
        });
    }
    /**
     * Get a list of the edge types readable by the current user.
     * Return `["*"]` if all types are readable.
     *
     * @param sourceKey Key of the data-source
     */
    readableTypes(sourceKey) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'edgeType', 'read');
    }
    /**
     * Check if an edge type is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadType(sourceKey, edgeType, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the type is readable
        return this.readableTypes(sourceKey).then(readableTypes => {
            const canRead = readableTypes[0] === '*' || _.includes(readableTypes, edgeType);
            if (!canRead && throwIfNot) {
                throw Errors.access('read_forbidden', 'Cannot read edge.');
            }
            return canRead;
        });
    }
    /**
     * Check if the given edge (by edge or id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.cached('RE/' + sourceKey + '/' + WrappedUser.itemId(edgeOrEdgeId), () => {
            return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
                return this.canReadType(sourceKey, edge.type, throwIfNot).then(canReadType => {
                    if (!canReadType) {
                        return false;
                    }
                    // we have to be able to read the source and the target nodes to read the edge
                    return this.canReadNode(sourceKey, edge.source, throwIfNot).then(canReadSource => {
                        if (!canReadSource) {
                            return false;
                        }
                        return this.canReadNode(sourceKey, edge.target, throwIfNot);
                    });
                });
            });
        });
    }
    /**
     * Get a list of the edge types editable by the current user.
     * Return `["*"]` if all types are editable.
     *
     * @param sourceKey Key of the data-source
     */
    editableTypes(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'edgeType', 'edit');
    }
    /**
     * Check if an edge type is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditType(sourceKey, edgeType, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the type is editable
        return this.editableTypes(sourceKey).then(editableTypes => {
            const canEdit = editableTypes[0] === '*' || _.includes(editableTypes, edgeType);
            if (!canEdit && throwIfNot) {
                throw Errors.access('write_forbidden', 'Cannot edit edge.');
            }
            return canEdit;
        });
    }
    /**
     * Check if the given edge (by edge or id) is editable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canEditEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canEditAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
            return this.canEditType(sourceKey, edge.type, throwIfNot);
        });
    }
    /**
     * Get a list of the edge types deletable by the current user.
     * Return `["*"]` if all types are deletable.
     *
     * @param sourceKey Key of the data-source
     */
    deletableTypes(sourceKey) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve([]);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(['*']);
        }
        return this.accessRightTargetNames(sourceKey, 'edgeType', 'write');
    }
    /**
     * Check if an edge type is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeType          An edge type
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteType(sourceKey, edgeType, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        // check if the type is deletable
        return this.deletableTypes(sourceKey).then(deletableTypes => {
            const canDelete = deletableTypes[0] === '*' || _.includes(deletableTypes, edgeType);
            if (!canDelete && throwIfNot) {
                throw Errors.access('write_forbidden', 'Cannot delete edge.');
            }
            return canDelete;
        });
    }
    /**
     * Check if the given edge (by edge or id) is deletable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param edgeOrEdgeId      An edge or the ID of an edge
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canDeleteEdge(sourceKey, edgeOrEdgeId, throwIfNot = true) {
        if (Data.resolveSource(sourceKey).isReadOnly()) {
            return Bluebird.resolve(false);
        }
        if (this.canDeleteAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return WrappedUser.resolveEdge(sourceKey, edgeOrEdgeId).then(edge => {
            return this.canDeleteType(sourceKey, edge.type, throwIfNot);
        });
    }
    /**
     * Check if the given alert (by id) is readable by the current user.
     *
     * @param sourceKey         Key of the data-source
     * @param alertId           ID of the alert
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    canReadAlert(sourceKey, alertId, throwIfNot = true) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(true);
        }
        return this.accessRightTargetNames(sourceKey, 'alert', 'read').then(readableAlertIds => {
            // user can read all alerts => ok
            if (readableAlertIds[0] === '*') {
                return true;
            }
            // alertId (as string) found in readable alert ids => ok
            if (readableAlertIds.indexOf(alertId + '') >= 0) {
                return true;
            }
            if (!throwIfNot) {
                return false;
            }
            throw Errors.access('read_forbidden', `You don't have read access to Alert #${alertId}.`);
        });
    }
    /**
     * Keep only readable nodes with readable digest, readable properties and readable categories.
     * Keep only readable edges with readable properties.
     *
     * @param sourceKey
     * @param result
     * @param options
     * @param [options.withAccess]
     * @param [options.discardNodesWithNoEdges]
     * @param [options.allOrNothing]
     */
    filterSubGraph(sourceKey, subgraph, options) {
        return this.filterNodesContent(sourceKey, subgraph.nodes).then(nodes => {
            return this.filterEdgesContent(sourceKey, subgraph.edges).then(edges => {
                if (options.allOrNothing &&
                    (subgraph.nodes.length !== nodes.length || subgraph.edges.length !== edges.length)) {
                    subgraph.nodes = [];
                    subgraph.edges = [];
                    return subgraph;
                }
                subgraph.nodes = nodes;
                subgraph.edges = edges;
                // if we got the subgraph by edge id or edge search, we are interested
                // in keeping the nodes only if the edges are kept as well in the subgraph
                if (options.discardNodesWithNoEdges) {
                    const seenNodeIds = new Set();
                    for (let i = 0; i < edges.length; i++) {
                        seenNodeIds.add(edges[i].source);
                        seenNodeIds.add(edges[i].target);
                    }
                    // we only keep nodes that appear at least once in an edge
                    subgraph.nodes = _.filter(subgraph.nodes, node => seenNodeIds.has(node.id));
                }
                if (!options.withAccess) {
                    return subgraph;
                }
                return this.addNodesAccess(sourceKey, subgraph.nodes)
                    .then(() => this.addEdgesAccess(sourceKey, subgraph.edges))
                    .return(subgraph);
            });
        });
    }
    /**
     * Filter an array of nodes to return only the ones readable by the current user.
     *
     * @param sourceKey Key of the data-source
     * @param nodes     Nodes
     */
    filterReadableNodes(sourceKey, nodes) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(nodes);
        }
        if (Utils.noValue(nodes) || nodes.length === 0) {
            return Bluebird.resolve(nodes);
        }
        return Bluebird.reduce(nodes, (filtered, node) => {
            return this.canReadNode(sourceKey, node, false).then(readable => {
                if (readable) {
                    filtered.push(node);
                }
                return filtered;
            });
        }, []);
    }
    /**
     * Filter an array of edges to return only the ones readable by the current user.
     * (i.e. edges with TYPE, SOURCE and TARGET readable by current user).
     *
     * @param sourceKey Key of the data-source
     * @param edges     Edges
     */
    filterReadableEdges(sourceKey, edges) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(edges);
        }
        if (Utils.noValue(edges) || edges.length === 0) {
            return Bluebird.resolve(edges);
        }
        return Bluebird.reduce(edges, (filtered, edge) => {
            return this.canReadEdge(sourceKey, edge, false).then(readable => {
                if (readable) {
                    filtered.push(edge);
                }
                return filtered;
            });
        }, []);
    }
    /**
     * Keep only readable nodes with readable digest, readable properties and readable categories.
     *
     * @param sourceKey Key of the data-source
     * @param nodes     A node array
     */
    filterNodesContent(sourceKey, nodes) {
        return this.filterReadableNodes(sourceKey, nodes).map(readableNode => {
            return this.filterNodeContent(sourceKey, readableNode);
        });
    }
    /**
     * Keep only readable edges with readable properties.
     *
     * @param sourceKey Key of the data-source
     * @param edges     An edge array
     */
    filterEdgesContent(sourceKey, edges) {
        return this.filterReadableEdges(sourceKey, edges).map(readableEdge => {
            return this.filterEdgeProperties(sourceKey, readableEdge);
        });
    }
    /**
     * Filter the categories of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeCategories(sourceKey, node) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(node);
        }
        return this.readableCategories(sourceKey).then(readable => {
            if (readable[0] === '*') {
                return node;
            }
            node.categories = _.intersection(node.categories, readable);
            return node;
        });
    }
    /**
     * Filter the content of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeContent(sourceKey, node) {
        return this.filterNodeCategories(sourceKey, node).then(filteredNode => {
            node = this.filterNodeProperties(sourceKey, filteredNode);
            return this.filterNodeDigest(sourceKey, node);
        });
    }
    /**
     * Filter the digest of a node.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node
     */
    filterNodeDigest(sourceKey, node) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(node);
        }
        // nothing to do if the digest is not there
        if (!node.statistics || !node.statistics.digest) {
            return Bluebird.resolve(node);
        }
        return this.filterDigest(sourceKey, node.statistics.digest).then(filteredDigest => {
            node.statistics.digest = filteredDigest;
            return node;
        });
    }
    /**
     * Filter the content of an adjacency digest for readable categories and types.
     * Regroup digest items accordingly.
     *
     * @param sourceKey Key of the data-source
     * @param digest    The adjacency digest of a node
     */
    filterDigest(sourceKey, digest) {
        if (this.canReadAll(sourceKey)) {
            return Bluebird.resolve(digest);
        }
        return this.readable(sourceKey).then(readable => {
            return _.chain(digest)
                .filter(entry => {
                if (readable.categoryMap['*'] || entry.nodeCategories.length === 0) {
                    // can read all node categories OR no node categories on entry => check only edge type
                    return readable.typeMap[entry.edgeType];
                }
                else {
                    // filter to readable categories
                    entry.nodeCategories = _.intersection(readable.categories, entry.nodeCategories);
                    return entry.nodeCategories.length > 0 && readable.typeMap[entry.edgeType];
                }
            })
                .groupBy(entry => {
                // entry group key
                return entry.edgeType + '/' + entry.nodeCategories;
            })
                .values()
                .map(entryGroup => {
                const mergedEntry = entryGroup[0];
                for (let i = 1; i < entryGroup.length; ++i) {
                    mergedEntry.nodes += entryGroup[i].nodes;
                    mergedEntry.edges += entryGroup[i].edges;
                }
                return mergedEntry;
            })
                .value();
        });
    }
    /**
     * Return the readable categories and types.
     *
     * @param sourceKey Key of the data-source
     */
    readable(sourceKey) {
        return Bluebird.join(this.readableCategories(sourceKey), this.readableTypes(sourceKey), (readableCategories, readableTypes) => {
            let i;
            const result = {
                categoryMap: {},
                typeMap: {},
                categories: readableCategories,
                types: readableTypes
            };
            for (i = 0; i < readableCategories.length; ++i) {
                result.categoryMap[readableCategories[i]] = true;
            }
            for (i = 0; i < readableTypes.length; ++i) {
                result.typeMap[readableTypes[i]] = true;
            }
            return result;
        });
    }
    /**
     * Throw a business LkError if the current user can't write the given folder.
     *
     * @param folder
     */
    canWriteFolder(folder) {
        const canWrite = this.id === folder.userId;
        if (!canWrite) {
            throw Errors.access('write_forbidden');
        }
    }
    /**
     * Throw a business LkError if the current user has no right on the visualization.
     * Return 'owner', 'write' or 'read' (reject if no right exists).
     *
     * @param visualization
     */
    getVisualizationRight(visualization) {
        return VisualizationShareDAO.getRight(visualization, this.id);
    }
    /**
     * Throw a business LkError if the current user doesn't have the needed right on the visualization.
     *
     * @param visualization
     * @param neededRight
     */
    hasVisualizationRight(visualization, neededRight) {
        return this.getVisualizationRight(visualization).then(right => {
            if (neededRight === 'read' && !right) {
                throw Errors.access('read_forbidden', 'You need read access to this visualization.');
            }
            if (neededRight === 'write' && right !== 'write' && right !== 'owner') {
                throw Errors.access('write_forbidden', 'You need write or owner access to this visualization.');
            }
            if (neededRight === 'owner' && right !== 'owner') {
                throw Errors.access('write_forbidden', 'You need owner access to this visualization.');
            }
        });
    }
    /**
     * Throw a business error if some properties of the given node are hidden.
     *
     * @param sourceKey    Key of the data-source
     * @param [node]       A node
     * @param [properties] Optional property array for the deleted ones
     */
    checkHiddenNodeProperties(sourceKey, node, properties) {
        if (!node || (!node.data && !properties)) {
            return;
        }
        const hiddenProperties = Data.resolveSource(sourceKey).getHiddenNodeProperties();
        // check the optional property array
        if (properties && Array.isArray(properties)) {
            const hiddenKeys = _.intersection(properties, hiddenProperties);
            if (hiddenKeys.length > 0) {
                throw Errors.business('node_property_hidden', 'Node property "' + hiddenKeys[0] + '" is not accessible (disabled by administrator)');
            }
        }
        // check the node
        let hiddenKey;
        if (node.data) {
            for (let i = 0; i < hiddenProperties.length; ++i) {
                hiddenKey = hiddenProperties[i];
                if (node.data[hiddenKey] !== undefined) {
                    throw Errors.business('node_property_hidden', 'Node property "' + hiddenKey + '" is not accessible (disabled by administrator)');
                }
            }
        }
    }
    /**
     * Throw a business error if some properties of the given edge are hidden.
     *
     * @param sourceKey    Key of the data-source
     * @param [edge]       An edge
     * @param [properties] Optional property array for the deleted ones
     */
    checkHiddenEdgeProperties(sourceKey, edge, properties) {
        if (!edge || (!edge.data && !properties)) {
            return;
        }
        const hiddenProperties = Data.resolveSource(sourceKey).getHiddenEdgeProperties();
        // check the optional property array
        if (properties && Array.isArray(properties)) {
            const hiddenKeys = _.intersection(properties, hiddenProperties);
            if (hiddenKeys.length > 0) {
                throw Errors.access('edge_property_hidden', 'Edge property "' + hiddenKeys[0] + '" is not accessible (disabled by administrator)');
            }
        }
        if (edge.data) {
            for (let i = 0; i < hiddenProperties.length; ++i) {
                const hiddenKey = hiddenProperties[i];
                if (edge.data[hiddenKey] !== undefined) {
                    throw Errors.access('edge_property_hidden', 'Edge property "' + hiddenKey + '" is not accessible (disabled by administrator)');
                }
            }
        }
    }
    /**
     * Check if `properties` is readable in the given source.
     * Always succeed if `properties` is undefined or empty.
     *
     * @param type         'node' or 'edge'
     * @param sourceKey    Key of the data-source
     * @param [properties] Properties to check if hidden
     */
    canReadProperties(type, sourceKey, properties) {
        if (properties === undefined || properties.length === 0) {
            return Bluebird.resolve();
        }
        const hiddenProperties = type === 'node'
            ? Data.resolveSource(sourceKey).getHiddenNodeProperties()
            : Data.resolveSource(sourceKey).getHiddenEdgeProperties();
        const hidden = _.intersection(hiddenProperties, properties);
        if (hidden.length === 0) {
            return Bluebird.resolve();
        }
        return Errors.access(type + '_property_hidden', `${_.capitalize(type)} property "${hidden[0]}" is not accessible (disabled by administrator)`, true);
    }
    /**
     * Check if `property` is readable in the given source.
     * Always succeed if `property` is undefined.
     *
     * @param type       'node' or 'edge'
     * @param sourceKey  Key of the data-source
     * @param [property] Property to check if hidden
     */
    canReadProperty(type, sourceKey, property) {
        if (property === undefined) {
            return Bluebird.resolve();
        }
        return this.canReadProperties(type, sourceKey, [property]);
    }
    /**
     * Shorthand method for source.filterNodeProperties.
     *
     * @param sourceKey Key of the data-source
     * @param node      A node or a node array
     */
    filterNodeProperties(sourceKey, node) {
        return Data.resolveSource(sourceKey).filterNodeProperties(node);
    }
    /**
     * Shorthand method for source.filterEdgeProperties.
     *
     * @param sourceKey Key of the data-source
     * @param edge      An edge or an edge array
     */
    filterEdgeProperties(sourceKey, edge) {
        return Data.resolveSource(sourceKey).filterEdgeProperties(edge);
    }
    /**
     * Check if the given action (by action name) is doable by the current user.
     * - If sourceKey is `undefined`, it checks that the user can do the action in *at least one* source.
     * - If sourceKey is '*', it checks that the user can do the action in *all* sources.
     *
     * @param actionName        Name of the action
     * @param [sourceKey]       Key of the data-source
     * @param [throwIfNot=true] Whether to reject if the condition is not met
     */
    hasAction(actionName, sourceKey, throwIfNot = true) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve().then(() => {
                if (!Actions.exists(actionName)) {
                    return Errors.technical('bug', 'action "' + actionName + '" doesn\'t exist.', true);
                }
                return this.accessRightTargetNames(sourceKey, 'action', 'do').then(actions => {
                    if (actions[0] === '*') {
                        return true;
                    }
                    // if the required action is "runQuery"; "rawReadQuery" and "rawWriteQuery" satisfy it
                    const actionNames = Utils.hasValue(Actions.IMPLICIT_ACTIONS.get(actionName))
                        ? Actions.IMPLICIT_ACTIONS.get(actionName)
                        : [actionName];
                    const hasAction = _.intersection(actions, actionNames).length > 0;
                    if (hasAction || !throwIfNot) {
                        return hasAction;
                    }
                    let dataSourceMsg = '';
                    if (sourceKey && sourceKey === '*') {
                        dataSourceMsg = ' on all data-sources.';
                    }
                    else if (sourceKey) {
                        dataSourceMsg = ' on data-source ' + sourceKey + '.';
                    }
                    else {
                        dataSourceMsg = ' on any data-source.';
                    }
                    throw Errors.access('forbidden', 'You can\'t do action "' + actionName + '"' + dataSourceMsg);
                });
            });
        });
    }
    /**
     * If `edgeOrEdgeId` is an LkEdge resolve immediately with it.
     * If it's an ID, retrieve and resolve the LkEdge.
     *
     * @param sourceKey    Key of the data-source
     * @param edgeOrEdgeId An edge or the ID of an edge
     */
    static resolveEdge(sourceKey, edgeOrEdgeId) {
        if (Utils.noValue(edgeOrEdgeId)) {
            return Errors.technical('edge_not_found', 'Edge not found.', true);
        }
        const type = typeof edgeOrEdgeId;
        if (type === 'string') {
            // was an ID
            return Data.getEdgesByID({ ids: [edgeOrEdgeId], sourceKey: sourceKey }).get(0);
        }
        else {
            // was already an edge
            return Bluebird.resolve(edgeOrEdgeId);
        }
    }
    /**
     * If `itemOrItemId` is an object return the property `id`.
     * If it's an ID, return it directly.
     *
     * @param itemOrItemId
     */
    static itemId(itemOrItemId) {
        const type = typeof itemOrItemId;
        if (type === 'string') {
            return itemOrItemId;
        }
        else {
            return itemOrItemId.id;
        }
    }
}
exports.WrappedUser = WrappedUser;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV3JhcHBlZFVzZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL1dyYXBwZWRVc2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7Ozs7Ozs7OztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCxnQ0FBaUM7QUFDakMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUMzQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0FBQy9DLE1BQU0scUJBQXFCLEdBQUcsR0FBRyxDQUFDLHdCQUF3QixFQUFFLENBQUM7QUFFN0QsU0FBUztBQUNULHFDQUFzQztBQUV0QyxNQUFNLE1BQU0sR0FBRztJQUNiLFFBQVEsRUFBRSxVQUFVO0lBQ3BCLFFBQVEsRUFBRSxVQUFVO0lBQ3BCLFFBQVEsRUFBRSxVQUFVO0lBQ3BCLElBQUksRUFBRSxNQUFNO0NBQ2IsQ0FBQztBQUVGLE1BQWEsV0FBVztJQXlCdEI7Ozs7T0FJRztJQUNILFlBQVksSUFBMEIsRUFBRSxXQUErQjtRQUNyRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdkIsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSwrQ0FBK0MsQ0FBQyxDQUFDO1NBQ2hGO1FBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTdCLG9CQUFvQjtRQUNwQixJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQzlCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDdEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzFCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNoQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFFaEMsNkRBQTZEO1FBQzdELElBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBRS9CLDZFQUE2RTtRQUM3RSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBRW5CLHFGQUFxRjtRQUNyRixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUVuQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDN0IsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFNUMsZ0NBQWdDO1lBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFO2dCQUNsQixPQUFPO2FBQ1I7WUFFRCxnRUFBZ0U7WUFDaEUsUUFBUSxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUNsQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDO2dCQUMxQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGVBQWU7b0JBQ2xDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsTUFBTSxDQUFDO29CQUNuRCxNQUFNO2dCQUNSLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsd0JBQXdCO29CQUMzQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE1BQU0sQ0FBQztvQkFDbkQsTUFBTTtnQkFDUixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixDQUFDO2dCQUNyRCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLHlCQUF5QjtvQkFDNUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPLENBQUM7b0JBQ3BELE1BQU07Z0JBQ1IsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0I7b0JBQ25DLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDO29CQUNwRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztvQkFDbEIsTUFBTTthQUNUO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxVQUFVLENBQUMsU0FBaUIsRUFBRSxJQUFZO1FBQ2hELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFDN0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFDM0MsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDckIsSUFBSSxTQUFTLEVBQUU7Z0JBQ2IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ3hCO2lCQUFNLElBQUksT0FBTyxFQUFFO2dCQUNsQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ3hCO1FBQ0gsQ0FBQyxDQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxVQUFVLENBQUMsU0FBaUIsRUFBRSxJQUFZO1FBQ2hELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFDN0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFDM0MsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDckIsSUFBSSxTQUFTLEVBQUU7Z0JBQ2IsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ3hCO2lCQUFNLElBQUksT0FBTyxFQUFFO2dCQUNsQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ3hCO1FBQ0gsQ0FBQyxDQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxjQUFjLENBQW1CLFNBQWlCLEVBQUUsS0FBVTtRQUNuRSxPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ2hDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUM7WUFDeEMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7aUJBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLFVBQStCLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQztZQUM1RCxDQUFDLENBQUM7aUJBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksY0FBYyxDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDbkUsT0FBTyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRTtZQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDO1lBQ3hDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO2lCQUNwQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLFVBQStCLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUN4RCxDQUFDLENBQUM7aUJBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksY0FBYyxDQUFDLFNBQWtCO1FBQ3RDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUM7YUFDRCxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7T0FFRztJQUNJLE9BQU87UUFDWixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGdCQUFnQixDQUFDLFNBQWlCLEVBQUUsYUFBc0IsSUFBSTtRQUNuRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFeEYsSUFBSSxNQUFNLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDekIsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUVELE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsOEJBQThCLEdBQUcsU0FBUyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLE1BQU0sQ0FBSSxHQUFXLEVBQUUsZUFBa0M7UUFDL0QsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUM3QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFNLENBQUMsQ0FBQztTQUN6RDthQUFNO1lBQ0wsT0FBTyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDbEMsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0ssc0JBQXNCLENBQzVCLFNBQTZCLEVBQzdCLFVBQWtCLEVBQ2xCLElBQVk7UUFFWixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksVUFBVSxLQUFLLFFBQVEsRUFBRTtZQUN2RCxnRUFBZ0U7WUFDaEUsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUNyQixLQUFLLEVBQ0wscURBQXFEO2dCQUNuRCx1REFBdUQsRUFDekQsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLEVBQUU7WUFDekUsT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxVQUFVLENBQUMsU0FBaUI7UUFDbEMsT0FBTyxDQUNMLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPO1lBQ3pDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQ3hFLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFVBQVUsQ0FBQyxTQUFpQjtRQUNsQyxPQUFPLENBQ0wsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU87WUFDekMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUNoRSxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxZQUFZLENBQUMsU0FBaUI7UUFDcEMsT0FBTyxDQUNMLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPO1lBQ3pDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUN4RCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksa0JBQWtCLENBQUMsU0FBaUI7UUFDekMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssbUJBQW1CLENBQ3pCLFNBQWlCLEVBQ2pCLGNBQXdCLEVBQ3hCLGFBQXNCLElBQUksRUFDMUIsR0FBYTtRQUViLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCwwRkFBMEY7UUFDMUYsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hELElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDdkIsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELElBQ0UsY0FBYyxDQUFDLE1BQU0sS0FBSyxDQUFDO2dCQUMzQixRQUFRLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyx1QkFBdUIsQ0FBQyxFQUN6RDtnQkFDQSxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVuRSxNQUFNLE9BQU8sR0FBRyxHQUFHO2dCQUNqQixDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxLQUFLLGNBQWMsQ0FBQyxNQUFNO2dCQUNwRCxDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVqQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDMUIsT0FBTyxPQUFPLENBQUM7YUFDaEI7WUFFRCxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLGdCQUFnQixFQUNoQixxQkFBcUIsR0FBRyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLElBQUksQ0FDdkYsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFdBQVcsQ0FDaEIsU0FBaUIsRUFDakIsWUFBNkIsRUFDN0IsYUFBc0IsSUFBSTtRQUUxQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxTQUFTLEdBQUcsR0FBRyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsR0FBRyxFQUFFO1lBQ2xGLE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNsRSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztZQUMxRSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksWUFBWSxDQUFDLFNBQWlCLEVBQUUsY0FBc0M7UUFDM0UsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxRQUFRLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsRUFBRSxDQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FDMUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNiLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLG9CQUFvQixDQUMxQixTQUFpQixFQUNqQixJQUFjO1FBRWQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQztvQkFDcEIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQztvQkFDckQsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQztvQkFDckQsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztpQkFDdkQsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUNwQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztvQkFDaEQsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7b0JBQ2hELENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDO2lCQUNsRCxDQUFDLENBQUM7YUFDSjtRQUNILENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO1lBQzdCLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUN6QyxLQUFLLE1BQU0sV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDN0UsOERBQThEO2dCQUM5RCx5REFBeUQ7Z0JBQ3pELE1BQU0saUJBQWlCLEdBQUcsc0JBQXNCLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzlELElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7b0JBQ3ZDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUM7aUJBQzlDO3FCQUFNO29CQUNMLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDLEVBQUU7d0JBQzVDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsV0FBVyxDQUFDLENBQUM7b0JBQzFELENBQUMsQ0FBQyxDQUFDO2lCQUNKO2FBQ0Y7WUFDRCxPQUFPLHNCQUFzQixDQUFDO1FBQ2hDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLG1CQUFtQixDQUN4QixTQUFpQixFQUNqQixJQUFjLEVBQ2QsTUFBbUI7UUFFbkIsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1lBQ3pFLE1BQU0sYUFBYSxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ2hFLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ3ZELE9BQU87b0JBQ0wsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJO29CQUNyQixNQUFNLEVBQUUsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxhQUFhO29CQUMvRCxLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUs7b0JBQ3ZCLFVBQVUsRUFBRSxVQUFVLENBQUMsVUFBVTtpQkFDbEMsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNuQixnREFBZ0Q7Z0JBQ2hELGdCQUFnQixDQUFDLElBQUksQ0FBQztvQkFDcEIsSUFBSSxFQUFFLElBQUk7b0JBQ1YsTUFBTSxFQUFFLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsSUFBSSxhQUFhO29CQUN0RixLQUFLLEVBQUUsQ0FBQztvQkFDUixVQUFVLEVBQUUsRUFBRTtpQkFDZixDQUFDLENBQUM7YUFDSjtZQUVELE9BQU87Z0JBQ0wsR0FBRyxFQUFFO29CQUNILE1BQU0sRUFBRSxhQUFhO2lCQUN0QjtnQkFDRCxPQUFPLEVBQUUsZ0JBQWdCO2FBQzFCLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGtCQUFrQixDQUFDLFNBQWlCO1FBQ3pDLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0I7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUVELE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxtQkFBbUIsQ0FDekIsU0FBaUIsRUFDakIsY0FBd0IsRUFDeEIsYUFBc0IsSUFBSSxFQUMxQixHQUFhO1FBRWIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCwwRkFBMEY7UUFDMUYsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3hELElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDdkIsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELElBQ0UsY0FBYyxDQUFDLE1BQU0sS0FBSyxDQUFDO2dCQUMzQixRQUFRLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyx1QkFBdUIsQ0FBQyxFQUN6RDtnQkFDQSxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVuRSxNQUFNLE9BQU8sR0FBRyxHQUFHO2dCQUNqQixDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxLQUFLLGNBQWMsQ0FBQyxNQUFNO2dCQUNwRCxDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVqQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDMUIsT0FBTyxPQUFPLENBQUM7YUFDaEI7WUFFRCxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLGlCQUFpQixFQUNqQixxQkFBcUIsR0FBRyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLElBQUksQ0FDdkYsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFdBQVcsQ0FDaEIsU0FBaUIsRUFDakIsWUFBNkIsRUFDN0IsYUFBc0IsSUFBSTtRQUUxQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzFFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksaUJBQWlCLENBQUMsU0FBaUIsRUFBRSxVQUFvQjtRQUM5RCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUM5RSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxtQkFBbUIsQ0FBQyxTQUFpQjtRQUMxQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssb0JBQW9CLENBQzFCLFNBQWlCLEVBQ2pCLGNBQXdCLEVBQ3hCLGFBQXNCLElBQUksRUFDMUIsR0FBYTtRQUViLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsMkZBQTJGO1FBQzNGLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUMxRCxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7Z0JBQ3hCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxJQUNFLGNBQWMsQ0FBQyxNQUFNLEtBQUssQ0FBQztnQkFDM0IsU0FBUyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsRUFDMUQ7Z0JBQ0EsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFFckUsTUFBTSxTQUFTLEdBQUcsR0FBRztnQkFDbkIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxjQUFjLENBQUMsTUFBTTtnQkFDckQsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFFbEMsSUFBSSxTQUFTLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQzVCLE9BQU8sU0FBUyxDQUFDO2FBQ2xCO1lBRUQsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixpQkFBaUIsRUFDakIsdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixJQUFJLENBQzNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxhQUFhLENBQ2xCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLGFBQXNCLElBQUk7UUFFMUIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNoQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLFdBQVcsQ0FBQyx5QkFBeUIsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hGLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FDM0UsaUJBQWlCLENBQUMsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFO29CQUN0QixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUMxRCxJQUFJLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7d0JBQzdCLE9BQU8sSUFBSSxDQUFDO3FCQUNiO29CQUVELE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO3lCQUM1QixHQUFHLENBQUMsNEJBQTRCLENBQUM7eUJBQ2pDLEdBQUcsQ0FBQyxVQUFVLENBQUM7eUJBQ2YsVUFBVSxDQUFDLGNBQWMsQ0FBQzt5QkFDMUIsT0FBTyxFQUFFO3lCQUNULEtBQUssRUFBRSxDQUFDO29CQUVYLElBQUksQ0FBQyxTQUFTLElBQUksVUFBVSxFQUFFO3dCQUM1QixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUscUJBQXFCLENBQUMsQ0FBQztxQkFDL0Q7b0JBQ0QsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQWlCLEVBQUUsWUFBNkI7UUFDekUsSUFBSSxPQUFPLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDcEMsZUFBZTtZQUNmLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDdkIsR0FBRyxFQUFFLENBQUMsWUFBc0IsQ0FBQztnQkFDN0IsU0FBUyxFQUFFLFNBQVM7YUFDckIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNYO2FBQU07WUFDTCx3QkFBd0I7WUFDeEIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLFlBQXNCLENBQUMsQ0FBQztTQUNqRDtJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLE1BQU0sQ0FBQyx5QkFBeUIsQ0FDdEMsU0FBaUIsRUFDakIsWUFBNkI7UUFFN0IsT0FBTyxXQUFXLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbEUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUM5RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDO2dCQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUM7Z0JBQzdDLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGFBQWEsQ0FBQyxTQUFpQjtRQUNwQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUVELE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFdBQVcsQ0FDaEIsU0FBaUIsRUFDakIsUUFBZ0IsRUFDaEIsYUFBc0IsSUFBSTtRQUUxQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDOUIsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO1FBRUQsZ0NBQWdDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxPQUFPLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVoRixJQUFJLENBQUMsT0FBTyxJQUFJLFVBQVUsRUFBRTtnQkFDMUIsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLG1CQUFtQixDQUFDLENBQUM7YUFDNUQ7WUFDRCxPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQ2hCLFNBQWlCLEVBQ2pCLFlBQTZCLEVBQzdCLGFBQXNCLElBQUk7UUFFMUIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLEdBQUcsRUFBRTtZQUNsRixPQUFPLFdBQVcsQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbEUsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtvQkFDM0UsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDaEIsT0FBTyxLQUFLLENBQUM7cUJBQ2Q7b0JBRUQsOEVBQThFO29CQUM5RSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO3dCQUMvRSxJQUFJLENBQUMsYUFBYSxFQUFFOzRCQUNsQixPQUFPLEtBQUssQ0FBQzt5QkFDZDt3QkFFRCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQzlELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGFBQWEsQ0FBQyxTQUFpQjtRQUNwQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxXQUFXLENBQ2hCLFNBQWlCLEVBQ2pCLFFBQWdCLEVBQ2hCLGFBQXNCLElBQUk7UUFFMUIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxnQ0FBZ0M7UUFDaEMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN4RCxNQUFNLE9BQU8sR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRWhGLElBQUksQ0FBQyxPQUFPLElBQUksVUFBVSxFQUFFO2dCQUMxQixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQzthQUM3RDtZQUNELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFdBQVcsQ0FDaEIsU0FBaUIsRUFDakIsWUFBNkIsRUFDN0IsYUFBc0IsSUFBSTtRQUUxQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM1RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGNBQWMsQ0FBQyxTQUFpQjtRQUNyQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxhQUFhLENBQ2xCLFNBQWlCLEVBQ2pCLFFBQWdCLEVBQ2hCLGFBQXNCLElBQUk7UUFFMUIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQzlDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNoQyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxpQ0FBaUM7UUFDakMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUMxRCxNQUFNLFNBQVMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXBGLElBQUksQ0FBQyxTQUFTLElBQUksVUFBVSxFQUFFO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUscUJBQXFCLENBQUMsQ0FBQzthQUMvRDtZQUNELE9BQU8sU0FBUyxDQUFDO1FBQ25CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGFBQWEsQ0FDbEIsU0FBaUIsRUFDakIsWUFBNkIsRUFDN0IsYUFBc0IsSUFBSTtRQUUxQixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDOUMsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2xFLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM5RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxZQUFZLENBQ2pCLFNBQWlCLEVBQ2pCLE9BQWUsRUFDZixhQUFzQixJQUFJO1FBRTFCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3JGLGlDQUFpQztZQUNqQyxJQUFJLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDL0IsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELHdEQUF3RDtZQUN4RCxJQUFJLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUMvQyxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDZixPQUFPLEtBQUssQ0FBQzthQUNkO1lBQ0QsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLHdDQUF3QyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQzVGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSSxjQUFjLENBQ25CLFNBQWlCLEVBQ2pCLFFBQVcsRUFDWCxPQUlDO1FBRUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDckUsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3JFLElBQ0UsT0FBTyxDQUFDLFlBQVk7b0JBQ3BCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssS0FBSyxDQUFDLE1BQU0sSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQ2xGO29CQUNBLFFBQVEsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNwQixRQUFRLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDcEIsT0FBTyxRQUFRLENBQUM7aUJBQ2pCO2dCQUVELFFBQVEsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUN2QixRQUFRLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztnQkFFdkIsc0VBQXNFO2dCQUN0RSwwRUFBMEU7Z0JBQzFFLElBQUksT0FBTyxDQUFDLHVCQUF1QixFQUFFO29CQUNuQyxNQUFNLFdBQVcsR0FBZ0IsSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFFM0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQ3JDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUNqQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDbEM7b0JBRUQsMERBQTBEO29CQUMxRCxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQzdFO2dCQUVELElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO29CQUN2QixPQUFPLFFBQVEsQ0FBQztpQkFDakI7Z0JBRUQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsS0FBSyxDQUFDO3FCQUNsRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUMxRCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDdEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG1CQUFtQixDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDeEUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQ3BCLEtBQUssRUFDTCxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzlELElBQUksUUFBUSxFQUFFO29CQUNaLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JCO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELEVBQVMsQ0FDVixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLG1CQUFtQixDQUFtQixTQUFpQixFQUFFLEtBQVU7UUFDeEUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNoQztRQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5QyxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDaEM7UUFFRCxPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQ3BCLEtBQUssRUFDTCxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQzlELElBQUksUUFBUSxFQUFFO29CQUNaLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JCO2dCQUNELE9BQU8sUUFBUSxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELEVBQVMsQ0FDVixDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksa0JBQWtCLENBQW1CLFNBQWlCLEVBQUUsS0FBVTtRQUN2RSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ25FLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxZQUFpQixDQUFDLENBQUM7UUFDOUQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxrQkFBa0IsQ0FBbUIsU0FBaUIsRUFBRSxLQUFVO1FBQ3ZFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDbkUsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLFlBQWlCLENBQUMsQ0FBQztRQUNqRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLG9CQUFvQixDQUFtQixTQUFpQixFQUFFLElBQU87UUFDdkUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4RCxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUM1RCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksaUJBQWlCLENBQW1CLFNBQWlCLEVBQUUsSUFBTztRQUNuRSxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3BFLElBQUksR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBRTFELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLGdCQUFnQixDQUFtQixTQUFpQixFQUFFLElBQU87UUFDbkUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELDJDQUEyQztRQUMzQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFO1lBQy9DLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtRQUVELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDL0UsSUFBSSxDQUFDLFVBQStCLENBQUMsTUFBTSxHQUFHLGNBQWMsQ0FBQztZQUM5RCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFlBQVksQ0FBQyxTQUFpQixFQUFFLE1BQXNCO1FBQzNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUM5QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7UUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7aUJBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDZCxJQUFJLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUNsRSxzRkFBc0Y7b0JBQ3RGLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3pDO3FCQUFNO29CQUNMLGdDQUFnQztvQkFDaEMsS0FBSyxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUNqRixPQUFPLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDNUU7WUFDSCxDQUFDLENBQUM7aUJBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNmLGtCQUFrQjtnQkFDbEIsT0FBTyxLQUFLLENBQUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQ3JELENBQUMsQ0FBQztpQkFDRCxNQUFNLEVBQUU7aUJBQ1IsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNoQixNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUMxQyxXQUFXLENBQUMsS0FBSyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ3pDLFdBQVcsQ0FBQyxLQUFLLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDMUM7Z0JBQ0QsT0FBTyxXQUFXLENBQUM7WUFDckIsQ0FBQyxDQUFDO2lCQUNELEtBQUssRUFBRSxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFFBQVEsQ0FDZCxTQUFpQjtRQU9qQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQ2xCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsRUFDbEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsRUFDN0IsQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLEVBQUUsRUFBRTtZQUNwQyxJQUFJLENBQUMsQ0FBQztZQUNOLE1BQU0sTUFBTSxHQUFHO2dCQUNiLFdBQVcsRUFBRSxFQUF5QjtnQkFDdEMsT0FBTyxFQUFFLEVBQXlCO2dCQUNsQyxVQUFVLEVBQUUsa0JBQWtCO2dCQUM5QixLQUFLLEVBQUUsYUFBYTthQUNyQixDQUFDO1lBQ0YsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzlDLE1BQU0sQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7YUFDbEQ7WUFDRCxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3pDLE1BQU0sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO2FBQ3pDO1lBRUQsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUNGLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGNBQWMsQ0FBQyxNQUFpQztRQUNyRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsRUFBRSxLQUFLLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDM0MsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQ3hDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0kscUJBQXFCLENBQUMsYUFBa0M7UUFDN0QsT0FBTyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxxQkFBcUIsQ0FDMUIsYUFBa0MsRUFDbEMsV0FBbUI7UUFFbkIsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzVELElBQUksV0FBVyxLQUFLLE1BQU0sSUFBSSxDQUFDLEtBQUssRUFBRTtnQkFDcEMsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLDZDQUE2QyxDQUFDLENBQUM7YUFDdEY7WUFDRCxJQUFJLFdBQVcsS0FBSyxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU8sSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFO2dCQUNyRSxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLGlCQUFpQixFQUNqQix1REFBdUQsQ0FDeEQsQ0FBQzthQUNIO1lBQ0QsSUFBSSxXQUFXLEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7Z0JBQ2hELE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSw4Q0FBOEMsQ0FBQyxDQUFDO2FBQ3hGO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0kseUJBQXlCLENBQzlCLFNBQWlCLEVBQ2pCLElBQXNDLEVBQ3RDLFVBQXFCO1FBRXJCLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN4QyxPQUFPO1NBQ1I7UUFDRCxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUVqRixvQ0FBb0M7UUFDcEMsSUFBSSxVQUFVLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMzQyxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2hFLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ3pCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsc0JBQXNCLEVBQ3RCLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxpREFBaUQsQ0FDdEYsQ0FBQzthQUNIO1NBQ0Y7UUFFRCxpQkFBaUI7UUFDakIsSUFBSSxTQUFTLENBQUM7UUFFZCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNoRCxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFTLEVBQUU7b0JBQ3RDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsc0JBQXNCLEVBQ3RCLGlCQUFpQixHQUFHLFNBQVMsR0FBRyxpREFBaUQsQ0FDbEYsQ0FBQztpQkFDSDthQUNGO1NBQ0Y7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0kseUJBQXlCLENBQzlCLFNBQWlCLEVBQ2pCLElBQXNDLEVBQ3RDLFVBQXFCO1FBRXJCLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN4QyxPQUFPO1NBQ1I7UUFDRCxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUVqRixvQ0FBb0M7UUFDcEMsSUFBSSxVQUFVLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMzQyxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2hFLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ3pCLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsc0JBQXNCLEVBQ3RCLGlCQUFpQixHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxpREFBaUQsQ0FDdEYsQ0FBQzthQUNIO1NBQ0Y7UUFFRCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDYixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNoRCxNQUFNLFNBQVMsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLFNBQVMsRUFBRTtvQkFDdEMsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUNqQixzQkFBc0IsRUFDdEIsaUJBQWlCLEdBQUcsU0FBUyxHQUFHLGlEQUFpRCxDQUNsRixDQUFDO2lCQUNIO2FBQ0Y7U0FDRjtJQUNILENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksaUJBQWlCLENBQ3RCLElBQWMsRUFDZCxTQUFpQixFQUNqQixVQUFxQjtRQUVyQixJQUFJLFVBQVUsS0FBSyxTQUFTLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdkQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFDRCxNQUFNLGdCQUFnQixHQUNwQixJQUFJLEtBQUssTUFBTTtZQUNiLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLHVCQUF1QixFQUFFO1lBQ3pELENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDOUQsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3ZCLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixJQUFJLEdBQUcsa0JBQWtCLEVBQ3pCLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlEQUFpRCxFQUM3RixJQUFJLENBQ0wsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksZUFBZSxDQUFDLElBQWMsRUFBRSxTQUFpQixFQUFFLFFBQWlCO1FBQ3pFLElBQUksUUFBUSxLQUFLLFNBQVMsRUFBRTtZQUMxQixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMzQjtRQUNELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG9CQUFvQixDQUE4QixTQUFpQixFQUFFLElBQU87UUFDakYsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG9CQUFvQixDQUE4QixTQUFpQixFQUFFLElBQU87UUFDakYsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNVLFNBQVMsQ0FDcEIsVUFBa0IsRUFDbEIsU0FBa0IsRUFDbEIsYUFBc0IsSUFBSTs7WUFFMUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQy9CLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxHQUFHLFVBQVUsR0FBRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDckY7Z0JBRUQsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQzNFLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTt3QkFDdEIsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBRUQsc0ZBQXNGO29CQUN0RixNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzFFLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQzt3QkFDMUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBRWpCLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBRWxFLElBQUksU0FBUyxJQUFJLENBQUMsVUFBVSxFQUFFO3dCQUM1QixPQUFPLFNBQVMsQ0FBQztxQkFDbEI7b0JBRUQsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO29CQUN2QixJQUFJLFNBQVMsSUFBSSxTQUFTLEtBQUssR0FBRyxFQUFFO3dCQUNsQyxhQUFhLEdBQUcsdUJBQXVCLENBQUM7cUJBQ3pDO3lCQUFNLElBQUksU0FBUyxFQUFFO3dCQUNwQixhQUFhLEdBQUcsa0JBQWtCLEdBQUcsU0FBUyxHQUFHLEdBQUcsQ0FBQztxQkFDdEQ7eUJBQU07d0JBQ0wsYUFBYSxHQUFHLHNCQUFzQixDQUFDO3FCQUN4QztvQkFFRCxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCx3QkFBd0IsR0FBRyxVQUFVLEdBQUcsR0FBRyxHQUFHLGFBQWEsQ0FDNUQsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssTUFBTSxDQUFDLFdBQVcsQ0FBQyxTQUFpQixFQUFFLFlBQTZCO1FBQ3pFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUMvQixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDcEU7UUFFRCxNQUFNLElBQUksR0FBRyxPQUFPLFlBQVksQ0FBQztRQUNqQyxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDckIsWUFBWTtZQUNaLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLFlBQXNCLENBQUMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDeEY7YUFBTTtZQUNMLHNCQUFzQjtZQUN0QixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBc0IsQ0FBQyxDQUFDO1NBQ2pEO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFzQztRQUMxRCxNQUFNLElBQUksR0FBRyxPQUFPLFlBQVksQ0FBQztRQUNqQyxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDckIsT0FBTyxZQUFzQixDQUFDO1NBQy9CO2FBQU07WUFDTCxPQUFRLFlBQWdDLENBQUMsRUFBRSxDQUFDO1NBQzdDO0lBQ0gsQ0FBQztDQUNGO0FBeGhERCxrQ0F3aERDIn0=