/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-17.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Data = LKE.getData();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const Actions = require('./actions');
class AccessRightDAO {
    /**
     * @type {AccessRightModel}
     */
    get model() {
        return Db.models.accessRight;
    }
    /**
     * @type {string}
     */
    get NO_CATEGORY_TARGET_NAME() {
        return '[no_category]';
    }
    /**
     * List all the possible right types.
     *
     * @returns {string[]}
     */
    listRightTypes() {
        return _.values(this.model.TYPES);
    }
    /**
     * List all the possible target types.
     *
     * @returns {string[]}
     */
    listTargetTypes() {
        return _.values(this.model.TARGET_TYPES);
    }
    /**
     * List all the possible actions for a custom group.
     *
     * @returns {string[]}
     */
    listActions() {
        return Actions.PUBLIC_ACTIONS;
    }
    /**
     * Validate the access rights that can be added to a custom group.
     * - No targetName "*" for targetType "nodeCategory" and "edgeType" (allowed for the builtin groups)
     * - No targetName "x" for targetType "nodeCategory" and "edgeType" if "x" is not in the schema and `validateAgainstSchema` is true
     *
     * @param {AccessRightAttributes[]} rights
     * @param {string}                  sourceKey
     * @param {boolean}                 [validateAgainstSchema] Whether the access rights will be checked to be of node categories or edge types in the schema
     * @returns {Bluebird<void>}
     */
    checkRights(rights, sourceKey, validateAgainstSchema) {
        const schemaPromise = validateAgainstSchema
            ? Promise.props({
                nodeCategories: Data.getSchemaNodeTypeNames(sourceKey),
                edgeTypes: Data.getSchemaEdgeTypeNames(sourceKey)
            })
            : Promise.resolve({ nodeCategories: [], edgeTypes: [] });
        return schemaPromise.then(schema => {
            const dataSource = Data.resolveSource(sourceKey);
            // if we allow nodes with no category
            if (validateAgainstSchema && dataSource.features.minNodeCategories === 0) {
                // we add the special category "[no_category]" to the possible access rights
                schema.nodeCategories.push(this.NO_CATEGORY_TARGET_NAME);
            }
            return Promise.map(rights, right => {
                Utils.check.properties('right', right, {
                    type: { required: true, values: this.listRightTypes() },
                    targetType: { required: true, values: this.listTargetTypes() },
                    targetName: { required: true, check: 'nonEmpty' },
                    sourceKey: { required: true, check: (key, value) => Utils.checkSourceKey(value) }
                });
                Utils.check.values('right.type', right.type, this.model.LEGAL_RIGHTS_BY_TARGET_TYPE.get(right.targetType));
                if (right.targetType === 'action') {
                    Utils.check.values('right.targetName', right.targetName, Actions.PUBLIC_ACTIONS);
                }
                if (right.targetType === 'nodeCategory' || right.targetType === 'edgeType') {
                    if (right.targetName === '*') {
                        return Errors.business('invalid_parameter', 'It\'s not possible to set "*" as "targetName" in a schema access right.', true);
                    }
                }
                if (validateAgainstSchema) {
                    if (right.targetType === 'nodeCategory') {
                        if (schema.nodeCategories.length === 0) {
                            return Errors.business('invalid_parameter', 'It\'s not possible to set "nodeCategory" as "targetType" ' +
                                'if no node category is available in the schema.', true);
                        }
                        Utils.check.values('right.targetName', right.targetName, schema.nodeCategories);
                    }
                    if (right.targetType === 'edgeType') {
                        if (schema.edgeTypes.length === 0) {
                            return Errors.business('invalid_parameter', 'It\'s not possible to set "edgeType" as "targetType" ' +
                                'if no edge type is available in the schema.', true);
                        }
                        Utils.check.values('right.targetName', right.targetName, schema.edgeTypes);
                    }
                }
            });
        }).return();
    }
    /**
     * Find a matching access right. An access right match with another one if their scopes
     * overlap (except wildcard "*").
     *
     * @param {number}                groupId ID of the group
     * @param {AccessRightAttributes} right   Access right to check
     * @returns {Bluebird<AccessRightInstance>}
     */
    findMatchingRight(groupId, right) {
        return this.model.findOne({
            where: {
                groupId: groupId,
                targetType: right.targetType,
                targetName: [right.targetName],
                sourceKey: right.sourceKey
            }
        });
    }
    /**
     * Get the list of target names (access rights) filtered by sourceKey, targetType and type.
     * If the type is "read" and on a given targetName the user has an higher type,
     * return that targetName in the result as well.
     * A returned value of `["*"]` means all the target names.
     *
     * If sourceKey is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * @param {PublicUser} publicUser  A public user with groups and access rights
     * @param {string}     targetType  Type of the target ("edgeType", "nodeCategory", "action", etc.)
     * @param {string}     type        Type of the right ("read", "write", etc.)
     * @param {string}     [sourceKey] Key of the data-source
     * @returns {Bluebird<string[]>} Matching target names
     */
    getRights(publicUser, targetType, type, sourceKey) {
        // if the type is "read", we also look for "edit" access rights
        const types = Utils.hasValue(this.model.IMPLICIT_RIGHTS.get(type))
            ? this.model.IMPLICIT_RIGHTS.get(type)
            : [type];
        let targetNames = [];
        if (Utils.hasValue(publicUser.groups)) {
            publicUser.groups.forEach(group => {
                // process each access right for each group in the data-source (or the admin group)
                if (Utils.hasValue(group.accessRights) &&
                    (group.sourceKey === sourceKey || group.sourceKey === '*' || Utils.noValue(sourceKey))) {
                    group.accessRights.forEach(accessRight => {
                        if (accessRight.targetType === targetType && types.includes(accessRight.type)) {
                            targetNames.push(accessRight.targetName);
                        }
                    });
                }
            });
        }
        // if targetNames includes the wildcard, return only the wildcard
        targetNames = targetNames.includes('*') ? ['*'] : targetNames;
        return Promise.resolve(targetNames);
    }
}
module.exports = new AccessRightDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWNjZXNzUmlnaHREQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL0FjY2Vzc1JpZ2h0REFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUVyQyxNQUFNLGNBQWM7SUFDbEI7O09BRUc7SUFDSCxJQUFJLEtBQUs7UUFDUCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksdUJBQXVCO1FBQ3pCLE9BQU8sZUFBZSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYztRQUNaLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsZUFBZTtRQUNiLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVztRQUNULE9BQU8sT0FBTyxDQUFDLGNBQWMsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsV0FBVyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUscUJBQXFCO1FBRWxELE1BQU0sYUFBYSxHQUFHLHFCQUFxQjtZQUN6QyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDZCxjQUFjLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQztnQkFDdEQsU0FBUyxFQUFFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUM7YUFDbEQsQ0FBQztZQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUMsY0FBYyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztRQUV6RCxPQUFPLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDakMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUVqRCxxQ0FBcUM7WUFDckMsSUFBSSxxQkFBcUIsSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLGlCQUFpQixLQUFLLENBQUMsRUFBRTtnQkFDeEUsNEVBQTRFO2dCQUM1RSxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQzthQUMxRDtZQUVELE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUU7b0JBQ3JDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBQztvQkFDckQsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFDO29CQUM1RCxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQy9DLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBQztpQkFDaEYsQ0FBQyxDQUFDO2dCQUVILEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUN6QyxJQUFJLENBQUMsS0FBSyxDQUFDLDJCQUEyQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQzdELENBQUM7Z0JBRUYsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFFBQVEsRUFBRTtvQkFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFDckQsT0FBTyxDQUFDLGNBQWMsQ0FDdkIsQ0FBQztpQkFDSDtnQkFFRCxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssY0FBYyxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFO29CQUMxRSxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO3dCQUM1QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQ3hDLHlFQUF5RSxFQUFFLElBQUksQ0FDaEYsQ0FBQztxQkFDSDtpQkFDRjtnQkFFRCxJQUFJLHFCQUFxQixFQUFFO29CQUN6QixJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssY0FBYyxFQUFFO3dCQUN2QyxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTs0QkFDdEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUN4QywyREFBMkQ7Z0NBQzNELGlEQUFpRCxFQUFFLElBQUksQ0FDeEQsQ0FBQzt5QkFDSDt3QkFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztxQkFDakY7b0JBRUQsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLFVBQVUsRUFBRTt3QkFDbkMsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7NEJBQ2pDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsdURBQXVEO2dDQUN2RCw2Q0FBNkMsRUFBRSxJQUFJLENBQ3BELENBQUM7eUJBQ0g7d0JBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7cUJBQzVFO2lCQUNGO1lBRUgsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsaUJBQWlCLENBQUMsT0FBTyxFQUFFLEtBQUs7UUFDOUIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUN4QixLQUFLLEVBQUU7Z0JBQ0wsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtnQkFDNUIsVUFBVSxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQkFDOUIsU0FBUyxFQUFFLEtBQUssQ0FBQyxTQUFTO2FBQzNCO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxTQUFTLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsU0FBUztRQUMvQywrREFBK0Q7UUFDL0QsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDdEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFWCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFFckIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNyQyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDaEMsbUZBQW1GO2dCQUNuRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztvQkFDcEMsQ0FBQyxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsU0FBUyxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3hGLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUN2QyxJQUFJLFdBQVcsQ0FBQyxVQUFVLEtBQUssVUFBVSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFOzRCQUM3RSxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQzt5QkFDMUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQsaUVBQWlFO1FBQ2pFLFdBQVcsR0FBRyxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFFOUQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxjQUFjLEVBQUUsQ0FBQyJ9