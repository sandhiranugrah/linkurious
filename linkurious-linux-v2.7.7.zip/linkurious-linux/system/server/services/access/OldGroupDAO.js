/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Data = LKE.getData();
const AccessRightDAO = LKE.getAccessRightDAO();
// locals
const UserCache = require('./UserCache');
const builtinGroups = require('./builtinGroups');
class OldGroupDAO {
    /**
     * @type {GroupModel}
     */
    get model() {
        return Db.models.group;
    }
    /**
     * Given a subset of access rights, the targetType and the node categories or the edge types
     * in the schema, produce the complete access rights set for the targetType:
     * - we expand `*` based on the schema information
     * - we set to `none` everything not in the access rights but in the schema
     *
     * @param {string}              targetType        'nodeCategory' or 'edgeType'
     * @param {PublicAccessRight[]} accessRights      Explicit access rights of a group
     * @param {string[]}            categoriesOrTypes List of node categories or edge types in the schema
     * @returns {PublicAccessRight[]}
     * @private
     */
    _expandAccessRights(targetType, accessRights, categoriesOrTypes) {
        // first we look for the wildcard access right, if present
        // 0 or 1 wildcards can be in the list
        let wildcardValue = Db.models.accessRight.TYPES.NONE;
        for (let i = 0; i < accessRights.length; ++i) {
            const currentRight = accessRights[i];
            if (currentRight.targetName === '*') {
                wildcardValue = currentRight.type;
                accessRights.splice(i, 1); // we remove the wildcard access right
                break;
            }
        }
        // now we set everything in the schema with the wildcardValue
        const missingAccessRightsTargetNames = _.difference(categoriesOrTypes, _.map(accessRights, 'targetName'));
        [].push.apply(accessRights, missingAccessRightsTargetNames.map(targetName => {
            return {
                type: wildcardValue,
                targetType: targetType,
                targetName: targetName
            };
        }));
        return accessRights;
    }
    /**
     * Return the proper access rights for a builtin group based on its name.
     *
     * @param {PublicGroup} group
     * @returns {PublicAccessRight[]}
     * @private
     */
    _getBuiltinAccessRights(group) {
        if (group.builtin) {
            switch (group.name) {
                case Db.models.group.READ_ONLY_GROUP_NAME:
                    return builtinGroups.READ_ONLY_ACCESS_RIGHTS;
                case Db.models.group.READ_GROUP_NAME:
                    return builtinGroups.READ_ACCESS_RIGHTS;
                case Db.models.group.READ_AND_EDIT_GROUP_NAME:
                    return builtinGroups.READ_EDIT_ACCESS_RIGHTS;
                case Db.models.group.READ_EDIT_AND_DELETE_GROUP_NAME:
                    return builtinGroups.READ_EDIT_DELETE_ACCESS_RIGHTS;
                case Db.models.group.SOURCE_MANAGER_GROUP_NAME:
                    return builtinGroups.SOURCE_MANAGER_ACCESS_RIGHTS;
                case Db.models.group.ADMIN_GROUP_NAME:
                    return builtinGroups.ADMIN_ACCESS_RIGHTS;
            }
        }
    }
    /**
     * In this function we do the following:
     * - we turn the groupInstance into group attributes
     * - we add the user-count to the group
     * - if `withAccessRights` we add the access rights for the group
     * - if `expandRights` is true
     *  - we expand `*` based on the schema information
     *  - we set to `none` everything not in the access rights but in the schema
     *
     * @param {GroupInstance} groupInstance               Group instance
     * @param {object}        [options]
     * @param {boolean}       [options.withAccessRights]  Whether to populate the accessRights
     * @param {boolean}       [options.withUserCount]     Whether to populate the userCount
     * @param {boolean}       [options.withDates]         Whether to populate the creation and update dates
     * @param {string}        [options.sourceKey]         Override sourceKey of the groupInstance (used to expand categories on the admin group)
     * @param {boolean}       [options.expandRights=true] Whether to expand the wildcard value on schema access rights
     * @returns {Bluebird<PublicGroup>}
     */
    formatToPublicGroup(groupInstance, options) {
        const group = this.model.instanceToPublicAttributes(groupInstance, options.withDates);
        let publicAccessRights;
        let sourceKey;
        const expandRights = options.expandRights !== false;
        return Promise.resolve().then(() => {
            if (!options.withUserCount) {
                return;
            }
            return Db.models.user.count({
                where: { id: { '$notIn': [Db.models.user.UNIQUE_USER_ID] } },
                include: [{
                        model: Db.models.group, where: { id: groupInstance.id }
                    }]
            }).then(count => {
                group.userCount = count;
            });
        }).then(() => {
            if (!options.withAccessRights) {
                return group;
            }
            // if we format the admin group, the sourceKey is '*' but we want to format it
            // correctly for a given data-source
            sourceKey = Utils.hasValue(options.sourceKey) ? options.sourceKey : groupInstance.sourceKey;
            // order of the statements is important because the admin group could have accessRights
            // saved in the sql db before the upgrade
            publicAccessRights = this._getBuiltinAccessRights(group);
            if (Utils.noValue(publicAccessRights)) {
                if (Utils.hasValue(groupInstance.accessRights)) {
                    publicAccessRights = groupInstance.accessRights.map(right => {
                        return Db.models.accessRight.instanceToPublicAttributes(right);
                    });
                }
                else {
                    publicAccessRights = [];
                }
            }
            if (!expandRights) {
                group.accessRights = publicAccessRights;
                return group;
            }
            return Promise.all([
                Data.getSchemaNodeTypeNames(sourceKey),
                Data.getSchemaEdgeTypeNames(sourceKey)
            ]).spread((nodeCategories, edgeTypes) => {
                // we add to the possible node categories the special category "[no_category]"
                const dataSource = Data.resolveSource(sourceKey);
                if (dataSource.features.minNodeCategories === 0) {
                    nodeCategories.push(AccessRightDAO.NO_CATEGORY_TARGET_NAME);
                }
                // we partition the access rights in schema related and non
                const [schemaAccessRights, otherAccessRights] = _.partition(publicAccessRights, right => right.targetType === Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY ||
                    right.targetType === Db.models.accessRight.TARGET_TYPES.EDGE_TYPE);
                group.accessRights = otherAccessRights;
                // all the schema-related access rights will be expanded to the whole schema
                // first we expand the wildcard `*`, then we fill the voids for the missing access rights
                // we partition them again in node category and edge type
                const [nodeAccessRights, edgeAccessRights] = _.partition(schemaAccessRights, right => right.targetType === Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY);
                [].push.apply(group.accessRights, this._expandAccessRights(Db.models.accessRight.TARGET_TYPES.NODE_CATEGORY, nodeAccessRights, nodeCategories));
                [].push.apply(group.accessRights, this._expandAccessRights(Db.models.accessRight.TARGET_TYPES.EDGE_TYPE, edgeAccessRights, edgeTypes));
                return group;
            });
        });
    }
    /**
     * Get multiple group instances by id.
     *
     * @param {number[]} groupIds           IDs of the groups
     * @param {boolean}  [withAccessRights] Whether to include the access rights
     * @returns {Bluebird<GroupInstance[]>}
     */
    getGroupInstances(groupIds, withAccessRights) {
        Utils.check.intArray('groupIds', groupIds);
        const query = { where: { id: groupIds } };
        if (withAccessRights) {
            query.include = [Db.models.accessRight];
        }
        return this.model.findAll(query).then(groups => {
            if (groups.length !== groupIds.length) {
                const missing = _.difference(groupIds, groups.map(g => g.id));
                if (missing.length > 0) {
                    return Errors.business('not_found', `Group #${missing[0]} was not found.`, true);
                }
            }
            return groups;
        });
    }
    /**
     * Retrieve a group instance by ID.
     * Return a rejected promise if the group wasn't found or if the sourceKey don't match.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<GroupInstance>}
     * @private
     */
    _getGroupInstance(groupId, sourceKey) {
        Utils.check.posInt('groupId', groupId);
        // check if the source exists and connected
        Data.resolveSource(sourceKey);
        return this.getGroupInstances([groupId], true).then(groupInstances => {
            // unwrap it from the array
            const group = groupInstances[0];
            if (group.sourceKey !== sourceKey) {
                return Errors.access('forbidden', `Group #${groupId} doesn't belong to data-source "${sourceKey}".`, true);
            }
            return group;
        });
    }
    /**
     * Get a group by id.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<PublicGroup>}
     */
    getGroup(groupId, sourceKey) {
        // it's possible to get also the admin group
        if (groupId === this.model.ADMIN_GROUP.id) {
            return this.formatToPublicGroup(this.model.ADMIN_GROUP, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true,
                sourceKey: sourceKey
            });
        }
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true
            });
        });
    }
    /**
     * Get all groups within a data-source.
     *
     * @param {string}  sourceKey          Key of the data-source
     * @param {boolean} [withAccessRights] Whether to include the access rights
     *
     * @returns {Bluebird<PublicGroup[]>}
     */
    getGroups(sourceKey, withAccessRights) {
        Data.resolveSource(sourceKey);
        const query = { where: { sourceKey: [sourceKey, '*'] } };
        if (withAccessRights) {
            query.include = [Db.models.accessRight];
        }
        return this.model.findAll(query).map(groupInstance => {
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: withAccessRights,
                withUserCount: true,
                withDates: true,
                sourceKey: sourceKey
            });
        });
    }
    /**
     * Create a group.
     *
     * @param {string} groupName Name of the group
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<PublicGroup>}
     */
    createGroup(groupName, sourceKey) {
        // check if the group name is legal
        Utils.check.nonEmpty('groupName', groupName);
        Data.resolveSource(sourceKey);
        return this.model.findOrCreate({ where: { name: groupName, sourceKey: sourceKey } })
            .spread((groupInstance, created) => {
            if (!created) {
                return Errors.business('group_exists', 'The group already exists', true);
            }
            return this.formatToPublicGroup(groupInstance, {
                withAccessRights: true,
                withUserCount: true,
                withDates: true
            });
        });
    }
    /**
     * Rename a group.
     *
     * @param {number} groupId   ID of the group
     * @param {string} sourceKey Key of the data-source
     * @param {string} name      New name of the group
     * @returns {Bluebird<PublicGroup>}
     */
    renameGroup(groupId, sourceKey, name) {
        // check if the group name is legal
        Utils.check.nonEmpty('name', name);
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'You can\'t rename a builtin group.', true);
            }
            groupInstance.name = name;
            return groupInstance.save().then(() => {
                UserCache.emptyCache();
                return this.formatToPublicGroup(groupInstance, {
                    withAccessRights: true,
                    withUserCount: true,
                    withDates: true
                });
            });
        });
    }
    /**
     * Delete a group and all the rights linked to that group.
     *
     * @param {number} groupId   ID of the group to delete
     * @param {string} sourceKey Key of the data-source
     * @returns {Bluebird<void>}
     */
    deleteGroup(groupId, sourceKey) {
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'You can\'t delete a builtin group.', true);
            }
            // we delete the access rights associated to the group
            return Db.models.accessRight.destroy({ where: { groupId: groupId } }).then(() => {
                UserCache.emptyCache();
                return groupInstance.destroy();
            });
        });
    }
    /**
     * Set an array of access rights on a group.
     *
     * @param {number}                  groupId                 ID of the group
     * @param {string}                  sourceKey               Key of the data-source
     * @param {AccessRightAttributes[]} rights                  Access rights to set
     * @param {boolean}                 [validateAgainstSchema] Whether the access rights will be checked to be of node categories or edge types in the schema
     * @returns {Bluebird<void>}
     */
    setRightsOnGroup(groupId, sourceKey, rights, validateAgainstSchema) {
        rights = rights.map(right => {
            right.sourceKey = sourceKey;
            return right;
        });
        Utils.check.array('rights', rights, 1);
        Data.resolveSource(sourceKey);
        // check that all the access rights are legit
        return AccessRightDAO.checkRights(rights, sourceKey, validateAgainstSchema).then(() => {
            return this._getGroupInstance(groupId, sourceKey);
        }).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'Cannot set access rights for builtin groups.', true);
            }
            return Promise.map(rights, right => {
                // we look for an existing access right with the same scope
                return AccessRightDAO.findMatchingRight(groupInstance.id, right).then(existingRight => {
                    // matching access rights exist
                    if (Utils.hasValue(existingRight)) {
                        // update the existing access right
                        existingRight.type = right.type;
                        return existingRight.save().return();
                    }
                    // no matching access right found, create a new one
                    return Db.models.accessRight.create(right).then(rightInstance => {
                        return groupInstance.addAccessRight(rightInstance);
                    }).return();
                });
            }, { concurrency: 1 });
        }).then(() => {
            UserCache.emptyCache();
        });
    }
    /**
     * Delete an access right from a group.
     *
     * @param {number} groupId    ID of the group
     * @param {string} sourceKey  Key of the data-source
     * @param {string} targetType Type of the target of the access rights to delete
     * @param {string} targetName Name of the target of the access rights to delete
     * @returns {Bluebird<void>}
     */
    deleteRightOnGroup(groupId, sourceKey, targetType, targetName) {
        // we check if the group exists and the sourceKey is valid
        return this._getGroupInstance(groupId, sourceKey).then(groupInstance => {
            if (groupInstance.builtin) {
                return Errors.access('forbidden', 'Cannot set access rights for builtin groups.', true);
            }
            const rightAttributes = {
                targetType,
                targetName,
                sourceKey,
                type: '' // AccessRightDAO.findMatchingRight doesn't care about the type
            };
            return AccessRightDAO.findMatchingRight(groupId, rightAttributes);
        }).then(rightInstance => {
            if (Utils.noValue(rightInstance)) {
                return Errors.business('not_found', 'Access right not found', true);
            }
            return rightInstance.destroy();
        }).then(() => {
            UserCache.emptyCache();
        });
    }
    /**
     * Return all the names of the groups that can perform a given action.
     *
     * @param sourceKey
     * @param [action]
     */
    getGroupNames(sourceKey, action) {
        return this.getGroups(sourceKey, true).then(groups => {
            if (Utils.hasValue(action)) {
                groups = _.filter(groups, group => {
                    let hasAction = false;
                    _.forEach(group.accessRights, accessRight => {
                        if (accessRight.targetType === 'action' &&
                            accessRight.type === 'do' &&
                            accessRight.targetName === action) {
                            hasAction = true;
                        }
                    });
                    return hasAction;
                });
            }
            return _.map(groups, group => ({
                id: group.id,
                name: group.name
            }));
        });
    }
}
module.exports = new OldGroupDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiT2xkR3JvdXBEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL09sZEdyb3VwREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLGlCQUFpQixFQUFFLENBQUM7QUFFL0MsU0FBUztBQUNULE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN6QyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUVqRCxNQUFNLFdBQVc7SUFDZjs7T0FFRztJQUNILElBQUksS0FBSztRQUNQLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsbUJBQW1CLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxpQkFBaUI7UUFDN0QsMERBQTBEO1FBQzFELHNDQUFzQztRQUN0QyxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3JELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQzVDLE1BQU0sWUFBWSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQyxJQUFJLFlBQVksQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUNuQyxhQUFhLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQztnQkFDbEMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxzQ0FBc0M7Z0JBQ2pFLE1BQU07YUFDUDtTQUNGO1FBRUQsNkRBQTZEO1FBQzdELE1BQU0sOEJBQThCLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FDakQsaUJBQWlCLEVBQ2pCLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUNsQyxDQUFDO1FBRUYsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLDhCQUE4QixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMxRSxPQUFPO2dCQUNMLElBQUksRUFBRSxhQUFhO2dCQUNuQixVQUFVLEVBQUUsVUFBVTtnQkFDdEIsVUFBVSxFQUFFLFVBQVU7YUFDdkIsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFSixPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsdUJBQXVCLENBQUMsS0FBSztRQUMzQixJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7WUFDakIsUUFBUSxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUNsQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQjtvQkFDdkMsT0FBTyxhQUFhLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9DLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZTtvQkFDbEMsT0FBTyxhQUFhLENBQUMsa0JBQWtCLENBQUM7Z0JBQzFDLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsd0JBQXdCO29CQUMzQyxPQUFPLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDL0MsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQywrQkFBK0I7b0JBQ2xELE9BQU8sYUFBYSxDQUFDLDhCQUE4QixDQUFDO2dCQUN0RCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLHlCQUF5QjtvQkFDNUMsT0FBTyxhQUFhLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3BELEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsZ0JBQWdCO29CQUNuQyxPQUFPLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQzthQUM1QztTQUNGO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILG1CQUFtQixDQUFDLGFBQWEsRUFBRSxPQUFPO1FBQ3hDLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN0RixJQUFJLGtCQUFrQixDQUFDO1FBQ3ZCLElBQUksU0FBUyxDQUFDO1FBQ2QsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLFlBQVksS0FBSyxLQUFLLENBQUM7UUFFcEQsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRTtnQkFDMUIsT0FBTzthQUNSO1lBRUQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQzFCLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFDLEVBQUM7Z0JBQ3hELE9BQU8sRUFBRSxDQUFDO3dCQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLEVBQUUsRUFBQztxQkFDdEQsQ0FBQzthQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2QsS0FBSyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDN0IsT0FBTyxLQUFLLENBQUM7YUFDZDtZQUVELDhFQUE4RTtZQUM5RSxvQ0FBb0M7WUFDcEMsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO1lBRTVGLHVGQUF1RjtZQUN2Rix5Q0FBeUM7WUFDekMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXpELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFO29CQUM5QyxrQkFBa0IsR0FBRyxhQUFhLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDMUQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDakUsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsa0JBQWtCLEdBQUcsRUFBRSxDQUFDO2lCQUN6QjthQUNGO1lBRUQsSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDakIsS0FBSyxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQztnQkFFeEMsT0FBTyxLQUFLLENBQUM7YUFDZDtZQUVELE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQztnQkFDakIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQzthQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxFQUFFLFNBQVMsRUFBRSxFQUFFO2dCQUN0Qyw4RUFBOEU7Z0JBQzlFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBRWpELElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsS0FBSyxDQUFDLEVBQUU7b0JBQy9DLGNBQWMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLENBQUM7aUJBQzdEO2dCQUVELDJEQUEyRDtnQkFDM0QsTUFBTSxDQUFDLGtCQUFrQixFQUFFLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsRUFDNUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxhQUFhO29CQUM5RSxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFFckUsS0FBSyxDQUFDLFlBQVksR0FBRyxpQkFBaUIsQ0FBQztnQkFFdkMsNEVBQTRFO2dCQUM1RSx5RkFBeUY7Z0JBRXpGLHlEQUF5RDtnQkFDekQsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsRUFDekUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFFbEYsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQ3hELEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQztnQkFFdkYsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQ3hELEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFFOUUsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGlCQUFpQixDQUFDLFFBQVEsRUFBRSxnQkFBZ0I7UUFDMUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRTNDLE1BQU0sS0FBSyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLFFBQVEsRUFBQyxFQUFDLENBQUM7UUFDdEMsSUFBSSxnQkFBZ0IsRUFBRTtZQUNwQixLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUN6QztRQUVELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzdDLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxRQUFRLENBQUMsTUFBTSxFQUFFO2dCQUNyQyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzlELElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3RCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBVSxPQUFPLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNsRjthQUNGO1lBRUQsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUztRQUNsQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFdkMsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFOUIsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDbkUsMkJBQTJCO1lBQzNCLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVoQyxJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFO2dCQUNqQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQ2xCLFdBQVcsRUFDWCxVQUFVLE9BQU8sbUNBQW1DLFNBQVMsSUFBSSxFQUNqRSxJQUFJLENBQ0wsQ0FBQzthQUNIO1lBQ0QsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVM7UUFDekIsNENBQTRDO1FBQzVDLElBQUksT0FBTyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRTtZQUN6QyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtnQkFDdEQsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsYUFBYSxFQUFFLElBQUk7Z0JBQ25CLFNBQVMsRUFBRSxJQUFJO2dCQUNmLFNBQVMsRUFBRSxTQUFTO2FBQ3JCLENBQUMsQ0FBQztTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNyRSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUU7Z0JBQzdDLGdCQUFnQixFQUFFLElBQUk7Z0JBQ3RCLGFBQWEsRUFBRSxJQUFJO2dCQUNuQixTQUFTLEVBQUUsSUFBSTthQUNoQixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsU0FBUyxDQUFDLFNBQVMsRUFBRSxnQkFBZ0I7UUFDbkMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU5QixNQUFNLEtBQUssR0FBRyxFQUFDLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBQyxFQUFDLENBQUM7UUFDckQsSUFBSSxnQkFBZ0IsRUFBRTtZQUNwQixLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUN6QztRQUVELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ25ELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRTtnQkFDN0MsZ0JBQWdCLEVBQUUsZ0JBQWdCO2dCQUNsQyxhQUFhLEVBQUUsSUFBSTtnQkFDbkIsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsU0FBUyxFQUFFLFNBQVM7YUFDckIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLFNBQVMsRUFBRSxTQUFTO1FBQzlCLG1DQUFtQztRQUNuQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFN0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU5QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQzthQUM3RSxNQUFNLENBQUMsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDakMsSUFBSSxDQUFDLE9BQU8sRUFBRTtnQkFDWixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLDBCQUEwQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzFFO1lBRUQsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFO2dCQUM3QyxnQkFBZ0IsRUFBRSxJQUFJO2dCQUN0QixhQUFhLEVBQUUsSUFBSTtnQkFDbkIsU0FBUyxFQUFFLElBQUk7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILFdBQVcsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUk7UUFDbEMsbUNBQW1DO1FBQ25DLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVuQyxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3JFLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxvQ0FBb0MsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMvRTtZQUVELGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBRTFCLE9BQU8sYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3BDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFO29CQUM3QyxnQkFBZ0IsRUFBRSxJQUFJO29CQUN0QixhQUFhLEVBQUUsSUFBSTtvQkFDbkIsU0FBUyxFQUFFLElBQUk7aUJBQ2hCLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsV0FBVyxDQUFDLE9BQU8sRUFBRSxTQUFTO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDckUsSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFO2dCQUN6QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQ2xCLFdBQVcsRUFBRSxvQ0FBb0MsRUFBRSxJQUFJLENBQ3hELENBQUM7YUFDSDtZQUVELHNEQUFzRDtZQUN0RCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDMUUsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUN2QixPQUFPLGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUscUJBQXFCO1FBQ2hFLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzFCLEtBQUssQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBQzVCLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXZDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFOUIsNkNBQTZDO1FBQzdDLE9BQU8sY0FBYyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNwRixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3RCLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixXQUFXLEVBQUUsOENBQThDLEVBQUUsSUFBSSxDQUNsRSxDQUFDO2FBQ0g7WUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNqQywyREFBMkQ7Z0JBQzNELE9BQU8sY0FBYyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO29CQUVwRiwrQkFBK0I7b0JBQy9CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRTt3QkFFakMsbUNBQW1DO3dCQUNuQyxhQUFhLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7d0JBQ2hDLE9BQU8sYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO3FCQUN0QztvQkFFRCxtREFBbUQ7b0JBQ25ELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTt3QkFDOUQsT0FBTyxhQUFhLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNyRCxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDZCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxVQUFVO1FBQzNELDBEQUEwRDtRQUMxRCxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3JFLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixXQUFXLEVBQUUsOENBQThDLEVBQUUsSUFBSSxDQUNsRSxDQUFDO2FBQ0g7WUFFRCxNQUFNLGVBQWUsR0FBRztnQkFDdEIsVUFBVTtnQkFDVixVQUFVO2dCQUNWLFNBQVM7Z0JBQ1QsSUFBSSxFQUFFLEVBQUUsQ0FBQywrREFBK0Q7YUFDekUsQ0FBQztZQUVGLE9BQU8sY0FBYyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQztRQUNwRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDdEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUNoQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLHdCQUF3QixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3JFO1lBRUQsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGFBQWEsQ0FBQyxTQUFTLEVBQUUsTUFBTTtRQUM3QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNuRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzFCLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDaEMsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN0QixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsV0FBVyxDQUFDLEVBQUU7d0JBQzFDLElBQ0UsV0FBVyxDQUFDLFVBQVUsS0FBSyxRQUFROzRCQUNuQyxXQUFXLENBQUMsSUFBSSxLQUFLLElBQUk7NEJBQ3pCLFdBQVcsQ0FBQyxVQUFVLEtBQUssTUFBTSxFQUFFOzRCQUNuQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3lCQUNsQjtvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFFSCxPQUFPLFNBQVMsQ0FBQztnQkFDbkIsQ0FBQyxDQUFDLENBQUM7YUFDSjtZQUVELE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUM3QixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO2FBQ2pCLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUMifQ==