/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-05-05.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const ldapjs = require('ldapjs');
// services
const LKE = require('../../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
/**
 * @typedef {{url: string, bindDN?: string, bindPassword?: string, baseDN: string[], usernameField: string, emailField?: string, groupField?: string, tls?: {rejectUnauthorized?: boolean}}} LkConfigAccessLdap
 */
const TIMEOUT = 5000;
const CONNECT_TIMEOUT = 5000;
class LDAPClient {
    /**
     * @param {LkConfigAccessLdap} options
     */
    constructor(options) {
        this._options = options;
        this._requiredAttributes = _.compact([
            options.usernameField,
            options.emailField,
            options.groupField
        ]);
        this._connected = false;
    }
    /**
     * Bind the LDAP client to the LDAP server.
     * Return a rejected promise if the bind was unsuccessful.
     *
     * @returns {Bluebird<boolean>}
     * @private
     */
    _bind() {
        return new Promise((resolve, reject) => {
            this._ldapjsClient.bind(this._options.bindDN, this._options.bindPassword, bindError => {
                if (bindError) {
                    this._ldapjsClient.destroy();
                    if (bindError.name === 'InvalidCredentialsError' ||
                        bindError.name === 'NoSuchObjectError') {
                        Log.debug('Bind LDAP client failure (credentials)');
                        resolve(false);
                    }
                    else {
                        reject(bindError);
                    }
                }
                else {
                    this._connected = true;
                    Log.debug('Bind LDAP client success');
                    resolve(true);
                }
            });
        });
    }
    /**
     * Initialize the client and bind the LDAP client to the LDAP server.
     * Return a rejected promise if the bind was unsuccessful.
     *
     * @returns {Bluebird<boolean>}
     */
    bind() {
        if (this._connected) {
            Log.debug('Attempt to bind but the LDAP client was already connected');
            return Promise.resolve(false);
        }
        this._initClient();
        return Utils.retryPromise('Bind to the LDAP server', () => this._bind(), { delay: 2000, retries: 5, fullErrors: false }).catch(error => {
            Log.error('Bind LDAP client failure (error)', error);
            return Errors.technical('ldap_bind_error', 'Could not connect to the LDAP server (' + (error.message ? error.message : error) + ')', true);
        });
    }
    /**
     * Unbind the LDAP client from the LDAP server.
     */
    unbind() {
        this._connected = false;
        this._ldapjsClient.destroy();
        Log.debug('Unbind LDAP client success');
    }
    /**
     * @private
     */
    _initClient() {
        this._ldapjsClient = ldapjs.createClient({
            url: this._options.url,
            maxConnections: 1,
            timeout: TIMEOUT,
            connectTimeout: CONNECT_TIMEOUT,
            tlsOptions: this._options.tls
        });
        const onError = e => {
            Log.error(e);
            this.unbind();
        };
        this._ldapjsClient.on('error', onError);
        this._ldapjsClient.on('timeout', () => onError('Request timed out'));
        this._ldapjsClient.on('connectTimeout', () => onError('Connection timed out'));
        Log.debug('LDAP client created');
    }
    /**
     * Check if the pair `username` and `password` is valid.
     *
     * @param {string} username
     * @param {string} password
     * @param {string} [baseDN]
     *
     * @returns {Bluebird<string | null>} the baseDN where the user is located or null, if the credentials are not valid
     * @private
     */
    _checkCredentials(username, password, baseDN) {
        let baseDNs;
        if (Utils.hasValue(baseDN)) { // if we know already the right baseDN because LDAPClient.findUser knew it already
            baseDNs = [baseDN];
        }
        else { // otherwise we look in all the possible configured baseDN
            baseDNs = this._options.baseDN;
        }
        return Promise.map(baseDNs, baseDN => {
            const bindDN = `${this._options.usernameField}=${username},${baseDN}`;
            const client = new LDAPClient(_.defaults({ bindDN: bindDN, bindPassword: password }, this._options));
            return client.bind().then(validCredentials => {
                if (!validCredentials) {
                    return null;
                }
                client.unbind();
                return baseDN;
            });
        }, { concurrency: 1 }).then(validBaseDNs => _.get(validBaseDNs.filter(Utils.hasValue), 0));
    }
    /**
     * Create an LDAP filter for `username` equality.
     *
     * @param {string} username
     * @private
     */
    _createLDAPFilter(username) {
        return new ldapjs.filters.AndFilter({ filters: [
                new ldapjs.filters.EqualityFilter({
                    attribute: this._options.usernameField,
                    value: username
                })
            ] });
    }
    /**
     * Search for `username` under `baseDN`. Return the LDAP search result.
     *
     * @param {string} username
     * @param {string} baseDN
     * @returns {Bluebird<any>}
     * @private
     */
    _doLDAPSearch(username, baseDN) {
        return new Promise((resolve, reject) => {
            this._ldapjsClient.search(baseDN, {
                scope: 'sub',
                filter: this._createLDAPFilter(username),
                attributes: this._requiredAttributes,
                sizeLimit: 1,
                timeLimit: TIMEOUT
            }, (error, searchEvents) => {
                if (error) {
                    Log.error(error);
                    this.unbind();
                    return reject(Errors.technical('critical', error));
                }
                let result = null;
                searchEvents.on('searchEntry', entry => { result = entry && entry.object; });
                searchEvents.on('error', error => {
                    if (error.name === 'NoSuchObjectError') {
                        return resolve();
                    }
                    Log.error(error);
                    this.unbind();
                    reject(Errors.technical('critical', 'Could not communicate with the LDAP server (' +
                        (error.message ? error.message : error) + ')'));
                });
                searchEvents.on('end', () => resolve(result));
            });
        });
    }
    /**
     * Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} baseDN
     *
     * @returns {Bluebird<ExternalUserProfile | null>}
     * @private
     */
    _retrieveUserProfile(username, baseDN) {
        return this.bind().then(validCredentials => {
            if (!validCredentials) {
                // the credentials for binding were already tested in LDAPClient._checkCredentials or
                // LDAPAuth.startupCheck. this code should be reachable only if the password was changed
                return Errors.technical('ldap_bind_error', 'Could not connect to the LDAP server (Invalid "bindDN", "bindPassword" credentials)', true);
            }
            return this._doLDAPSearch(username, baseDN).then(ldapSearchResult => {
                this.unbind();
                if (Utils.noValue(ldapSearchResult)) {
                    return null;
                }
                // parse the ldapSearchResult to the standard the external profile object
                const externalProfile = {
                    username: ldapSearchResult[this._options.usernameField],
                    email: ldapSearchResult[this._options.emailField] ||
                        Utils.generateRandomEmail(Config.get('customerId')),
                    externalGroupIds: []
                };
                if (Utils.hasValue(this._options.groupField)) {
                    const g = ldapSearchResult[this._options.groupField];
                    if (Utils.noValue(g)) {
                        // no group is set or `groupField` is wrong
                    }
                    else if (Array.isArray(g)) {
                        externalProfile.externalGroupIds = g.map(group => group + '');
                    }
                    else {
                        externalProfile.externalGroupIds.push(g + '');
                    }
                }
                return externalProfile;
            });
        });
    }
    /**
     * Check if the pair `username` and `password` is valid. Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} password
     * @param {string} [baseDN]
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    findUser(username, password, baseDN) {
        return this._checkCredentials(username, password, baseDN).then(baseDN => {
            if (Utils.noValue(baseDN)) {
                return null;
            }
            // we know that the pair `username` and `password` is valid and that the username can be
            // found under `baseDN`
            return this._retrieveUserProfile(username, baseDN);
        });
    }
}
class LDAPAuth {
    constructor() {
        // whether or not a master LDAP client will be used
        if (Utils.hasValue(this.config.bindDN)) {
            // init LDAP admin client
            this._adminLDAPClient = new LDAPClient(this.config);
        } // else we will lazily create a client for each user trying to authenticate
    }
    /**
     * @type {LkConfigAccessLdap}
     */
    get config() {
        const config = Config.get('access.ldap');
        if (typeof config.baseDN === 'string') {
            config.baseDN = [config.baseDN];
        }
        return config;
    }
    /**
     * Check if `config.bindDN`, if in use, can bind.
     *
     * @returns {Bluebird<void>}
     */
    startupCheck() {
        if (Utils.noValue(this._adminLDAPClient)) {
            return Promise.resolve();
        }
        return this._adminLDAPClient.bind().then(validCredentials => {
            if (!validCredentials) {
                return Errors.business('ldap_bind_error', 'Could not connect to the LDAP server (Invalid "bindDN", "bindPassword" credentials)', true);
            }
            this._adminLDAPClient.unbind();
        });
    }
    /**
     * Check if the pair `username` and `password` is valid. Return the external profile of the user.
     *
     * @param {string} username
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    authenticate(username, password) {
        if (Utils.hasValue(this._adminLDAPClient)) {
            // if we use the admin ldap client to find the user
            return this._adminLDAPClient.findUser(username, password);
        }
        // if we use the user itself to bind and we have 1 or multiple baseDN
        return Promise.map(this.config.baseDN, baseDN => {
            const bindDN = `${this.config.usernameField}=${username},${baseDN}`;
            const client = new LDAPClient(_.defaults({ bindDN: bindDN, bindPassword: password }, this.config));
            // we know that we have to search the user only in this baseDN
            return client.findUser(username, password, baseDN);
        }, { concurrency: 1 }).then(validExternalProfiles => _.get(validExternalProfiles.filter(Utils.hasValue), 0));
    }
}
module.exports = LDAPAuth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGRhcEF1dGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL2xkYXBBdXRoLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRWpDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDbkMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0Qzs7R0FFRztBQUVILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQztBQUNyQixNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUM7QUFFN0IsTUFBTSxVQUFVO0lBQ2Q7O09BRUc7SUFDSCxZQUFZLE9BQU87UUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7UUFFeEIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDbkMsT0FBTyxDQUFDLGFBQWE7WUFDckIsT0FBTyxDQUFDLFVBQVU7WUFDbEIsT0FBTyxDQUFDLFVBQVU7U0FDbkIsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILEtBQUs7UUFDSCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxFQUFFO2dCQUNwRixJQUFJLFNBQVMsRUFBRTtvQkFDYixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUM3QixJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUsseUJBQXlCO3dCQUM1QyxTQUFTLENBQUMsSUFBSSxLQUFLLG1CQUFtQixFQUFFO3dCQUMxQyxHQUFHLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7d0JBQ3BELE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDaEI7eUJBQU07d0JBQ0wsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUNuQjtpQkFDRjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIsR0FBRyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO29CQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Y7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsSUFBSTtRQUNGLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQixHQUFHLENBQUMsS0FBSyxDQUFDLDJEQUEyRCxDQUFDLENBQUM7WUFDdkUsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQy9CO1FBRUQsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FDdkIseUJBQXlCLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUMsQ0FDNUYsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxHQUFHLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRXJELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsaUJBQWlCLEVBQ2pCLHdDQUF3QyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUN4RixJQUFJLENBQ0wsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTTtRQUNKLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDN0IsR0FBRyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVc7UUFDVCxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUM7WUFDdkMsR0FBRyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRztZQUN0QixjQUFjLEVBQUUsQ0FBQztZQUNqQixPQUFPLEVBQUUsT0FBTztZQUNoQixjQUFjLEVBQUUsZUFBZTtZQUMvQixVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHO1NBQzlCLENBQUMsQ0FBQztRQUVILE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQ2xCLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDYixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDaEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7UUFFL0UsR0FBRyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU07UUFDMUMsSUFBSSxPQUFPLENBQUM7UUFFWixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxrRkFBa0Y7WUFDOUcsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDcEI7YUFBTSxFQUFFLDBEQUEwRDtZQUNqRSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7U0FDaEM7UUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25DLE1BQU0sTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLElBQUksUUFBUSxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ3RFLE1BQU0sTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUMsRUFDL0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFFbEIsT0FBTyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtvQkFDckIsT0FBTyxJQUFJLENBQUM7aUJBQ2I7Z0JBRUQsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNoQixPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUN2QyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUM5QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsaUJBQWlCLENBQUMsUUFBUTtRQUN4QixPQUFPLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBQyxPQUFPLEVBQUU7Z0JBQzVDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7b0JBQ2hDLFNBQVMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWE7b0JBQ3RDLEtBQUssRUFBRSxRQUFRO2lCQUNoQixDQUFDO2FBQ0gsRUFBQyxDQUFDLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGFBQWEsQ0FBQyxRQUFRLEVBQUUsTUFBTTtRQUM1QixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDaEMsS0FBSyxFQUFFLEtBQUs7Z0JBQ1osTUFBTSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7Z0JBQ3hDLFVBQVUsRUFBRSxJQUFJLENBQUMsbUJBQW1CO2dCQUNwQyxTQUFTLEVBQUUsQ0FBQztnQkFDWixTQUFTLEVBQUUsT0FBTzthQUNuQixFQUFFLENBQUMsS0FBSyxFQUFFLFlBQVksRUFBRSxFQUFFO2dCQUN6QixJQUFJLEtBQUssRUFBRTtvQkFDVCxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ2QsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztpQkFDcEQ7Z0JBRUQsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO2dCQUNsQixZQUFZLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsRUFBRSxHQUFHLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUU3RSxZQUFZLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDL0IsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLG1CQUFtQixFQUFFO3dCQUN0QyxPQUFPLE9BQU8sRUFBRSxDQUFDO3FCQUNsQjtvQkFFRCxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBRWQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQ3JCLFVBQVUsRUFDViw4Q0FBOEM7d0JBQzlDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUM5QyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILG9CQUFvQixDQUFDLFFBQVEsRUFBRSxNQUFNO1FBQ25DLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDckIscUZBQXFGO2dCQUNyRix3RkFBd0Y7Z0JBQ3hGLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsaUJBQWlCLEVBQ2pCLHFGQUFxRixFQUNyRixJQUFJLENBQ0wsQ0FBQzthQUNIO1lBRUQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDbEUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUVkLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO29CQUNuQyxPQUFPLElBQUksQ0FBQztpQkFDYjtnQkFFRCx5RUFBeUU7Z0JBQ3pFLE1BQU0sZUFBZSxHQUFHO29CQUN0QixRQUFRLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7b0JBQ3ZELEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQzt3QkFDL0MsS0FBSyxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ3JELGdCQUFnQixFQUFFLEVBQUU7aUJBQ3JCLENBQUM7Z0JBRUYsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQzVDLE1BQU0sQ0FBQyxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ3JELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEIsMkNBQTJDO3FCQUM1Qzt5QkFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzNCLGVBQWUsQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDO3FCQUMvRDt5QkFBTTt3QkFDTCxlQUFlLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztxQkFDL0M7aUJBQ0Y7Z0JBRUQsT0FBTyxlQUFlLENBQUM7WUFDekIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsUUFBUSxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTTtRQUNqQyxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN0RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3pCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCx3RkFBd0Y7WUFDeEYsdUJBQXVCO1lBRXZCLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sUUFBUTtJQUNaO1FBQ0UsbURBQW1EO1FBQ25ELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3RDLHlCQUF5QjtZQUN6QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3JELENBQUMsMkVBQTJFO0lBQy9FLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksTUFBTTtRQUNSLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDekMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFO1lBQ3JDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVk7UUFDVixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDeEMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUMxRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3JCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsaUJBQWlCLEVBQ2pCLHFGQUFxRixFQUNyRixJQUFJLENBQ0wsQ0FBQzthQUNIO1lBRUQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFlBQVksQ0FBQyxRQUFRLEVBQUUsUUFBUTtRQUM3QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDekMsbURBQW1EO1lBQ25ELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDM0Q7UUFFRCxxRUFBcUU7UUFDckUsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQzlDLE1BQU0sTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLElBQUksUUFBUSxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ3BFLE1BQU0sTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUMsRUFDL0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFFaEIsOERBQThEO1lBQzlELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3JELENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQ2hELENBQUMsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FDdkQsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDIn0=