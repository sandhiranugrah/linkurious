/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-09-16.
 */
'use strict';
// external libs
const _ = require('lodash');
const ActiveDirectory = require('activedirectory');
const Promise = require('bluebird');
// services
const LKE = require('../../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const find = Promise.promisify(ActiveDirectory.prototype.find);
class MSActiveDirectoryAuth {
    /**
     * Connector to access Microsoft Active Directory users trough LDAP.
     */
    constructor() {
        this._baseDN = Config.get('access.msActiveDirectory.baseDN', undefined, true);
        this._url = Config.get('access.msActiveDirectory.url', undefined, true);
        this._domain = Config.get('access.msActiveDirectory.domain', undefined);
        this._netbiosDomain = Config.get('access.msActiveDirectory.netbiosDomain', undefined);
        this._tlsOptions = Config.get('access.msActiveDirectory.tls', undefined);
    }
    /**
     * Check if the pair `usernameOrEmail` and `password` is valid.
     * Return the external profile of the user.
     * Valid `usernameOrEmail` are:
     * - userPrincipalName, e.g.: "examplePrincipal@linkurio.us"
     * - userPrincipalName without domain, e.g.: "examplePrincipal"
     * - pre-Windows 2000 logon name, e.g.: "LINKURIO\exampleAMA"
     * - pre-Windows 2000 logon name without prefix, also called sAMAccountName, e.g.: "exampleAMA"
     *
     * @param {string} usernameOrEmail
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>}
     */
    authenticate(usernameOrEmail, password) {
        // We first try to authenticate on 'userPrincipalName'
        let userPrincipalName = usernameOrEmail;
        // If `usernameOrEmail` is not an e-mail the domain that is set in the configuration is used to
        // generate an e-mail address `{username}@{domain}` that will be used as `userPrincipalName`
        if (!userPrincipalName.includes('@') && Utils.hasValue(this._domain)) {
            userPrincipalName += '@' + this._domain;
        }
        return this._authenticate(userPrincipalName, password, 'userPrincipalName', userPrincipalName)
            .then(externalUserProfile => {
            if (Utils.hasValue(externalUserProfile)) {
                return externalUserProfile;
            }
            // As second option, we try to authenticate on 'sAMAccountName'
            // If `usernameOrEmail` is not a pre-Windows 2000 logon name,
            // the NetBios domain that is set in the configuration is used to generate
            // a `{domain}\{username}` that will be used as such
            let userLogonName;
            let sAMAccountName;
            if (!usernameOrEmail.includes('\\')) {
                userLogonName = this._netbiosDomain + '\\' + usernameOrEmail;
                sAMAccountName = usernameOrEmail;
            }
            else {
                userLogonName = usernameOrEmail;
                sAMAccountName = usernameOrEmail.split('\\')[1];
            }
            return this._authenticate(userLogonName, password, 'sAMAccountName', sAMAccountName);
        });
    }
    /**
     * Bind to ActiveDirectory using `bindUser` and `bindPassword`.
     * Then, search a user profile where `ldapPropertyKey` is `ldapPropertyValue`.
     *
     * @param {string} bindUser
     * @param {string} bindPassword
     * @param {string} ldapPropertyKey   'userPrincipalName' or 'sAMAccountName'
     * @param {string} ldapPropertyValue
     * @returns {Bluebird<ExternalUserProfile | null>}
     * @private
     */
    _authenticate(bindUser, bindPassword, ldapPropertyKey, ldapPropertyValue) {
        const ad = new ActiveDirectory({
            url: this._url,
            baseDN: this._baseDN,
            username: bindUser,
            password: bindPassword
        });
        const query = '(&(objectCategory=User)(' + ldapPropertyKey + '=' + ldapPropertyValue + '))';
        const opts = {
            filter: query,
            includeMembership: ['all'],
            includeDeleted: false,
            tlsOptions: this._tlsOptions
        };
        return find.call(ad, opts).then(result => {
            if (result && result.users) {
                const users = result.users, length = users.length;
                let user, i;
                for (i = 0; i < length; ++i) {
                    user = users[i];
                    if (typeof user[ldapPropertyKey] === 'string' &&
                        user[ldapPropertyKey].toLowerCase() === ldapPropertyValue.toLowerCase()) {
                        // userPrincipalName can be empty, sAMAccountName can't. We want both to be defined
                        if (Utils.noValue(user.userPrincipalName)) {
                            throw Errors.business('invalid_parameter', 'This user doesn\' have a "userPrincipalName",' +
                                ' please contact your system administrator.');
                        }
                        return {
                            username: user.sAMAccountName,
                            email: user.userPrincipalName,
                            // user.groups contains both the distinguished name and the common name of a group
                            // CN, e.g.: "Administrators"
                            // DN, e.g.: "CN=Administrators,CN=Users,DC=linkurious,DC=local"
                            // We put both of them, as different groups, in the ExternalUserProfile instance
                            // s.t. our clients can use one or the other
                            externalGroupIds: _.flatten(_.map(user.groups, g => [g.dn, g.cn]))
                        };
                    }
                }
            }
            // no user found matching the query
            return null;
        }).catch(e => {
            if (e instanceof Errors.LkError) {
                throw e;
            }
            if (e.stack && e.stack.startsWith('InvalidCredentialsError')) {
                return null;
            }
            Log.error('ActiveDirectory.find failed', e);
            return Errors.technical('critical', 'Active Directory server returned an error.', true);
        });
    }
}
module.exports = MSActiveDirectoryAuth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXNBY3RpdmVEaXJlY3RvcnlBdXRoLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2FjY2Vzcy9wcm92aWRlci9tc0FjdGl2ZURpcmVjdG9yeUF1dGguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ25DLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBRS9ELE1BQU0scUJBQXFCO0lBRXpCOztPQUVHO0lBQ0g7UUFDRSxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzlFLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0RixJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNILFlBQVksQ0FBQyxlQUFlLEVBQUUsUUFBUTtRQUVwQyxzREFBc0Q7UUFDdEQsSUFBSSxpQkFBaUIsR0FBRyxlQUFlLENBQUM7UUFFeEMsK0ZBQStGO1FBQy9GLDRGQUE0RjtRQUM1RixJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3BFLGlCQUFpQixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO1NBQ3pDO1FBRUQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLFFBQVEsRUFBRSxtQkFBbUIsRUFBRSxpQkFBaUIsQ0FBQzthQUMzRixJQUFJLENBQUMsbUJBQW1CLENBQUMsRUFBRTtZQUMxQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsRUFBRTtnQkFDdkMsT0FBTyxtQkFBbUIsQ0FBQzthQUM1QjtZQUVELCtEQUErRDtZQUUvRCw2REFBNkQ7WUFDN0QsMEVBQTBFO1lBQzFFLG9EQUFvRDtZQUNwRCxJQUFJLGFBQWEsQ0FBQztZQUNsQixJQUFJLGNBQWMsQ0FBQztZQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbkMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxHQUFHLGVBQWUsQ0FBQztnQkFDN0QsY0FBYyxHQUFHLGVBQWUsQ0FBQzthQUNsQztpQkFBTTtnQkFDTCxhQUFhLEdBQUcsZUFBZSxDQUFDO2dCQUNoQyxjQUFjLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNqRDtZQUVELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZGLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxhQUFhLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsaUJBQWlCO1FBQ3RFLE1BQU0sRUFBRSxHQUFHLElBQUksZUFBZSxDQUFDO1lBQzdCLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTztZQUNwQixRQUFRLEVBQUUsUUFBUTtZQUNsQixRQUFRLEVBQUUsWUFBWTtTQUN2QixDQUFDLENBQUM7UUFFSCxNQUFNLEtBQUssR0FBRywwQkFBMEIsR0FBRyxlQUFlLEdBQUcsR0FBRyxHQUFHLGlCQUFpQixHQUFHLElBQUksQ0FBQztRQUM1RixNQUFNLElBQUksR0FBRztZQUNYLE1BQU0sRUFBRSxLQUFLO1lBQ2IsaUJBQWlCLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDMUIsY0FBYyxFQUFFLEtBQUs7WUFDckIsVUFBVSxFQUFFLElBQUksQ0FBQyxXQUFXO1NBQzdCLENBQUM7UUFFRixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN2QyxJQUFJLE1BQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFO2dCQUMxQixNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUNsRCxJQUFJLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBRVosS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQzNCLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWhCLElBQUksT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssUUFBUTt3QkFDM0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxLQUFLLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxFQUFFO3dCQUV6RSxtRkFBbUY7d0JBQ25GLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRTs0QkFDekMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFBRSwrQ0FBK0M7Z0NBQ3BFLDRDQUE0QyxDQUM3QyxDQUFDO3lCQUNIO3dCQUVELE9BQU87NEJBQ0wsUUFBUSxFQUFFLElBQUksQ0FBQyxjQUFjOzRCQUM3QixLQUFLLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjs0QkFDN0Isa0ZBQWtGOzRCQUNsRiw2QkFBNkI7NEJBQzdCLGdFQUFnRTs0QkFDaEUsZ0ZBQWdGOzRCQUNoRiw0Q0FBNEM7NEJBQzVDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3lCQUNuRSxDQUFDO3FCQUNIO2lCQUNGO2FBQ0Y7WUFFRCxtQ0FBbUM7WUFDbkMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDWCxJQUFJLENBQUMsWUFBWSxNQUFNLENBQUMsT0FBTyxFQUFFO2dCQUMvQixNQUFNLENBQUMsQ0FBQzthQUNUO1lBRUQsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLHlCQUF5QixDQUFDLEVBQUU7Z0JBQzVELE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCxHQUFHLENBQUMsS0FBSyxDQUFDLDZCQUE2QixFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzVDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsNENBQTRDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDMUYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLHFCQUFxQixDQUFDIn0=