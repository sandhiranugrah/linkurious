/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-06-27.
 */
'use strict';
// internal libs
const fs = require('fs');
// external libs
const Promise = require('bluebird');
const saml2 = require('saml2-js');
// services
const LKE = require('../../index');
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
class SAML2 {
    startupCheck() {
        // retrieve SAML2 specific configurations
        this._url = Config.get('access.saml2.url');
        this._identityProviderCertificate = fs.readFileSync(LKE.dataFile(Config.get('access.saml2.identityProviderCertificate', undefined, true))).toString();
        this._groupAttribute = Config.get('access.saml2.groupAttribute');
        this._emailAttribute = Config.get('access.saml2.emailAttribute');
        this.sp = this._instantiateSP(LKE.getBaseURL());
        const identityProviderOptions = {
            'sso_login_url': this._url,
            certificates: [this._identityProviderCertificate],
            'allow_unencrypted_assertion': true
        };
        // Call identity provider constructor with options
        this.idp = new saml2.IdentityProvider(identityProviderOptions);
        return Promise.resolve();
    }
    /**
     * @param {string} redirectURL
     * @returns {any}
     * @private
     */
    _instantiateSP(redirectURL) {
        const baseUrl = Utils.normalizeUrl(redirectURL);
        const serviceProviderOptions = {
            'entity_id': baseUrl,
            'assert_endpoint': baseUrl + '/api/auth/sso/return'
        };
        return new saml2.ServiceProvider(serviceProviderOptions);
    }
    /**
     * Return the URL of the SAML2 authorization endpoint.
     *
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user should be redirected by the authentication provider
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(requestBaseUrl) {
        const sp = Utils.hasValue(requestBaseUrl)
            ? this._instantiateSP(requestBaseUrl)
            : this.sp;
        return new Promise((resolve, reject) => {
            sp.create_login_request_url(this.idp, {}, (err, loginUrl) => {
                if (err) {
                    Log.error('saml2.create_login_request_url failed', err);
                    reject(Errors.technical('critical', 'SAML2 connector returned an error.'));
                }
                resolve(loginUrl);
            });
        });
    }
    /**
     * Authenticate the user via SAML2.
     *
     * @param {string} code
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user was redirected by the authentication provider (for verification)
     * @returns {Bluebird<ExternalUserProfile>}
     */
    handleAuthenticateURLResponseSSO(code, requestBaseUrl) {
        const sp = Utils.hasValue(requestBaseUrl)
            ? this._instantiateSP(requestBaseUrl)
            : this.sp;
        return new Promise((resolve, reject) => {
            const options = { 'request_body': { SAMLResponse: code } };
            sp.post_assert(this.idp, options, (err, samlResponse) => {
                if (err) {
                    Log.error('saml2.post_assert failed', err);
                    return reject(Errors.technical('critical', 'SAML2 server returned an error.'));
                }
                if (Utils.noValue(samlResponse.user) || Utils.noValue(samlResponse.user.name_id)) {
                    return reject(Errors.technical('critical', 'SAML2 server didn\'t return any user.'));
                }
                // if email attribute is not defined, we expect name ID format to be an email
                let email = samlResponse.user.name_id;
                if (Utils.hasValue(this._emailAttribute) && Utils.hasValue(samlResponse.user.attributes)) {
                    email = samlResponse.user.attributes[this._emailAttribute];
                    // email attribute can be an array or a string
                    if (Array.isArray(email)) {
                        email = email[0];
                    }
                }
                const externalUserProfile = {
                    username: samlResponse.user.name_id,
                    email: email
                };
                if (Utils.hasValue(this._groupAttribute) && Utils.hasValue(samlResponse.user.attributes)) {
                    externalUserProfile.externalGroupIds = samlResponse.user.attributes[this._groupAttribute];
                }
                resolve(externalUserProfile);
            });
        });
    }
}
module.exports = SAML2;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FtbDIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL3NhbWwyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUV6QixnQkFBZ0I7QUFDaEIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVsQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ25DLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxLQUFLO0lBQ1QsWUFBWTtRQUNWLHlDQUF5QztRQUN6QyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FDakQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUN0RixDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2IsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7UUFFakUsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBRWhELE1BQU0sdUJBQXVCLEdBQUc7WUFDOUIsZUFBZSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQzFCLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQztZQUNqRCw2QkFBNkIsRUFBRSxJQUFJO1NBQ3BDLENBQUM7UUFFRixrREFBa0Q7UUFDbEQsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBRS9ELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxDQUFDLFdBQVc7UUFDeEIsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVoRCxNQUFNLHNCQUFzQixHQUFHO1lBQzdCLFdBQVcsRUFBRSxPQUFPO1lBQ3BCLGlCQUFpQixFQUFFLE9BQU8sR0FBRyxzQkFBc0I7U0FDcEQsQ0FBQztRQUVGLE9BQU8sSUFBSSxLQUFLLENBQUMsZUFBZSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gscUJBQXFCLENBQUMsY0FBYztRQUNsQyxNQUFNLEVBQUUsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQztZQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUM7WUFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFFWixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLEVBQUUsQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBRTtnQkFDMUQsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsR0FBRyxDQUFDLEtBQUssQ0FBQyx1Q0FBdUMsRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDeEQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLG9DQUFvQyxDQUFDLENBQUMsQ0FBQztpQkFDNUU7Z0JBRUQsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3BCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsZ0NBQWdDLENBQUMsSUFBSSxFQUFFLGNBQWM7UUFDbkQsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7WUFDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBRVosT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxNQUFNLE9BQU8sR0FBRyxFQUFFLGNBQWMsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBRTNELEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLEVBQUUsWUFBWSxFQUFFLEVBQUU7Z0JBQ3RELElBQUksR0FBRyxFQUFFO29CQUNQLEdBQUcsQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBQzNDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLGlDQUFpQyxDQUFDLENBQUMsQ0FBQztpQkFDaEY7Z0JBRUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ2hGLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLHVDQUF1QyxDQUFDLENBQUMsQ0FBQztpQkFDdEY7Z0JBRUQsNkVBQTZFO2dCQUM3RSxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztnQkFFdEMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQ3hGLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQzNELDhDQUE4QztvQkFDOUMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUN4QixLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNsQjtpQkFDRjtnQkFFRCxNQUFNLG1CQUFtQixHQUFHO29CQUMxQixRQUFRLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPO29CQUNuQyxLQUFLLEVBQUUsS0FBSztpQkFDYixDQUFDO2dCQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUN4RixtQkFBbUIsQ0FBQyxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7aUJBQzNGO2dCQUVELE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyJ9