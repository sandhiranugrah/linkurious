/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-28.
 */
'use strict';
/* eslint no-unused-vars: 0 */ // abstract methods
// services
const LKE = require('../../../index');
const Errors = LKE.getErrors();
class AbstractOAuth2 {
    /**
     * Parse the response of the tokenURL (including, but not limited to, the `access_token`)
     * to get username and email.
     *
     * @param {{access_token: string, id_token?: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        throw Errors.business('not_implemented', 'getProfileData is not implemented.');
    }
    /**
     * The OAuth2 scope.
     *
     * @returns {string} scope
     */
    getScope() {
        throw Errors.business('not_implemented', 'getScope is not implemented.');
    }
    /**
     * Params to be passed to the tokenURL to acquire the access token.
     *
     * @param {string} code
     * @param {string} clientID
     * @param {string} clientSecret
     * @param {string} redirectURL
     * @returns {any} params
     */
    getTokenURLParams(code, clientID, clientSecret, redirectURL) {
        return {
            code: code,
            'client_id': clientID,
            'client_secret': clientSecret,
            'redirect_uri': redirectURL,
            'grant_type': 'authorization_code'
        };
    }
}
module.exports = AbstractOAuth2;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3RvYXV0aDIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL29hdXRoMi9hYnN0cmFjdG9hdXRoMi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLDhCQUE4QixDQUFDLG1CQUFtQjtBQUVsRCxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sY0FBYztJQUNsQjs7Ozs7O09BTUc7SUFDSCxjQUFjLENBQUMsUUFBUTtRQUNyQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsb0NBQW9DLENBQUMsQ0FBQztJQUNqRixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVE7UUFDTixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsOEJBQThCLENBQUMsQ0FBQztJQUMzRSxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxXQUFXO1FBQ3pELE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSTtZQUNWLFdBQVcsRUFBRSxRQUFRO1lBQ3JCLGVBQWUsRUFBRSxZQUFZO1lBQzdCLGNBQWMsRUFBRSxXQUFXO1lBQzNCLFlBQVksRUFBRSxvQkFBb0I7U0FDbkMsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDIn0=