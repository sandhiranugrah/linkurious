/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-28.
 */
'use strict';
// locals
const AbstractOAuth2 = require('./abstractoauth2');
const LkRequest = require('../../../../lib/LkRequest');
class Github extends AbstractOAuth2 {
    constructor() {
        super();
        this._request = new LkRequest({
            headers: {
                'User-Agent': 'request'
            },
            json: true
        });
    }
    /**
     * The OAuth2 scope.
     *
     * @returns {string} scope
     */
    getScope() {
        return 'user:email';
    }
    /**
     * @param {{access_token: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        return this._request.get('https://api.github.com/user', { qs: { 'access_token': response.access_token } }).then(userR => {
            return { username: userR.body.login, email: userR.body.email };
        });
    }
}
module.exports = Github;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2l0aHViLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2FjY2Vzcy9wcm92aWRlci9vYXV0aDIvZ2l0aHViLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsU0FBUztBQUNULE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBRXZELE1BQU0sTUFBTyxTQUFRLGNBQWM7SUFFakM7UUFDRSxLQUFLLEVBQUUsQ0FBQztRQUNSLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFO2dCQUNQLFlBQVksRUFBRSxTQUFTO2FBQ3hCO1lBQ0QsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVE7UUFDTixPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsY0FBYyxDQUFDLFFBQVE7UUFDckIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsRUFDcEQsRUFBQyxFQUFFLEVBQUUsRUFBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLFlBQVksRUFBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDNUQsT0FBTyxFQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDIn0=