/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-25.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const jwt = require('jsonwebtoken');
// locals
const OpenIDConnect = require('./openidconnect');
const LkRequest = require('../../../../lib/LkRequest');
// services
const LKE = require('../../../index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
class Azure extends OpenIDConnect {
    /**
     * @param {{tenantID?: string}} azureConf
     */
    constructor(azureConf) {
        super({});
        this.tenantID = azureConf.tenantID;
        if (Utils.hasValue(Config.get('access.externalUsersGroupMapping')) &&
            Utils.noValue(this.tenantID)) {
            throw Errors.access('missing_field', '"configuration.access.oauth2.azure.tenantID" ' +
                'must not be undefined if "access.externalUsersGroupMapping" is defined.');
        }
        this._request = new LkRequest({
            headers: {
                'User-Agent': 'request'
            },
            json: true
        });
    }
    /**
     * Return the group a given user has in the Azure Active Directory.
     *
     * @param {string} userId
     * @param {string} accessToken
     * @returns {Bluebird<string[]>}
     * @private
     */
    _getExternalGroupIds(userId, accessToken) {
        return Promise.resolve().then(() => {
            if (Utils.hasValue(this.tenantID) &&
                Utils.hasValue(Config.get('access.externalUsersGroupMapping'))) {
                return this._request.post(`https://graph.windows.net/${this.tenantID}/users/${userId}/getMemberGroups`, {
                    body: { 'securityEnabledOnly': false },
                    qs: { 'api-version': '1.6' },
                    headers: { Authorization: 'Bearer ' + accessToken }
                }).then(groupsR => {
                    if (groupsR.statusCode === 401) {
                        return Errors.business('critical', 'The access token is not authorized ' +
                            'to access the Azure graph API as the signed-in user', true);
                    }
                    else if (groupsR.statusCode !== 200) {
                        return Errors.technical('critical', JSON.stringify(groupsR.body), true);
                    }
                    return groupsR.body && groupsR.body.value || [];
                });
            }
        });
    }
    /**
     * Retrieve username and email of the user by parsing the ID token inside response.
     *
     * @param {{access_token: string, id_token: string}} response
     * @returns {Bluebird<ExternalUserProfile>}
     */
    getProfileData(response) {
        const decodedIDToken = jwt.decode(response.id_token);
        const email = decodedIDToken.email || decodedIDToken.unique_name; // <-- different from openidconnect
        const username = decodedIDToken.name || decodedIDToken.email;
        return this._getExternalGroupIds(decodedIDToken.oid, response.access_token)
            .then(externalGroupIds => {
            return {
                username: username,
                email: email,
                externalGroupIds: externalGroupIds
            };
        });
    }
    /**
     * Azure AD requires an additional param `resource` to obtain an access token
     * that has the rights to read the groups.
     *
     * @param {string} code
     * @param {string} clientID
     * @param {string} clientSecret
     * @param {string} redirectURL
     * @returns {any} params
     */
    getTokenURLParams(code, clientID, clientSecret, redirectURL) {
        return {
            code: code,
            'client_id': clientID,
            'client_secret': clientSecret,
            'resource': 'https://graph.windows.net',
            'redirect_uri': redirectURL,
            'grant_type': 'authorization_code'
        };
    }
}
module.exports = Azure;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXp1cmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL3Byb3ZpZGVyL29hdXRoMi9henVyZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBRXBDLFNBQVM7QUFDVCxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNqRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUV2RCxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBTSxLQUFNLFNBQVEsYUFBYTtJQUUvQjs7T0FFRztJQUNILFlBQVksU0FBUztRQUNuQixLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDVixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDbkMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUNoRSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM5QixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLCtDQUErQztnQkFDbEYseUVBQXlFLENBQUMsQ0FBQztTQUM5RTtRQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDNUIsT0FBTyxFQUFFO2dCQUNQLFlBQVksRUFBRSxTQUFTO2FBQ3hCO1lBQ0QsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILG9CQUFvQixDQUFDLE1BQU0sRUFBRSxXQUFXO1FBQ3RDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQy9CLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2hFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ3ZCLDZCQUE2QixJQUFJLENBQUMsUUFBUSxVQUFVLE1BQU0sa0JBQWtCLEVBQzVFO29CQUNFLElBQUksRUFBRSxFQUFDLHFCQUFxQixFQUFFLEtBQUssRUFBQztvQkFDcEMsRUFBRSxFQUFFLEVBQUMsYUFBYSxFQUFFLEtBQUssRUFBQztvQkFDMUIsT0FBTyxFQUFFLEVBQUMsYUFBYSxFQUFFLFNBQVMsR0FBRyxXQUFXLEVBQUM7aUJBQ2xELENBQ0YsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ2YsSUFBSSxPQUFPLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTt3QkFDOUIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxxQ0FBcUM7NEJBQ3RFLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNoRTt5QkFBTSxJQUFJLE9BQU8sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO3dCQUNyQyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUN6RTtvQkFDRCxPQUFPLE9BQU8sQ0FBQyxJQUFJLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO2dCQUNsRCxDQUFDLENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsUUFBUTtRQUNyQixNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsS0FBSyxJQUFJLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxtQ0FBbUM7UUFDckcsTUFBTSxRQUFRLEdBQUcsY0FBYyxDQUFDLElBQUksSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDO1FBRTdELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLFlBQVksQ0FBQzthQUN4RSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUN2QixPQUFPO2dCQUNMLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixLQUFLLEVBQUUsS0FBSztnQkFDWixnQkFBZ0IsRUFBRSxnQkFBZ0I7YUFDbkMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILGlCQUFpQixDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLFdBQVc7UUFDekQsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJO1lBQ1YsV0FBVyxFQUFFLFFBQVE7WUFDckIsZUFBZSxFQUFFLFlBQVk7WUFDN0IsVUFBVSxFQUFFLDJCQUEyQjtZQUN2QyxjQUFjLEVBQUUsV0FBVztZQUMzQixZQUFZLEVBQUUsb0JBQW9CO1NBQ25DLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyJ9