/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-10-25.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../index');
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
const Log = LKE.getLogger(__filename);
class AuthProviderWrapper {
    /**
     * @param {string} name      Human readable name
     * @param {string} configKey Configuration key (under `access` config root)
     * @param {string} className Location of the implementation file (relative to `access/provider` package)
     */
    constructor(name, configKey, className) {
        this.name = name;
        // load config
        this.config = Config.get('access.' + configKey, { enabled: false });
        this.enabled = this.config.enabled;
        // create the provider instance
        this.instance = this.enabled ? new (require('./' + className))() : null;
    }
    /**
     * @param {string} username
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile | null>} an external user
     */
    authenticate(username, password) {
        if (!this.enabled) {
            return Promise.resolve(null);
        }
        // not all auth providers can authenticate via username and password
        if (!this.instance.authenticate) {
            return Promise.resolve(null);
        }
        return this.instance.authenticate(username, password);
    }
    /**
     * Checked at startup (can be used to check connectivity with the auth server).
     *
     * @returns {Bluebird<void>}
     */
    startupCheck() {
        if (!this.enabled) {
            // Log.info('Auth provider "' + this.name + '": disabled');
            return Promise.resolve();
        }
        if (!this.instance.startupCheck) {
            Log.info('Auth provider "' + this.name + '": enabled');
            return Promise.resolve();
        }
        return this.instance.startupCheck().then(() => {
            Log.info('Auth provider "' + this.name + '": startup check success');
        }).catch(e => {
            Log.error('Auth provider "' + this.name + '": startup check failure');
            return Promise.reject(e);
        });
    }
    /**
     * Return the URL of the OAuth2/SAML2 authorization endpoint.
     *
     * The `state` parameter is only used by OAuth2.
     *
     * @param {string} state            A random string, stored in the current session, to be checked on AuthenticateURL response
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user should be redirected by the authentication provider
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(state, requestBaseUrl) {
        if (!this.instance.getAuthenticateURLSSO) {
            return Errors.technical('bug', 'getAuthenticateURLSSO() should only be called on the oauth2/saml2 provider.', true);
        }
        if (this.name === 'OAuth2') {
            return this.instance.getAuthenticateURLSSO(state, requestBaseUrl);
        }
        return this.instance.getAuthenticateURLSSO(requestBaseUrl);
    }
    /**
     * Authenticate the user via OAuth2/SAML2.
     *
     * @param {string} code
     * @param {string} [requestBaseUrl] Base url of Linkurious where the user was redirected by the authentication provider (for verification)
     * @returns {Bluebird<ExternalUserProfile>}
     */
    handleAuthenticateURLResponseSSO(code, requestBaseUrl) {
        if (!this.instance.handleAuthenticateURLResponseSSO) {
            return Errors.technical('bug', 'getAuthenticateURLSSO() should only be called on the oauth2/saml2 provider.', true);
        }
        return this.instance.handleAuthenticateURLResponseSSO(code, requestBaseUrl);
    }
}
module.exports = AuthProviderWrapper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXV0aFByb3ZpZGVyV3JhcHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvcHJvdmlkZXIvQXV0aFByb3ZpZGVyV3JhcHBlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsTUFBTSxtQkFBbUI7SUFFdkI7Ozs7T0FJRztJQUNILFlBQVksSUFBSSxFQUFFLFNBQVMsRUFBRSxTQUFTO1FBQ3BDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWpCLGNBQWM7UUFDZCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLFNBQVMsRUFBRSxFQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFFbkMsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDMUUsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxZQUFZLENBQUMsUUFBUSxFQUFFLFFBQVE7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDakIsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO1FBRUQsb0VBQW9FO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRTtZQUMvQixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVk7UUFDVixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQiwyREFBMkQ7WUFDM0QsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUU7WUFDL0IsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDNUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLDBCQUEwQixDQUFDLENBQUM7UUFDdkUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1gsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLDBCQUEwQixDQUFDLENBQUM7WUFDdEUsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gscUJBQXFCLENBQUMsS0FBSyxFQUFFLGNBQWM7UUFDekMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMscUJBQXFCLEVBQUU7WUFDeEMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFDM0IsNkVBQTZFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDeEY7UUFFRCxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQzFCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDbkU7UUFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGdDQUFnQyxDQUFDLElBQUksRUFBRSxjQUFjO1FBQ25ELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxFQUFFO1lBQ25ELE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQzNCLDZFQUE2RSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hGO1FBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztJQUM5RSxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLG1CQUFtQixDQUFDIn0=