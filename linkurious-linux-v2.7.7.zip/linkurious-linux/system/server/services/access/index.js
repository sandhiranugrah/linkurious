/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-04.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
const basicAuth = require('basic-auth');
// services
const LKE = require('../index');
const Errors = LKE.getErrors();
const Application = LKE.getApplication();
const Config = LKE.getConfig();
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const UserDAO = LKE.getUserDAO();
// locals
const { WrappedUser } = require('./WrappedUser');
const AuthProviderWrapper = require('./provider/AuthProviderWrapper');
const SessionStore = require('./SessionStore');
const API = require('../webServer/api');
const UserCache = require('./UserCache');
/**
 * @dokapi access.groupmapping
 *
 * If an external source already organizes users in groups, it's possible to use this information to map automatically
 * external groups to Linkurious groups. To do so, you have to set the `access.externalUsersGroupMapping` configuration key
 * to be an object with the external group IDs as keys and the internal group IDs as values.
 *
 * For example, if we want to provide group mapping for Microsoft Active Directory:
 * ```json
 * { // under the access configuration key
 *   // ...
 *   "externalUsersGroupMapping": {
 *     "Administrators": 1 // any Active Directory admin is a Linkurious admin
 *   }
 *   // ...
 * }
 * ```
 *
 * For some identity providers the external group IDs is an actual name, for others is an ID:
 * - Azure AD uses the group ID, e.g. `"818b6e03-15dd-4e19-8cb1-a4f434b40a04"`
 * - LDAP uses the content of the field configured in `access.ldap.groupField`
 * - Microsoft Active Directory uses the group common name, e.g. `"Administrators"` or the group distinguished name, e.g. `"CN=Administrators,CN=Users,DC=linkurious,DC=local"`
 *
 * To exclude some groups of users from logging in into Linkurious, set up a list of
 * authorized groups in the configuration key `access.externalUsersAllowedGroups`.
 * ```json
 * { // under the access configuration key
 *   // ...
 *   "externalUsersAllowedGroups": [
 *     "CN=Administrators,CN=Users,DC=linkurious,DC=local",
 *     "CN=Analysts,CN=Users,DC=linkurious,DC=local"
 *   ]
 *   // ...
 * }
 * ```
 */
class AccessService {
    constructor() {
        /**@type {AuthProviderWrapper}*/
        this._oauth2Provider = new AuthProviderWrapper('OAuth2', 'oauth2', 'oauth2/index.js');
        /**@type {AuthProviderWrapper}*/
        this._saml2Provider = new AuthProviderWrapper('SAML2', 'saml2', 'saml2.js');
        if (this._oauth2Provider.enabled && this._saml2Provider.enabled) {
            throw Errors.business('invalid_parameter', 'OAuth2 and SAML2 can\'t be enabled at the same time.');
        }
        this._ssoProvider = this._oauth2Provider.enabled ? this._oauth2Provider : this._saml2Provider;
        /**@type {AuthProviderWrapper[]}*/
        this._providers = [
            new AuthProviderWrapper('LDAP', 'ldap', 'ldapAuth.js'),
            new AuthProviderWrapper('Microsoft Active Directory', 'msActiveDirectory', 'msActiveDirectoryAuth.js'),
            this._oauth2Provider,
            this._saml2Provider
        ];
        /**@type {SessionStore}*/
        this._sessionStore = new SessionStore(Config.get('access.floatingLicenses', 0));
        this._externalUsersGroupMapping = Config.get('access.externalUsersGroupMapping', {});
        UserCache.init();
    }
    /**
     * @type {AuthProviderWrapper[]}
     */
    get providers() {
        return this._providers;
    }
    /**
     * @type {SessionStore}
     */
    get sessionStore() {
        return this._sessionStore;
    }
    /**
     * If `req.session.userId` is defined, populate `req.user`.
     *
     * @param {IncomingMessage} req
     * @returns {Bluebird<void>}
     * @private
     */
    _populateReqUser(req) {
        const authRequired = Config.get('access.authRequired');
        const guestModeAllowed = Config.get('access.guestMode');
        let userIdToRetrieve = req.session.userId;
        if (!authRequired) {
            // use the unique user when authRequired is false
            userIdToRetrieve = UserDAO.model.UNIQUE_USER_ID;
        }
        if (req.query.guest === 'true') {
            if (!guestModeAllowed) {
                return Errors.access('guest_disabled', undefined, true);
            }
            userIdToRetrieve = UserDAO.model.GUEST_USER_ID;
        }
        if (Utils.noValue(userIdToRetrieve)) {
            return Promise.resolve();
        }
        return UserCache.getUser(userIdToRetrieve).then(user => {
            req.user = user;
            req.wrappedUser = new WrappedUser(req.user);
        });
    }
    /**
     * Check that there is an authenticated user.
     * Throw an access error if no current user.
     *
     * @param {WrappedUser} [wrappedUser]
     * @param {string}      [apiAction]        An API action the application needs to have to be allowed to perform on behalf of the user
     * @param {boolean}     [guestModeAllowed] Whether the guest user can be returned
     * @returns {WrappedUser}
     */
    checkAuth(wrappedUser, apiAction, guestModeAllowed) {
        if (!wrappedUser) {
            throw Errors.access('unauthorized');
        }
        // if we are an application
        if (Utils.hasValue(wrappedUser.application)) {
            // if API action is not defined, it means that
            // the action can't be performed by an application
            if (Utils.noValue(apiAction)) {
                throw Errors.access('forbidden', 'Application "' + wrappedUser.application.name +
                    '" (#' + wrappedUser.application.id + ') does not have access to this feature.');
            }
            // we check if we have the right to do the intended action
            this._checkAppAction(wrappedUser.application, apiAction);
        }
        if (!guestModeAllowed && wrappedUser.id === UserDAO.model.GUEST_USER_ID) {
            throw Errors.access('forbidden', 'A guest user does not have access to this feature.');
        }
        return wrappedUser;
    }
    /**
     * Express middleware responsible to set `req.user` and to check floating license errors.
     *
     * @param {IncomingMessage} req
     * @param {OutgoingMessage} res
     * @param {function} next
     */
    checkUserSession(req, res, next) {
        this._checkSessionErrors(req).then(() => {
            return this._populateReqUser(req);
        }).then(() => {
            next();
        }).catch(error => {
            API.respondToLkError(res, error);
        });
    }
    /**
     * Check that `req.session` doesn't contain any error.
     * If it does, reject with an LkError and destroy the session.
     *
     * @param {IncomingMessage} req
     * @returns {Bluebird<void>}
     * @private
     */
    _checkSessionErrors(req) {
        if (Utils.noValue(req.session.error)) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const sessionError = req.session.error;
            req.session.destroy(() => {
                let error;
                switch (sessionError) {
                    case SessionStore.Errors.EXPIRED:
                    case SessionStore.Errors.FLOATING_EXPIRED:
                        error = Errors.access('session_expired');
                        break;
                    case SessionStore.Errors.FLOATING_KICKED:
                        error = Errors.access('session_evicted');
                        break;
                    case SessionStore.Errors.FLOATING_FULL:
                        error = Errors.access('server_full');
                        break;
                    default:
                        error = Errors.access('unauthorized', `Session error: "${sessionError}"`);
                }
                reject(error);
            });
        });
    }
    /**
     * Express middleware responsible to set `req.application`.
     *
     * @param {IncomingMessage} req
     * @param {OutgoingMessage} res
     * @param {function} next
     */
    checkApplication(req, res, next) {
        /**@type{{name: string, pass: string}}*/
        const credentials = basicAuth(req);
        // no basic auth, bypass this step
        if (!credentials) {
            next();
            return;
        }
        return Application.checkApplication(credentials.name, credentials.pass).then(userAndApp => {
            // the user which the app can act on behalf of
            req.user = userAndApp.user;
            // the public app itself
            req.application = userAndApp.application;
            req.wrappedUser = new WrappedUser(req.user, req.application);
            next();
        }).catch(error => {
            API.respondToLkError(res, error);
        });
    }
    /**
     * @param {string} usernameOrEmail
     * @param {string} password
     * @returns {Bluebird<ExternalUserProfile> | null} `null` if no external provider is enabled
     * @private
     */
    _getProviderAuthPromise(usernameOrEmail, password) {
        for (const provider of this.providers) {
            if (provider.enabled) {
                return provider.authenticate(usernameOrEmail, password);
            }
        }
        return null;
    }
    /**
     * Use the group mapping to retrieve the desired `internalGroupIds` from the `externalGroupIds`.
     * Each external group id can produce 1 or 0 internal group ids.
     *
     * @param {Array<string | number>} externalGroupIds
     * @returns {number[]} internalGroupIds
     * @private
     */
    _externalGroupsToInternalGroups(externalGroupIds) {
        let internalGroupIds = [];
        _.forEach(externalGroupIds, externalGroupId => {
            const caseSensitiveGroupId = _.findKey(this._externalUsersGroupMapping, (value, key) => {
                return key.toLowerCase() === ('' + externalGroupId).toLowerCase();
            });
            const mappedValue = this._externalUsersGroupMapping[caseSensitiveGroupId];
            if (Utils.noValue(mappedValue)) {
                return;
            }
            const newInternalGroupIds = Array.isArray(mappedValue) ? mappedValue : [mappedValue];
            internalGroupIds = internalGroupIds.concat(newInternalGroupIds);
        });
        return _.uniq(internalGroupIds);
    }
    /**
     * Given an external user profile, check if a user with the same email exists in the user database.
     * - If such user exists, but with source=local, the user is migrated (the source is updated to `source`)
     * - If a shadow user already exists, it is returned
     * - Otherwise, a shadow user is created.
     *
     * Shadow user: A user profile in the local database that represents an external user.
     * No password is stored for shadow users, since the authentication is done by the external provider.
     * Username/email of shadow users cannot be edited since they are a cache of the profile stored by the external provider.
     *
     * @param {ExternalUserProfile} profile
     * @param {string} source ("oauth" for OAuth2 or SAML2, "ldap" for LDAP or AD)
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _getOrCreateShadowExternalUser(profile, source) {
        const externalUsersAllowedGroups = Config.get('access.externalUsersAllowedGroups');
        // if only some groups are allowed but none of the current user
        if (Utils.hasValue(externalUsersAllowedGroups) &&
            _.intersectionBy(externalUsersAllowedGroups, profile.externalGroupIds, o => o.toLowerCase()).length === 0) {
            Log.debug('auth(' + profile.username + '): source:' + source + ', group:NOK');
            return Errors.access('unauthorized', 'The user doesn\'t belong to any authorized group.', true);
        }
        let desiredGroupIds = null;
        if (profile.externalGroupIds) {
            desiredGroupIds = this._externalGroupsToInternalGroups(profile.externalGroupIds);
        }
        return UserDAO.getUserInstanceByEmail(profile.email, true).then(user => {
            if (user) {
                Log.debug('auth(' + profile.username + '): source:' + source + ', in-db');
                return Promise.resolve().then(() => {
                    // if the user source is different, we migrate the user from 'local' to `source`
                    if (user.source !== source) {
                        user.username = profile.username;
                        user.source = source;
                        Log.debug('auth(' + profile.username + '): source:' + source + ', migrating-source');
                        return user.save();
                    }
                }).then(() => {
                    return UserDAO.formatToPublicUser(user);
                });
            }
            // if the user was not found, we create the user
            Log.debug('auth(' + profile.username + '): source:' + source + ', creating');
            return UserDAO.createUser(profile.username, profile.email, null, desiredGroupIds, source);
        });
    }
    /**
     * @param {string} usernameOrEmail Username or email of the user
     * @param {string} password        Password of the user
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _authenticate(usernameOrEmail, password) {
        return Promise.resolve().then(() => {
            // strategy 1: try to authenticate with external providers
            const externalUserPromise = this._getProviderAuthPromise(usernameOrEmail, password);
            if (externalUserPromise) {
                return externalUserPromise.then(externalUserProfile => {
                    if (!externalUserProfile) {
                        // user not found or wrong credentials for LDAP/AD user (will try next strategy)
                        Log.debug('auth(' + usernameOrEmail + '): source:external, pass:NOK');
                        return;
                    }
                    return this._getOrCreateShadowExternalUser(externalUserProfile, 'ldap');
                });
            }
        }).then(user => {
            if (Utils.hasValue(user)) {
                // user was authenticated with an external provider
                return user;
            }
            // strategy 2: look for user in local DB
            return UserDAO.getLocalUserByUsernameAndPassword(usernameOrEmail, password).then(dbUser => {
                if (dbUser && dbUser.id === UserDAO.model.UNIQUE_USER_ID) {
                    return Errors.access('unauthorized', 'This user cannot be used when authentication is enabled.', true);
                }
                if (dbUser && dbUser.id === UserDAO.model.GUEST_USER_ID) {
                    return Errors.access('unauthorized', 'This user cannot be used to log in.', true);
                }
                // found user in DB, a local user, password matched
                if (!dbUser) {
                    return Errors.access('unauthorized', 'Incorrect username/email or password.', true);
                }
                Log.debug('auth(' + usernameOrEmail + '): source:local, pass:ok');
                return Promise.resolve(dbUser);
            });
        });
    }
    /**
     * Save the ID of the user in the session.
     *
     * @param {IncomingMessage} req  The current HTTP request
     * @param {PublicUser}      user Public user populated with actions
     * @returns {Bluebird<PublicUser>}
     * @private
     */
    _saveUserSession(req, user) {
        return new Promise((resolve, reject) => {
            req.session.userId = user.id;
            // We also save in the session if the user is admin
            // This is needed to kick out other users if floating licenses are on
            _.forEach(user.groups, group => {
                if (group.builtin && group.name === Db.models.group.ADMIN_GROUP_NAME) {
                    req.session.admin = true;
                }
            });
            req.session.save(err => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(user);
                }
            });
        }).then(user => {
            return this._checkSessionErrors(req).return(user);
        });
    }
    /**
     * Authenticate a user.
     *
     * @param {string}          usernameOrEmail Username or email of the user
     * @param {string}          password        Password of the user
     * @param {IncomingMessage} req             The current HTTP request
     * @returns {Bluebird<PublicUser>}
     */
    login(usernameOrEmail, password, req) {
        if (Utils.noValue(usernameOrEmail) || Utils.noValue(password)) {
            throw Errors.business('missing_field', 'Username and password are required.');
        }
        return this._authenticate(usernameOrEmail, password).then(user => {
            if (!user) {
                return Errors.access('unauthorized', null, true);
            }
            return this._saveUserSession(req, user);
        }).catch(err => {
            if (err instanceof Errors.LkError) {
                throw err;
            }
            Log.error(err);
            return Errors.technical('critical', err, true);
        });
    }
    /**
     * Return the URL of the OAuth2 authorization endpoint.
     *
     * @param {IncomingMessage} req The current HTTP request (required to access the session)
     * @returns {Bluebird<string>} authenticateURL
     */
    getAuthenticateURLSSO(req) {
        if (!this._ssoProvider.enabled) {
            return Errors.access('feature_disabled', 'No Single Sign-On authentication service is enabled.', true);
        }
        const state = Utils.randomHex(30);
        const isHttps = Utils.isRequestHTTPS(req) || Config.get('server.forcePublicHttps', false);
        let requestBaseUrl = (isHttps ? 'https' : 'http') + '://' + req.headers.host;
        const baseFolder = Config.get('server.baseFolder');
        requestBaseUrl += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}` : '';
        return new Promise((resolve, reject) => {
            // Needed to make the session live in our session store
            req.session.twoStageAuth = true;
            req.session.state = state;
            req.session.save(err => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve();
                }
            });
        }).then(() => {
            return this._ssoProvider.getAuthenticateURLSSO(state, requestBaseUrl);
        });
    }
    /**
     * Authenticate the user via OAuth2/SAML2.
     *
     * @param {string}          code    Response code from OAuth2/SAML2 server
     * @param {string}          [state] Handshake state from OAuth2 server
     * @param {IncomingMessage} req     The current HTTP request (required to access the session)
     * @returns {Bluebird<void>}
     */
    handleAuthenticateURLResponseSSO(code, state, req) {
        if (!this._ssoProvider.enabled) {
            return Errors.access('feature_disabled', 'No Single Sign-On authentication service is enabled.', true);
        }
        Utils.check.exist('code', code);
        // check the state only in OAuth2
        if (this._oauth2Provider.enabled) {
            if (state !== req.session.state) {
                if (Utils.noValue(req.session.state)) {
                    Log.warn('Session state is undefined in OAuth2 response, ' +
                        'redirect domain might not match actual domain.');
                }
                return Errors.access('unauthorized', 'The OAuth2 response state did not match.', true);
            }
        }
        const isHttps = Utils.isRequestHTTPS(req) || Config.get('server.forcePublicHttps', false);
        let requestBaseUrl = (isHttps ? 'https' : 'http') + '://' + req.headers.host;
        const baseFolder = Config.get('server.baseFolder');
        requestBaseUrl += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}` : '';
        return this._ssoProvider.handleAuthenticateURLResponseSSO(code, requestBaseUrl).then(profile => {
            // TODO source for saml2 is "oauth"
            return this._getOrCreateShadowExternalUser(profile, 'oauth');
        }).then(user => {
            return this._saveUserSession(req, user);
        }).return();
    }
    /**
     * Log the current user out of Linkurious.
     *
     * @param {IncomingMessage} req The current HTTP request
     * @returns {Bluebird<void>}
     */
    logout(req) {
        return new Promise((resolve, reject) => {
            req.session.destroy(err => {
                if (err) {
                    reject(err);
                }
                else {
                    // if no user was logged id
                    if (Utils.noValue(req.user)) {
                        return reject(Errors.access('unauthorized'));
                    }
                    resolve();
                }
            });
        });
    }
    /**
     * Return a resolved promise if the user can manage users on at least one data-source or
     * on a particular data-source if `sourceKey` is defined.
     *
     * @param {IncomingMessage} req
     * @param {string}          [sourceKey]
     * @returns {Bluebird<void>}
     */
    canManageUsers(req, sourceKey) {
        return this.getCurrentWrappedUser(req).canManageUsers(sourceKey);
    }
    /**
     * Return the current user.
     *
     * @param {IncomingMessage} req                The current HTTP request
     * @param {boolean}         [throwIfNone=true] By default, it will throw an exception if no current user
     * @throws {LkError} if no current user and `throwIfNone` is true
     * @returns {PublicUser} Public user with actions, groups and access rights (with wildcards not expanded)
     */
    getCurrentUser(req, throwIfNone) {
        if (!req.user && throwIfNone !== false) {
            throw Errors.access('unauthorized');
        }
        return req.user;
    }
    /**
     * @param {IncomingMessage} req                The current HTTP request
     * @param {boolean}         [throwIfNone=true] By default, it will throw an exception if no current user
     * @returns {WrappedUser} Wrapped user with actions, groups and access rights (with wildcards not expanded)
     */
    getCurrentWrappedUser(req, throwIfNone) {
        if (req.wrappedUser) {
            return req.wrappedUser;
        }
        if (!req.user && throwIfNone !== false) {
            throw Errors.access('unauthorized');
        }
        if (req.user) {
            req.wrappedUser = new WrappedUser(req.user, req.application);
        }
        return req.wrappedUser;
    }
    /**
     * Check if the application has the right perform the action.
     *
     * @param {PublicApplication} application
     * @param {string}            [actionKey]
     * @throws {LkError} if `actionKey` is not allowed
     * @private
     */
    _checkAppAction(application, actionKey) {
        if (actionKey !== undefined) {
            // check that the action is valid
            Utils.check.values('actionKey', actionKey, Db.models.application.APP_ACTIONS, true);
        }
        // action is allowed for the app
        const allowed = application.rights.includes(actionKey);
        if (allowed) {
            return;
        }
        // action is not allowed for the app
        throw Errors.access('forbidden', 'Application "' + application.name +
            '" (#' + application.id + ') is not allowed to do action "' + actionKey + '".');
    }
    /**
     * Get the current user wrapped:
     * - check for application rights (if the user is an app).
     * - check for guest mode (if the user is the guest user).
     *
     * @param {IncomingMessage} req                 The current HTTP request
     * @param {string}          [intendedApiAction] An API action the application needs to be allowed to do
     * @param {boolean}         [guestModeAllowed]  Whether the guest user can be returned
     * @throws {LkError} if req.application is defined and intendedApiAction is not allowed
     * @returns {WrappedUser}
     */
    getUserCheck(req, intendedApiAction, guestModeAllowed) {
        // if we are an application
        if (Utils.hasValue(req.application)) {
            // if the intended action is not defined, it means for sure it can't be performed by an app
            if (Utils.noValue(intendedApiAction)) {
                throw Errors.access('forbidden', 'Application "' + req.application.name +
                    '" (#' + req.application.id + ') does not have access to this feature.');
            }
            // we check if we have the right to do the intended action
            this._checkAppAction(req.application, intendedApiAction);
        }
        const currentWrappedUser = this.getCurrentWrappedUser(req);
        if (!guestModeAllowed && currentWrappedUser.id === UserDAO.model.GUEST_USER_ID) {
            throw Errors.access('forbidden', 'A guest user does not have access to this feature.');
        }
        return currentWrappedUser;
    }
    /**
     * Perform startup checks for all enabled auth providers.
     *
     * @returns {Bluebird<void>}
     */
    providersStartupCheck() {
        return Promise.each(this.providers, provider => {
            return provider.startupCheck().catch(e => {
                Log.error(e);
                throw e;
            });
        }).return();
    }
    /**
     * Check that there is an authenticated user.
     * Return a rejected promise if no current user and `throwIfNone` is true.
     *
     * @param {IncomingMessage} req               The current HTTP request
     * @param {boolean}         [throwIfNot=true] Whether to reject if not authenticated
     * @returns {Bluebird<boolean>}
     */
    isAuthenticated(req, throwIfNot) {
        return Promise.resolve().then(() => {
            return !!this.getCurrentUser(req, throwIfNot);
        });
    }
    /**
     * Check if `actionName` is doable by the current user.
     * If `sourceKey` is undefined it means *any* sourceKey. To not confuse with *all* sourceKey.
     *
     * Additionally, if the API is used by an application,
     * check if `intendedApiAction` is doable by the current application on behalf of the user.
     *
     * Note:
     * - all the possible `actionName` are defined in `PUBLIC_ACTIONS` and `PRIVATE_ACTIONS`, and they are actions for users
     * - all the possible `intendedApiAction` are defined in `APP_ACTIONS` and they are actions for applications
     *
     * An application A to act on behalf of a user U needs:
     *  - U to be able to perform `actionName`
     *  - A to be able to perform `intendedApiAction`
     *
     * @param {IncomingMessage} req                 The current HTTP request
     * @param {string}          actionName          Name of the action the user needs to be allowed to do
     * @param {string}          [sourceKey]         Key of the data-source
     * @param {string}          [intendedApiAction] An API action the application needs to be allowed to do
     * @param {boolean}         [guestModeAllowed]  Whether the guest user can be returned
     * @param {boolean}         [throwIfNot=true]   Whether to reject if the condition is not met
     * @returns {Bluebird<boolean>}
     */
    hasAction(req, actionName, sourceKey, intendedApiAction, guestModeAllowed, throwIfNot = true) {
        if (actionName.startsWith('admin') &&
            intendedApiAction !== 'admin.index' &&
            Utils.hasValue(req.application)) {
            return Errors.access('admin_required', 'Applications cannot perform administrator actions.', true); // except `admin.index`
        }
        let wrappedUser;
        try {
            // We get the user and at the same time we check the api action
            wrappedUser = this.getUserCheck(req, intendedApiAction, guestModeAllowed);
        }
        catch (e) {
            if (throwIfNot) {
                throw e;
            }
            return Promise.resolve(false);
        }
        return Promise.resolve().then(() => {
            return wrappedUser.hasAction(actionName, sourceKey, throwIfNot);
        });
    }
    /**
     * Check that builtin groups exists for every existing data-source.
     * Create them if they don't exist.
     *
     * @returns {Bluebird<void>}
     */
    ensureBuiltinGroups() {
        return Db.models.dataSourceState.findAll({ attributes: ['key'] }).map(dataSourceStateInstance => {
            return Db.models.group.ensureBuiltins(dataSourceStateInstance.key);
        }, { concurrency: 1 }).return();
    }
    /**
     * @returns {Bluebird<void>}
     * @private
     */
    _migrateDefaultGroup() {
        // 1) retrieve the default group
        return Db.models.group.findAllByName('default', true).then(defaultGroups => {
            const defaultGroup = defaultGroups[0]; // unwrap it, there is only one
            if (Utils.noValue(defaultGroup)) {
                return; // migration already took place in the past
            }
            /**@type {UserInstance[]}*/
            let defaultUsers;
            /**@type {UserInstance[]}*/
            let adminUsers;
            // 2) look for all the users belonging to the deprecated default group
            return Db.models.user.findAll({
                include: [{
                        model: Db.models.group, where: { id: defaultGroup.id }
                    }]
            }).then(_defaultUsers => {
                defaultUsers = _defaultUsers;
                return Db.models.user.findAll({
                    include: [{
                            model: Db.models.group, where: { id: Db.models.group.ADMIN_GROUP.id }
                        }]
                });
            }).then(_adminUsers => {
                adminUsers = _adminUsers;
                // 3) retrieve all the builtin "read" groups
                return Db.models.group.findAllByName('read', true);
            }).then(readGroups => {
                // 4) to any group in readGroups assign all the users in defaultUsers not in the admin group
                const readUsers = _.differenceBy(defaultUsers, adminUsers, 'id');
                return Promise.map(readGroups, group => {
                    return group.addUsers(readUsers);
                }, { concurrency: 1 });
            }).then(() => {
                // 5) remove all the users from the defaultGroup
                return defaultGroup.removeUsers(defaultUsers);
            }).then(() => {
                // 6) delete the default group
                return defaultGroup.destroy();
            });
        });
    }
    /**
     * @param {GroupInstance} legacyGroup Group instance with access rights
     * @returns {Bluebird<void>}
     * @private
     */
    _migrateLegacyGroup(legacyGroup) {
        const usersWithLegacyGroupQuery = {
            include: [{
                    model: Db.models.group, where: { id: legacyGroup.id }
                }]
        };
        const rightsWithLegacyGroupQuery = {
            where: { groupId: legacyGroup.id }
        };
        /**@type {UserInstance[]}*/
        let legacyUsers;
        // 1) retrieve all the users belonging to this legacy group
        return Db.models.user.findAll(usersWithLegacyGroupQuery).then(_legacyUsers => {
            legacyUsers = _legacyUsers;
            // 2) retrieve all the data-source keys
            return Db.models.dataSourceState.findAll();
        }).map(dataSourceStateInstance => {
            // 3) create a group with the same name in every data-source
            return Db.models.group.create({
                sourceKey: dataSourceStateInstance.key,
                name: legacyGroup.name,
                builtin: false
            }).then(groupInstance => {
                // 4) filter the access rights of the legacy group by sourceKey and turn them in AccessRightAttributes
                /**@type {AccessRightAttributes[]}*/
                const accessRights = _.map(_.filter(legacyGroup.accessRights, accessRight => accessRight.sourceKey === groupInstance.sourceKey), accessRightInstance => {
                    return Db.models.accessRight.instanceToPublicAttributes(accessRightInstance, true);
                });
                // 5) create and assign the new access rights to the new group
                return Promise.map(accessRights, accessRight => {
                    return Db.models.accessRight.create(accessRight).then(rightInstance => {
                        return groupInstance.addAccessRight(rightInstance);
                    });
                }, { concurrency: 1 }).then(() => {
                    // 6) add the new group to any user of the legacy group
                    return groupInstance.addUsers(legacyUsers);
                });
            });
        }, { concurrency: 1 }).then(() => {
            // 7) delete all the access rights of the legacy group
            return Db.models.accessRight.destroy(rightsWithLegacyGroupQuery);
        }).then(() => {
            // 8) remove all the users from the legacy group
            return legacyGroup.removeUsers(legacyUsers);
        }).then(() => {
            // 9) delete the legacy group
            return legacyGroup.destroy();
        });
    }
    /**
     * Legacy groups were groups with sourceKey set to *.
     * This was prior than introducing the builtin groups "read", "read and edit" and so on.
     * Originally every user not belonging to a group belonged to a group called "default".
     *
     * With the release of LKE v2 we migrate all the legacy groups to new groups.
     * - Every user belonging to the "default" group will belong to any "read" builtin group of
     * every data-source.
     * - Every user belonging to a legacy "custom" group will belong to a copy of that custom group
     * specific for the data-source.
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    migrateLegacyGroups() {
        // 1) migrate the default group
        return this._migrateDefaultGroup().then(() => {
            // 2) migrate any other legacy group
            const legacyGroupQuery = {
                where: { sourceKey: '*', builtin: false },
                include: [Db.models.accessRight]
            };
            return Db.models.group.findAll(legacyGroupQuery).map(legacyGroup => {
                return this._migrateLegacyGroup(legacyGroup);
            }, { concurrency: 1 });
        }).return();
    }
}
module.exports = new AccessService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYWNjZXNzL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBRXhDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUN6QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQztBQUVqQyxTQUFTO0FBQ1QsTUFBTSxFQUFDLFdBQVcsRUFBQyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUMvQyxNQUFNLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0FBQ3RFLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQy9DLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ3hDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUV6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FtQ0c7QUFFSCxNQUFNLGFBQWE7SUFDakI7UUFDRSxnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUV0RixnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFNUUsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRTtZQUMvRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQixzREFBc0QsQ0FDdkQsQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUU5RixrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFVBQVUsR0FBRztZQUNoQixJQUFJLG1CQUFtQixDQUNyQixNQUFNLEVBQUUsTUFBTSxFQUFFLGFBQWEsQ0FDOUI7WUFDRCxJQUFJLG1CQUFtQixDQUNyQiw0QkFBNEIsRUFBRSxtQkFBbUIsRUFBRSwwQkFBMEIsQ0FDOUU7WUFDRCxJQUFJLENBQUMsZUFBZTtZQUNwQixJQUFJLENBQUMsY0FBYztTQUNwQixDQUFDO1FBRUYseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWhGLElBQUksQ0FBQywwQkFBMEIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRXJGLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLFNBQVM7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDekIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsSUFBSSxZQUFZO1FBQ2QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzVCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxnQkFBZ0IsQ0FBQyxHQUFHO1FBQ2xCLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUN2RCxNQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUN4RCxJQUFJLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1FBRTFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDakIsaURBQWlEO1lBQ2pELGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO1NBQ2pEO1FBRUQsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDOUIsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUNyQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3pEO1lBQ0QsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUM7U0FDaEQ7UUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtZQUNuQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyRCxHQUFHLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUVoQixHQUFHLENBQUMsV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILFNBQVMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLGdCQUFnQjtRQUNoRCxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ2hCLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNyQztRQUVELDJCQUEyQjtRQUMzQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzNDLDhDQUE4QztZQUM5QyxrREFBa0Q7WUFDbEQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCxlQUFlLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJO29CQUM5QyxNQUFNLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEdBQUcseUNBQXlDLENBQ2hGLENBQUM7YUFDSDtZQUVELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDMUQ7UUFFRCxJQUFJLENBQUMsZ0JBQWdCLElBQUksV0FBVyxDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRTtZQUN2RSxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCxvREFBb0QsQ0FDckQsQ0FBQztTQUNIO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGdCQUFnQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSTtRQUM3QixJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUN0QyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsSUFBSSxFQUFFLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixHQUFHLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxtQkFBbUIsQ0FBQyxHQUFHO1FBQ3JCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3BDLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUN2QyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7Z0JBQ3ZCLElBQUksS0FBSyxDQUFDO2dCQUNWLFFBQVEsWUFBWSxFQUFFO29CQUNwQixLQUFLLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO29CQUNqQyxLQUFLLFlBQVksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCO3dCQUN2QyxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO3dCQUN6QyxNQUFNO29CQUNSLEtBQUssWUFBWSxDQUFDLE1BQU0sQ0FBQyxlQUFlO3dCQUN0QyxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO3dCQUN6QyxNQUFNO29CQUNSLEtBQUssWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhO3dCQUNwQyxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQzt3QkFDckMsTUFBTTtvQkFDUjt3QkFDRSxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsbUJBQW1CLFlBQVksR0FBRyxDQUFDLENBQUM7aUJBQzdFO2dCQUVELE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGdCQUFnQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSTtRQUM3Qix3Q0FBd0M7UUFDeEMsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRW5DLGtDQUFrQztRQUNsQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ2hCLElBQUksRUFBRSxDQUFDO1lBQ1AsT0FBTztTQUNSO1FBRUQsT0FBTyxXQUFXLENBQUMsZ0JBQWdCLENBQ2pDLFdBQVcsQ0FBQyxJQUFJLEVBQ2hCLFdBQVcsQ0FBQyxJQUFJLENBQ2pCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ2xCLDhDQUE4QztZQUM5QyxHQUFHLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDM0Isd0JBQXdCO1lBQ3hCLEdBQUcsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUN6QyxHQUFHLENBQUMsV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzdELElBQUksRUFBRSxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHVCQUF1QixDQUFDLGVBQWUsRUFBRSxRQUFRO1FBQy9DLEtBQUssTUFBTSxRQUFRLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNyQyxJQUFJLFFBQVEsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3BCLE9BQU8sUUFBUSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDekQ7U0FDRjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCwrQkFBK0IsQ0FBQyxnQkFBZ0I7UUFDOUMsSUFBSSxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7UUFFMUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxlQUFlLENBQUMsRUFBRTtZQUM1QyxNQUFNLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO2dCQUNyRixPQUFPLEdBQUcsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBRyxlQUFlLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNwRSxDQUFDLENBQUMsQ0FBQztZQUVILE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQzFFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsT0FBTzthQUNSO1lBRUQsTUFBTSxtQkFBbUIsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDckYsZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDbEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSCw4QkFBOEIsQ0FBQyxPQUFPLEVBQUUsTUFBTTtRQUM1QyxNQUFNLDBCQUEwQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztRQUVuRiwrREFBK0Q7UUFDL0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDO1lBQzVDLENBQUMsQ0FBQyxjQUFjLENBQUMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLGdCQUFnQixFQUNuRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFFBQVEsR0FBRyxZQUFZLEdBQUcsTUFBTSxHQUFHLGFBQWEsQ0FBQyxDQUFDO1lBRTlFLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQ2pDLG1EQUFtRCxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzlEO1FBRUQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBRTNCLElBQUksT0FBTyxDQUFDLGdCQUFnQixFQUFFO1lBQzVCLGVBQWUsR0FBRyxJQUFJLENBQUMsK0JBQStCLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDbEY7UUFFRCxPQUFPLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNyRSxJQUFJLElBQUksRUFBRTtnQkFDUixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsUUFBUSxHQUFHLFlBQVksR0FBRyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUM7Z0JBRTFFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ2pDLGdGQUFnRjtvQkFDaEYsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRTt3QkFDMUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDO3dCQUNqQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzt3QkFDckIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFFBQVEsR0FBRyxZQUFZLEdBQUcsTUFBTSxHQUFHLG9CQUFvQixDQUFDLENBQUM7d0JBQ3JGLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO3FCQUNwQjtnQkFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO29CQUNYLE9BQU8sT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMxQyxDQUFDLENBQUMsQ0FBQzthQUNKO1lBQ0QsZ0RBQWdEO1lBQ2hELEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsWUFBWSxHQUFHLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztZQUM3RSxPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDNUYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxhQUFhLENBQUMsZUFBZSxFQUFFLFFBQVE7UUFDckMsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQywwREFBMEQ7WUFDMUQsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ3BGLElBQUksbUJBQW1CLEVBQUU7Z0JBQ3ZCLE9BQU8sbUJBQW1CLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7b0JBQ3BELElBQUksQ0FBQyxtQkFBbUIsRUFBRTt3QkFDeEIsZ0ZBQWdGO3dCQUNoRixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxlQUFlLEdBQUcsOEJBQThCLENBQUMsQ0FBQzt3QkFDdEUsT0FBTztxQkFDUjtvQkFFRCxPQUFPLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxtQkFBbUIsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDMUUsQ0FBQyxDQUFDLENBQUM7YUFDSjtRQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDeEIsbURBQW1EO2dCQUNuRCxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsd0NBQXdDO1lBQ3hDLE9BQU8sT0FBTyxDQUFDLGlDQUFpQyxDQUFDLGVBQWUsRUFBRSxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3hGLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUU7b0JBQ3hELE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FDbEIsY0FBYyxFQUFFLDBEQUEwRCxFQUFFLElBQUksQ0FDakYsQ0FBQztpQkFDSDtnQkFFRCxJQUFJLE1BQU0sSUFBSSxNQUFNLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO29CQUN2RCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQ2xCLGNBQWMsRUFBRSxxQ0FBcUMsRUFBRSxJQUFJLENBQzVELENBQUM7aUJBQ0g7Z0JBRUQsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxFQUFFO29CQUNYLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3JGO2dCQUVELEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLGVBQWUsR0FBRywwQkFBMEIsQ0FBQyxDQUFDO2dCQUNsRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLElBQUk7UUFDeEIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBRTdCLG1EQUFtRDtZQUNuRCxxRUFBcUU7WUFDckUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUM3QixJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRTtvQkFDcEUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2lCQUMxQjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3JCLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Y7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsS0FBSyxDQUFDLGVBQWUsRUFBRSxRQUFRLEVBQUUsR0FBRztRQUNsQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM3RCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLHFDQUFxQyxDQUFDLENBQUM7U0FDL0U7UUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMvRCxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2xEO1lBRUQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNiLElBQUksR0FBRyxZQUFZLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2pDLE1BQU0sR0FBRyxDQUFDO2FBQ1g7WUFFRCxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2YsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxxQkFBcUIsQ0FBQyxHQUFHO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUM5QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQ3JDLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsQyxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDMUYsSUFBSSxjQUFjLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO1FBRTdFLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuRCxjQUFjLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxVQUFVLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFMUYsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNyQyx1REFBdUQ7WUFDdkQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ2hDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUMxQixHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDckIsSUFBSSxHQUFHLEVBQUU7b0JBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNiO3FCQUFNO29CQUNMLE9BQU8sRUFBRSxDQUFDO2lCQUNYO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQztRQUN4RSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0NBQWdDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHO1FBQy9DLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtZQUM5QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQ3JDLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRWhDLGlDQUFpQztRQUNqQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFO1lBQ2hDLElBQUksS0FBSyxLQUFLLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFO2dCQUMvQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDcEMsR0FBRyxDQUFDLElBQUksQ0FDTixpREFBaUQ7d0JBQ2pELGdEQUFnRCxDQUNqRCxDQUFDO2lCQUNIO2dCQUNELE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsMENBQTBDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDeEY7U0FDRjtRQUVELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMxRixJQUFJLGNBQWMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7UUFFN0UsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ25ELGNBQWMsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLFVBQVUsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUUxRixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsZ0NBQWdDLENBQ3ZELElBQUksRUFBRSxjQUFjLENBQ3JCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2YsbUNBQW1DO1lBQ25DLE9BQU8sSUFBSSxDQUFDLDhCQUE4QixDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDYixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxNQUFNLENBQUMsR0FBRztRQUNSLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3hCLElBQUksR0FBRyxFQUFFO29CQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDYjtxQkFBTTtvQkFDTCwyQkFBMkI7b0JBQzNCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQzNCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztxQkFDOUM7b0JBRUQsT0FBTyxFQUFFLENBQUM7aUJBQ1g7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxjQUFjLENBQUMsR0FBRyxFQUFFLFNBQVM7UUFDM0IsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXO1FBQzdCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLFdBQVcsS0FBSyxLQUFLLEVBQUU7WUFDdEMsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ3JDO1FBRUQsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gscUJBQXFCLENBQUMsR0FBRyxFQUFFLFdBQVc7UUFDcEMsSUFBSSxHQUFHLENBQUMsV0FBVyxFQUFFO1lBQ25CLE9BQU8sR0FBRyxDQUFDLFdBQVcsQ0FBQztTQUN4QjtRQUVELElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLFdBQVcsS0FBSyxLQUFLLEVBQUU7WUFDdEMsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ3JDO1FBRUQsSUFBSSxHQUFHLENBQUMsSUFBSSxFQUFFO1lBQ1osR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM5RDtRQUVELE9BQU8sR0FBRyxDQUFDLFdBQVcsQ0FBQztJQUN6QixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGVBQWUsQ0FBQyxXQUFXLEVBQUUsU0FBUztRQUNwQyxJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUU7WUFDM0IsaUNBQWlDO1lBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3JGO1FBRUQsZ0NBQWdDO1FBQ2hDLE1BQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZELElBQUksT0FBTyxFQUFFO1lBQ1gsT0FBTztTQUNSO1FBRUQsb0NBQW9DO1FBQ3BDLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsV0FBVyxFQUNYLGVBQWUsR0FBRyxXQUFXLENBQUMsSUFBSTtZQUNsQyxNQUFNLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxpQ0FBaUMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUMvRSxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSCxZQUFZLENBQUMsR0FBRyxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQjtRQUNuRCwyQkFBMkI7UUFDM0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNuQywyRkFBMkY7WUFDM0YsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQ3BDLE1BQU0sTUFBTSxDQUFDLE1BQU0sQ0FDakIsV0FBVyxFQUNYLGVBQWUsR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUk7b0JBQ3RDLE1BQU0sR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsR0FBRyx5Q0FBeUMsQ0FDeEUsQ0FBQzthQUNIO1lBRUQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1NBQzFEO1FBRUQsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFM0QsSUFBSSxDQUFDLGdCQUFnQixJQUFJLGtCQUFrQixDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRTtZQUM5RSxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQ2pCLFdBQVcsRUFDWCxvREFBb0QsQ0FDckQsQ0FBQztTQUNIO1FBRUQsT0FBTyxrQkFBa0IsQ0FBQztJQUM1QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILHFCQUFxQjtRQUNuQixPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsRUFBRTtZQUM3QyxPQUFPLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3ZDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsTUFBTSxDQUFDLENBQUM7WUFDVixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxlQUFlLENBQUMsR0FBRyxFQUFFLFVBQVU7UUFDN0IsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXNCRztJQUNILFNBQVMsQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUMxRixJQUNFLFVBQVUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzlCLGlCQUFpQixLQUFLLGFBQWE7WUFDbkMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQy9CO1lBQ0EsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixnQkFBZ0IsRUFBRSxvREFBb0QsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtTQUN6RztRQUVELElBQUksV0FBVyxDQUFDO1FBQ2hCLElBQUk7WUFDRiwrREFBK0Q7WUFDL0QsV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixDQUFDLENBQUM7U0FDM0U7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULElBQUksVUFBVSxFQUFFO2dCQUNkLE1BQU0sQ0FBQyxDQUFDO2FBQ1Q7WUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDL0I7UUFFRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLE9BQU8sV0FBVyxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsbUJBQW1CO1FBQ2pCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEVBQUMsVUFBVSxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO1lBQzVGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3JFLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxvQkFBb0I7UUFDbEIsZ0NBQWdDO1FBQ2hDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDekUsTUFBTSxZQUFZLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsK0JBQStCO1lBQ3RFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDL0IsT0FBTyxDQUFDLDJDQUEyQzthQUNwRDtZQUVELDJCQUEyQjtZQUMzQixJQUFJLFlBQVksQ0FBQztZQUNqQiwyQkFBMkI7WUFDM0IsSUFBSSxVQUFVLENBQUM7WUFFZixzRUFBc0U7WUFDdEUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQzVCLE9BQU8sRUFBRSxDQUFDO3dCQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLEVBQUUsRUFBQztxQkFDckQsQ0FBQzthQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQzFCLFlBQVksR0FBRyxhQUFhLENBQUM7Z0JBRTdCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM1QixPQUFPLEVBQUUsQ0FBQzs0QkFDUixLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUM7eUJBQ3BFLENBQUM7aUJBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUNwQixVQUFVLEdBQUcsV0FBVyxDQUFDO2dCQUV6Qiw0Q0FBNEM7Z0JBQzVDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNyRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ25CLDRGQUE0RjtnQkFDNUYsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUVqRSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxFQUFFO29CQUNyQyxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ25DLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsZ0RBQWdEO2dCQUNoRCxPQUFPLFlBQVksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCw4QkFBOEI7Z0JBQzlCLE9BQU8sWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2hDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG1CQUFtQixDQUFDLFdBQVc7UUFDN0IsTUFBTSx5QkFBeUIsR0FBRztZQUNoQyxPQUFPLEVBQUUsQ0FBQztvQkFDUixLQUFLLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxFQUFFLEVBQUM7aUJBQ3BELENBQUM7U0FDSCxDQUFDO1FBRUYsTUFBTSwwQkFBMEIsR0FBRztZQUNqQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLEVBQUUsRUFBQztTQUNqQyxDQUFDO1FBRUYsMkJBQTJCO1FBQzNCLElBQUksV0FBVyxDQUFDO1FBRWhCLDJEQUEyRDtRQUMzRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUMzRSxXQUFXLEdBQUcsWUFBWSxDQUFDO1lBRTNCLHVDQUF1QztZQUN2QyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzdDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO1lBQy9CLDREQUE0RDtZQUM1RCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDNUIsU0FBUyxFQUFFLHVCQUF1QixDQUFDLEdBQUc7Z0JBQ3RDLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSTtnQkFDdEIsT0FBTyxFQUFFLEtBQUs7YUFDZixDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUN0QixzR0FBc0c7Z0JBQ3RHLG9DQUFvQztnQkFDcEMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQzFELFdBQVcsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFNBQVMsS0FBSyxhQUFhLENBQUMsU0FBUyxDQUNqRSxFQUFFLG1CQUFtQixDQUFDLEVBQUU7b0JBQ3ZCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsMEJBQTBCLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3JGLENBQUMsQ0FBQyxDQUFDO2dCQUVILDhEQUE4RDtnQkFDOUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsRUFBRTtvQkFDN0MsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO3dCQUNwRSxPQUFPLGFBQWEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQ3JELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQzdCLHVEQUF1RDtvQkFDdkQsT0FBTyxhQUFhLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM3QyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUFFLEVBQUMsV0FBVyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM3QixzREFBc0Q7WUFDdEQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsMEJBQTBCLENBQUMsQ0FBQztRQUNuRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsZ0RBQWdEO1lBQ2hELE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsNkJBQTZCO1lBQzdCLE9BQU8sV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxtQkFBbUI7UUFDakIsK0JBQStCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUMzQyxvQ0FBb0M7WUFDcEMsTUFBTSxnQkFBZ0IsR0FBRztnQkFDdkIsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDO2dCQUN2QyxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQzthQUNqQyxDQUFDO1lBRUYsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQ2pFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQy9DLENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLGFBQWEsRUFBRSxDQUFDIn0=