/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2017-06-12.
 */
'use strict';
// access rights of builtin groups are not actually saved on the sql db
const ADMIN_ACCESS_RIGHTS = [
    {
        targetType: 'action',
        targetName: 'admin.users',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.alerts',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.connect',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.index',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.styles',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.app',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.report',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.users.delete',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.config',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawReadQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawWriteQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'runQuery',
        type: 'do'
    },
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'alert',
        targetName: '*',
        type: 'read'
    }
];
const SOURCE_MANAGER_ACCESS_RIGHTS = [
    {
        targetType: 'action',
        targetName: 'admin.users',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.alerts',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.connect',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.index',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.styles',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'admin.report',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawReadQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawWriteQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'runQuery',
        type: 'do'
    },
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'alert',
        targetName: '*',
        type: 'read'
    }
];
const READ_EDIT_DELETE_ACCESS_RIGHTS = [
    {
        targetType: 'action',
        targetName: 'admin.alerts',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawReadQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'rawWriteQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'runQuery',
        type: 'do'
    },
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'write'
    },
    {
        targetType: 'alert',
        targetName: '*',
        type: 'read'
    }
];
const READ_EDIT_ACCESS_RIGHTS = [
    {
        targetType: 'action',
        targetName: 'rawReadQuery',
        type: 'do'
    },
    {
        targetType: 'action',
        targetName: 'runQuery',
        type: 'do'
    },
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'edit'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'edit'
    },
    {
        targetType: 'alert',
        targetName: '*',
        type: 'read'
    }
];
const READ_ACCESS_RIGHTS = [
    {
        targetType: 'action',
        targetName: 'runQuery',
        type: 'do'
    },
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'read'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'read'
    },
    {
        targetType: 'alert',
        targetName: '*',
        type: 'read'
    }
];
const READ_ONLY_ACCESS_RIGHTS = [
    {
        targetType: 'nodeCategory',
        targetName: '*',
        type: 'read'
    },
    {
        targetType: 'edgeType',
        targetName: '*',
        type: 'read'
    }
];
module.exports = {
    ADMIN_ACCESS_RIGHTS,
    SOURCE_MANAGER_ACCESS_RIGHTS,
    READ_EDIT_DELETE_ACCESS_RIGHTS,
    READ_EDIT_ACCESS_RIGHTS,
    READ_ACCESS_RIGHTS,
    READ_ONLY_ACCESS_RIGHTS
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVpbHRpbkdyb3Vwcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvYnVpbHRpbkdyb3Vwcy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLHVFQUF1RTtBQUV2RSxNQUFNLG1CQUFtQixHQUFHO0lBQzFCO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGFBQWE7UUFDekIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGNBQWM7UUFDMUIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGVBQWU7UUFDM0IsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGFBQWE7UUFDekIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGNBQWM7UUFDMUIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLFdBQVc7UUFDdkIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLGNBQWM7UUFDMUIsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNEO1FBQ0UsVUFBVSxFQUFFLFFBQVE7UUFDcEIsVUFBVSxFQUFFLG9CQUFvQjtRQUNoQyxJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsZUFBZTtRQUMzQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsVUFBVTtRQUN0QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE9BQU87S0FDZDtJQUNEO1FBQ0UsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsTUFBTTtLQUNiO0NBQ0YsQ0FBQztBQUNGLE1BQU0sNEJBQTRCLEdBQUc7SUFDbkM7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsYUFBYTtRQUN6QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsZUFBZTtRQUMzQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsYUFBYTtRQUN6QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsZUFBZTtRQUMzQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsVUFBVTtRQUN0QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE9BQU87S0FDZDtJQUNEO1FBQ0UsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsTUFBTTtLQUNiO0NBQ0YsQ0FBQztBQUNGLE1BQU0sOEJBQThCLEdBQUc7SUFDckM7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsZUFBZTtRQUMzQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsVUFBVTtRQUN0QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE9BQU87S0FDZDtJQUNEO1FBQ0UsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsTUFBTTtLQUNiO0NBQ0YsQ0FBQztBQUNGLE1BQU0sdUJBQXVCLEdBQUc7SUFDOUI7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsY0FBYztRQUMxQixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsVUFBVTtRQUN0QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxNQUFNO0tBQ2I7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE1BQU07S0FDYjtJQUNEO1FBQ0UsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsTUFBTTtLQUNiO0NBQ0YsQ0FBQztBQUNGLE1BQU0sa0JBQWtCLEdBQUc7SUFDekI7UUFDRSxVQUFVLEVBQUUsUUFBUTtRQUNwQixVQUFVLEVBQUUsVUFBVTtRQUN0QixJQUFJLEVBQUUsSUFBSTtLQUNYO0lBQ0Q7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxNQUFNO0tBQ2I7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE1BQU07S0FDYjtJQUNEO1FBQ0UsVUFBVSxFQUFFLE9BQU87UUFDbkIsVUFBVSxFQUFFLEdBQUc7UUFDZixJQUFJLEVBQUUsTUFBTTtLQUNiO0NBQ0YsQ0FBQztBQUNGLE1BQU0sdUJBQXVCLEdBQUc7SUFDOUI7UUFDRSxVQUFVLEVBQUUsY0FBYztRQUMxQixVQUFVLEVBQUUsR0FBRztRQUNmLElBQUksRUFBRSxNQUFNO0tBQ2I7SUFDRDtRQUNFLFVBQVUsRUFBRSxVQUFVO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO1FBQ2YsSUFBSSxFQUFFLE1BQU07S0FDYjtDQUNGLENBQUM7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHO0lBQ2YsbUJBQW1CO0lBQ25CLDRCQUE0QjtJQUM1Qiw4QkFBOEI7SUFDOUIsdUJBQXVCO0lBQ3ZCLGtCQUFrQjtJQUNsQix1QkFBdUI7Q0FDeEIsQ0FBQyJ9