"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-06-19.
 */
// external libs
const _ = require("lodash");
/**
 * Actions that can be set to a custom group.
 */
const PUBLIC_ACTIONS = [
    {
        key: 'admin.connect',
        description: 'Connect the data-source and read the configuration'
    },
    {
        key: 'admin.index',
        description: 'Index the data-source and read the configuration'
    },
    {
        key: 'admin.users',
        description: 'Manage the users in the data-source'
    },
    {
        key: 'admin.alerts',
        description: 'Manage the alerts in the data-source'
    },
    {
        key: 'admin.report',
        description: 'Generate analytics report'
    },
    {
        key: 'runQuery',
        description: 'Execute a saved query'
    },
    {
        key: 'rawReadQuery',
        description: 'Create a read query'
    },
    {
        key: 'rawWriteQuery',
        description: 'Create a read/write query'
    },
    {
        key: 'admin.styles',
        description: 'Reset design and captions of all sandboxes of the given data-source'
    }
];
/**
 * Actions that can't be set to a custom group.
 */
const PRIVATE_ACTIONS = [
    {
        key: 'admin.app',
        description: 'Manage applications'
    },
    {
        key: 'admin.users.delete',
        description: 'Delete users'
    },
    {
        key: 'admin.config',
        description: 'Set the configuration'
    }
];
const IMPLICIT_ACTIONS = new Map();
// runQuery can be performed by user with action rawReadQuery or rawWriteQuery
IMPLICIT_ACTIONS.set('runQuery', ['runQuery', 'rawReadQuery', 'rawWriteQuery']);
// rawReadQuery can be performed by user with action rawWriteQuery
IMPLICIT_ACTIONS.set('rawReadQuery', ['rawReadQuery', 'rawWriteQuery']);
const EXPLICIT_ACTIONS = new Map();
for (const implicitAction of IMPLICIT_ACTIONS.keys()) {
    for (const explicitAction of IMPLICIT_ACTIONS.get(implicitAction)) {
        if (!EXPLICIT_ACTIONS.get(explicitAction)) {
            EXPLICIT_ACTIONS.set(explicitAction, []);
        }
        EXPLICIT_ACTIONS.get(explicitAction).push(implicitAction);
    }
}
const PUBLIC_MAP = _.keyBy(PUBLIC_ACTIONS, 'key');
const PRIVATE_MAP = _.keyBy(PRIVATE_ACTIONS, 'key');
module.exports = {
    // all action keys for a custom group
    PUBLIC_ACTIONS: _.map(PUBLIC_ACTIONS, 'key'),
    IMPLICIT_ACTIONS: IMPLICIT_ACTIONS,
    EXPLICIT_ACTIONS: EXPLICIT_ACTIONS,
    /**
     * Return true if this action key exists.
     *
     * @param key The action key
     */
    exists: (key) => !!PUBLIC_MAP[key] || !!PRIVATE_MAP[key]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9hY2Nlc3MvYWN0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSCxnQkFBZ0I7QUFDaEIsNEJBQTRCO0FBRTVCOztHQUVHO0FBQ0gsTUFBTSxjQUFjLEdBQUc7SUFDckI7UUFDRSxHQUFHLEVBQUUsZUFBZTtRQUNwQixXQUFXLEVBQUUsb0RBQW9EO0tBQ2xFO0lBQ0Q7UUFDRSxHQUFHLEVBQUUsYUFBYTtRQUNsQixXQUFXLEVBQUUsa0RBQWtEO0tBQ2hFO0lBQ0Q7UUFDRSxHQUFHLEVBQUUsYUFBYTtRQUNsQixXQUFXLEVBQUUscUNBQXFDO0tBQ25EO0lBQ0Q7UUFDRSxHQUFHLEVBQUUsY0FBYztRQUNuQixXQUFXLEVBQUUsc0NBQXNDO0tBQ3BEO0lBQ0Q7UUFDRSxHQUFHLEVBQUUsY0FBYztRQUNuQixXQUFXLEVBQUUsMkJBQTJCO0tBQ3pDO0lBQ0Q7UUFDRSxHQUFHLEVBQUUsVUFBVTtRQUNmLFdBQVcsRUFBRSx1QkFBdUI7S0FDckM7SUFDRDtRQUNFLEdBQUcsRUFBRSxjQUFjO1FBQ25CLFdBQVcsRUFBRSxxQkFBcUI7S0FDbkM7SUFDRDtRQUNFLEdBQUcsRUFBRSxlQUFlO1FBQ3BCLFdBQVcsRUFBRSwyQkFBMkI7S0FDekM7SUFDRDtRQUNFLEdBQUcsRUFBRSxjQUFjO1FBQ25CLFdBQVcsRUFBRSxxRUFBcUU7S0FDbkY7Q0FDRixDQUFDO0FBRUY7O0dBRUc7QUFDSCxNQUFNLGVBQWUsR0FBRztJQUN0QjtRQUNFLEdBQUcsRUFBRSxXQUFXO1FBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7S0FDbkM7SUFDRDtRQUNFLEdBQUcsRUFBRSxvQkFBb0I7UUFDekIsV0FBVyxFQUFFLGNBQWM7S0FDNUI7SUFDRDtRQUNFLEdBQUcsRUFBRSxjQUFjO1FBQ25CLFdBQVcsRUFBRSx1QkFBdUI7S0FDckM7Q0FDRixDQUFDO0FBRUYsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ25DLDhFQUE4RTtBQUM5RSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLGtFQUFrRTtBQUNsRSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLENBQUMsY0FBYyxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFFeEUsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ25DLEtBQUssTUFBTSxjQUFjLElBQUksZ0JBQWdCLENBQUMsSUFBSSxFQUFFLEVBQUU7SUFDcEQsS0FBSyxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7UUFDakUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN6QyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUMzRDtDQUNGO0FBRUQsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDbEQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFFcEQsaUJBQVM7SUFDUCxxQ0FBcUM7SUFDckMsY0FBYyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQztJQUM1QyxnQkFBZ0IsRUFBRSxnQkFBZ0I7SUFDbEMsZ0JBQWdCLEVBQUUsZ0JBQWdCO0lBRWxDOzs7O09BSUc7SUFDSCxNQUFNLEVBQUUsQ0FBQyxHQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUM7Q0FDakUsQ0FBQyJ9