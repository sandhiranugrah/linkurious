/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-02.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Errors = LKE.getErrors();
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
class ApplicationDAO {
    /**
     * @type {ApplicationModel}
     */
    get model() {
        return Db.models.application;
    }
    /**
     * Return an application instance by id.
     * Return a rejected promise if the application wasn't found.
     *
     * @param {number} id
     * @returns {Bluebird<ApplicationInstance>}
     */
    _getApplicationInstance(id) {
        Utils.check.posInt('id', id);
        return this.model.findOne({ where: { id: id }, include: [Db.models.group] }).then(instance => {
            if (!instance) {
                return Errors.business('not_found', `Application #${id} was not found.`, true);
            }
            return instance;
        });
    }
    /**
     * @param {ApplicationInstance} appInstance
     * @returns {Bluebird<PublicApplication>}
     */
    formatToPublicApplication(appInstance) {
        const publicApplication = this.model.instanceToPublicAttributes(appInstance);
        return Promise.resolve().then(() => {
            if (Utils.noValue(appInstance.groups)) {
                return;
            }
            return Promise.map(appInstance.groups, group => {
                return Db.models.group.instanceToPublicAttributes(group);
            }).then(publicGroups => {
                publicApplication.groups = publicGroups;
            });
        }).return(publicApplication);
    }
    /**
     * Return an application instance by API key.
     * The application has to be enabled otherwise a rejected promise is returned.
     *
     * @param {string} apiKey
     * @returns {Bluebird<PublicApplication>} ApplicationInstance populated with the groups
     */
    findApplication(apiKey) {
        return this.model.findOne({
            where: { apiKey: apiKey },
            include: [Db.models.group]
        }).then(applicationInstance => {
            if (!applicationInstance) {
                return Errors.access('bad_credentials', 'Wrong API key.', true);
            }
            if (!applicationInstance.enabled) {
                return Errors.access('forbidden', 'The application is not enabled.', true);
            }
            return this.formatToPublicApplication(applicationInstance);
        });
    }
    /**
     * Set the groups of an application and return the populated application.
     *
     * @param {ApplicationInstance} appInstance
     * @param {GroupInstance[]}     groupInstances
     * @returns {Bluebird<ApplicationInstance>}
     * @private
     */
    _setGroups(appInstance, groupInstances) {
        return appInstance.setGroups(groupInstances).then(() => {
            appInstance.groups = groupInstances;
            return appInstance;
        });
    }
    /**
     * Create a new application.
     *
     * @param {ApplicationAttributes} application
     * @param {GroupInstance[]}       groupInstances
     * @returns {Bluebird<ApplicationInstance>}
     */
    createApplication(application, groupInstances) {
        // generate apiKey
        application.apiKey = Utils.randomHex(16);
        // enable by default
        if (Utils.noValue(application.enabled)) {
            application.enabled = true;
        }
        // validation
        Utils.check.properties('application', application, {
            name: { required: true, check: 'nonEmpty' },
            enabled: { required: true, type: 'boolean' },
            apiKey: { required: true, check: ['string', true, true, 32, 32] },
            rights: { required: true, arrayItem: { check: ['values', this.model.APP_ACTIONS, true] } }
        });
        return this.model.create(application).then(appInstance => {
            return this._setGroups(appInstance, groupInstances);
        });
    }
    /**
     * @param {{id: number, name?: string, enabled?: boolean, rights?: string[]}} application
     * @param {GroupInstance[]} [groupInstances]
     * @returns {Bluebird<ApplicationInstance>}
     */
    updateApplication(application, groupInstances) {
        Utils.check.properties('application', application, {
            id: { required: true, check: 'posInt' },
            name: { required: false, check: 'nonEmpty' },
            enabled: { required: false, type: 'boolean' },
            rights: { required: false, arrayItem: { check: ['values', this.model.APP_ACTIONS, true] } }
        });
        return this._getApplicationInstance(application.id).then(appInstance => {
            // update editable fields fields
            let changes = 0;
            ['name', 'enabled', 'rights'].forEach(key => {
                if (Utils.hasValue(application[key])) {
                    appInstance[key] = application[key];
                    changes++;
                }
            });
            if (changes > 0) {
                return appInstance.save();
            }
            else {
                return appInstance;
            }
        }).then(appInstance => {
            // update groups
            if (groupInstances) {
                return this._setGroups(appInstance, groupInstances);
            }
            else {
                return appInstance;
            }
        });
    }
    /**
     * Get all applications (with groups).
     *
     * @returns {Bluebird<ApplicationInstance[]>}
     */
    getApplications() {
        return this.model.findAll({
            include: [Db.models.group]
        });
    }
}
module.exports = new ApplicationDAO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXBwbGljYXRpb25EQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYXBwbGljYXRpb24vQXBwbGljYXRpb25EQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxjQUFjO0lBQ2xCOztPQUVHO0lBQ0gsSUFBSSxLQUFLO1FBQ1AsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsdUJBQXVCLENBQUMsRUFBRTtRQUN4QixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFN0IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDdkYsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDYixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ2hGO1lBRUQsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gseUJBQXlCLENBQUMsV0FBVztRQUNuQyxNQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFN0UsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNyQyxPQUFPO2FBQ1I7WUFFRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDN0MsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ3JCLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUM7WUFDMUMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsZUFBZSxDQUFDLE1BQU07UUFDcEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUN4QixLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFDO1lBQ3ZCLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsRUFBRTtZQUM1QixJQUFJLENBQUMsbUJBQW1CLEVBQUU7Z0JBQ3hCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNqRTtZQUVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUU7Z0JBQ2hDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsaUNBQWlDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUU7WUFFRCxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxVQUFVLENBQUMsV0FBVyxFQUFFLGNBQWM7UUFDcEMsT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDckQsV0FBVyxDQUFDLE1BQU0sR0FBRyxjQUFjLENBQUM7WUFDcEMsT0FBTyxXQUFXLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsaUJBQWlCLENBQUMsV0FBVyxFQUFFLGNBQWM7UUFDM0Msa0JBQWtCO1FBQ2xCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV6QyxvQkFBb0I7UUFDcEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUFFLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1NBQUU7UUFFdkUsYUFBYTtRQUNiLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUU7WUFDakQsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3pDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMxQyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBQztZQUMvRCxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBQyxFQUFDO1NBQ3ZGLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3ZELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGlCQUFpQixDQUFDLFdBQVcsRUFBRSxjQUFjO1FBQzNDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUU7WUFDakQsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1lBQ3JDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUMxQyxPQUFPLEVBQUUsRUFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDM0MsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLEVBQUMsRUFBQztTQUN4RixDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JFLGdDQUFnQztZQUNoQyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7WUFDaEIsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDMUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNwQyxPQUFPLEVBQUUsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxPQUFPLEdBQUcsQ0FBQyxFQUFFO2dCQUNmLE9BQU8sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQzNCO2lCQUFNO2dCQUNMLE9BQU8sV0FBVyxDQUFDO2FBQ3BCO1FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BCLGdCQUFnQjtZQUNoQixJQUFJLGNBQWMsRUFBRTtnQkFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQzthQUNyRDtpQkFBTTtnQkFDTCxPQUFPLFdBQVcsQ0FBQzthQUNwQjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxlQUFlO1FBQ2IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUN4QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUMzQixDQUFDLENBQUM7SUFDTCxDQUFDO0NBRUY7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksY0FBYyxFQUFFLENBQUMifQ==