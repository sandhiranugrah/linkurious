/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// our libs
const EphemeralSoftLocks = require('../../../lib/EphemeralSoftLock');
// services
const LKE = require('../index');
const Db = LKE.getSqlDb();
const DataProxy = LKE.getDataProxy();
const Data = LKE.getData();
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const WidgetService = LKE.getWidget();
const Layout = LKE.getLayout();
const Log = LKE.getLogger(__filename);
/**@type {AlertService}*/
const AlertManager = LKE.getAlert();
// locals
const VisualizationChecker = require('./VisualizationChecker');
const DesignUtils = require('./designUtils');
// consts
const PUBLIC_FOLDER_FIELDS = ['id', 'title', 'parent', 'sourceKey'];
const VIZ_PUBLIC_FIELDS = [
    'id',
    'title',
    'folder',
    'nodes',
    'edges',
    'nodeFields',
    'edgeFields',
    'design',
    'filters',
    'sourceKey',
    'user',
    'userId',
    'sandbox',
    'createdAt',
    'updatedAt',
    'alternativeIds',
    'mode',
    'layout',
    'geo'
];
const ADD_ALL_LIMIT = Config.get('advanced.searchAddAllThreshold');
const VisualizationDAO = module.exports = {};
const vizLocks = new EphemeralSoftLocks(60, lock => {
    return Errors.business('visualization_locked', 'This visualization is currently locked by ' +
        lock.owner.username + ' (' + lock.owner.email + '). ' +
        'Your changes will not be saved unless you take over. ' +
        'If you take over, ' + lock.owner.username + ' will be blocked from continuing to edit.' +
        'This lock will expire automatically in ' + Utils.humanDuration(lock.timeLeft) + '.', true);
}, ['email', 'username']);
/**
 * Create a new folder
 *
 * @param {string} title
 * @param {string|number} parent ID of the parent visualizationFolder
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualizationFolder>}
 */
VisualizationDAO.createFolder = function (title, parent, sourceKey, currentUser) {
    if (Utils.noValue(parent)) {
        parent = -1;
    }
    Utils.check.nonEmpty('title', title);
    Utils.check.nonEmpty('sourceKey', sourceKey);
    Utils.check.exist('currentUser', currentUser);
    Utils.check.integer('parent', parent, -1);
    return _checkFolderCollision(parent, sourceKey, currentUser, title).then(() => {
        return Db.models.visualizationFolder.create({
            title: title,
            parent: parent === null || parent === undefined ? -1 : parent,
            sourceKey: sourceKey,
            userId: currentUser.id
        });
    }).then(_filterFolderFields);
};
function _filterFolderFields(folder) {
    return Promise.resolve(_.pick(folder, PUBLIC_FOLDER_FIELDS));
}
/**
 * Find a folder owned by `user`, with id `id` and sourceKey `sourceKey`.
 *
 * @param {number} folderId
 * @param {string} sourceKey
 * @param {WrappedUser} user
 * @returns {Bluebird<visualizationFolder>} rejected if no folder is found
 * @private
 */
function _findFolder(folderId, sourceKey, user) {
    // root folder explicitly (id=-1) or implicitly (undefined ID)
    if (folderId === -1 || folderId === undefined) {
        // special case for "abstract" root folder
        return Promise.resolve({ id: folderId, userId: user.id, sourceKey: sourceKey });
    }
    return Db.models.visualizationFolder.find({
        where: { id: folderId, sourceKey: sourceKey, userId: user.id }
    }).then(folder => {
        if (!folder) {
            return Errors.business('not_found', `Folder #${folderId} was not found for user #${user.id} in data-source "${sourceKey}".`, true);
        }
        return folder;
    });
}
/**
 * Check for title collision for folders: checks is a folder with title=`title` exists in
 * folder where id=`parentFolderId`.
 *
 * @param {number} parentFolderId
 * @param {string} sourceKey
 * @param {WrappedUser} user
 * @param {string} title
 * @returns {Promise} rejected in case of collision
 * @private
 */
function _checkFolderCollision(parentFolderId, sourceKey, user, title) {
    return Db.models.visualizationFolder.find({
        where: { parent: parentFolderId, sourceKey: sourceKey, userId: user.id, title: title }
    }).then(folder => {
        if (folder) {
            return Errors.business('folder_collision', null, true);
        }
    });
}
/**
 * Update a folder property.
 * Checked in this code:
 * - must the the owner of the folder to edit it
 * - cannot edit properties (id, sourceKey, userId): will fail
 * - cannot move the folder to a folder
 *
 * @param {string|number} folderId ID of the visualizationFolder to update
 * @param {string} propertyKey the property key of the visualizationFolder to update
 * @param {*} propertyValue the new value to set for the given property key
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualizationFolder>}
 */
VisualizationDAO.updateFolder = function (folderId, propertyKey, propertyValue, currentUser) {
    if (!propertyKey || Utils.noValue(propertyValue)) {
        return Errors.business('missing_field', '"key" and "value" are required', true);
    }
    if (Utils.noValue(currentUser)) {
        return Errors.business('missing_field', '"currentUser" is required', true);
    }
    Utils.check.values('key', propertyKey, ['title', 'parent']);
    // find folder
    return Db.models.visualizationFolder.findById(folderId).then(folder => {
        if (!folder) {
            return Errors.business('not_found', 'Folder #' + folderId + ' was not found.', true);
        }
        currentUser.canWriteFolder(folder);
        if (propertyKey === 'parent') {
            const parentId = propertyValue;
            // 0) updating parent folder: check that the target folder ID is legal
            Utils.check.integer('parent', parentId, -1);
            // 1) check that the move is structurally correct
            return Promise.resolve().then(() => {
                // 1.a) moving to root: special case shortcut
                if (parentId === -1) {
                    return { id: -1, title: 'root' };
                }
                // 1.b) load folder tree
                return Db.models.visualizationFolder.findAll({ where: {
                        sourceKey: folder.sourceKey,
                        userId: currentUser.id
                    }, attributes: ['id', 'parent', 'title'] }).then(folders => {
                    folders = folders.map(f => f.get());
                    /** @type {Map<String, visualizationFolder>} */
                    const foldersById = Utils.indexBy(folders, folder => folder.id + '');
                    // 2) check if new parent exists
                    const newParent = foldersById.get(parentId + '');
                    if (!newParent) {
                        return Errors.business('not_found', 'Folder #' + parentId + ' was not found.', true);
                    }
                    // 3) check if folder was moved into its own tree
                    let newParentAncestor = newParent;
                    while (newParentAncestor && newParentAncestor.id !== -1) {
                        if (newParentAncestor.id === folder.id) {
                            return Errors.business('invalid_parameter', 'Cannot move a folder into its own subtree.', true);
                        }
                        newParentAncestor = foldersById.get(newParentAncestor.parent + '');
                    }
                    return newParent;
                });
            }).then(newParent => {
                // 4) check for title collisions in the target directory
                return _checkFolderCollision(newParent.id, folder.sourceKey, currentUser, folder.title).return(newParent);
            }).then(newParent => {
                folder.parent = newParent.id;
                return folder;
            });
        }
        if (propertyKey === 'title') {
            const newTitle = propertyValue;
            // check if this folder name is not already taken in the target folder
            return _checkFolderCollision(folder.parent, folder.sourceKey, currentUser, newTitle).then(() => {
                folder.title = newTitle;
                return folder;
            });
        }
    }).then(updatedFolder => {
        // save and return saved folder
        return updatedFolder.save([propertyKey]).then(_filterFolderFields);
    });
};
/**
 * @param {string|number} folderId ID of a visualizationFolder
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Promise}
 */
VisualizationDAO.removeFolder = function (folderId, currentUser) {
    return Db.models.visualizationFolder.findById(folderId).then(folder => {
        if (folder === null) {
            throw Errors.business('not_found', 'Folder #' + folderId + ' was not found.');
        }
        currentUser.canWriteFolder(folder);
        // Folder has children if any visualisation or folder belongs to it
        return Promise.map([Db.models.visualizationFolder.findOne({ where: { parent: folderId } }),
            Db.models.visualization.findOne({ where: { folder: folderId } })], Utils.hasValue)
            .then(([containsFolders, containsVisualizations]) => {
            if (containsFolders || containsVisualizations) {
                return Errors.business('folder_deletion_failed', 'Cannot delete ' +
                    'a folder that is not empty, move or delete the content ' +
                    'before deleting the folder.', true);
            }
            else {
                return folder.destroy();
            }
        });
    });
};
/**
 * Only attributes 'id', 'folder', 'title', 'updatedAt', 'createdAt' are returned.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<visualization[]>}
 * @private
 */
VisualizationDAO._getAll = function (sourceKey, currentUser) {
    // we load the shares just to add the count to the visualization object
    // if guest mode is not allowed, we don't count the shares towards the guest user
    const guestModeAllowed = Config.get('access.guestMode');
    let guestUserIdFilter;
    if (!guestModeAllowed) {
        guestUserIdFilter = {
            userId: { $ne: Db.models.user.GUEST_USER_ID }
        };
    }
    return Promise.resolve(Db.models.visualization.findAll({
        where: { sourceKey: sourceKey, userId: currentUser.id, sandbox: false },
        attributes: ['id', 'folder', 'title', 'updatedAt', 'createdAt'],
        include: [{
                model: Db.models.visualizationShare,
                required: false,
                where: guestUserIdFilter
            }]
    })).map(visualization => {
        // remove the shares before returning
        visualization = visualization.get();
        visualization.shareCount = visualization.visualizationShares.length;
        delete visualization.visualizationShares;
        return visualization;
    });
};
/**
 *
 * @param {string|number|null} parentId
 * @param {visualizationFolder[]} folders
 * @param {visualization[]} visualizations
 * @param {object} widgetsByViz widgets by visualization ID
 * @returns {visualizationFolder[]}
 */
function buildTree(parentId, folders, visualizations, widgetsByViz) {
    const subTree = [];
    // folders
    folders.forEach(folder => {
        if (folder.parent === parentId) {
            const children = buildTree(folder.id, folders, visualizations, widgetsByViz);
            const newFolder = {
                id: folder.id,
                type: 'folder',
                title: folder.title
            };
            if (children) {
                newFolder.children = children;
            }
            subTree.push(newFolder);
        }
    });
    // files
    let widget;
    visualizations.forEach(visu => {
        if (visu.folder === parentId) {
            widget = widgetsByViz[visu.id];
            subTree.push({
                id: visu.id,
                type: 'visu',
                title: visu.title,
                shareCount: visu.shareCount,
                updatedAt: visu.updatedAt,
                createdAt: visu.createdAt,
                widgetKey: widget ? widget.key : widget
            });
        }
    });
    return subTree;
}
/**
 * Each returned folder has a `children` property containing Visualization and
 * VisualizationFolder objects.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<Array<visualization|visualizationFolder>>}
 */
VisualizationDAO.getTree = function (sourceKey, currentUser) {
    const userId = currentUser.id;
    return Promise.join(this._getAll(sourceKey, currentUser), Db.models.visualizationFolder.findAll({ where: { sourceKey: sourceKey, userId: userId } }), Db.models.widget.findAll({ where: { userId: userId }, attributes: ['visualizationId', 'key'] }), (visualizations, folders, widgets) => {
        const widgetsByViz = _.keyBy(widgets, 'visualizationId');
        return Promise.resolve(buildTree(-1, folders, visualizations, widgetsByViz));
    });
};
/**
 * Migrate nodeFields and edgeFields
 *
 * @param {visualization} viz visualization
 */
VisualizationDAO.migrateFields = function (viz) {
    // #293 migrate nodeFields and edgeFields
    _.forEach(['nodeFields', 'edgeFields'], key => {
        let orgValue = viz[key];
        if (!orgValue) {
            orgValue = [];
        }
        // already migrated
        if (!Array.isArray(orgValue)) {
            return;
        }
        // migrate
        viz[key] = { fields: orgValue, captions: {} };
    });
};
/**
 *
 * @param {string|Number} vizId
 * @param {boolean} populated whether to include resolved nodes and edges in the result
 *                  if false, 'right' and 'user' will not be included in the visualization.
 * @param {WrappedUser} user the currently connected user
 * @param {object} [options]
 * @param {boolean} [options.withDigest=false] Whether to include the digest in the returned nodes
 * @param {boolean} [options.withDegree=false] Whether to include the degree in the returned nodes
 * @param {boolean} [options.withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
 * @returns {Bluebird<PublicVisualization>}
 */
VisualizationDAO.getById = function (vizId, populated, user, options) {
    if (!options) {
        options = {};
    }
    return _findViz(vizId, true).then(viz => {
        // throw an error if the required data-source is not available
        const source = DataProxy.resolveSource(viz.sourceKey);
        source.assertReady();
        return user.getVisualizationRight(viz).then(right => {
            // unwrap sequelize object, add right (of current user) and user (owner information)
            viz = _filterVizFields(viz);
            viz.right = right;
            // #293 migrate nodeFields and edgeFields
            VisualizationDAO.migrateFields(viz);
            if (!populated) {
                return viz;
            }
            // in case alternative IDs are used, store the path of effective IDs
            const nodeIdPath = viz.alternativeIds.node === undefined
                ? 'id' : ['data', viz.alternativeIds.node];
            const edgeIdPath = viz.alternativeIds.edge === undefined
                ? 'id' : ['data', viz.alternativeIds.edge];
            // fetch nodes and edges
            return DataProxy.getNodesAndEdgesByID({
                nodeIds: _.map(viz.nodes, 'id'),
                edgeIds: _.map(viz.edges, 'id'),
                sourceKey: viz.sourceKey,
                alternativeNodeId: viz.alternativeIds.node,
                alternativeNodeIdIndex: source.config.graphdb.alternativeNodeIdIndex,
                alternativeEdgeId: viz.alternativeIds.edge,
                alternativeEdgeIdIndex: source.config.graphdb.alternativeEdgeIdIndex,
                ignoreMissing: true,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, user).then(subgraph => {
                if (subgraph.isFiltered && (viz.right === 'owner' || viz.right === 'write')) {
                    viz.right += '-filtered';
                }
                const vizNodesByID = _.keyBy(viz.nodes, 'id');
                // if node ids returned by getNodesById do not match the visualization ids
                // then the nodes are assigned a random position
                viz.nodes = _.map(subgraph.result.nodes, dbN => _node2VizNode(dbN, vizNodesByID[_.get(dbN, nodeIdPath)]));
                // needed in edge-filter step, in case some vizNodes are not readable by current user or
                // if the viz is using alternative IDs (edge.source and edge.target are native node DB IDs).
                const nodesByDbID = _.keyBy(viz.nodes, 'id');
                const edges = _.filter(subgraph.result.edges, 
                // edge must be defined AND have source and target in the nodes
                edge => !!edge &&
                    nodesByDbID[edge.source] !== undefined &&
                    nodesByDbID[edge.target] !== undefined);
                const vizEdgesByID = _.keyBy(viz.edges, 'id');
                viz.edges = _.map(edges, dbE => _edge2VizEdge(dbE, vizEdgesByID[_.get(dbE, edgeIdPath)]));
                return viz;
            });
        });
    }).then(viz => {
        // set the widget key
        return WidgetService.getWidgetKeyFromVisualizationId(viz.id).then(key => {
            viz.widgetKey = key || null;
            return viz;
        });
    });
};
/**
 * Get the sandbox for a (data-source, user). Optionally return populated with a node/edge
 *
 * @param {object} options
 * @param {string} options.sourceKey Key of the data-source
 * @param {string} [options.populate] Describes how the sandbox should be populated (must be one of `["visualizationId","expandNodeId","nodeId","edgeId","searchNodes","searchEdges","pattern","matchId"]`)
 * @param {number|string} [options.itemId] ID of the node, or edge to load (when `options.populate` is one of  `["visualizationId", "nodeId", "edgeId", "expandNodeId"]`)
 * @param {number} [options.matchId] ID of the alert match load (when `options.populate` is `"matchId"`)
 * @param {string} [options.searchQuery] Search query to search for nodes or edges (when `options.populate` is one of  `["searchNodes", "searchEdges"]`)
 * @param {number} [options.searchFuzziness] Search query fuzziness (when `options.populate` is one of  `["searchNodes", "searchEdges"]`)
 * @param {string} [options.patternQuery] Pattern query to match nodes and/or edges (when `populate` is `"pattern"`)
 * @param {string} [options.patternDialect] Pattern dialect (when `populate` is `"pattern"`)
 * @param {boolean} [options.doLayout] Whether to apply a server-side layout
 * @param {boolean} [options.withDigest] Whether to include the adjacency digest in the returned nodes
 * @param {boolean} [options.withDegree] Whether to include the degree in the returned nodes
 * @param {boolean} [options.withAccess] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
 * @param {WrappedUser} user the user currently logged in
 * @returns {Bluebird<PublicVisualization>} the sandbox visualization
 */
VisualizationDAO.getSandBox = function (options, user) {
    const proxyOptions = user;
    return Promise.resolve().then(() => {
        Utils.check.values('populate', options.populate, [
            undefined,
            'visualizationId',
            'expandNodeId', 'nodeId', 'edgeId',
            'searchNodes', 'searchEdges',
            'pattern',
            'matchId'
        ]);
        switch (options.populate) {
            case 'visualizationId':
            case 'expandNodeId':
            case 'nodeId':
            case 'edgeId':
                Utils.check.exist('itemId', options.itemId);
                break;
            case 'matchId':
                Utils.check.posInt('matchId', options.matchId);
                break;
            case 'searchNode':
            case 'searchEdge':
                Utils.check.string('searchQuery', options.searchQuery, true);
                if (options.searchFuzziness !== undefined) {
                    Utils.check.number('searchFuzziness', options.searchFuzziness, 0, 1);
                }
                break;
            case 'pattern':
                Utils.check.string('patternQuery', options.patternQuery, true);
                Utils.check.string('patternDialect', options.patternDialect, true);
                break;
        }
        return _findSandBox(options.sourceKey, user);
    }).then(sandbox => {
        sandbox = _filterVizFields(sandbox);
        if (!options.populate) {
            return sandbox;
        }
        sandbox.nodes = [];
        sandbox.edges = [];
        // populate the sandbox ...
        if (options.populate === 'visualizationId') {
            // ... with a visualization
            return this.getById(options.itemId, true, user, {
                withDigest: options.withDigest,
                withDegree: options.withDegree,
                withAccess: options.withAccess
            }).then(visualization => {
                sandbox.nodes = visualization.nodes;
                sandbox.edges = visualization.edges;
                sandbox.design = visualization.design;
                sandbox.nodeFields = visualization.nodeFields;
                sandbox.edgeFields = visualization.edgeFields;
                sandbox.title = visualization.title;
                sandbox.filters = visualization.filters;
                return sandbox;
            });
        }
        else if (options.populate === 'nodeId') {
            // ... with a node
            return DataProxy.getNode({
                id: options.itemId,
                withDigest: options.withDigest,
                withDegree: options.withDegree,
                sourceKey: options.sourceKey
            }, proxyOptions).then(subgraph => {
                sandbox.nodes = [_node2VizNode(subgraph.nodes[0], { x: 0, y: 0 })];
                return sandbox;
            });
        }
        else if (options.populate === 'edgeId') {
            // ... with edge
            const getEdgeOptions = {
                id: options.itemId,
                sourceKey: options.sourceKey,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            };
            return DataProxy.getEdge(getEdgeOptions, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = [
                    _node2VizNode(subgraph.nodes[0], { x: 0, y: 0 }),
                    _node2VizNode(subgraph.nodes[1], { x: 30, y: -1 })
                ];
                return sandbox;
            });
        }
        else if (options.populate === 'expandNodeId') {
            return DataProxy.getNode({
                id: options.itemId,
                withDigest: options.withDigest,
                withDegree: options.withDegree,
                sourceKey: options.sourceKey
            }, proxyOptions).then(subGraph => {
                const sourceNode = _node2VizNode(subGraph.nodes[0]);
                return DataProxy.getAdjacentNodes([options.itemId], {
                    limit: ADD_ALL_LIMIT,
                    withDigest: options.withDigest,
                    withDegree: options.withDegree
                }, options.sourceKey, proxyOptions).then(subGraph => {
                    sandbox.edges = subGraph.edges;
                    sandbox.nodes = _.map(subGraph.nodes, node => _node2VizNode(node));
                    sandbox.nodes.unshift(sourceNode);
                    return sandbox;
                });
            });
        }
        else if (options.populate === 'searchNodes' || options.populate === 'searchEdges') {
            // ... with a search query
            const searchFullOptions = {
                type: options.populate === 'searchNodes' ? 'node' : 'edge',
                q: options.searchQuery,
                fuzziness: options.searchFuzziness,
                size: ADD_ALL_LIMIT
            };
            return DataProxy.searchFull(searchFullOptions, options.sourceKey, {
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = _.map(subgraph.nodes, node => _node2VizNode(node));
                return sandbox;
            });
        }
        else if (options.populate === 'pattern') {
            // ... with a pattern matching query (cypher, gremlin, ...)
            return DataProxy.runGraphQueryByContent({
                dataSource: options.sourceKey,
                dialect: options.patternDialect,
                query: options.patternQuery,
                withDigest: options.withDigest,
                withDegree: options.withDegree
            }, proxyOptions).then(subgraph => {
                sandbox.edges = subgraph.edges;
                sandbox.nodes = _.map(subgraph.nodes, node => _node2VizNode(node));
                return sandbox;
            });
        }
        else if (options.populate === 'matchId') {
            return AlertManager.getMatch(options.matchId, user).then(match => {
                const nodeOptions = {
                    ids: match.nodes,
                    sourceKey: options.sourceKey,
                    withDigest: options.withDigest,
                    withDegree: options.withDegree
                };
                const edgeOptions = { ids: match.edges, sourceKey: options.sourceKey };
                // TODO 2.6.0 ignore missing?
                return DataProxy.getNodesByID(nodeOptions, proxyOptions).then(nodes => {
                    sandbox.nodes = _.map(nodes, node => _node2VizNode(node));
                    return DataProxy.getEdgesByID(edgeOptions, proxyOptions);
                }).then(edges => {
                    sandbox.edges = edges.map(edge => _edge2VizEdge(edge));
                    return sandbox;
                });
            });
        }
    }).then(sandbox => {
        // note: layout.incremental is persisted and restored, but not layout.algorithm or layout.mode
        if (options.doLayout && sandbox.nodes.length >= 1) {
            return _doLayout(sandbox);
        }
        else {
            // layout not requested or not needed
            sandbox.layout = { incremental: sandbox.layout.incremental };
            return sandbox;
        }
    });
};
/**
 * @param {visualization} visualization
 * @returns {Bluebird<visualization>}
 * @private
 */
function _doLayout(visualization) {
    // server-side layout requested and needed
    visualization.layout = {
        algorithm: 'force',
        incremental: visualization.layout ? visualization.layout.incremental : false
    };
    return Layout.layout(visualization);
}
/**
 *
 * @param {object} viz
 * @param {string} viz.sourceKey Key of the data-source
 * @param {string} viz.title
 * @param {string|number} [viz.folder] ID of visualizationFolder (or null for root)
 *
 * @param {object} viz.nodeFields
 * @param {object} viz.nodeFields.captions Key: nodeCategory:string. Value: {active:boolean, displayName:boolean, properties:string[]}
 *
 * @param {object} viz.edgeFields
 * @param {object} viz.edgeFields.captions Key: edgeType:string. Value: {active:boolean, displayName:boolean, properties:string[]}
 *
 * @param {object[]} viz.nodes
 * @param {string|number} viz.nodes.id Node ID (seen `alternativeIds` to use non-native IDs)
 * @param {boolean} [viz.nodes.selected=false]
 * @param {object} viz.nodes.nodelink
 * @param {number} viz.nodes.nodelink.x
 * @param {number} viz.nodes.nodelink.y
 * @param {boolean} [viz.nodes.nodelink.fixed=false]
 * @param {object} [viz.nodes.geo]
 * @param {number} [viz.nodes.latitude]
 * @param {number} [viz.nodes.latitudeDiff]
 * @param {number} [viz.nodes.longitude]
 * @param {number} [viz.nodes.longitudeDiff]
 *
 * @param {object[]} viz.edges
 * @param {string|number} viz.edges.id Edge IDs (seen `alternativeIds` to use non-native IDs)
 * @param {boolean} [viz.edges.selected=false]
 *
 * @param {object} [viz.design]
 * @param {object} [viz.design.styles]
 * @param {object} [viz.design.palette]
 *
 * @param {{node: object[], edge: object[]}} [viz.filters]
 *
 * @param {object} [viz.alternativeIds]
 * @param {string} [viz.alternativeIds.node] alternative (non-native) node ID
 * @param {string} [viz.alternativeIds.edge] alternative (non-native) edge ID
 *
 * @param {string} viz.mode Current mode ("nodelink" or "geo")
 *
 * @param {object} viz.layout Last used Layout
 * @param {string} viz.layout.algorithm Layout algorithm ("force" or "hierarchical")
 *
 * @param {string} [viz.layout.mode] Layout mode (depends on algorithm)
 * @param {object} [viz.geo]
 * @param {string} [viz.geo.latitudeProperty]
 * @param {string} [viz.geo.longitudeProperty]
 * @param {string[]} [viz.geo.layers] Enabled tiles layers
 *
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<PublicVisualization>}
 */
VisualizationDAO.createVisualization = function (viz, currentUser) {
    if (!currentUser) {
        return Errors.business('missing_field', '"currentUser" is required', true);
    }
    Utils.check.object('visualization', viz);
    const source = DataProxy.resolveSource(viz.sourceKey);
    // default values
    if (Utils.noValue(viz.folder)) {
        viz.folder = -1;
    }
    if (!viz.filters) {
        viz.filters = { node: [], edge: [] };
    }
    if (!viz.mode) {
        viz.mode = 'nodelink';
    }
    if (Utils.noValue(viz.alternativeIds)) {
        viz.alternativeIds = {};
    }
    if (Utils.noValue(viz.layout)) {
        viz.layout = {};
    }
    if (Utils.noValue(viz.geo)) {
        viz.geo = {};
    }
    if (Utils.noValue(viz.geo.layers)) {
        viz.geo.layers = [];
    }
    if (Utils.noValue(viz.nodeFields)) {
        viz.nodeFields = { captions: source.state.defaultCaptions.nodes, types: {} };
    }
    if (Utils.noValue(viz.edgeFields)) {
        viz.edgeFields = { captions: source.state.defaultCaptions.edges, types: {} };
    }
    // validate visualization object
    VisualizationChecker.checkCreation('visualization', viz);
    DataProxy
        .resolveSource(viz.sourceKey)
        .checkAlternativeIdKeys(viz.alternativeIds);
    const getDesign = viz.design
        ? Promise.resolve(viz.design)
        : VisualizationDAO.getSandBox({ sourceKey: viz.sourceKey }, currentUser).get('design');
    return getDesign.then(design => {
        return Db.models.visualization.create({
            title: Utils.noValue(viz.title) ? 'Untitled Visualization' : viz.title,
            sandbox: false,
            folder: viz.folder,
            nodes: viz.nodes,
            edges: viz.edges,
            nodeFields: viz.nodeFields,
            edgeFields: viz.edgeFields,
            alternativeIds: viz.alternativeIds,
            design: design,
            filters: viz.filters,
            sourceKey: viz.sourceKey,
            userId: currentUser.id,
            mode: viz.mode,
            layout: viz.layout,
            geo: viz.geo,
            version: 4
        });
    }).then(_filterVizFields);
};
/**
 * @param {VisualizationInstance} _viz
 * @returns {PublicVisualization}
 * @private
 */
function _filterVizFields(_viz) {
    const viz = _.pick(_viz.get(), VIZ_PUBLIC_FIELDS);
    const source = DataProxy.resolveSource(viz.sourceKey);
    // default alternative IDs
    if (!viz.alternativeIds) {
        viz.alternativeIds = {};
    }
    // default interaction mode
    if (!viz.mode) {
        viz.mode = 'nodelink';
    }
    // default layout
    if (!viz.layout) {
        viz.layout = { algorithm: 'force', mode: 'fast', incremental: false };
    }
    if (!viz.nodeFields.captions) {
        viz.nodeFields.captions = source.defaultCaptions.nodes;
    }
    if (!viz.edgeFields.captions) {
        viz.edgeFields.captions = source.defaultCaptions.edges;
    }
    // default geo data (read from source config), reset for sandbox
    if (!viz.geo || viz.sandbox) {
        const source = DataProxy.resolveSource(viz.sourceKey);
        viz.geo = {
            latitudeProperty: source.config.graphdb.latitudeProperty,
            longitudeProperty: source.config.graphdb.longitudeProperty,
            // for a sandbox, the layers might be set, don't reset them in that case
            layers: viz.geo ? viz.geo.layers : []
        };
    }
    // filter the owner user (if set)
    if (viz.user) {
        viz.user = _.pick(viz.user, ['id', 'username', 'email']);
    }
    return viz;
}
/**
 * Count visualizations for a user
 *
 * @param {string} sourceKey Key of the data-source
 * @param {boolean} [skipSourceKeyValidation=false] Whether to skip the validation of the sourceKey
 * @returns {Bluebird<number>} the number of visualizations
 */
VisualizationDAO.getVisualizationCount = function (sourceKey, skipSourceKeyValidation) {
    if (!skipSourceKeyValidation) {
        Utils.checkSourceKey(sourceKey);
    }
    return Promise.resolve(Db.models.visualization.count({ where: {
            sourceKey: sourceKey,
            sandbox: false
        } }));
};
/**
 * Duplicates a visualization and saves it in the same folder as the targeted visualization
 *
 * @param {object} options
 * @param {number} options.id ID of the visualization to duplicate
 * @param {number} [options.folderId] ID of the target folder (defaults to same folder if user is not changing, or root folder is user is changing)
 * @param {string} [options.title] title of the target (defaults to `"Copy of [source title]"`)
 * @param {WrappedUser} wUser the currently connected user
 * @returns {Bluebird<number>}
 */
VisualizationDAO.duplicateVisualization = function (options, wUser) {
    Utils.check.properties('options', options, {
        id: { required: true, check: 'posInt' },
        folderId: { check: ['number', -1] },
        title: { check: 'nonEmpty' }
    });
    let vizCopy;
    return _findViz(options.id).then(_visualization => {
        vizCopy = _visualization.get();
        // this will reject if currentUser has not at least read access to the visualization
        return wUser.getVisualizationRight(_visualization);
    }).then(() => {
        // remove instance-specific info
        delete vizCopy.id;
        delete vizCopy.createdAt;
        delete vizCopy.updatedAt;
        // set default folder
        if (Utils.noValue(options.folderId)) {
            if (vizCopy.userId === wUser.id) {
                // the source and target users are the same, keep the viz in the same folder
                options.folderId = vizCopy.folder;
            }
            else {
                // the source and target users are different, set viz at root folder or target user
                options.folderId = -1;
            }
        }
        // set the owner of the viz to the current user
        vizCopy.userId = wUser.id;
        // set the title
        if (Utils.hasValue(options.title)) {
            vizCopy.title = options.title;
        }
        else {
            vizCopy.title = 'Copy of ' + vizCopy.title;
        }
        // set the folder (checks that the folder is owned by the current user in current data-source)
        return _findFolder(options.folderId, vizCopy.sourceKey, wUser);
    }).then(folder => {
        vizCopy.folder = folder.id;
        // save the copy
        return Db.models.visualization.create(vizCopy);
    }).get('id');
};
/**
 * Update a visualization.
 * Checked in this code:
 * - to update the folder, `currentUser` must be the owner
 * - to update any other field, `currentUser` must has write access
 * - field (id, sourceKey, userId, sandbox) cannot be updated and will be silently ignored
 * - updating other fields not included in VIZ_EDITABLE_FIELDS will cause an error
 *
 * @param {number} vizId ID of the visualization to update
 * @param {object} newProperties map of properties to update with new values
 * @param {object} [newProperties.folder]
 * @param {object} [newProperties.title]
 * @param {object} [newProperties.nodes]
 * @param {object} [newProperties.edges]
 * @param {object} [newProperties.design]
 * @param {object} [newProperties.filters]
 * @param {object} [newProperties.nodeFields]
 * @param {object} [newProperties.edgeFields]
 * @param {object} [newProperties.alternativeIds]
 * @param {object} options
 * @param {boolean} [options.forceLock=false] Take the edit-lock by force (if `currentUser` doesn't own it)
 * @param {boolean} [options.doLayout=false] Perform a server-side layout of the visualization graph
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Bluebird<VisualizationInstance>}
 */
VisualizationDAO.updateVisualization = function (vizId, newProperties, options, currentUser) {
    if (!newProperties && !options.doLayout) {
        throw Errors.business('missing_field');
    }
    newProperties = _.defaults(newProperties);
    if (!currentUser) {
        throw Errors.business('missing_field', '"currentUser" is required');
    }
    if (typeof newProperties !== 'object') {
        throw Errors.business('invalid_parameter', 'new visualization fields must be given as a map');
    }
    Utils.check.objectKeys('options', options, ['forceLock', 'doLayout']);
    // ignore these fields from newProperties (they cannot be changed)
    delete newProperties.id;
    delete newProperties.sourceKey;
    delete newProperties.userId;
    delete newProperties.sandbox;
    // check for unexpected keys
    VisualizationChecker.checkUpdate('visualization', newProperties);
    return vizLocks.take(vizId, currentUser, options.forceLock).then(() => {
        // find the visualization in DB
        return _findViz(vizId);
    }).then(viz => {
        DataProxy.resolveSource(viz.sourceKey).checkAlternativeIdKeys(newProperties.alternativeIds);
        // if the folder is provided but did not change, ignore the change
        if (newProperties.folder !== undefined && viz.folder === newProperties.folder) {
            delete newProperties.folder;
        }
        // if the user wants to change the folder, it needs to be the owner
        const neededRight = newProperties.folder !== undefined ? 'owner' : 'write';
        return currentUser.hasVisualizationRight(viz, neededRight).then(() => {
            let updatePromise = Promise.resolve();
            // update all fields given as parameters
            _.forEach(newProperties, (value, key) => {
                if (key === 'folder') {
                    // check that the folder exists + belongs to user + is in the same sourceKey as the viz
                    updatePromise = _findFolder(value, viz.sourceKey, currentUser).then(folder => {
                        viz.folder = folder.id;
                    });
                }
                else {
                    viz[key] = value;
                }
            });
            return updatePromise;
        }).then(() => {
            // layout not requested/required
            if (!options.doLayout || viz.nodes.length === 0) {
                return;
            }
            // layout visualization
            // 1) load populated viz
            return VisualizationDAO.getById(viz.id, true, currentUser).then(populatedViz => {
                // 2) layout populated viz
                return _doLayout(populatedViz);
            }).then(laidOutViz => {
                // 3) patch current nodes with new coordinates
                const newNodes = new Array(laidOutViz.nodes.length);
                laidOutViz.nodes.forEach((n, i) => {
                    const un = viz.nodes[i];
                    if (!un.nodelink) {
                        un.nodelink = {};
                    }
                    if (un.nodelink.fixed !== true) {
                        un.nodelink.x = n.nodelink.x;
                        un.nodelink.y = n.nodelink.y;
                    }
                    newNodes[i] = un;
                });
                // 4) update "nodes" in updated viz with patched nodes
                viz.nodes = newNodes;
            });
        }).then(() => {
            return viz.save();
        });
    }).then(_filterVizFields);
};
/**
 * Update the sandbox visualization.
 *
 * @param {string} sourceKey Key of the data-source
 * @param {object} newProperties
 * @param {object} [newProperties.design]
 * @param {object} [newProperties.nodeFields]
 * @param {object} [newProperties.edgeFields]
 * @param {WrappedUser} currentUser
 * @returns {Promise}
 */
VisualizationDAO.updateSandBox = function (sourceKey, newProperties, currentUser) {
    Utils.check.object('visualization', newProperties);
    // ignore these fields from newProperties (they cannot be changed)
    delete newProperties.id;
    delete newProperties.sourceKey;
    delete newProperties.userId;
    delete newProperties.sandbox;
    return _findSandBox(sourceKey, currentUser).then(viz => {
        // sandboxes: only edit nodeFields, edgeFields, design
        // #956 Patch sandbox should validate captions
        VisualizationChecker.checkUpdateSandbox('visualisation', newProperties);
        _.forEach(newProperties, (value, key) => {
            viz[key] = value;
        });
        return viz.save();
    }).return(undefined);
};
/**
 * Remove a visualization
 *
 * @param {string|Number} visualizationId
 * @param {WrappedUser} currentUser the currently connected use (wrapped)
 * @returns {Promise}
 */
VisualizationDAO.removeById = function (visualizationId, currentUser) {
    return _findViz(visualizationId).then(visualization => {
        return currentUser.hasVisualizationRight(visualization, 'owner').then(() => {
            return Promise.resolve(visualization.destroy());
        });
    });
};
/**
 * If the visualization is not up to date, update it to the latest version and return it.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateViz(visualization) {
    return _updateVizToVersion2(visualization)
        .then(v2Viz => _updateVizToVersion3(v2Viz))
        .then(v3Viz => _updateVizToVersion4(v3Viz));
}
/**
 * If the visualization is version 1, update it to version 2 and return it.
 *
 * Filters are stored in a different format.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion2(visualization) {
    if (visualization.version > 1) {
        return Promise.resolve(visualization);
    }
    else {
        visualization.filters = visualization.filters.map(filter => {
            // there are 5 types of filters in in visualization v1
            // - filters with key "node.data.categories"
            // - filters with key "node.data.properties.<propertyName>"
            // - filters with key "edge.data.type"
            // - filters with key "edge.data.properties.<propertyName>"
            // - filters with key "geo-coordinates"
            if (filter.key === 'geo-coordinates') {
                // Valid geo filter
                return {
                    key: 'geo-coordinates'
                };
            }
            if (Utils.noValue(filter.options) || Utils.noValue(filter.key)) {
                Log.warn('This v1 filter was invalid: ', global.JSON.stringify(filter));
                return; // the filter is invalid
            }
            const values = _.keys(_.pickBy(filter.options.values));
            if (values.length === 0) {
                Log.warn('This v1 filter was invalid: ', global.JSON.stringify(filter));
                return; // the filter is invalid
            }
            if (filter.key === 'node.data.categories' ||
                filter.key.startsWith('node.data.properties.') ||
                filter.key === 'edge.data.type' ||
                filter.key.startsWith('edge.data.properties.')) {
                return {
                    key: filter.key,
                    values
                };
            }
        });
        // remove null filters, filters that were invalid
        visualization.filters = visualization.filters.filter(Utils.hasValue);
        visualization.version = 2;
        return visualization.save();
    }
}
/**
 * If the visualization is version 2, update it to version 3 and return it.
 *
 * Since visualizations v3, node and edge ids are stored exclusively as strings.
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion3(visualization) {
    if (visualization.version > 2) {
        return Promise.resolve(visualization);
    }
    else {
        // originally node and edge ids in Linkurious could have been both string and numbers
        // we force them to be string now
        visualization.nodes = _.map(visualization.nodes, node => {
            node.id = '' + node.id;
            return node;
        });
        visualization.edges = _.map(visualization.edges, edge => {
            edge.id = '' + edge.id;
            return edge;
        });
        visualization.version = 3;
        return visualization.save();
    }
}
/**
 * If the visualization is version 3, update it to version 4 and return it.
 *
 * Since visualizations v4,
 * - Design Styles are stored in a different format
 * - Filters are stored in a different format
 * - Fields are removed from node.edge fields
 *
 * @param {VisualizationInstance} visualization
 * @returns {Bluebird<VisualizationInstance>}
 * @private
 * @backward-compatibility
 */
function _updateVizToVersion4(visualization) {
    if (visualization.version > 3) {
        return Promise.resolve(visualization);
    }
    return Promise.props({
        nodeCategories: Data.getSchemaNodeTypeNames(visualization.sourceKey),
        edgeTypes: Data.getSchemaEdgeTypeNames(visualization.sourceKey)
    }).then(schema => {
        const designV4 = {};
        // Auto color only sandboxes
        const autoColor = visualization.sandbox;
        // 1) Migrate visualization.design.styles to the new format
        designV4.styles = DesignUtils.migrateStyles(schema, visualization.design.styles, visualization.design.palette, autoColor);
        // 2) Replace visualization.design.palette with the default palette
        designV4.palette = DesignUtils.PALETTE;
        const nodeFields = visualization.nodeFields || {};
        const edgeFields = visualization.edgeFields || {};
        // Create fields viz.(node|edge)Fields.types
        nodeFields.types = {};
        edgeFields.types = {};
        // Remove fields
        delete nodeFields.fields;
        delete edgeFields.fields;
        // design, nodeFields and edgeFields are getter and setter objects
        // so to update a property we assign the whole object that will be parsed by the setter
        visualization.design = designV4;
        visualization.nodeFields = nodeFields;
        visualization.edgeFields = edgeFields;
        visualization.filters = { node: [], edge: [] };
        visualization.version = 4;
        return visualization.save();
    });
}
/**
 * @param {number} visualizationId
 * @param {boolean} [includeUser=false] whether to fetch the owner of the viz
 * @returns {Bluebird<VisualizationInstance>}
 */
function _findViz(visualizationId, includeUser) {
    const options = { where: { id: visualizationId, sandbox: false } };
    if (includeUser) {
        options.include = [Db.models.user];
    }
    return Db.models.visualization.find(options).then(visualization => {
        if (visualization === null || visualization === undefined) {
            return Errors.business('not_found', 'Visualization #' + visualizationId + ' was not found.', true);
        }
        if (!visualization.alternativeIds) {
            visualization.alternativeIds = {};
        }
        return visualization;
    }).then(_updateViz);
}
/**
 * @param {string} sourceKey
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<PublicVisualization>} sandbox
 * @private
 */
function _findSandBox(sourceKey, currentUser) {
    const source = DataProxy.resolveSource(sourceKey);
    source.assertReady();
    const where = {
        sandbox: true,
        sourceKey: sourceKey,
        userId: currentUser.id
    };
    const values = {
        title: 'SandBox',
        nodes: [],
        edges: [],
        folder: -1,
        nodeFields: { captions: source.state.defaultCaptions.nodes, types: {} },
        edgeFields: { captions: source.state.defaultCaptions.edges, types: {} },
        design: {
            palette: DesignUtils.PALETTE,
            styles: source.state.defaultStyles
        },
        filters: { node: [], edge: [] },
        version: 4
    };
    return Db.models.visualization.findOrCreate({
        where: where,
        defaults: values
    }).spread(sandbox => sandbox).then(_updateViz);
}
/**
 * Resets sandbox styles and captions to the dataSource default values.
 * Resets sandbox palette to the default value.
 *
 * @param {string} sourceKey Data-source of the sandboxes that will be reset
 * @param {object} options
 * @param {boolean} [options.design] Reset sandbox design using the defaultStyles of the data-source
 * @param {boolean} [options.captions] Reset sandbox captions using the defaultCaptions of the data-source
 * @returns {Bluebird<void>}
 */
VisualizationDAO.resetSandboxes = function (sourceKey, options) {
    Utils.checkSourceKey(sourceKey);
    const source = DataProxy.resolveSource(sourceKey);
    const allSandboxesForTheCurrentSource = { where: { sourceKey: sourceKey, sandbox: true } };
    return Promise.resolve().then(() => {
        // reset design?
        if (!options.design) {
            return;
        }
        return Db.models.visualization.update({
            design: {
                palette: DesignUtils.PALETTE,
                styles: source.state.defaultStyles
            }
        }, allSandboxesForTheCurrentSource).then(updateCount => {
            Log.info(`Design reset for ${updateCount} sandboxes (data-source: ${sourceKey}).`);
        });
    }).then(() => {
        // reset captions?
        if (!options.captions) {
            return;
        }
        return Db.models.visualization.update({
            nodeFields: { captions: source.state.defaultCaptions.nodes, types: {} },
            edgeFields: { captions: source.state.defaultCaptions.edges, types: {} }
        }, allSandboxesForTheCurrentSource).then(updateCount => {
            Log.info(`Captions reset for ${updateCount} sandboxes (data-source: ${sourceKey}).`);
        });
    });
};
/**
 * Merge node and vizNode content.
 *
 * @param {LkNode} node
 * @param {object} [vizNode] visualization node
 * @param {number} [vizNode.nodelink.x]
 * @param {number} [vizNode.nodelink.y]
 * @param {boolean} [vizNode.nodelink.fixed]
 * @param {number} [vizNode.geo.latitude]
 * @param {number} [vizNode.geo.longitude]
 * @param {number} [vizNode.geo.latitudeDiff]
 * @param {number} [vizNode.geo.longitudeDiff]
 * @param {boolean} [vizNode.selected]
 * @returns {object}
 * @private
 */
function _node2VizNode(node, vizNode) {
    // generate random position
    if (vizNode === undefined) {
        vizNode = { nodelink: { x: 500 * Math.random(), y: 500 * Math.random() } };
    }
    // migrate old-format to new-format vizNode position info
    if (vizNode.x !== undefined && vizNode.y !== undefined) {
        vizNode = { nodelink: { x: vizNode.x, y: vizNode.y } };
    }
    return {
        id: node.id,
        nodelink: vizNode.nodelink ? vizNode.nodelink : {},
        geo: vizNode && vizNode.geo ? vizNode.geo : {},
        selected: vizNode.selected === true ? true : undefined,
        data: node.data,
        categories: node.categories,
        statistics: node.statistics,
        readAt: node.readAt
    };
}
/**
 * Merge edge and vizEdge content.
 *
 * @param {LkEdge} edge
 * @param {object} [vizEdge]
 * @param {object} vizEdge.selected
 * @returns {object} edge and vizEdge merged
 * @private
 */
function _edge2VizEdge(edge, vizEdge) {
    return {
        id: edge.id,
        type: edge.type,
        data: edge.data,
        source: edge.source,
        target: edge.target,
        selected: vizEdge && vizEdge.selected ? true : undefined,
        statistics: edge.statistics,
        readAt: edge.readAt
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvbkRBTy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9idXNpbmVzcy9WaXN1YWxpemF0aW9uREFPLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7QUFFckUsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDMUIsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUMzQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMseUJBQXlCO0FBQ3pCLE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUVwQyxTQUFTO0FBQ1QsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUMvRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFFN0MsU0FBUztBQUNULE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztBQUNwRSxNQUFNLGlCQUFpQixHQUFHO0lBQ3hCLElBQUk7SUFDSixPQUFPO0lBQ1AsUUFBUTtJQUNSLE9BQU87SUFDUCxPQUFPO0lBQ1AsWUFBWTtJQUNaLFlBQVk7SUFDWixRQUFRO0lBQ1IsU0FBUztJQUNULFdBQVc7SUFDWCxNQUFNO0lBQ04sUUFBUTtJQUNSLFNBQVM7SUFDVCxXQUFXO0lBQ1gsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixNQUFNO0lBQ04sUUFBUTtJQUNSLEtBQUs7Q0FDTixDQUFDO0FBRUYsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0FBRW5FLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFFN0MsTUFBTSxRQUFRLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7SUFDakQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixzQkFBc0IsRUFDdEIsNENBQTRDO1FBQzVDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLO1FBQ3JELHVEQUF1RDtRQUN2RCxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRywyQ0FBMkM7UUFDeEYseUNBQXlDLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxFQUNwRixJQUFJLENBQ0wsQ0FBQztBQUNKLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBRTFCOzs7Ozs7OztHQVFHO0FBQ0gsZ0JBQWdCLENBQUMsWUFBWSxHQUFHLFVBQVMsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsV0FBVztJQUM1RSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FBRTtJQUMzQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzdDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM5QyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFMUMsT0FBTyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQzVFLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUM7WUFDMUMsS0FBSyxFQUFFLEtBQUs7WUFDWixNQUFNLEVBQUUsTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtZQUM3RCxTQUFTLEVBQUUsU0FBUztZQUNwQixNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUU7U0FDdkIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBRUYsU0FBUyxtQkFBbUIsQ0FBQyxNQUFNO0lBQ2pDLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsU0FBUyxXQUFXLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxJQUFJO0lBQzVDLDhEQUE4RDtJQUM5RCxJQUFJLFFBQVEsS0FBSyxDQUFDLENBQUMsSUFBSSxRQUFRLEtBQUssU0FBUyxFQUFFO1FBQzdDLDBDQUEwQztRQUMxQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDO0tBQy9FO0lBQ0QsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztRQUN4QyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUM7S0FDN0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNmLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDWCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLFdBQVcsRUFDWCxXQUFXLFFBQVEsNEJBQTRCLElBQUksQ0FBQyxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFDdkYsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7Ozs7Ozs7O0dBVUc7QUFDSCxTQUFTLHFCQUFxQixDQUFDLGNBQWMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUs7SUFDbkUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztRQUN4QyxLQUFLLEVBQUUsRUFBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztLQUNyRixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2YsSUFBSSxNQUFNLEVBQUU7WUFDVixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hEO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7Ozs7Ozs7Ozs7OztHQVlHO0FBQ0gsZ0JBQWdCLENBQUMsWUFBWSxHQUFHLFVBQVMsUUFBUSxFQUFFLFdBQVcsRUFBRSxhQUFhLEVBQUUsV0FBVztJQUN4RixJQUFJLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7UUFDaEQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxnQ0FBZ0MsRUFBRSxJQUFJLENBQUMsQ0FBQztLQUNqRjtJQUNELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtRQUM5QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0tBQzVFO0lBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRTVELGNBQWM7SUFDZCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNwRSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3RGO1FBQ0QsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVuQyxJQUFJLFdBQVcsS0FBSyxRQUFRLEVBQUU7WUFDNUIsTUFBTSxRQUFRLEdBQUcsYUFBYSxDQUFDO1lBQy9CLHNFQUFzRTtZQUN0RSxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFNUMsaURBQWlEO1lBQ2pELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBRWpDLDZDQUE2QztnQkFDN0MsSUFBSSxRQUFRLEtBQUssQ0FBQyxDQUFDLEVBQUU7b0JBQ25CLE9BQU8sRUFBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQyxDQUFDO2lCQUNoQztnQkFFRCx3QkFBd0I7Z0JBQ3hCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUU7d0JBQ25ELFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUzt3QkFDM0IsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO3FCQUN2QixFQUFFLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDeEQsT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDcEMsK0NBQStDO29CQUMvQyxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBRXJFLGdDQUFnQztvQkFDaEMsTUFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBQ2pELElBQUksQ0FBQyxTQUFTLEVBQUU7d0JBQ2QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUN0RjtvQkFFRCxpREFBaUQ7b0JBQ2pELElBQUksaUJBQWlCLEdBQUcsU0FBUyxDQUFDO29CQUNsQyxPQUFPLGlCQUFpQixJQUFJLGlCQUFpQixDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTt3QkFDdkQsSUFBSSxpQkFBaUIsQ0FBQyxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsRUFBRTs0QkFDdEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFBRSw0Q0FBNEMsRUFBRSxJQUFJLENBQ3hFLENBQUM7eUJBQ0g7d0JBQ0QsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQ3BFO29CQUVELE9BQU8sU0FBUyxDQUFDO2dCQUNuQixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFFbEIsd0RBQXdEO2dCQUN4RCxPQUFPLHFCQUFxQixDQUMxQixTQUFTLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQzFELENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDbEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUM3QixPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQsSUFBSSxXQUFXLEtBQUssT0FBTyxFQUFFO1lBQzNCLE1BQU0sUUFBUSxHQUFHLGFBQWEsQ0FBQztZQUMvQixzRUFBc0U7WUFDdEUsT0FBTyxxQkFBcUIsQ0FDMUIsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQ3ZELENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVixNQUFNLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztnQkFDeEIsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUVILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtRQUN0QiwrQkFBK0I7UUFDL0IsT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNyRSxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7O0dBSUc7QUFDSCxnQkFBZ0IsQ0FBQyxZQUFZLEdBQUcsVUFBUyxRQUFRLEVBQUUsV0FBVztJQUU1RCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNwRSxJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUU7WUFDbkIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEdBQUcsUUFBUSxHQUFHLGlCQUFpQixDQUFDLENBQUM7U0FDL0U7UUFDRCxXQUFXLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRW5DLG1FQUFtRTtRQUNuRSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDO1lBQ3BGLEVBQUUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsRUFBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDO2FBQzdFLElBQUksQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLHNCQUFzQixDQUFDLEVBQUUsRUFBRTtZQUVsRCxJQUFJLGVBQWUsSUFBSSxzQkFBc0IsRUFBRTtnQkFDN0MsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHdCQUF3QixFQUFFLGdCQUFnQjtvQkFDL0QseURBQXlEO29CQUN6RCw2QkFBNkIsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUV4QztpQkFBTTtnQkFDTCxPQUFPLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFFTCxDQUFDLENBQUM7QUFFRjs7Ozs7OztHQU9HO0FBQ0gsZ0JBQWdCLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFdBQVc7SUFDeEQsdUVBQXVFO0lBQ3ZFLGlGQUFpRjtJQUNqRixNQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUN4RCxJQUFJLGlCQUFpQixDQUFDO0lBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtRQUNyQixpQkFBaUIsR0FBRztZQUNsQixNQUFNLEVBQUUsRUFBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFDO1NBQzVDLENBQUM7S0FDSDtJQUVELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFDckQsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDO1FBQ3JFLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUM7UUFDL0QsT0FBTyxFQUFFLENBQUM7Z0JBQ1IsS0FBSyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsa0JBQWtCO2dCQUNuQyxRQUFRLEVBQUUsS0FBSztnQkFDZixLQUFLLEVBQUUsaUJBQWlCO2FBQ3pCLENBQUM7S0FDSCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUU7UUFDdEIscUNBQXFDO1FBQ3JDLGFBQWEsR0FBRyxhQUFhLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDcEMsYUFBYSxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDO1FBQ3BFLE9BQU8sYUFBYSxDQUFDLG1CQUFtQixDQUFDO1FBQ3pDLE9BQU8sYUFBYSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7R0FPRztBQUNILFNBQVMsU0FBUyxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLFlBQVk7SUFDaEUsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDO0lBRW5CLFVBQVU7SUFDVixPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ3ZCLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7WUFDOUIsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUM3RSxNQUFNLFNBQVMsR0FBRztnQkFDaEIsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNiLElBQUksRUFBRSxRQUFRO2dCQUNkLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSzthQUNwQixDQUFDO1lBRUYsSUFBSSxRQUFRLEVBQUU7Z0JBQ1osU0FBUyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7YUFDL0I7WUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3pCO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCxRQUFRO0lBQ1IsSUFBSSxNQUFNLENBQUM7SUFDWCxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQzVCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7WUFDNUIsTUFBTSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDL0IsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDWCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7Z0JBQ1gsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO2dCQUNqQixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7Z0JBQzNCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDekIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN6QixTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNO2FBQ3hDLENBQUMsQ0FBQztTQUNKO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPLE9BQU8sQ0FBQztBQUNqQixDQUFDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILGdCQUFnQixDQUFDLE9BQU8sR0FBRyxVQUFTLFNBQVMsRUFBRSxXQUFXO0lBQ3hELE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxFQUFFLENBQUM7SUFDOUIsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsRUFDcEMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUMsRUFBQyxDQUFDLEVBQ3RGLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsRUFBQyxDQUFDLEVBQzNGLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsRUFBRTtRQUNuQyxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3pELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQy9FLENBQUMsQ0FDRixDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUY7Ozs7R0FJRztBQUNILGdCQUFnQixDQUFDLGFBQWEsR0FBRyxVQUFTLEdBQUc7SUFDM0MseUNBQXlDO0lBQ3pDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUU7UUFDNUMsSUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFBRSxRQUFRLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFDakMsbUJBQW1CO1FBQ25CLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQ3pDLFVBQVU7UUFDVixHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUMsQ0FBQztJQUM5QyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsZ0JBQWdCLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsT0FBTztJQUNqRSxJQUFJLENBQUMsT0FBTyxFQUFFO1FBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBRS9CLE9BQU8sUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFFdEMsOERBQThEO1FBQzlELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RELE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVyQixPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEQsb0ZBQW9GO1lBQ3BGLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM1QixHQUFHLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUVsQix5Q0FBeUM7WUFDekMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRXBDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2QsT0FBTyxHQUFHLENBQUM7YUFDWjtZQUVELG9FQUFvRTtZQUNwRSxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksS0FBSyxTQUFTO2dCQUN0RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdDLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxLQUFLLFNBQVM7Z0JBQ3RELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0Msd0JBQXdCO1lBQ3hCLE9BQU8sU0FBUyxDQUFDLG9CQUFvQixDQUFDO2dCQUNwQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztnQkFDL0IsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7Z0JBQy9CLFNBQVMsRUFBRSxHQUFHLENBQUMsU0FBUztnQkFDeEIsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJO2dCQUMxQyxzQkFBc0IsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0I7Z0JBQ3BFLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSTtnQkFDMUMsc0JBQXNCLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsc0JBQXNCO2dCQUNwRSxhQUFhLEVBQUUsSUFBSTtnQkFDbkIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDL0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ3ZCLElBQUksUUFBUSxDQUFDLFVBQVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssT0FBTyxJQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssT0FBTyxDQUFDLEVBQUU7b0JBQzNFLEdBQUcsQ0FBQyxLQUFLLElBQUksV0FBVyxDQUFDO2lCQUMxQjtnQkFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRTlDLDBFQUEwRTtnQkFDMUUsZ0RBQWdEO2dCQUNoRCxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQ2YsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQ3JCLEdBQUcsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUNoRSxDQUFDO2dCQUVGLHdGQUF3RjtnQkFDeEYsNEZBQTRGO2dCQUM1RixNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRTdDLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQ3BCLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSztnQkFDckIsK0RBQStEO2dCQUMvRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUNaLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssU0FBUztvQkFDdEMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxTQUFTLENBQ3pDLENBQUM7Z0JBRUYsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM5QyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTFGLE9BQU8sR0FBRyxDQUFDO1lBQ2IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNaLHFCQUFxQjtRQUNyQixPQUFPLGFBQWEsQ0FBQywrQkFBK0IsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3RFLEdBQUcsQ0FBQyxTQUFTLEdBQUcsR0FBRyxJQUFJLElBQUksQ0FBQztZQUM1QixPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBa0JHO0FBQ0gsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLFVBQVMsT0FBTyxFQUFFLElBQUk7SUFDbEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDO0lBQzFCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDakMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQ2hCLFVBQVUsRUFDVixPQUFPLENBQUMsUUFBUSxFQUNoQjtZQUNFLFNBQVM7WUFDVCxpQkFBaUI7WUFDakIsY0FBYyxFQUFFLFFBQVEsRUFBRSxRQUFRO1lBQ2xDLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFNBQVM7WUFDVCxTQUFTO1NBQ1YsQ0FDRixDQUFDO1FBQ0YsUUFBUSxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQ3hCLEtBQUssaUJBQWlCLENBQUM7WUFDdkIsS0FBSyxjQUFjLENBQUM7WUFDcEIsS0FBSyxRQUFRLENBQUM7WUFDZCxLQUFLLFFBQVE7Z0JBQ1gsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDNUMsTUFBTTtZQUVSLEtBQUssU0FBUztnQkFDWixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvQyxNQUFNO1lBRVIsS0FBSyxZQUFZLENBQUM7WUFDbEIsS0FBSyxZQUFZO2dCQUNmLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3RCxJQUFJLE9BQU8sQ0FBQyxlQUFlLEtBQUssU0FBUyxFQUFFO29CQUN6QyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDdEU7Z0JBQ0QsTUFBTTtZQUVSLEtBQUssU0FBUztnQkFDWixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbkUsTUFBTTtTQUNUO1FBQ0QsT0FBTyxZQUFZLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMvQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUM7U0FBRTtRQUMxQyxPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNuQixPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVuQiwyQkFBMkI7UUFFM0IsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLGlCQUFpQixFQUFFO1lBQzFDLDJCQUEyQjtZQUMzQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQ2pCLE9BQU8sQ0FBQyxNQUFNLEVBQ2QsSUFBSSxFQUNKLElBQUksRUFDSjtnQkFDRSxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2FBQy9CLENBQ0YsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3JCLE9BQU8sQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFDcEMsT0FBTyxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDO2dCQUNwQyxPQUFPLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7Z0JBQ3RDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDLFVBQVUsQ0FBQztnQkFDOUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxDQUFDO2dCQUM5QyxPQUFPLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUM7Z0JBQ3BDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQztnQkFFeEMsT0FBTyxPQUFPLENBQUM7WUFDakIsQ0FBQyxDQUFDLENBQUM7U0FDSjthQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7WUFDeEMsa0JBQWtCO1lBQ2xCLE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQztnQkFDdkIsRUFBRSxFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUNsQixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO2FBQzdCLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pFLE9BQU8sT0FBTyxDQUFDO1lBQ2pCLENBQUMsQ0FBQyxDQUFDO1NBRUo7YUFBTSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO1lBQ3hDLGdCQUFnQjtZQUNoQixNQUFNLGNBQWMsR0FBRztnQkFDckIsRUFBRSxFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUNsQixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzVCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtnQkFDOUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2FBQy9CLENBQUM7WUFDRixPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFFckUsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO2dCQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHO29CQUNkLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUM7b0JBQzlDLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQztpQkFDakQsQ0FBQztnQkFDRixPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUMsQ0FBQztTQUVKO2FBQU0sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLGNBQWMsRUFBRTtZQUM5QyxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUM7Z0JBQ3ZCLEVBQUUsRUFBRSxPQUFPLENBQUMsTUFBTTtnQkFDbEIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUzthQUM3QixFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFFL0IsTUFBTSxVQUFVLEdBQUcsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFcEQsT0FBTyxTQUFTLENBQUMsZ0JBQWdCLENBQy9CLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUNoQixLQUFLLEVBQUUsYUFBYTtvQkFDcEIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO29CQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7aUJBQy9CLEVBQ0QsT0FBTyxDQUFDLFNBQVMsRUFDakIsWUFBWSxDQUNiLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNoQixPQUFPLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBQy9CLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ25FLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUVsQyxPQUFPLE9BQU8sQ0FBQztnQkFDakIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUVKO2FBQU0sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLGFBQWEsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLGFBQWEsRUFBRTtZQUNuRiwwQkFBMEI7WUFDMUIsTUFBTSxpQkFBaUIsR0FBRztnQkFDeEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEtBQUssYUFBYSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU07Z0JBQzFELENBQUMsRUFBRSxPQUFPLENBQUMsV0FBVztnQkFDdEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxlQUFlO2dCQUNsQyxJQUFJLEVBQUUsYUFBYTthQUNwQixDQUFDO1lBRUYsT0FBTyxTQUFTLENBQUMsVUFBVSxDQUN6QixpQkFBaUIsRUFDakIsT0FBTyxDQUFDLFNBQVMsRUFDakI7Z0JBQ0UsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2dCQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDL0IsRUFDRCxZQUFZLENBQ2IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ2hCLE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFDL0IsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDbkUsT0FBTyxPQUFPLENBQUM7WUFDakIsQ0FBQyxDQUFDLENBQUM7U0FFSjthQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDekMsMkRBQTJEO1lBQzNELE9BQU8sU0FBUyxDQUFDLHNCQUFzQixDQUFDO2dCQUN0QyxVQUFVLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzdCLE9BQU8sRUFBRSxPQUFPLENBQUMsY0FBYztnQkFDL0IsS0FBSyxFQUFFLE9BQU8sQ0FBQyxZQUFZO2dCQUMzQixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTthQUMvQixFQUFFLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDL0IsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO2dCQUMvQixPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUMsQ0FBQztTQUNKO2FBQU0sSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtZQUN6QyxPQUFPLFlBQVksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQy9ELE1BQU0sV0FBVyxHQUFHO29CQUNsQixHQUFHLEVBQUUsS0FBSyxDQUFDLEtBQUs7b0JBQ2hCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztvQkFDNUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO29CQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7aUJBQy9CLENBQUM7Z0JBQ0YsTUFBTSxXQUFXLEdBQUcsRUFBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBQyxDQUFDO2dCQUVyRSw2QkFBNkI7Z0JBQzdCLE9BQU8sU0FBUyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNwRSxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQzFELE9BQU8sU0FBUyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQzNELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDZCxPQUFPLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDdkQsT0FBTyxPQUFPLENBQUM7Z0JBQ2pCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtRQUNoQiw4RkFBOEY7UUFFOUYsSUFBSSxPQUFPLENBQUMsUUFBUSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUNqRCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzQjthQUFNO1lBQ0wscUNBQXFDO1lBQ3JDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsRUFBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUMsQ0FBQztZQUMzRCxPQUFPLE9BQU8sQ0FBQztTQUNoQjtJQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7R0FJRztBQUNILFNBQVMsU0FBUyxDQUFDLGFBQWE7SUFDOUIsMENBQTBDO0lBQzFDLGFBQWEsQ0FBQyxNQUFNLEdBQUc7UUFDckIsU0FBUyxFQUFFLE9BQU87UUFDbEIsV0FBVyxFQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLO0tBQzdFLENBQUM7SUFDRixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDdEMsQ0FBQztBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXFERztBQUNILGdCQUFnQixDQUFDLG1CQUFtQixHQUFHLFVBQVMsR0FBRyxFQUFFLFdBQVc7SUFDOUQsSUFBSSxDQUFDLFdBQVcsRUFBRTtRQUNoQixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0tBQzVFO0lBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBRXpDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBRXRELGlCQUFpQjtJQUNqQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQUUsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztLQUFFO0lBQ25ELElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFO1FBQUUsR0FBRyxDQUFDLE9BQU8sR0FBRyxFQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBQyxDQUFDO0tBQUU7SUFDekQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7UUFBRSxHQUFHLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQztLQUFFO0lBQ3pDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQ25FLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQ25ELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztLQUFFO0lBQzdDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0tBQUU7SUFDM0QsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRTtRQUNqQyxHQUFHLENBQUMsVUFBVSxHQUFHLEVBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFDLENBQUM7S0FDNUU7SUFDRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ2pDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUMsQ0FBQztLQUM1RTtJQUVELGdDQUFnQztJQUNoQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBRXpELFNBQVM7U0FDTixhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztTQUM1QixzQkFBc0IsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFOUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLE1BQU07UUFDMUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUM3QixDQUFDLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFdkYsT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQzdCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO1lBQ3RFLE9BQU8sRUFBRSxLQUFLO1lBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1lBQ2xCLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSztZQUNoQixLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxVQUFVO1lBQzFCLFVBQVUsRUFBRSxHQUFHLENBQUMsVUFBVTtZQUMxQixjQUFjLEVBQUUsR0FBRyxDQUFDLGNBQWM7WUFDbEMsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU87WUFDcEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1lBQ3hCLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBRTtZQUN0QixJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUk7WUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU07WUFDbEIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1lBQ1osT0FBTyxFQUFFLENBQUM7U0FDWCxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFFRjs7OztHQUlHO0FBQ0gsU0FBUyxnQkFBZ0IsQ0FBQyxJQUFJO0lBQzVCLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLGlCQUFpQixDQUFDLENBQUM7SUFFbEQsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7SUFFdEQsMEJBQTBCO0lBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFO1FBQ3ZCLEdBQUcsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO0tBQ3pCO0lBRUQsMkJBQTJCO0lBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFO1FBQ2IsR0FBRyxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7S0FDdkI7SUFFRCxpQkFBaUI7SUFDakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUU7UUFDZixHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUMsQ0FBQztLQUNyRTtJQUVELElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRTtRQUM1QixHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztLQUN4RDtJQUNELElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRTtRQUM1QixHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztLQUN4RDtJQUVELGdFQUFnRTtJQUNoRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsT0FBTyxFQUFFO1FBQzNCLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RELEdBQUcsQ0FBQyxHQUFHLEdBQUc7WUFDUixnQkFBZ0IsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0I7WUFDeEQsaUJBQWlCLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCO1lBQzFELHdFQUF3RTtZQUN4RSxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7U0FDdEMsQ0FBQztLQUNIO0lBRUQsaUNBQWlDO0lBQ2pDLElBQUksR0FBRyxDQUFDLElBQUksRUFBRTtRQUNaLEdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQzFEO0lBRUQsT0FBTyxHQUFHLENBQUM7QUFDYixDQUFDO0FBRUQ7Ozs7OztHQU1HO0FBQ0gsZ0JBQWdCLENBQUMscUJBQXFCLEdBQUcsVUFBUyxTQUFTLEVBQUUsdUJBQXVCO0lBQ2xGLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtRQUM1QixLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ2pDO0lBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUFDLEtBQUssRUFBRTtZQUMzRCxTQUFTLEVBQUUsU0FBUztZQUNwQixPQUFPLEVBQUUsS0FBSztTQUNmLEVBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7O0dBU0c7QUFDSCxnQkFBZ0IsQ0FBQyxzQkFBc0IsR0FBRyxVQUFTLE9BQU8sRUFBRSxLQUFLO0lBQy9ELEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7UUFDekMsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO1FBQ3JDLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDO1FBQ2pDLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7S0FDM0IsQ0FBQyxDQUFDO0lBRUgsSUFBSSxPQUFPLENBQUM7SUFDWixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1FBQ2hELE9BQU8sR0FBRyxjQUFjLENBQUMsR0FBRyxFQUFFLENBQUM7UUFFL0Isb0ZBQW9GO1FBQ3BGLE9BQU8sS0FBSyxDQUFDLHFCQUFxQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3JELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDWCxnQ0FBZ0M7UUFDaEMsT0FBTyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sT0FBTyxDQUFDLFNBQVMsQ0FBQztRQUN6QixPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUM7UUFFekIscUJBQXFCO1FBQ3JCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLEtBQUssQ0FBQyxFQUFFLEVBQUU7Z0JBQy9CLDRFQUE0RTtnQkFDNUUsT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2FBQ25DO2lCQUFNO2dCQUNMLG1GQUFtRjtnQkFDbkYsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUN2QjtTQUNGO1FBRUQsK0NBQStDO1FBQy9DLE9BQU8sQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUUxQixnQkFBZ0I7UUFDaEIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNqQyxPQUFPLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDL0I7YUFBTTtZQUNMLE9BQU8sQ0FBQyxLQUFLLEdBQUcsVUFBVSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDNUM7UUFFRCw4RkFBOEY7UUFDOUYsT0FBTyxXQUFXLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNmLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUUzQixnQkFBZ0I7UUFDaEIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDakQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXdCRztBQUNILGdCQUFnQixDQUFDLG1CQUFtQixHQUFHLFVBQVMsS0FBSyxFQUFFLGFBQWEsRUFBRSxPQUFPLEVBQUUsV0FBVztJQUN4RixJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRTtRQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUM7S0FDeEM7SUFFRCxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUUxQyxJQUFJLENBQUMsV0FBVyxFQUFFO1FBQ2hCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsMkJBQTJCLENBQUMsQ0FBQztLQUNyRTtJQUNELElBQUksT0FBTyxhQUFhLEtBQUssUUFBUSxFQUFFO1FBQ3JDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRSxpREFBaUQsQ0FBQyxDQUFDO0tBQy9GO0lBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBRXRFLGtFQUFrRTtJQUNsRSxPQUFPLGFBQWEsQ0FBQyxFQUFFLENBQUM7SUFDeEIsT0FBTyxhQUFhLENBQUMsU0FBUyxDQUFDO0lBQy9CLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQztJQUM1QixPQUFPLGFBQWEsQ0FBQyxPQUFPLENBQUM7SUFFN0IsNEJBQTRCO0lBQzVCLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFFakUsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDcEUsK0JBQStCO1FBQy9CLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3pCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNaLFNBQVMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUU1RixrRUFBa0U7UUFDbEUsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLFNBQVMsSUFBSSxHQUFHLENBQUMsTUFBTSxLQUFLLGFBQWEsQ0FBQyxNQUFNLEVBQUU7WUFDN0UsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDO1NBQzdCO1FBRUQsbUVBQW1FO1FBQ25FLE1BQU0sV0FBVyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUUzRSxPQUFPLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNuRSxJQUFJLGFBQWEsR0FBRyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFdEMsd0NBQXdDO1lBQ3hDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO2dCQUN0QyxJQUFJLEdBQUcsS0FBSyxRQUFRLEVBQUU7b0JBQ3BCLHVGQUF1RjtvQkFDdkYsYUFBYSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQzNFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDekIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztpQkFDbEI7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sYUFBYSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxnQ0FBZ0M7WUFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUMvQyxPQUFPO2FBQ1I7WUFFRCx1QkFBdUI7WUFDdkIsd0JBQXdCO1lBQ3hCLE9BQU8sZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDN0UsMEJBQTBCO2dCQUMxQixPQUFPLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ25CLDhDQUE4QztnQkFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDcEQsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ2hDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFO3dCQUFFLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO3FCQUFFO29CQUN2QyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsS0FBSyxLQUFLLElBQUksRUFBRTt3QkFDOUIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0JBQzdCLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3FCQUM5QjtvQkFDRCxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNuQixDQUFDLENBQUMsQ0FBQztnQkFDSCxzREFBc0Q7Z0JBQ3RELEdBQUcsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7Ozs7R0FVRztBQUNILGdCQUFnQixDQUFDLGFBQWEsR0FBRyxVQUFTLFNBQVMsRUFBRSxhQUFhLEVBQUUsV0FBVztJQUM3RSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFFbkQsa0VBQWtFO0lBQ2xFLE9BQU8sYUFBYSxDQUFDLEVBQUUsQ0FBQztJQUN4QixPQUFPLGFBQWEsQ0FBQyxTQUFTLENBQUM7SUFDL0IsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDO0lBQzVCLE9BQU8sYUFBYSxDQUFDLE9BQU8sQ0FBQztJQUU3QixPQUFPLFlBQVksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3JELHNEQUFzRDtRQUN0RCw4Q0FBOEM7UUFDOUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXhFLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQ3RDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNwQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDO0FBRUY7Ozs7OztHQU1HO0FBQ0gsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLFVBQVMsZUFBZSxFQUFFLFdBQVc7SUFDakUsT0FBTyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1FBQ3BELE9BQU8sV0FBVyxDQUFDLHFCQUFxQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ3pFLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7R0FPRztBQUNILFNBQVMsVUFBVSxDQUFDLGFBQWE7SUFDL0IsT0FBTyxvQkFBb0IsQ0FBQyxhQUFhLENBQUM7U0FDdkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsU0FBUyxvQkFBb0IsQ0FBQyxhQUFhO0lBQ3pDLElBQUksYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUU7UUFDN0IsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBQ3ZDO1NBQU07UUFFTCxhQUFhLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3pELHNEQUFzRDtZQUN0RCw0Q0FBNEM7WUFDNUMsMkRBQTJEO1lBQzNELHNDQUFzQztZQUN0QywyREFBMkQ7WUFDM0QsdUNBQXVDO1lBRXZDLElBQUksTUFBTSxDQUFDLEdBQUcsS0FBSyxpQkFBaUIsRUFBRTtnQkFDcEMsbUJBQW1CO2dCQUNuQixPQUFPO29CQUNMLEdBQUcsRUFBRSxpQkFBaUI7aUJBQ3ZCLENBQUM7YUFDSDtZQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzlELEdBQUcsQ0FBQyxJQUFJLENBQUMsOEJBQThCLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDeEUsT0FBTyxDQUFDLHdCQUF3QjthQUNqQztZQUVELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFFdkQsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDdkIsR0FBRyxDQUFDLElBQUksQ0FBQyw4QkFBOEIsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUN4RSxPQUFPLENBQUMsd0JBQXdCO2FBQ2pDO1lBRUQsSUFBSSxNQUFNLENBQUMsR0FBRyxLQUFLLHNCQUFzQjtnQkFDdkMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUM7Z0JBQzlDLE1BQU0sQ0FBQyxHQUFHLEtBQUssZ0JBQWdCO2dCQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO2dCQUNoRCxPQUFPO29CQUNMLEdBQUcsRUFBRSxNQUFNLENBQUMsR0FBRztvQkFDZixNQUFNO2lCQUNQLENBQUM7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsaURBQWlEO1FBQ2pELGFBQWEsQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXJFLGFBQWEsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBRTFCLE9BQU8sYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQzdCO0FBQ0gsQ0FBQztBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILFNBQVMsb0JBQW9CLENBQUMsYUFBYTtJQUN6QyxJQUFJLGFBQWEsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO1FBQzdCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUN2QztTQUFNO1FBQ0wscUZBQXFGO1FBQ3JGLGlDQUFpQztRQUNqQyxhQUFhLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRTtZQUN0RCxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7UUFDSCxhQUFhLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRTtZQUN0RCxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7UUFFSCxhQUFhLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUUxQixPQUFPLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztLQUM3QjtBQUNILENBQUM7QUFFRDs7Ozs7Ozs7Ozs7O0dBWUc7QUFDSCxTQUFTLG9CQUFvQixDQUFDLGFBQWE7SUFDekMsSUFBSSxhQUFhLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRTtRQUM3QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDdkM7SUFFRCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDbkIsY0FBYyxFQUFFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO1FBQ3BFLFNBQVMsRUFBRSxJQUFJLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztLQUNoRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2YsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLDRCQUE0QjtRQUM1QixNQUFNLFNBQVMsR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDO1FBQ3hDLDJEQUEyRDtRQUMzRCxRQUFRLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUNoRCxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFDM0IsYUFBYSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQzVCLFNBQVMsQ0FBQyxDQUFDO1FBQ2IsbUVBQW1FO1FBQ25FLFFBQVEsQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQztRQUN2QyxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztRQUNsRCxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztRQUNsRCw0Q0FBNEM7UUFDNUMsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDdEIsVUFBVSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFdEIsZ0JBQWdCO1FBQ2hCLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQztRQUN6QixPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFFekIsa0VBQWtFO1FBQ2xFLHVGQUF1RjtRQUN2RixhQUFhLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQztRQUNoQyxhQUFhLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUN0QyxhQUFhLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUN0QyxhQUFhLENBQUMsT0FBTyxHQUFHLEVBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFDLENBQUM7UUFDN0MsYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFFMUIsT0FBTyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFFTCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILFNBQVMsUUFBUSxDQUFDLGVBQWUsRUFBRSxXQUFXO0lBQzVDLE1BQU0sT0FBTyxHQUFHLEVBQUMsS0FBSyxFQUFFLEVBQUMsRUFBRSxFQUFFLGVBQWUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDLEVBQUMsQ0FBQztJQUMvRCxJQUFJLFdBQVcsRUFBRTtRQUNmLE9BQU8sQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3BDO0lBQ0QsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1FBQ2hFLElBQUksYUFBYSxLQUFLLElBQUksSUFBSSxhQUFhLEtBQUssU0FBUyxFQUFFO1lBQ3pELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsV0FBVyxFQUFFLGlCQUFpQixHQUFHLGVBQWUsR0FBRyxpQkFBaUIsRUFBRSxJQUFJLENBQzNFLENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFFO1lBQ2pDLGFBQWEsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1NBQ25DO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDdkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsWUFBWSxDQUFDLFNBQVMsRUFBRSxXQUFXO0lBQzFDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbEQsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBRXJCLE1BQU0sS0FBSyxHQUFHO1FBQ1osT0FBTyxFQUFFLElBQUk7UUFDYixTQUFTLEVBQUUsU0FBUztRQUNwQixNQUFNLEVBQUUsV0FBVyxDQUFDLEVBQUU7S0FDdkIsQ0FBQztJQUNGLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLFNBQVM7UUFDaEIsS0FBSyxFQUFFLEVBQUU7UUFDVCxLQUFLLEVBQUUsRUFBRTtRQUNULE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVixVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7UUFDckUsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFDO1FBQ3JFLE1BQU0sRUFBRTtZQUNOLE9BQU8sRUFBRSxXQUFXLENBQUMsT0FBTztZQUM1QixNQUFNLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhO1NBQ25DO1FBQ0QsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFDO1FBQzdCLE9BQU8sRUFBRSxDQUFDO0tBQ1gsQ0FBQztJQUNGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDO1FBQzFDLEtBQUssRUFBRSxLQUFLO1FBQ1osUUFBUSxFQUFFLE1BQU07S0FDakIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsZ0JBQWdCLENBQUMsY0FBYyxHQUFHLFVBQVMsU0FBUyxFQUFFLE9BQU87SUFDM0QsS0FBSyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNoQyxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ2xELE1BQU0sK0JBQStCLEdBQUcsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUMsRUFBQyxDQUFDO0lBRXZGLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFFakMsZ0JBQWdCO1FBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQ2hDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLE1BQU0sRUFBRTtnQkFDTixPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU87Z0JBQzVCLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWE7YUFDbkM7U0FDRixFQUFFLCtCQUErQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3JELEdBQUcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLFdBQVcsNEJBQTRCLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFDckYsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBRVgsa0JBQWtCO1FBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQ2xDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3BDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQztZQUNyRSxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7U0FDdEUsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNyRCxHQUFHLENBQUMsSUFBSSxDQUFDLHNCQUFzQixXQUFXLDRCQUE0QixTQUFTLElBQUksQ0FBQyxDQUFDO1FBQ3ZGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7Ozs7Ozs7Ozs7O0dBZUc7QUFDSCxTQUFTLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTztJQUNsQywyQkFBMkI7SUFDM0IsSUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO1FBQ3pCLE9BQU8sR0FBRyxFQUFDLFFBQVEsRUFBRSxFQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFDLEVBQUMsQ0FBQztLQUN4RTtJQUVELHlEQUF5RDtJQUN6RCxJQUFJLE9BQU8sQ0FBQyxDQUFDLEtBQUssU0FBUyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUFFO1FBQ3RELE9BQU8sR0FBRyxFQUFDLFFBQVEsRUFBRSxFQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFDLEVBQUMsQ0FBQztLQUNwRDtJQUVELE9BQU87UUFDTCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDWCxRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNsRCxHQUFHLEVBQUUsT0FBTyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDOUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVM7UUFDdEQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1FBQ2YsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1FBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtRQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07S0FDcEIsQ0FBQztBQUNKLENBQUM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPO0lBQ2xDLE9BQU87UUFDTCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDWCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7UUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7UUFDZixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07UUFDbkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1FBQ25CLFFBQVEsRUFBRSxPQUFPLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTO1FBQ3hELFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtRQUMzQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07S0FDcEIsQ0FBQztBQUNKLENBQUMifQ==