/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-23.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
// services
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Errors = LKE.getErrors();
const UserDAO = LKE.getUserDAO();
const VisualizationShareDAO = module.exports = {};
/**
 * Get all visualization shared with current user
 *
 * @param {string} sourceKey Key of the data-source
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<Array<{visualizationId: string, title: string, sourceKey: string, ownerId: number, right: string, ownerUsername: string, updatedAt: string}>>}
 */
VisualizationShareDAO.getSharedWithMe = function (sourceKey, currentUser) {
    const query = {
        where: { userId: currentUser.id },
        include: [{
                model: Db.models.visualization,
                where: { sourceKey: sourceKey },
                include: [Db.models.user]
            }]
    };
    return Promise.resolve(Db.models.visualizationShare.findAll(query)).map(share => {
        return {
            right: share.right,
            visualizationId: share.visualization.id,
            ownerId: share.visualization.userId,
            ownerUsername: share.visualization.user.username,
            sourceKey: share.visualization.sourceKey,
            title: share.visualization.title,
            updatedAt: JSON.parse(JSON.stringify(new Date(share.visualization.updatedAt)))
        };
    });
};
/**
 * Get all shares for a visualization
 *
 * @param {number} visualizationId
 * @returns {Bluebird<{owner: {id: number, username: string, email: string, source: string}, shares:{userId:number, username:string, email:string, visualizationId:number, right:string}[]}>}
 */
VisualizationShareDAO.getShares = function (visualizationId) {
    const query = {
        where: { visualizationId: visualizationId },
        include: [Db.models.user]
    };
    return resolveVisualization(visualizationId).then(viz => {
        return UserDAO.getUser(viz.userId);
    }).then(owner => {
        return Promise.resolve(Db.models.visualizationShare.findAll(query)).map(share => {
            return {
                userId: share.userId,
                username: share.user.username,
                email: share.user.email,
                right: share.right,
                visualizationId: share.visualizationId
            };
        }).then(shares => {
            return {
                owner: owner,
                shares: shares
            };
        });
    });
};
/**
 * Add or update a visualizationShare
 *
 * @param {number} visualizationId
 * @param {number} userId
 * @param {string} right 'read' or 'write'
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<{userId:number, visualizationId:number, right:string, createdAt:string, updatedAt:string}>}
 */
VisualizationShareDAO.shareWithUser = function (visualizationId, userId, right, currentUser) {
    if (!_.includes(Db.models.visualizationShare.RIGHTS, right)) {
        return Errors.business('invalid_parameter', 'Right (' + right + ') must be one of ' + Db.models.visualizationShare.RIGHTS, true);
    }
    return checkOwner(visualizationId, currentUser).then(() => {
        const whereAndDefaults = {
            where: { visualizationId: visualizationId, userId: userId },
            defaults: { right: right }
        };
        return Db.models.visualizationShare.findOrCreate(whereAndDefaults).spread(vizShare => {
            // update the vizShare if the "right" is different
            if (vizShare.right !== right) {
                vizShare.right = right;
                return vizShare.save();
            }
            return vizShare;
        }).then(vizShare => {
            // remove the sequelize wrapper
            vizShare = vizShare.get();
            vizShare.userId = +vizShare.userId;
            vizShare.visualizationId = +vizShare.visualizationId;
            delete vizShare.id;
            return vizShare;
        });
    });
};
/**
 * Get a user's right for a visualization
 *
 * @param {object} visualization
 * @param {number} visualization.userId
 * @param {number} visualization.id
 * @param {number} userId
 * @returns {Bluebird<string>} resolves to 'owner', 'write' or 'read' (or reject if no right exists)
 */
VisualizationShareDAO.getRight = function (visualization, userId) {
    if (visualization.userId === userId) {
        return Promise.resolve('owner');
    }
    return getShare(visualization.id, userId).then(share => {
        if (!share) {
            return Errors.access('read_forbidden', 'You don\'t have access to this visualization', true);
        }
        return share.right;
    });
};
/**
 * Delete a visualizationShare
 *
 * @param {number} visualizationId
 * @param {number} userId
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<void>}
 */
VisualizationShareDAO.unshare = function (visualizationId, userId, currentUser) {
    return checkOwner(visualizationId, currentUser).then(() => {
        return getShare(visualizationId, userId).then(share => {
            if (share) {
                return share.destroy();
            }
        });
    });
};
/**
 * Resolve a visualization
 *
 * @param {number} id a visualization id
 * @returns {Bluebird<PublicVisualization>}
 */
function resolveVisualization(id) {
    const query = { where: { id: id } };
    return Db.models.visualization.find(query).then(viz => {
        if (!viz) {
            return Errors.business('not_found', 'Visualization "' + id + '" was not found', true);
        }
        return Promise.resolve(viz);
    });
}
/**
 * Check if the current user is the owner of a visualization
 *
 * @param {number}      visualizationId
 * @param {WrappedUser} currentUser
 * @returns {Bluebird<void>} resolved if the current user matches the viz' owner
 * @private
 */
function checkOwner(visualizationId, currentUser) {
    return resolveVisualization(visualizationId).then(viz => {
        // user is the original owner
        if (viz.userId === currentUser.id) {
            return;
        }
        return getShare(visualizationId, currentUser.id).then(share => {
            // user has delegated ownership
            if (share && share.right === 'owner') {
                return;
            }
            // user is not owner
            return Errors.access('forbidden', 'You can not change the share settings of a visualization that you don\'t own', true);
        });
    });
}
/**
 * @param {number} visualizationId
 * @param {number} userId
 * @returns {Bluebird<VisualizationShareInstance>}
 * @private
 */
function getShare(visualizationId, userId) {
    const where = { visualizationId: visualizationId, userId: userId };
    return Db.models.visualizationShare.find({ where: where });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvblNoYXJlREFPLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2J1c2luZXNzL1Zpc3VhbGl6YXRpb25TaGFyZURBTy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUM7QUFFakMsTUFBTSxxQkFBcUIsR0FBRyxNQUFNLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUVsRDs7Ozs7O0dBTUc7QUFDSCxxQkFBcUIsQ0FBQyxlQUFlLEdBQUcsVUFBUyxTQUFTLEVBQUUsV0FBVztJQUNyRSxNQUFNLEtBQUssR0FBRztRQUNaLEtBQUssRUFBRSxFQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBRSxFQUFDO1FBQy9CLE9BQU8sRUFBRSxDQUFDO2dCQUNSLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLGFBQWE7Z0JBQzlCLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUM7Z0JBQzdCLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2FBQzFCLENBQUM7S0FDSCxDQUFDO0lBQ0YsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQzlFLE9BQU87WUFDTCxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7WUFDbEIsZUFBZSxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUN2QyxPQUFPLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxNQUFNO1lBQ25DLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQ2hELFNBQVMsRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQVM7WUFDeEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSztZQUNoQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztTQUMvRSxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7R0FLRztBQUNILHFCQUFxQixDQUFDLFNBQVMsR0FBRyxVQUFTLGVBQWU7SUFDeEQsTUFBTSxLQUFLLEdBQUc7UUFDWixLQUFLLEVBQUUsRUFBQyxlQUFlLEVBQUUsZUFBZSxFQUFDO1FBQ3pDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0tBQzFCLENBQUM7SUFDRixPQUFPLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN0RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNkLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM5RSxPQUFPO2dCQUNMLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtnQkFDcEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUTtnQkFDN0IsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSztnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO2dCQUNsQixlQUFlLEVBQUUsS0FBSyxDQUFDLGVBQWU7YUFDdkMsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLE9BQU87Z0JBQ0wsS0FBSyxFQUFFLEtBQUs7Z0JBQ1osTUFBTSxFQUFFLE1BQU07YUFDZixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUVGOzs7Ozs7OztHQVFHO0FBQ0gscUJBQXFCLENBQUMsYUFBYSxHQUFHLFVBQVMsZUFBZSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVztJQUN4RixJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtRQUMzRCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLG1CQUFtQixFQUNuQixTQUFTLEdBQUcsS0FBSyxHQUFHLG1CQUFtQixHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUM3RSxJQUFJLENBQ0wsQ0FBQztLQUNIO0lBQ0QsT0FBTyxVQUFVLENBQUMsZUFBZSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDeEQsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QixLQUFLLEVBQUUsRUFBQyxlQUFlLEVBQUUsZUFBZSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUM7WUFDekQsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQztTQUN6QixDQUFDO1FBQ0YsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNuRixrREFBa0Q7WUFDbEQsSUFBSSxRQUFRLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRTtnQkFDNUIsUUFBUSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ3ZCLE9BQU8sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3hCO1lBQ0QsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pCLCtCQUErQjtZQUMvQixRQUFRLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzFCLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQ25DLFFBQVEsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDO1lBQ3JELE9BQU8sUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNuQixPQUFPLFFBQVEsQ0FBQztRQUNsQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7Ozs7O0dBUUc7QUFDSCxxQkFBcUIsQ0FBQyxRQUFRLEdBQUcsVUFBUyxhQUFhLEVBQUUsTUFBTTtJQUM3RCxJQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssTUFBTSxFQUFFO1FBQ25DLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUNqQztJQUNELE9BQU8sUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ3JELElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDVixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsOENBQThDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDOUY7UUFDRCxPQUFPLEtBQUssQ0FBQyxLQUFLLENBQUM7SUFDckIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRjs7Ozs7OztHQU9HO0FBQ0gscUJBQXFCLENBQUMsT0FBTyxHQUFHLFVBQVMsZUFBZSxFQUFFLE1BQU0sRUFBRSxXQUFXO0lBQzNFLE9BQU8sVUFBVSxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ3hELE9BQU8sUUFBUSxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDcEQsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsT0FBTyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDeEI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBRUY7Ozs7O0dBS0c7QUFDSCxTQUFTLG9CQUFvQixDQUFDLEVBQUU7SUFDOUIsTUFBTSxLQUFLLEdBQUcsRUFBQyxLQUFLLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQztJQUNoQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDcEQsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNSLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLEdBQUcsRUFBRSxHQUFHLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3ZGO1FBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzlCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7Ozs7O0dBT0c7QUFDSCxTQUFTLFVBQVUsQ0FBQyxlQUFlLEVBQUUsV0FBVztJQUM5QyxPQUFPLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN0RCw2QkFBNkI7UUFDN0IsSUFBSSxHQUFHLENBQUMsTUFBTSxLQUFLLFdBQVcsQ0FBQyxFQUFFLEVBQUU7WUFDakMsT0FBTztTQUNSO1FBRUQsT0FBTyxRQUFRLENBQUMsZUFBZSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDNUQsK0JBQStCO1lBQy9CLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssT0FBTyxFQUFFO2dCQUNwQyxPQUFPO2FBQ1I7WUFFRCxvQkFBb0I7WUFDcEIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUNsQixXQUFXLEVBQ1gsOEVBQThFLEVBQzlFLElBQUksQ0FDTCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsUUFBUSxDQUFDLGVBQWUsRUFBRSxNQUFNO0lBQ3ZDLE1BQU0sS0FBSyxHQUFHLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDLENBQUM7SUFDakUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO0FBQzNELENBQUMifQ==