/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-15.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../index');
const DbModels = LKE.getSqlDb().models;
/**
 *
 * @param {object|object[]} o
 * @param {string} [subField]
 * @returns {object|object[]}
 */
function omitSourceKey(o, subField) {
    if (Array.isArray(o)) {
        for (let i = 0; i < o.length; ++i) {
            o[i].sourceKey = undefined;
            o[i].id = undefined;
            if (subField) {
                o[i][subField] = omitSourceKey(o[i][subField]);
            }
            o[i] = normalizePropertiesField(o[i]);
        }
    }
    else if (o !== null && o !== undefined) {
        o.sourceKey = undefined;
        o.id = undefined;
        if (subField) {
            o[subField] = omitSourceKey(o[subField]);
        }
        o = normalizePropertiesField(o);
    }
    return o;
}
/**
 * Normalize 'nodeProperties'/'edgeProperties' field to 'properties'
 *
 * @param {object} o
 * @private
 */
function normalizePropertiesField(o) {
    if (typeof o.get === 'function') {
        o = o.get();
    }
    o.id = undefined;
    if (o.nodeProperties) {
        o.properties = o.nodeProperties.map(property => _.omit(property, 'typeId'));
        o.nodeProperties = undefined;
    }
    else if (o.edgeProperties) {
        o.properties = o.edgeProperties.map(property => _.omit(property, 'typeId'));
        o.edgeProperties = undefined;
    }
    return o;
}
/**
 * @class GraphSchemaDAO
 */
const GraphSchemaDAO = {
    NODE_CATEGORY: 'nodeCategory',
    EDGE_TYPE: 'edgeType',
    /**
     * Retrieves all Node Types with their properties.
     *
     * @param {string} sourceKey Key of the data-source
     * @param {boolean} [omitProperties=false]
     * @returns {Bluebird<nodeType[]>}
     */
    getAllNodeTypes: function (sourceKey, omitProperties) {
        return DbModels.nodeType.findAll({
            where: { sourceKey: sourceKey, name: { $not: '*' } },
            include: omitProperties ? undefined : DbModels.nodeProperty
        }).then(types => {
            // @backward-compatibility inferred types were removed in LKEv2.6.0
            // We filter them here to ensure that the saved inferred types schema are not leaked to the client
            types = types.filter(nodeType => nodeType.name.indexOf('inferred-') !== 0);
            return omitSourceKey(types, 'nodeProperties');
        });
    },
    /**
     * Get all edgeTypes (these are META-types, they include targetNodeType and sourceNodeType)
     *
     * @param {string} sourceKey ID of a data-source
     * @param {boolean} [omitProperties=false]
     * @returns {Bluebird<edgeType[]>}
     */
    getAllEdgeTypes: function (sourceKey, omitProperties) {
        return DbModels.edgeType.findAll({
            where: { sourceKey: sourceKey, name: { $not: '*' } },
            include: omitProperties ? undefined : DbModels.edgeProperty
        }).then(edgeTypes => omitSourceKey(edgeTypes, 'edgeProperties'));
    },
    /**
     * Gets all the node properties name and aggregates the node properties count by property key
     *
     * @param {string} sourceKey ID of a data-source
     * @returns {Bluebird<nodeProperty[]>}
     */
    getAllNodeProperties: function (sourceKey) {
        return DbModels.nodeType.findOne({
            where: { sourceKey: sourceKey, name: '*' },
            include: DbModels.nodeProperty
        }).then(wildcardType => {
            if (wildcardType) {
                return omitSourceKey(wildcardType, 'nodeProperties').properties;
            }
            // reverse compatibility with old schemas
            return this.getAllNodeTypes(sourceKey, false, false).then(types => {
                // @backward-compatibility remove this code when we have forced all old schemas to re-index
                const map = new Map();
                types.forEach(type => {
                    type.properties.forEach(p => {
                        if (map.has(p.key)) {
                            map.get(p.key).count += p.count;
                        }
                        else {
                            map.set(p.key, { key: p.key, count: p.count });
                        }
                    });
                });
                return Array.from(map.values());
            });
        });
    },
    /**
     * @param {string} sourceKey ID of a data-source
     * @returns {Bluebird<edgeProperty[]>}
     */
    getAllEdgeProperties: function (sourceKey) {
        return DbModels.edgeType.findOne({
            where: { sourceKey: sourceKey, name: '*' },
            include: DbModels.edgeProperty
        }).then(wildcardType => {
            // normal case
            if (wildcardType) {
                return omitSourceKey(wildcardType, 'edgeProperties').properties;
            }
            // reverse compatibility with old schemas
            return this.getAllEdgeTypes(sourceKey, false).then(types => {
                // @backward-compatibility remove this code when we have forced all old schemas to re-index
                const map = new Map();
                types.forEach(type => {
                    type.properties.forEach(p => {
                        if (map.has(p.key)) {
                            map.get(p.key).count += p.count;
                        }
                        else {
                            map.set(p.key, { key: p.key, count: p.count });
                        }
                    });
                });
                return Array.from(map.values());
            });
        });
    }
};
module.exports = GraphSchemaDAO;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3JhcGhTY2hlbWFEQU8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvYnVzaW5lc3MvR3JhcGhTY2hlbWFEQU8uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUV2Qzs7Ozs7R0FLRztBQUNILFNBQVMsYUFBYSxDQUFDLENBQUMsRUFBRSxRQUFRO0lBQ2hDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNwQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLFNBQVMsQ0FBQztZQUNwQixJQUFJLFFBQVEsRUFBRTtnQkFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2FBQ2hEO1lBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3ZDO0tBQ0Y7U0FBTSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRTtRQUN4QyxDQUFDLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUN4QixDQUFDLENBQUMsRUFBRSxHQUFHLFNBQVMsQ0FBQztRQUNqQixJQUFJLFFBQVEsRUFBRTtZQUNaLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDMUM7UUFDRCxDQUFDLEdBQUcsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDakM7SUFDRCxPQUFPLENBQUMsQ0FBQztBQUNYLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsd0JBQXdCLENBQUMsQ0FBQztJQUNqQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxVQUFVLEVBQUU7UUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0tBQUU7SUFDakQsQ0FBQyxDQUFDLEVBQUUsR0FBRyxTQUFTLENBQUM7SUFDakIsSUFBSSxDQUFDLENBQUMsY0FBYyxFQUFFO1FBQ3BCLENBQUMsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzVFLENBQUMsQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO0tBQzlCO1NBQU0sSUFBSSxDQUFDLENBQUMsY0FBYyxFQUFFO1FBQzNCLENBQUMsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzVFLENBQUMsQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO0tBQzlCO0lBQ0QsT0FBTyxDQUFDLENBQUM7QUFDWCxDQUFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLGNBQWMsR0FBRztJQUVyQixhQUFhLEVBQUUsY0FBYztJQUM3QixTQUFTLEVBQUUsVUFBVTtJQUVyQjs7Ozs7O09BTUc7SUFDSCxlQUFlLEVBQUUsVUFBUyxTQUFTLEVBQUUsY0FBYztRQUNqRCxPQUFPLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1lBQy9CLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLEdBQUcsRUFBQyxFQUFDO1lBQ2hELE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVk7U0FDNUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNkLG1FQUFtRTtZQUNuRSxrR0FBa0c7WUFDbEcsS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUUzRSxPQUFPLGFBQWEsQ0FBQyxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxlQUFlLEVBQUUsVUFBUyxTQUFTLEVBQUUsY0FBYztRQUNqRCxPQUFPLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1lBQy9CLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLEdBQUcsRUFBQyxFQUFDO1lBQ2hELE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVk7U0FDNUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixFQUFFLFVBQVMsU0FBUztRQUN0QyxPQUFPLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1lBQy9CLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQztZQUN4QyxPQUFPLEVBQUUsUUFBUSxDQUFDLFlBQVk7U0FDL0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNyQixJQUFJLFlBQVksRUFBRTtnQkFDaEIsT0FBTyxhQUFhLENBQUMsWUFBWSxFQUFFLGdCQUFnQixDQUFDLENBQUMsVUFBVSxDQUFDO2FBQ2pFO1lBRUQseUNBQXlDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDaEUsMkZBQTJGO2dCQUMzRixNQUFNLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUN0QixLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDMUIsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTs0QkFDbEIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7eUJBQ2pDOzZCQUFNOzRCQUNMLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQzt5QkFDOUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQW9CLEVBQUUsVUFBUyxTQUFTO1FBQ3RDLE9BQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDL0IsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFDO1lBQ3hDLE9BQU8sRUFBRSxRQUFRLENBQUMsWUFBWTtTQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3JCLGNBQWM7WUFDZCxJQUFJLFlBQVksRUFBRTtnQkFDaEIsT0FBTyxhQUFhLENBQUMsWUFBWSxFQUFFLGdCQUFnQixDQUFDLENBQUMsVUFBVSxDQUFDO2FBQ2pFO1lBRUQseUNBQXlDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN6RCwyRkFBMkY7Z0JBQzNGLE1BQU0sR0FBRyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ25CLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUMxQixJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFOzRCQUNsQixHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQzt5QkFDakM7NkJBQU07NEJBQ0wsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDO3lCQUM5QztvQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFFSCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRixDQUFDO0FBRUYsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMifQ==