/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-23.
 */
'use strict';
module.exports = function (sequelize, DataTypes) {
    const rights = ['read', 'write', 'owner'];
    const visualizationShare = sequelize.define('visualizationShare', {
        right: {
            type: DataTypes.STRING(20),
            values: rights
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                visualizationShare.belongsTo(models.visualization, { foreignKey: 'visualizationId' });
                visualizationShare.belongsTo(models.user, { foreignKey: 'userId' });
            }
        }
    });
    visualizationShare.RIGHTS = rights;
    return visualizationShare;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVmlzdWFsaXphdGlvblNoYXJlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3NxbERiL21vZGVscy9WaXN1YWxpemF0aW9uU2hhcmUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFFNUMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBRTFDLE1BQU0sa0JBQWtCLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRTtRQUVoRSxLQUFLLEVBQUU7WUFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDMUIsTUFBTSxFQUFFLE1BQU07U0FDZjtLQUVGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsa0JBQWtCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsRUFBQyxVQUFVLEVBQUUsaUJBQWlCLEVBQUMsQ0FBQyxDQUFDO2dCQUNwRixrQkFBa0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxFQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO1lBQ3BFLENBQUM7U0FDRjtLQUNGLENBQUMsQ0FBQztJQUVILGtCQUFrQixDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFFbkMsT0FBTyxrQkFBa0IsQ0FBQztBQUM1QixDQUFDLENBQUMifQ==