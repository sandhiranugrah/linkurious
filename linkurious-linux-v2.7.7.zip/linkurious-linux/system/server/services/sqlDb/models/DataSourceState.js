/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-01-22.
 */
'use strict';
const DBFields = require('../../../lib/DBFields');
module.exports = function (sequelize, DataTypes) {
    const dataSourceState = sequelize.define('dataSourceState', {
        /**
         * Created by `DataSource.computeSourceInfo`.
         * Available here for easier debugging as this explicitly contains the graph server info
         */
        info: {
            allowNull: false,
            type: DataTypes.STRING(200),
            unique: true
        },
        /**
         * Created by `DataSource.computeSourceKey`
         */
        key: {
            allowNull: false,
            type: DataTypes.STRING(8),
            unique: true
        },
        /**
         * Last time this data-source was seen online
         */
        lastSeen: {
            allowNull: false,
            type: DataTypes.DATE()
        },
        /**
         * Human-readable name of the data-source (copied from config.name)
         */
        name: {
            allowNull: true,
            type: DataTypes.STRING(200),
            defaultValue: null
        },
        /**
         * Machine-readable name of the last used Graph DAO vendor (copied from config.graphdb.vendor)
         */
        graphVendor: {
            allowNull: true,
            type: DataTypes.STRING(100),
            defaultValue: null
        },
        /**
         * Machine-readable name of the last used Index DAO vendor (copied from config.index.vendor)
         */
        indexVendor: {
            allowNull: true,
            type: DataTypes.STRING(100),
            defaultValue: null
        },
        /**
         * Last time this data-source was fully indexed
         */
        indexedDate: {
            allowNull: true,
            type: DataTypes.DATE(),
            defaultValue: null
        },
        /**
         * Error message if the last indexation failed or got interrupted, `null` otherwise
         */
        indexationError: {
            allowNull: true,
            type: DataTypes.TEXT(),
            defaultValue: null
        },
        /**
         * Set to true when one of the following fields changes:
         * - noIndexNodeProperties
         * - hiddenNodeProperties
         * - noIndexEdgeProperties
         * - hiddenEdgeProperties
         */
        needReindex: {
            allowNull: false,
            type: DataTypes.BOOLEAN(),
            defaultValue: false
        },
        noIndexNodeProperties: DBFields.generateJsonField('noIndexNodeProperties'),
        hiddenNodeProperties: DBFields.generateJsonField('hiddenNodeProperties'),
        noIndexEdgeProperties: DBFields.generateJsonField('noIndexEdgeProperties'),
        hiddenEdgeProperties: DBFields.generateJsonField('hiddenEdgeProperties'),
        defaultCaptions: DBFields.generateJsonField('defaultCaptions'),
        defaultStyles: DBFields.generateJsonField('defaultStyles')
    }, {
        charset: 'utf8'
    });
    return dataSourceState;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGF0YVNvdXJjZVN0YXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3NxbERiL21vZGVscy9EYXRhU291cmNlU3RhdGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUVsRCxNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFDNUMsTUFBTSxlQUFlLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRTtRQUMxRDs7O1dBR0c7UUFDSCxJQUFJLEVBQUU7WUFDSixTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDM0IsTUFBTSxFQUFFLElBQUk7U0FDYjtRQUVEOztXQUVHO1FBQ0gsR0FBRyxFQUFFO1lBQ0gsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLE1BQU0sRUFBRSxJQUFJO1NBQ2I7UUFFRDs7V0FFRztRQUNILFFBQVEsRUFBRTtZQUNSLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFO1NBQ3ZCO1FBRUQ7O1dBRUc7UUFDSCxJQUFJLEVBQUU7WUFDSixTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztZQUMzQixZQUFZLEVBQUUsSUFBSTtTQUNuQjtRQUVEOztXQUVHO1FBQ0gsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDM0IsWUFBWSxFQUFFLElBQUk7U0FDbkI7UUFFRDs7V0FFRztRQUNILFdBQVcsRUFBRTtZQUNYLFNBQVMsRUFBRSxJQUFJO1lBQ2YsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQzNCLFlBQVksRUFBRSxJQUFJO1NBQ25CO1FBRUQ7O1dBRUc7UUFDSCxXQUFXLEVBQUU7WUFDWCxTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFO1lBQ3RCLFlBQVksRUFBRSxJQUFJO1NBQ25CO1FBRUQ7O1dBRUc7UUFDSCxlQUFlLEVBQUU7WUFDZixTQUFTLEVBQUUsSUFBSTtZQUNmLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFO1lBQ3RCLFlBQVksRUFBRSxJQUFJO1NBQ25CO1FBRUQ7Ozs7OztXQU1HO1FBQ0gsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPLEVBQUU7WUFDekIsWUFBWSxFQUFFLEtBQUs7U0FDcEI7UUFFRCxxQkFBcUIsRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsdUJBQXVCLENBQUM7UUFFMUUsb0JBQW9CLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLHNCQUFzQixDQUFDO1FBRXhFLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsQ0FBQztRQUUxRSxvQkFBb0IsRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsc0JBQXNCLENBQUM7UUFFeEUsZUFBZSxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQztRQUU5RCxhQUFhLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQztLQUMzRCxFQUFFO1FBQ0QsT0FBTyxFQUFFLE1BQU07S0FDaEIsQ0FBQyxDQUFDO0lBRUgsT0FBTyxlQUFlLENBQUM7QUFDekIsQ0FBQyxDQUFDIn0=