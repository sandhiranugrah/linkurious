/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../../index');
const Db = LKE.getSqlDb();
const Utils = LKE.getUtils();
// locals
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = ['id', 'name', 'builtin', 'sourceKey'];
const ADMIN_GROUP_NAME = 'admin';
const READ_ONLY_GROUP_NAME = 'read only';
const READ_GROUP_NAME = 'read';
const READ_AND_EDIT_GROUP_NAME = 'read and edit';
const READ_EDIT_AND_DELETE_GROUP_NAME = 'read, edit and delete';
const SOURCE_MANAGER_GROUP_NAME = 'source manager';
module.exports = function (sequelize, DataTypes) {
    const groupModel = sequelize.define('group', {
        name: DBFields.generateStringFieldInUnique('name'),
        builtin: {
            allowNull: false,
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.user.belongsToMany(groupModel, { through: 'userGroups' });
                groupModel.belongsToMany(models.graphQuery, { through: 'queryGroups' });
            },
            initialValues: () => {
                return _ensureBuiltinGroup(ADMIN_GROUP_NAME, '*')
                    .then(adminGroup => {
                    groupModel.ADMIN_GROUP = adminGroup;
                });
            },
            findAllByName: (name, builtin) => {
                // the field containing the name may not contain only the name
                // but also the suffix for removing the unique constraint
                const searchOptions = { where: {
                        $or: [
                            {
                                name: {
                                    $like: name + DBFields.DEUNIQUE_SUFFIX
                                }
                            },
                            {
                                // @backward-compatibility for old group names not updated
                                name: name
                            }
                        ]
                    } };
                if (Utils.hasValue(builtin)) {
                    searchOptions.where.builtin = builtin;
                }
                return groupModel.findAll(searchOptions);
            },
            instanceToPublicAttributes: instanceToPublicAttributes,
            ensureBuiltins: ensureBuiltins
        }
    });
    groupModel.PUBLIC_FIELDS = PUBLIC_FIELDS;
    groupModel.ADMIN_GROUP_NAME = ADMIN_GROUP_NAME;
    groupModel.READ_ONLY_GROUP_NAME = READ_ONLY_GROUP_NAME;
    groupModel.READ_GROUP_NAME = READ_GROUP_NAME;
    groupModel.READ_AND_EDIT_GROUP_NAME = READ_AND_EDIT_GROUP_NAME;
    groupModel.READ_EDIT_AND_DELETE_GROUP_NAME = READ_EDIT_AND_DELETE_GROUP_NAME;
    groupModel.SOURCE_MANAGER_GROUP_NAME = SOURCE_MANAGER_GROUP_NAME;
    return groupModel;
};
/**
 * @param {GroupInstance} groupInstance
 * @param {boolean}       [withDates]   Whether to populate the creation and update dates
 * @returns {PublicGroup}
 */
function instanceToPublicAttributes(groupInstance, withDates) {
    let fields = PUBLIC_FIELDS;
    if (withDates) {
        fields = fields.concat(['createdAt', 'updatedAt']);
    }
    return /**@type {PublicGroup}*/ (_.pick(groupInstance, fields));
}
/**
 * @param {string}                  name
 * @param {string}                  sourceKey
 * @returns {Bluebird<GroupInstance>}
 * @private
 */
function _ensureBuiltinGroup(name, sourceKey) {
    const findCreate = {
        where: {
            sourceKey: sourceKey,
            $or: [
                {
                    name: {
                        $like: name + DBFields.DEUNIQUE_SUFFIX
                    }
                },
                {
                    name: name // for old names not updated
                }
            ]
        },
        defaults: { name: name, builtin: true, sourceKey: sourceKey }
    };
    return Db.models.group.findOrCreate(findCreate).spread(group => {
        return group;
    });
}
/**
 * Check that the built-in groups `read`, `read and edit`, `read, edit and delete` and
 * `source manager` exist for this data-source.
 *
 * @param {string} sourceKey
 * @returns {Bluebird<void>}
 */
function ensureBuiltins(sourceKey) {
    return Promise.map([
        READ_ONLY_GROUP_NAME,
        READ_GROUP_NAME,
        READ_AND_EDIT_GROUP_NAME,
        READ_EDIT_AND_DELETE_GROUP_NAME,
        SOURCE_MANAGER_GROUP_NAME
    ], groupName => {
        return _ensureBuiltinGroup(groupName, sourceKey);
    }, { concurrency: 1 }).return();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3JvdXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL0dyb3VwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7R0FHRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDbkMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFbEQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztBQUM3RCxNQUFNLGdCQUFnQixHQUFHLE9BQU8sQ0FBQztBQUNqQyxNQUFNLG9CQUFvQixHQUFHLFdBQVcsQ0FBQztBQUN6QyxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUM7QUFDL0IsTUFBTSx3QkFBd0IsR0FBRyxlQUFlLENBQUM7QUFDakQsTUFBTSwrQkFBK0IsR0FBRyx1QkFBdUIsQ0FBQztBQUNoRSxNQUFNLHlCQUF5QixHQUFHLGdCQUFnQixDQUFDO0FBRW5ELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUU1QyxNQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUMzQyxJQUFJLEVBQUUsUUFBUSxDQUFDLDJCQUEyQixDQUFDLE1BQU0sQ0FBQztRQUNsRCxPQUFPLEVBQUU7WUFDUCxTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU87WUFDdkIsWUFBWSxFQUFFLEtBQUs7U0FDcEI7UUFDRCxTQUFTLEVBQUU7WUFDVCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDekIsU0FBUyxFQUFFLEtBQUs7U0FDakI7S0FDRixFQUFFO1FBQ0QsT0FBTyxFQUFFLE1BQU07UUFDZixZQUFZLEVBQUU7WUFDWixTQUFTLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO2dCQUMvRCxVQUFVLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBQyxPQUFPLEVBQUUsYUFBYSxFQUFDLENBQUMsQ0FBQztZQUN4RSxDQUFDO1lBQ0QsYUFBYSxFQUFFLEdBQUcsRUFBRTtnQkFDbEIsT0FBTyxtQkFBbUIsQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUM7cUJBQzlDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtvQkFDakIsVUFBVSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7Z0JBQ3RDLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztZQUNELGFBQWEsRUFBRSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRTtnQkFDL0IsOERBQThEO2dCQUM5RCx5REFBeUQ7Z0JBQ3pELE1BQU0sYUFBYSxHQUFHLEVBQUMsS0FBSyxFQUFFO3dCQUM1QixHQUFHLEVBQUU7NEJBQ0g7Z0NBQ0UsSUFBSSxFQUFFO29DQUNKLEtBQUssRUFBRSxJQUFJLEdBQUcsUUFBUSxDQUFDLGVBQWU7aUNBQ3ZDOzZCQUNGOzRCQUNEO2dDQUNFLDBEQUEwRDtnQ0FDMUQsSUFBSSxFQUFFLElBQUk7NkJBQ1g7eUJBQ0Y7cUJBQ0YsRUFBQyxDQUFDO2dCQUNILElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDM0IsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2lCQUN2QztnQkFDRCxPQUFPLFVBQVUsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDM0MsQ0FBQztZQUNELDBCQUEwQixFQUFFLDBCQUEwQjtZQUN0RCxjQUFjLEVBQUUsY0FBYztTQUMvQjtLQUNGLENBQUMsQ0FBQztJQUVILFVBQVUsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBQ3pDLFVBQVUsQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQztJQUMvQyxVQUFVLENBQUMsb0JBQW9CLEdBQUcsb0JBQW9CLENBQUM7SUFDdkQsVUFBVSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUM7SUFDN0MsVUFBVSxDQUFDLHdCQUF3QixHQUFHLHdCQUF3QixDQUFDO0lBQy9ELFVBQVUsQ0FBQywrQkFBK0IsR0FBRywrQkFBK0IsQ0FBQztJQUM3RSxVQUFVLENBQUMseUJBQXlCLEdBQUcseUJBQXlCLENBQUM7SUFFakUsT0FBTyxVQUFVLENBQUM7QUFDcEIsQ0FBQyxDQUFDO0FBRUY7Ozs7R0FJRztBQUNILFNBQVMsMEJBQTBCLENBQUMsYUFBYSxFQUFFLFNBQVM7SUFDMUQsSUFBSSxNQUFNLEdBQUcsYUFBYSxDQUFDO0lBQzNCLElBQUksU0FBUyxFQUFFO1FBQ2IsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztLQUNwRDtJQUVELE9BQU8sd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2xFLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLFNBQVM7SUFDMUMsTUFBTSxVQUFVLEdBQUc7UUFDakIsS0FBSyxFQUFFO1lBQ0wsU0FBUyxFQUFFLFNBQVM7WUFDcEIsR0FBRyxFQUFFO2dCQUNIO29CQUNFLElBQUksRUFBRTt3QkFDSixLQUFLLEVBQUUsSUFBSSxHQUFHLFFBQVEsQ0FBQyxlQUFlO3FCQUN2QztpQkFDRjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLDRCQUE0QjtpQkFDeEM7YUFDRjtTQUNGO1FBQ0QsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUM7S0FDNUQsQ0FBQztJQUNGLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUM3RCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7Ozs7R0FNRztBQUNILFNBQVMsY0FBYyxDQUFDLFNBQVM7SUFDL0IsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQ2pCLG9CQUFvQjtRQUNwQixlQUFlO1FBQ2Ysd0JBQXdCO1FBQ3hCLCtCQUErQjtRQUMvQix5QkFBeUI7S0FDMUIsRUFBRSxTQUFTLENBQUMsRUFBRTtRQUNiLE9BQU8sbUJBQW1CLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ25ELENBQUMsRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ2hDLENBQUMifQ==