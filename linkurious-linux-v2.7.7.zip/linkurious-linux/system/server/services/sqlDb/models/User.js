/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../../index');
const Db = LKE.getSqlDb();
// locals
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = ['id', 'username', 'email', 'source', 'preferences'];
const UNIQUE_USER_ID = 1;
const UNIQUE_USER_DEFAULTS = {
    id: UNIQUE_USER_ID,
    username: 'Unique user',
    email: 'user@linkurio.us',
    source: 'local',
    password: '-',
    preferences: {}
};
const GUEST_USER_EMAIL = 'guest@linkurio.us';
const GUEST_USER_DEFAULTS = {
    username: 'Guest',
    email: GUEST_USER_EMAIL,
    source: 'local',
    password: '-',
    preferences: {}
};
module.exports = function (sequelize, DataTypes) {
    const userModel = sequelize.define('user', {
        username: {
            type: DataTypes.STRING,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false,
            validate: {
                isEmail: true
            }
        },
        salt: {
            type: DataTypes.STRING(24),
            allowNull: false
        },
        password: {
            type: DataTypes.STRING(512),
            allowNull: false,
            set: function (password) {
                DBFields.storePassword(this, password);
            }
        },
        source: {
            type: DataTypes.STRING(20),
            allowNull: false,
            get: function () {
                const valueSource = this.getDataValue('source');
                const valueLdap = this.getDataValue('ldap');
                // if the ldap field is set to true (only possible in user created in or before v1.3.6)
                // overrides the source value
                return valueLdap ? 'ldap' : valueSource;
            }
        },
        preferences: DBFields.generateJsonField('preferences', {}),
        // @backward-compatibility ldap field was deprecated by the source field
        ldap: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false // null is not allowed, so we leave a default value
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.group.belongsToMany(userModel, { through: 'userGroups' });
            },
            initialValues: () => {
                // Persist the unique user
                return userModel.findOrCreate({
                    // we check also for the OLDER unique user id (-1)
                    where: { id: [UNIQUE_USER_ID, -1] },
                    include: [{ model: Db.models.group, include: [Db.models.accessRight] }],
                    defaults: UNIQUE_USER_DEFAULTS
                }).spread((uniqueUser, created) => {
                    userModel.UNIQUE_USER_ID = uniqueUser.id;
                    // findOrCreate doesn't set groups to empty array on create but it will set it on find
                    if (!created && uniqueUser.groups.length > 0) { // in LKE 1 the unique user wasn't assigned to any group
                        return;
                    }
                    return uniqueUser.addGroup(Db.models.group.ADMIN_GROUP).return();
                }).then(() => {
                    // Persist the guest user
                    return userModel.findOrCreate({
                        where: { email: GUEST_USER_EMAIL },
                        defaults: GUEST_USER_DEFAULTS
                    });
                }).spread(guestUser => {
                    userModel.GUEST_USER_ID = guestUser.id;
                });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        },
        instanceMethods: {
            /**
             * @param {string} password
             * @returns {boolean}
             */
            comparePassword: function (password) {
                return DBFields.checkPassword(this, password);
            }
        }
    });
    userModel.PUBLIC_FIELDS = PUBLIC_FIELDS;
    return userModel;
};
/**
 * @param {UserInstance} userInstance
 * @param {boolean}      [withDates]  Whether to populate the creation and update dates
 * @returns {Partial<PublicUser>} only missing actions
 */
function instanceToPublicAttributes(userInstance, withDates) {
    let fields = PUBLIC_FIELDS;
    if (withDates) {
        fields = fields.concat(['createdAt', 'updatedAt']);
    }
    const publicUser = /**@type {Partial<PublicUser>}*/ (_.pick(userInstance, fields));
    // @backward-compatibility we remove these old preferences lazily
    publicUser.preferences = _.omit(publicUser.preferences, [
        'uiDesign',
        'uiCaptionConfig',
        'uiTooltipConfig',
        'uiWorkspaceSearch',
        'uiExport',
        'uiLayout',
        'uiEdgeSearch',
        'uiShortestPath',
        'uiCollapseNode',
        'uiScreenshot',
        'uiVisualizationPanel',
        'uiNodeList',
        'uiEdgeList',
        'uiTooltip',
        'uiSimpleLayout'
    ]);
    return publicUser;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9zcWxEYi9tb2RlbHMvVXNlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFNUIsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFMUIsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBRWxELE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQzNFLE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQztBQUN6QixNQUFNLG9CQUFvQixHQUFHO0lBQzNCLEVBQUUsRUFBRSxjQUFjO0lBQ2xCLFFBQVEsRUFBRSxhQUFhO0lBQ3ZCLEtBQUssRUFBRSxrQkFBa0I7SUFDekIsTUFBTSxFQUFFLE9BQU87SUFDZixRQUFRLEVBQUUsR0FBRztJQUNiLFdBQVcsRUFBRSxFQUFFO0NBQ2hCLENBQUM7QUFFRixNQUFNLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDO0FBQzdDLE1BQU0sbUJBQW1CLEdBQUc7SUFDMUIsUUFBUSxFQUFFLE9BQU87SUFDakIsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QixNQUFNLEVBQUUsT0FBTztJQUNmLFFBQVEsRUFBRSxHQUFHO0lBQ2IsV0FBVyxFQUFFLEVBQUU7Q0FDaEIsQ0FBQztBQUVGLE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUU1QyxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtRQUN6QyxRQUFRLEVBQUU7WUFDUixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07WUFDdEIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFDRCxLQUFLLEVBQUU7WUFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU07WUFDdEIsTUFBTSxFQUFFLElBQUk7WUFDWixTQUFTLEVBQUUsS0FBSztZQUNoQixRQUFRLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLElBQUk7YUFDZDtTQUNGO1FBQ0QsSUFBSSxFQUFFO1lBQ0osSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQzFCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBQ0QsUUFBUSxFQUFFO1lBQ1IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQzNCLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLEdBQUcsRUFBRSxVQUFTLFFBQVE7Z0JBQ3BCLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ3pDLENBQUM7U0FDRjtRQUNELE1BQU0sRUFBRTtZQUNOLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUMxQixTQUFTLEVBQUUsS0FBSztZQUNoQixHQUFHLEVBQUU7Z0JBQ0gsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDaEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDNUMsdUZBQXVGO2dCQUN2Riw2QkFBNkI7Z0JBQzdCLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztZQUMxQyxDQUFDO1NBQ0Y7UUFDRCxXQUFXLEVBQUUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUM7UUFFMUQsd0VBQXdFO1FBQ3hFLElBQUksRUFBRTtZQUNKLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztZQUN2QixTQUFTLEVBQUUsS0FBSztZQUNoQixZQUFZLEVBQUUsS0FBSyxDQUFDLG1EQUFtRDtTQUN4RTtLQUNGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLEVBQUMsT0FBTyxFQUFFLFlBQVksRUFBQyxDQUFDLENBQUM7WUFDakUsQ0FBQztZQUNELGFBQWEsRUFBRSxHQUFHLEVBQUU7Z0JBQ2xCLDBCQUEwQjtnQkFDMUIsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDO29CQUM1QixrREFBa0Q7b0JBQ2xELEtBQUssRUFBRSxFQUFDLEVBQUUsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDO29CQUNqQyxPQUFPLEVBQUUsQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFDLENBQUM7b0JBQ3JFLFFBQVEsRUFBRSxvQkFBb0I7aUJBQy9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLEVBQUU7b0JBQ2hDLFNBQVMsQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQztvQkFFekMsc0ZBQXNGO29CQUN0RixJQUFJLENBQUMsT0FBTyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxFQUFFLHdEQUF3RDt3QkFDdEcsT0FBTztxQkFDUjtvQkFDRCxPQUFPLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ25FLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7b0JBQ1gseUJBQXlCO29CQUN6QixPQUFPLFNBQVMsQ0FBQyxZQUFZLENBQUM7d0JBQzVCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxnQkFBZ0IsRUFBQzt3QkFDaEMsUUFBUSxFQUFFLG1CQUFtQjtxQkFDOUIsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDcEIsU0FBUyxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUN6QyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFDRCwwQkFBMEIsRUFBRSwwQkFBMEI7U0FDdkQ7UUFFRCxlQUFlLEVBQUU7WUFDZjs7O2VBR0c7WUFDSCxlQUFlLEVBQUUsVUFBUyxRQUFRO2dCQUNoQyxPQUFPLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2hELENBQUM7U0FDRjtLQUNGLENBQUMsQ0FBQztJQUVILFNBQVMsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBRXhDLE9BQU8sU0FBUyxDQUFDO0FBQ25CLENBQUMsQ0FBQztBQUVGOzs7O0dBSUc7QUFDSCxTQUFTLDBCQUEwQixDQUFDLFlBQVksRUFBRSxTQUFTO0lBQ3pELElBQUksTUFBTSxHQUFHLGFBQWEsQ0FBQztJQUMzQixJQUFJLFNBQVMsRUFBRTtRQUNiLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7S0FDcEQ7SUFFRCxNQUFNLFVBQVUsR0FBRyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFFbkYsaUVBQWlFO0lBQ2pFLFVBQVUsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FDN0IsVUFBVSxDQUFDLFdBQVcsRUFBRTtRQUN0QixVQUFVO1FBQ1YsaUJBQWlCO1FBQ2pCLGlCQUFpQjtRQUNqQixtQkFBbUI7UUFDbkIsVUFBVTtRQUNWLFVBQVU7UUFDVixjQUFjO1FBQ2QsZ0JBQWdCO1FBQ2hCLGdCQUFnQjtRQUNoQixjQUFjO1FBQ2Qsc0JBQXNCO1FBQ3RCLFlBQVk7UUFDWixZQUFZO1FBQ1osV0FBVztRQUNYLGdCQUFnQjtLQUNqQixDQUNGLENBQUM7SUFFRixPQUFPLFVBQVUsQ0FBQztBQUNwQixDQUFDIn0=