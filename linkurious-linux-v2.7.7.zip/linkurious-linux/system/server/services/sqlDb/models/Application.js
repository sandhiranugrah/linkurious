/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-02.
 */
'use strict';
// external libs
const _ = require('lodash');
// locals
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = [
    'id', 'enabled', 'apiKey', 'name', 'rights', 'createdAt', 'updatedAt'
];
const APP_ACTIONS = [
    // visualization actions
    'visualization.read',
    'visualization.create',
    'visualization.edit',
    'visualization.delete',
    'visualization.list',
    // visualization folder actions
    'visualizationFolder.create',
    'visualizationFolder.edit',
    'visualizationFolder.delete',
    // visualization share actions
    'visualizationShare.read',
    'visualizationShare.create',
    'visualizationShare.delete',
    // search action
    'sandbox',
    // widget actions
    'widget.read',
    'widget.create',
    'widget.edit',
    'widget.delete',
    // graph item actions
    'graphItem.read',
    'graphItem.create',
    'graphItem.edit',
    'graphItem.delete',
    // search action
    'graphItem.search',
    // saved graph query actions
    'savedGraphQuery.read',
    'savedGraphQuery.create',
    'savedGraphQuery.edit',
    'savedGraphQuery.delete',
    // graph query actions
    'graph.rawRead',
    'graph.rawWrite',
    'graph.runQuery',
    // alert actions
    'alert.read',
    'alert.doAction',
    'admin.alerts',
    // schema action
    'schema',
    // reindex action
    'admin.index'
];
module.exports = function (sequelize, DataTypes) {
    const application = sequelize.define('application', {
        // application name
        name: {
            type: DataTypes.STRING(),
            allowNull: false
        },
        // whether this app is allowed to authenticate
        enabled: {
            type: DataTypes.BOOLEAN(),
            allowNull: false
        },
        // access token to authenticate the application
        apiKey: {
            type: DataTypes.STRING(40),
            allowNull: false
        },
        // array of allowed APP_ACTIONS
        rights: DBFields.generateJsonField('rights', [], false, sequelize.options.dialect)
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                application.belongsToMany(models.group, { through: 'applicationGroups' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    application.APP_ACTIONS = APP_ACTIONS;
    application.PUBLIC_FIELDS = PUBLIC_FIELDS;
    return application;
};
/**
 * @param {ApplicationInstance} applicationInstance
 * @returns {PublicApplication}
 */
function instanceToPublicAttributes(applicationInstance) {
    return /**@type {PublicApplication}*/ (_.pick(applicationInstance, PUBLIC_FIELDS));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXBwbGljYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL0FwcGxpY2F0aW9uLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixTQUFTO0FBQ1QsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFbEQsTUFBTSxhQUFhLEdBQUc7SUFDcEIsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsV0FBVztDQUN0RSxDQUFDO0FBRUYsTUFBTSxXQUFXLEdBQUc7SUFDbEIsd0JBQXdCO0lBQ3hCLG9CQUFvQjtJQUNwQixzQkFBc0I7SUFDdEIsb0JBQW9CO0lBQ3BCLHNCQUFzQjtJQUN0QixvQkFBb0I7SUFFcEIsK0JBQStCO0lBQy9CLDRCQUE0QjtJQUM1QiwwQkFBMEI7SUFDMUIsNEJBQTRCO0lBRTVCLDhCQUE4QjtJQUM5Qix5QkFBeUI7SUFDekIsMkJBQTJCO0lBQzNCLDJCQUEyQjtJQUUzQixnQkFBZ0I7SUFDaEIsU0FBUztJQUVULGlCQUFpQjtJQUNqQixhQUFhO0lBQ2IsZUFBZTtJQUNmLGFBQWE7SUFDYixlQUFlO0lBRWYscUJBQXFCO0lBQ3JCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUVsQixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBRWxCLDRCQUE0QjtJQUM1QixzQkFBc0I7SUFDdEIsd0JBQXdCO0lBQ3hCLHNCQUFzQjtJQUN0Qix3QkFBd0I7SUFFeEIsc0JBQXNCO0lBQ3RCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBRWhCLGdCQUFnQjtJQUNoQixZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGNBQWM7SUFFZCxnQkFBZ0I7SUFDaEIsUUFBUTtJQUVSLGlCQUFpQjtJQUNqQixhQUFhO0NBQ2QsQ0FBQztBQUVGLE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxTQUFTLEVBQUUsU0FBUztJQUU1QyxNQUFNLFdBQVcsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRTtRQUNsRCxtQkFBbUI7UUFDbkIsSUFBSSxFQUFFO1lBQ0osSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDeEIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFDRCw4Q0FBOEM7UUFDOUMsT0FBTyxFQUFFO1lBQ1AsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPLEVBQUU7WUFDekIsU0FBUyxFQUFFLEtBQUs7U0FDakI7UUFDRCwrQ0FBK0M7UUFDL0MsTUFBTSxFQUFFO1lBQ04sSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQzFCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBQ0QsK0JBQStCO1FBQy9CLE1BQU0sRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7S0FDbkYsRUFBRTtRQUNELE9BQU8sRUFBRSxNQUFNO1FBQ2YsWUFBWSxFQUFFO1lBQ1osU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNsQixXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBQyxPQUFPLEVBQUUsbUJBQW1CLEVBQUMsQ0FBQyxDQUFDO1lBQzFFLENBQUM7WUFDRCwwQkFBMEIsRUFBRSwwQkFBMEI7U0FDdkQ7S0FDRixDQUFDLENBQUM7SUFFSCxXQUFXLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztJQUN0QyxXQUFXLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztJQUUxQyxPQUFPLFdBQVcsQ0FBQztBQUNyQixDQUFDLENBQUM7QUFFRjs7O0dBR0c7QUFDSCxTQUFTLDBCQUEwQixDQUFDLG1CQUFtQjtJQUNyRCxPQUFPLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDO0FBQ3JGLENBQUMifQ==