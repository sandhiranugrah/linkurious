/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
module.exports = function (sequelize, DataTypes) {
    const edgeProperty = sequelize.define('edgeProperty', {
        key: {
            type: DataTypes.STRING,
            allowNull: false
        },
        count: {
            type: DataTypes.INTEGER,
            defaultValue: 0
        },
        sourceKey: {
            type: DataTypes.STRING(8),
            allowNull: false
        }
    }, {
        charset: 'utf8',
        timestamps: false,
        classMethods: {
            associate: models => {
                // A property is uniquely linked to an edge type.
                // Different properties can have the same names but belong to different edge types
                models.edgeType.hasMany(edgeProperty, { foreignKey: 'typeId' });
            }
        }
    });
    return edgeProperty;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRWRnZVByb3BlcnR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3NxbERiL21vZGVscy9ncmFwaFNjaGVtYS9FZGdlUHJvcGVydHkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsU0FBUyxFQUFFLFNBQVM7SUFDNUMsTUFBTSxZQUFZLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUU7UUFDcEQsR0FBRyxFQUFFO1lBQ0gsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNO1lBQ3RCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBQ0QsS0FBSyxFQUFFO1lBQ0wsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1lBQ3ZCLFlBQVksRUFBRSxDQUFDO1NBQ2hCO1FBQ0QsU0FBUyxFQUFFO1lBQ1QsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO0tBQ0YsRUFBRTtRQUNELE9BQU8sRUFBRSxNQUFNO1FBQ2YsVUFBVSxFQUFFLEtBQUs7UUFDakIsWUFBWSxFQUFFO1lBQ1osU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNsQixpREFBaUQ7Z0JBQ2pELGtGQUFrRjtnQkFDbEYsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7WUFDaEUsQ0FBQztTQUNGO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsT0FBTyxZQUFZLENBQUM7QUFDdEIsQ0FBQyxDQUFDIn0=