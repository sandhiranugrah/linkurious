/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-23.
 */
'use strict';
// externals
const _ = require('lodash');
// services
const LKE = require('../../../services');
const Utils = LKE.getUtils();
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = [
    'title', 'key', 'content', 'url', 'userId', 'visualizationId', 'updatedAt', 'createdAt'
];
module.exports = function (sequelize, DataTypes) {
    const widget = sequelize.define('widget', {
        title: {
            type: DataTypes.STRING(),
            allowNull: false
        },
        key: {
            type: DataTypes.STRING(8),
            allowNull: false
        },
        salt: {
            type: DataTypes.STRING(24),
            allowNull: true
        },
        password: {
            type: DataTypes.STRING(512),
            allowNull: true,
            set: function (password) {
                DBFields.storePassword(this, password);
            }
        },
        content: DBFields.generateJsonField('content', {}, true, sequelize.options.dialect),
        version: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: function (models) {
                models.visualization.hasOne(widget, {
                    foreignKey: 'visualizationId',
                    onDelete: 'cascade'
                });
                widget.belongsTo(models.user, { foreignKey: 'userId' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        },
        instanceMethods: {
            /**
             * @param {string} password
             * @returns {boolean}
             */
            checkPassword: function (password) {
                return DBFields.checkPassword(this, password);
            }
        }
    });
    return widget;
};
/**
 * @param {WidgetInstance} widget
 * @returns {PublicWidget}
 */
function instanceToPublicAttributes(widget) {
    /**@type {object}**/
    const publicWidget = _.pick(widget.get(), PUBLIC_FIELDS);
    publicWidget.password = Utils.hasValue(widget.password);
    publicWidget.url = LKE.getBaseURL('/widget/' + publicWidget.key);
    return /**@type {PublicWidget}**/ (publicWidget);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV2lkZ2V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3NxbERiL21vZGVscy9XaWRnZXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixZQUFZO0FBQ1osTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUN6QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFbEQsTUFBTSxhQUFhLEdBQUc7SUFDcEIsT0FBTyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsV0FBVztDQUN4RixDQUFDO0FBRUYsTUFBTSxDQUFDLE9BQU8sR0FBRyxVQUFTLFNBQVMsRUFBRSxTQUFTO0lBRTVDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO1FBRXhDLEtBQUssRUFBRTtZQUNMLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxFQUFFO1lBQ3hCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBRUQsR0FBRyxFQUFFO1lBQ0gsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLFNBQVMsRUFBRSxLQUFLO1NBQ2pCO1FBRUQsSUFBSSxFQUFFO1lBQ0osSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQzFCLFNBQVMsRUFBRSxJQUFJO1NBQ2hCO1FBQ0QsUUFBUSxFQUFFO1lBQ1IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQzNCLFNBQVMsRUFBRSxJQUFJO1lBQ2YsR0FBRyxFQUFFLFVBQVMsUUFBUTtnQkFDcEIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDekMsQ0FBQztTQUNGO1FBRUQsT0FBTyxFQUFFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztRQUVuRixPQUFPLEVBQUU7WUFDUCxJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU87WUFDdkIsU0FBUyxFQUFFLEtBQUs7U0FDakI7S0FFRixFQUFFO1FBQ0QsT0FBTyxFQUFFLE1BQU07UUFDZixZQUFZLEVBQUU7WUFDWixTQUFTLEVBQUUsVUFBUyxNQUFNO2dCQUN4QixNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7b0JBQ2xDLFVBQVUsRUFBRSxpQkFBaUI7b0JBQzdCLFFBQVEsRUFBRSxTQUFTO2lCQUNwQixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7WUFDeEQsQ0FBQztZQUNELDBCQUEwQixFQUFFLDBCQUEwQjtTQUN2RDtRQUVELGVBQWUsRUFBRTtZQUNmOzs7ZUFHRztZQUNILGFBQWEsRUFBRSxVQUFTLFFBQVE7Z0JBQzlCLE9BQU8sUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDaEQsQ0FBQztTQUNGO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQyxDQUFDO0FBRUY7OztHQUdHO0FBQ0gsU0FBUywwQkFBMEIsQ0FBQyxNQUFNO0lBQ3hDLG9CQUFvQjtJQUNwQixNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUN6RCxZQUFZLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3hELFlBQVksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pFLE9BQU8sMEJBQTBCLENBQUEsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNsRCxDQUFDIn0=