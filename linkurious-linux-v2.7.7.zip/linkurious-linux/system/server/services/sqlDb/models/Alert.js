/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-11.
 */
'use strict';
// external libs
const _ = require('lodash');
// locals
const DBFields = require('../../../lib/DBFields');
const PUBLIC_FIELDS = ['id', 'title', 'sourceKey', 'query',
    'dialect', 'enabled', 'columns', 'cron', 'matchTTL',
    'lastRun', 'lastRunProblem', 'maxMatches',
    'userId', 'createdAt', 'updatedAt'
];
/**
 * Alert
 *
 * @property {number}   id                     Id of the alert (added by sequelize)
 * @property {string}   title                  Title of the alert
 * @property {string}   sourceKey              Key of the data-source containing the nodes and edges
 * @property {string}   query                  The query that will periodically run
 * @property {string}   dialect                The dialect of the query
 * @property {boolean}  enabled                Boolean that indicates if the query will run periodically or not
 * @property {object[]} [columns]              Columns among the returned values of the query to save in a match as scalar values
 * @property {string}   columns.type           Type of the column ("number", "string")
 * @property {string}   columns.columnName     Name of the column
 * @property {string}   cron                   CRON expression representing the frequency with which the query runs
 * @property {number}   matchTTL               Time (in days) after which the matches of this alert are going to be deleted
 * @property {number}   userId                 ID of the user that created the alert
 * @property {string}   lastRun                Last time the query was executed
 * @property {{error?:  string, partial?: boolean} | undefined} lastRunProblem
 * @property {string}   lastRunProblem.error   Error that identifies the last run problem
 * @property {boolean}  lastRunProblem.partial Boolean that represents if the last run was at least partially executed
 * @property {number}   maxMatches             Maximum number of matches after which new matches are discarded
 * @property {string}   createdAt              Creation date (added by sequelize)
 * @property {string}   updatedAt              Update date (added by sequelize)
 * @property {string}   nextRun                Date of the future scheduled run (added by the alert service)
 */
module.exports = function (sequelize, DataTypes) {
    const alert = sequelize.define('alert', {
        title: {
            allowNull: false,
            type: DataTypes.STRING(200)
        },
        sourceKey: {
            allowNull: false,
            type: DataTypes.STRING(8)
        },
        query: {
            allowNull: false,
            type: DataTypes.TEXT
        },
        dialect: {
            allowNull: false,
            type: DataTypes.STRING(20)
        },
        enabled: {
            allowNull: false,
            type: DataTypes.BOOLEAN
        },
        columns: DBFields.generateJsonField('columns'),
        cron: {
            allowNull: false,
            type: DataTypes.STRING(50)
        },
        // time to live of a match (in days)
        matchTTL: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        // @backward-compatibility scoreColumn field was deprecated by allowing more columns
        scoreColumn: {
            allowNull: true,
            type: DataTypes.STRING(200)
        },
        // @backward-compatibility sortDirection field was deprecated by allowing more columns
        sortDirection: {
            allowNull: false,
            type: DataTypes.STRING(20),
            defaultValue: '' // null is not allowed, so we leave a default value
        },
        lastRun: DBFields.generateIntegerDateField('lastRun', true),
        lastRunProblem: DBFields.generateJsonField('lastRunProblem'),
        maxMatches: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        // @backward-compatibility maxRuntime field was deprecated, global alerts.maxRuntimeLimit is used
        maxRuntime: {
            allowNull: false,
            type: DataTypes.INTEGER,
            defaultValue: 0 // null is not allowed, so we leave a default value
        }
    }, {
        charset: 'utf8',
        classMethods: {
            associate: models => {
                models.alert.hasMany(models.match, { foreignKey: 'alertId', onDelete: 'cascade' });
                models.alert.belongsTo(models.user, { foreignKey: 'userId' });
            },
            instanceToPublicAttributes: instanceToPublicAttributes
        }
    });
    return alert;
};
/**
 * @param {AlertInstance} alertInstance
 * @returns {PublicAlert}
 */
function instanceToPublicAttributes(alertInstance) {
    return /**@type {PublicAlert}*/ (_.pick(alertInstance, PUBLIC_FIELDS));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWxlcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvbW9kZWxzL0FsZXJ0LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUU1QixTQUFTO0FBQ1QsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFFbEQsTUFBTSxhQUFhLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxPQUFPO0lBQ3hELFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxVQUFVO0lBQ25ELFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZO0lBQ3pDLFFBQVEsRUFBRSxXQUFXLEVBQUUsV0FBVztDQUNuQyxDQUFDO0FBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBdUJHO0FBRUgsTUFBTSxDQUFDLE9BQU8sR0FBRyxVQUFTLFNBQVMsRUFBRSxTQUFTO0lBRTVDLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3RDLEtBQUssRUFBRTtZQUNMLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUNELFNBQVMsRUFBRTtZQUNULFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUMxQjtRQUNELEtBQUssRUFBRTtZQUNMLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTtTQUNyQjtRQUNELE9BQU8sRUFBRTtZQUNQLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztTQUMzQjtRQUNELE9BQU8sRUFBRTtZQUNQLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztTQUN4QjtRQUNELE9BQU8sRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDO1FBQzlDLElBQUksRUFBRTtZQUNKLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztTQUMzQjtRQUNELG9DQUFvQztRQUNwQyxRQUFRLEVBQUU7WUFDUixTQUFTLEVBQUUsS0FBSztZQUNoQixJQUFJLEVBQUUsU0FBUyxDQUFDLE9BQU87U0FDeEI7UUFDRCxvRkFBb0Y7UUFDcEYsV0FBVyxFQUFFO1lBQ1gsU0FBUyxFQUFFLElBQUk7WUFDZixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7U0FDNUI7UUFDRCxzRkFBc0Y7UUFDdEYsYUFBYSxFQUFFO1lBQ2IsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQzFCLFlBQVksRUFBRSxFQUFFLENBQUMsbURBQW1EO1NBQ3JFO1FBQ0QsT0FBTyxFQUFFLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO1FBQzNELGNBQWMsRUFBRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUM7UUFDNUQsVUFBVSxFQUFFO1lBQ1YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxPQUFPO1NBQ3hCO1FBQ0QsaUdBQWlHO1FBQ2pHLFVBQVUsRUFBRTtZQUNWLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztZQUN2QixZQUFZLEVBQUUsQ0FBQyxDQUFDLG1EQUFtRDtTQUNwRTtLQUNGLEVBQUU7UUFDRCxPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRTtZQUNaLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDbEIsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUM7Z0JBQ2pGLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBQyxVQUFVLEVBQUUsUUFBUSxFQUFDLENBQUMsQ0FBQztZQUM5RCxDQUFDO1lBQ0QsMEJBQTBCLEVBQUUsMEJBQTBCO1NBQ3ZEO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUM7QUFFRjs7O0dBR0c7QUFDSCxTQUFTLDBCQUEwQixDQUFDLGFBQWE7SUFDL0MsT0FBTyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDekUsQ0FBQyJ9