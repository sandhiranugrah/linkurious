/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-08.
 */
'use strict';
// internal libs
const path = require('path');
// external libs
const fs = require('fs-extra');
const Promise = require('bluebird');
const _ = require('lodash');
const Sequelize = require('sequelize');
// our libs
const SequelizeUpdater = require('./../../../lib/SequelizeUpdater');
// services
const LKE = require('../index');
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
class SqlDbService {
    /**
     * @param {object} dbConfig SQL configuration
     * @param {string} dbConfig.name
     * @param {string} dbConfig.username
     * @param {string} dbConfig.password
     * @param {number} [dbConfig.connectionRetries=5]
     * @param {object} dbConfig.options
     * @param {string} dbConfig.options.dialect ("sqlite", "mariadb", "mysql")
     */
    constructor(dbConfig) {
        /**
         * @type {SqlDbModels}
         */
        this.models = {};
        this.connected = false;
        /** @type {Sequelize} */
        this.sequelize = undefined;
        this.dbName = dbConfig.name;
        this.dbUsername = dbConfig.username;
        this.dbPassword = dbConfig.password;
        this.connectionRetries = dbConfig.connectionRetries || 5;
        this.dbOptions = _.omitBy(dbConfig.options, optionValue => optionValue === null);
        // change to Log.info to log all SQL queries done by Sequelize
        this.dbOptions.logging = Log.debug;
    }
    /**
     * Adds all the containing .js files fo the directory to the Database model. It explores all the
     * subdirectories except fo the lib directory and skips index.js files.
     *
     * @param {string} directory containing the different models
     */
    _addModelsToDb(directory) {
        fs.readdirSync(directory).filter(file => {
            return (file.indexOf('.') !== 0) && file !== 'lib';
        }).forEach(file => {
            const filePath = path.resolve(directory, file);
            if (fs.statSync(filePath).isDirectory()) {
                this._addModelsToDb(filePath);
            }
            else {
                Log.debug('SQL : adding model "' + file + '"');
                const model = this.sequelize.import(filePath);
                this.models[model.name] = model;
            }
        });
    }
    /**
     * Synchronise the database state
     *
     * @returns {Promise}
     */
    sync() {
        return this.sequelize.sync();
    }
    /**
     * Close the database connection
     */
    close() {
        if (!this.sequelize) {
            return;
        }
        this.sequelize.close();
        // currently sequelize.close() does nothing for sqlite, see https://github.com/sequelize/sequelize/issues/6798
        if (this.dbOptions.dialect === 'sqlite' &&
            this.sequelize.connectionManager.connections &&
            this.sequelize.connectionManager.connections.default) {
            this.sequelize.connectionManager.connections.default.close();
        }
    }
    /**
     * Destroy all data in the database
     *
     * @returns {Bluebird<void>}
     */
    destroyAll() {
        return Promise.each(_.values(this.models), model => {
            return model.destroy({ where: {} });
        }).then(() => this.sync());
    }
    /**
     * Authenticate, Add models and Sync
     * Will retry 5 times with 1000ms delay if connection is refused for network reasons.
     *
     * @returns {Bluebird<Sequelize>}
     */
    _getAuthenticatedSequelize() {
        return Utils.retryPromise('Connecting to SQL DB', () => {
            const sequelize = new Sequelize(this.dbName, this.dbUsername, this.dbPassword, this.dbOptions);
            return sequelize.authenticate().then(() => sequelize);
        }, {
            delay: 1000,
            retries: this.connectionRetries,
            giveUp: e => (
            // SQLite can't "timeout"
            (this.dbOptions.dialect === 'sqlite') ||
                // credential errors should not be retried
                (e && e.name && e.name === 'SequelizeAccessDeniedError'))
        });
    }
    /**
     * @returns {Bluebird<void>}
     */
    connect() {
        // if the DB is already connected, resolve right away
        if (this.connected === true) {
            return Promise.resolve();
        }
        // else: authenticate, add models and sync state
        const isSqlite = this.dbOptions.dialect === 'sqlite';
        if (isSqlite) {
            // database file: build its absolute path and make sure it exists (creates the needed dirs)
            this.dbOptions.storage = LKE.dataFile(this.dbOptions.storage);
            fs.ensureFileSync(this.dbOptions.storage);
        }
        // 1) connect to DB
        return this._getAuthenticatedSequelize().then(sequelize => {
            this.sequelize = sequelize;
            LKE.getStateMachine().set('SqlDB', 'up');
        }).catch(error => {
            return Errors.technical('critical', 'SQL connection error: ' + error, true);
        }).then(() => {
            // 2) migrate the schema if necessary
            const schemaUpdater = new SequelizeUpdater(this.dbName, // same options as sqlDb.sequelize
            this.dbUsername, this.dbPassword, this.dbOptions, 'lk_version');
            return schemaUpdater.run(fs.readJsonSync(path.resolve(__dirname, 'databaseUpdates.json')), LKE.getVersion());
        }).then(appliedUpdates => {
            if (appliedUpdates.length > 0) {
                Log.info(`Applied ${appliedUpdates.length} database update` +
                    `${appliedUpdates.length > 1 ? 's' : ''} to version ${LKE.getVersion()}.`);
            }
            // 3) load models and associations
            this._addModelsToDb(path.resolve(__dirname, 'models'));
            this._addModelsToDb(path.resolve(__dirname, '../../models/sql'));
            _.forEach(this.models, model => {
                if ('associate' in model) {
                    model.associate(this.models);
                }
            });
            // 4) sync models (create tables etc.)
            return this.sequelize.sync().then(() => {
                // 4.1) create initial values for each model
                return Promise.each(_.values(this.models), model => {
                    if (!model.initialValues) {
                        return;
                    }
                    return model.initialValues();
                });
            });
        }).then(() => {
            // 5) enable write-ahead-log for sqlite
            if (!isSqlite) {
                return;
            }
            // SQLITE: turn on Write-Ahead-Log optimization (https://www.sqlite.org/wal.html)
            const pragmaList = ['busy_timeout = 5000', 'journal_mode = WAL', 'synchronous = NORMAL'];
            return Promise.each(pragmaList, pragma => this.sequelize.query('PRAGMA ' + pragma));
        }).catch(err => {
            LKE.getStateMachine().set('SqlDB', 'sync_error');
            Log.error('SQL Sync error', err);
            return Errors.technical('critical', 'SQL synchronisation failure' + err, true);
        }).then(() => {
            // 6) set connected+synced state
            this.connected = true;
            LKE.getStateMachine().set('SqlDB', 'synced');
        }).catch(error => {
            LKE.getStateMachine().set('SqlDB', 'down');
            return Promise.reject(error);
        });
    }
}
module.exports = new SqlDbService(Config.get('db'));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3FsRGIvaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBRTdCLGdCQUFnQjtBQUNoQixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7QUFFdkMsV0FBVztBQUNYLE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7QUFFcEUsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sWUFBWTtJQUVoQjs7Ozs7Ozs7T0FRRztJQUNILFlBQVksUUFBUTtRQUVsQjs7V0FFRztRQUNILElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBRWpCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLHdCQUF3QjtRQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUUzQixJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQztRQUNwQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLFdBQVcsS0FBSyxJQUFJLENBQUMsQ0FBQztRQUNqRiw4REFBOEQ7UUFDOUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsU0FBUztRQUN0QixFQUFFLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxJQUFJLEtBQUssS0FBSyxDQUFDO1FBQ3JELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUUvQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3ZDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDL0I7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQy9DLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM5QyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDakM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsSUFBSTtRQUNGLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLO1FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFBRSxPQUFPO1NBQUU7UUFFaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUV2Qiw4R0FBOEc7UUFDOUcsSUFDRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxRQUFRO1lBQ25DLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsV0FBVztZQUM1QyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQ3BEO1lBQ0EsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQzlEO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxVQUFVO1FBQ1IsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ2pELE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCwwQkFBMEI7UUFDeEIsT0FBTyxLQUFLLENBQUMsWUFBWSxDQUN2QixzQkFBc0IsRUFDdEIsR0FBRyxFQUFFO1lBQ0gsTUFBTSxTQUFTLEdBQUcsSUFBSSxTQUFTLENBQzdCLElBQUksQ0FBQyxNQUFNLEVBQ1gsSUFBSSxDQUFDLFVBQVUsRUFDZixJQUFJLENBQUMsVUFBVSxFQUNmLElBQUksQ0FBQyxTQUFTLENBQ2YsQ0FBQztZQUNGLE9BQU8sU0FBUyxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN4RCxDQUFDLEVBQ0Q7WUFDRSxLQUFLLEVBQUUsSUFBSTtZQUNYLE9BQU8sRUFBRSxJQUFJLENBQUMsaUJBQWlCO1lBQy9CLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ1gseUJBQXlCO1lBQ3pCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUssUUFBUSxDQUFDO2dCQUVyQywwQ0FBMEM7Z0JBQzFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyw0QkFBNEIsQ0FBQyxDQUN6RDtTQUNGLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILE9BQU87UUFDTCxxREFBcUQ7UUFDckQsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksRUFBRTtZQUMzQixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELGdEQUFnRDtRQUNoRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxRQUFRLENBQUM7UUFDckQsSUFBSSxRQUFRLEVBQUU7WUFDWiwyRkFBMkY7WUFDM0YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzlELEVBQUUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzQztRQUVELG1CQUFtQjtRQUNuQixPQUFPLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUN4RCxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUUzQixHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLHdCQUF3QixHQUFHLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM5RSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBRVgscUNBQXFDO1lBQ3JDLE1BQU0sYUFBYSxHQUFHLElBQUksZ0JBQWdCLENBQ3hDLElBQUksQ0FBQyxNQUFNLEVBQUUsa0NBQWtDO1lBQy9DLElBQUksQ0FBQyxVQUFVLEVBQ2YsSUFBSSxDQUFDLFVBQVUsRUFDZixJQUFJLENBQUMsU0FBUyxFQUNkLFlBQVksQ0FDYixDQUFDO1lBQ0YsT0FBTyxhQUFhLENBQUMsR0FBRyxDQUN0QixFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLHNCQUFzQixDQUFDLENBQUMsRUFDaEUsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUNqQixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3ZCLElBQUksY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQzdCLEdBQUcsQ0FBQyxJQUFJLENBQ04sV0FBVyxjQUFjLENBQUMsTUFBTSxrQkFBa0I7b0JBQ2xELEdBQUcsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxlQUFlLEdBQUcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUMxRSxDQUFDO2FBQ0g7WUFFRCxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO1lBQ2pFLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDN0IsSUFBSSxXQUFXLElBQUksS0FBSyxFQUFFO29CQUN4QixLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDOUI7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILHNDQUFzQztZQUN0QyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDckMsNENBQTRDO2dCQUM1QyxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ2pELElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO3dCQUFFLE9BQU87cUJBQUU7b0JBQ3JDLE9BQU8sS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUMvQixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLHVDQUF1QztZQUN2QyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUMxQixpRkFBaUY7WUFDakYsTUFBTSxVQUFVLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxvQkFBb0IsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3pGLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUV0RixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDYixHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQztZQUNqRCxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ2pDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsNkJBQTZCLEdBQUcsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxnQ0FBZ0M7WUFDaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDdEIsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDL0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDM0MsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMifQ==