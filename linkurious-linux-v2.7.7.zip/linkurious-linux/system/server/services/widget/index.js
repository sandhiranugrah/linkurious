/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-05-23.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const _ = require('lodash');
const { StyleRules, NodeAttributes, EdgeAttributes, Tools, Filters } = require('linkurious-shared/umd');
// services
const LKE = require('../index');
const Db = LKE.getSqlDb();
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
const Logger = LKE.getLogger(__filename);
// locals
const DesignUtils = require('../business/designUtils');
const VisualizationShareDAO = require('../business/VisualizationShareDAO');
class WidgetService {
    /**
     * Create or updates a widget from visualization.
     *
     * @param {number}        visualizationId Id of the visualization used to create this widget
     * @param {WrappedUser}   currentUser     Current connected user (will be owner of the widget)
     * @param {WidgetOptions} [options]       Toolbar options of the widget
     * @returns {Bluebird<string>} the key of the created widget
     */
    createWidget(visualizationId, currentUser, options = {}) {
        this._checkWidgetCreation(currentUser, visualizationId, options);
        // Check if a widget already exists for that visualization
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(existingWidget => {
            if (Utils.hasValue(existingWidget)) {
                return Errors.business('widget_exists', undefined, true);
            }
            // Check that the current user owns the visualization
            return this._getOwnVisualization(visualizationId, currentUser, 'You must be the owner of the visualization to create a widget')
                .then(visualization => {
                const uiOptions = _.omit(options, ['password']);
                const widget = this._generateWidget(visualization, {
                    key: Utils.randomHex8(),
                    userId: currentUser.id,
                    password: options.password
                }, uiOptions);
                return Db.models.widget.create(widget).return(widget.key);
            });
        });
    }
    /**
     * Updates a widget from a visualization preserving the existing key.
     *
     * @param {number}        visualizationId Id of the visualization used to create this widget
     * @param {WrappedUser}   currentUser     Current connected user
     * @param {WidgetOptions} [options]       Toolbar options of the widget
     * @returns {Bluebird<string>} the key of the updated widget
     */
    updateWidget(visualizationId, currentUser, options = {}) {
        this._checkWidgetCreation(currentUser, visualizationId, options);
        // Check if a widget already exists for that visualization
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(existingWidget => {
            if (Utils.noValue(existingWidget)) {
                return Errors.business('not_found', `Cannot find widget from visualization #${visualizationId}`, true);
            }
            // Check that the current user owns the visualization
            return this._getOwnVisualization(visualizationId, currentUser, 'You must be the owner of the visualization to update the widget')
                .then(visualization => {
                const uiOptions = _.omit(options, ['password']);
                const widget = this._generateWidget(visualization, {
                    key: existingWidget.key,
                    userId: currentUser.id,
                    password: options.password
                }, _.defaults(uiOptions, existingWidget.content.ui));
                for (const key in widget) {
                    existingWidget[key] = widget[key];
                }
                // null means explicitly: "remove the password"
                if (options.password === null) {
                    existingWidget.password = null;
                }
                return existingWidget.save().return(widget.key);
            });
        });
    }
    /**
     * Find a widget by key.
     *
     * @param {string} key   Key of a widget
     * @param {object}      [credentials]
     * @param {WrappedUser} [credentials.user]
     * @param {string}      [credentials.password]
     * @returns {Bluebird<PublicWidget>}
     */
    getWidgetByKey(key, credentials = {}) {
        Utils.check.nonEmpty('key', key);
        return this._findWidgetByKey(key)
            .then(widget => this._checkCredentials(widget, credentials)
            .then(() => Db.models.widget.instanceToPublicAttributes(widget)));
    }
    /**
     * Return the widget key from the visualization id.
     * If the widget does not exist, return undefined.
     *
     * @param {number} visualizationId
     * @returns {Bluebird<string>}
     */
    getWidgetKeyFromVisualizationId(visualizationId) {
        Utils.check.posInt('visualizationId', visualizationId);
        return Db.models.widget.find({ where: { visualizationId: visualizationId } })
            .then(widget => {
            if (Utils.noValue(widget)) {
                return undefined;
            }
            return widget.key;
        });
    }
    /**
     * Delete a widget by key.
     *
     * @param {string}      key         Key of a widget
     * @param {WrappedUser} currentUser
     * @returns {Bluebird<void>}
     */
    deleteByKey(key, currentUser) {
        return this._findWidgetByKey(key)
            .then(widget => this._getOwnVisualization(widget.visualizationId, currentUser, 'You must be the owner of a widget to delete it.')
            .then(() => widget.destroy()))
            .return();
    }
    /**
     * Migrate all existing widgets
     *
     * @returns {Bluebird<void>}
     * @backward-compatibility
     */
    migrateWidgets() {
        return Db.models.widget.findAll().map(widget => {
            this._updateWidgetToVersion2(widget).catch(error => {
                // In some legacy version of LKE widget content was unchecked. The midget migration might fail due to some unexpected data structure.
                // The broken widgets can be fixed by an update from the original visualization see https://github.com/Linkurious/linkurious-server/issues/1655
                Logger.error(`Failed to migrate widget ${JSON.stringify(widget)}`, error);
            });
        }).return();
    }
    /**
     * @param {WrappedUser}   currentUser
     * @param {number}        visualizationId
     * @param {WidgetOptions} [options]
     * @private
     * @throws {LkError}
     */
    _checkWidgetCreation(currentUser, visualizationId, options) {
        Utils.check.exist('currentUser', currentUser);
        Utils.check.posInt('visualizationId', visualizationId);
        Utils.check.properties('options', options, {
            search: { type: 'boolean' },
            share: { type: 'boolean' },
            layout: { type: 'boolean' },
            fullscreen: { type: 'boolean' },
            zoom: { type: 'boolean' },
            legend: { type: 'boolean' },
            geo: { type: 'boolean' },
            password: { check: 'nonEmpty' }
        });
    }
    /**
     * Find a visualization created by the `currentUser`.
     *
     * @param {number}      id          Visualization ID
     * @param {WrappedUser} currentUser
     * @param {string}      [errorMessage] Error message to shown when `currentUser` does not own the visualization
     * @returns {Bluebird<PublicVisualization>}
     * @private
     * @throws {LkError} If `currentUser` does not own the visualization
     */
    _getOwnVisualization(id, currentUser, errorMessage) {
        const VisualizationDAO = LKE.getVisualizationDAO();
        return VisualizationDAO.getById(id, true, currentUser).then(visualization => {
            if (Utils.noValue(visualization)) {
                return Errors.business('not_found', 'Visualization does not exists', true);
            }
            return VisualizationShareDAO
                .getRight({ id: visualization.id, userId: visualization.userId }, currentUser.id)
                .then(right => {
                if (right !== 'owner') {
                    return Errors.access('forbidden', errorMessage, true);
                }
            }).return(visualization);
        });
    }
    /**
     * Find a widget instance by key.
     *
     * @param {string} key
     * @returns {Bluebird<WidgetInstance>}
     * @private
     * @throws {LkError} If the widget does not exist
     */
    _findWidgetByKey(key) {
        return Db.models.widget.find({ where: { key: key } }).then(widget => {
            if (Utils.noValue(widget)) {
                return Errors.business('not_found', `Cannot find widget with key ${key}`, true);
            }
            return widget;
        });
    }
    /**
     * Generate a widget for a `visualization`
     *
     * @param {PublicVisualization} visualization
     * @param {WidgetConfiguration} configuration
     * @param {WidgetUiOptions}     [uiOptions]
     * @returns {WidgetAttributes}
     * @private
     */
    _generateWidget(visualization, configuration, uiOptions = {}) {
        const { key, userId, password } = configuration;
        const nodeStyleRules = new StyleRules(
        /**@type {SharedNodeStyleRule[]}**/ (visualization.design.styles.node));
        const widgetNodes = this._generateWidgetNodes(visualization, nodeStyleRules);
        const widgetNodeIds = _.map(widgetNodes, 'id');
        const edgeStyleRules = new StyleRules(
        /**@type {SharedEdgeStyleRule[]}**/ (visualization.design.styles.edge));
        const widgetEdges = this._generateWidgetEdges(visualization, edgeStyleRules)
            .filter(edge => {
            // Include only edges with both ends in the widget
            return _.includes(widgetNodeIds, edge.source) && _.includes(widgetNodeIds, edge.target);
        });
        const legend = {
            nodes: nodeStyleRules.generateLegend(widgetNodes, DesignUtils.PALETTE),
            edges: edgeStyleRules.generateLegend(widgetEdges, DesignUtils.PALETTE)
        };
        const defaultUiOptions = {
            search: false,
            share: false,
            fullscreen: false,
            layout: false,
            zoom: false,
            legend: false,
            geo: false
        };
        const widgetContent = {
            graph: { nodes: widgetNodes, edges: widgetEdges },
            legend: legend,
            mapLayers: this._getMapLayersAttributes(visualization.geo.layers),
            mode: visualization.mode,
            ui: _.defaults(uiOptions, defaultUiOptions)
        };
        const widgetAttributes = {
            title: visualization.title,
            key: key,
            content: widgetContent,
            visualizationId: visualization.id,
            userId: userId,
            version: 2
        };
        if (Utils.hasValue(password)) {
            // Set the password only when defined to avoid to clear the password unintentionally
            widgetAttributes.password = password;
        }
        return widgetAttributes;
    }
    /**
     * @param {any}        visualization
     * @param {StyleRules} nodeStyleRules
     * @returns {OgmaNode[]}
     * @private
     */
    _generateWidgetNodes(visualization, nodeStyleRules) {
        // list visible node/edge properties (from visualization Tooltips) to filter content
        return visualization.nodes
            .filter(node => !Filters.isFiltered(visualization.filters.node, node))
            .map(node => ({
            id: node.id,
            attributes: this._generateNodeAttributes(node, nodeStyleRules, this._getNodeCaption(node, visualization.nodeFields.captions)),
            data: {
                categories: node.categories,
                properties: node.data,
                _geo: Tools.getOgmaCoordinates(node.geo)
            }
        }));
    }
    /**
     * @param {any}        visualization
     * @param {StyleRules} edgeStyleRules
     * @returns {OgmaEdge[]}
     * @private
     */
    _generateWidgetEdges(visualization, edgeStyleRules) {
        return visualization.edges
            .filter(edge => !Filters.isFiltered(visualization.filters.edge, edge))
            .map(edge => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            attributes: this._generateEdgeAttributes(edge, edgeStyleRules, this._getEdgeCaption(edge, visualization.edgeFields.captions)),
            data: {
                type: edge.type,
                properties: edge.data
            }
        }));
    }
    /**
     * @param {VisualizationNode} node
     * @param {StyleRules}        styleRules
     * @param {string}            label
     * @returns {{color: OgmaColor | OgmaColor[], radius: number, shape: NodeShape, x: number, y: number, icon: Icon, image: Image, text: {content: string}}}
     * @private
     */
    _generateNodeAttributes(node, styleRules, label) {
        const ogmaSettings = Config.get('ogma');
        const defaultRadius = _.get(ogmaSettings, ['options', 'styles', 'nodeRadius'], 5);
        const defaultShape = _.get(ogmaSettings, ['options', 'styles', 'shapes', 'nodes'], 'circle');
        const attributes = new NodeAttributes(styleRules.nodeRules).all(node, DesignUtils.PALETTE);
        return {
            color: attributes.color,
            radius: attributes.radius || defaultRadius,
            shape: attributes.shape || defaultShape,
            x: node.nodelink.x,
            y: node.nodelink.y,
            icon: attributes.icon,
            image: attributes.image,
            text: { content: label }
        };
    }
    /**
     * @param {LkEdge}     edge
     * @param {StyleRules} styleRules
     * @param {string}     label
     * @returns {{color: OgmaColor, shape: EdgeShape, width: number, text: {content: string}}}
     * @private
     */
    _generateEdgeAttributes(edge, styleRules, label) {
        const ogmaSettings = Config.get('ogma');
        const defaultWidth = _.get(ogmaSettings, ['options', 'styles', 'edgeWidth'], 1);
        const defaultShape = _.get(ogmaSettings, ['options', 'styles', 'shapes', 'edges'], 'arrow');
        const attributes = new EdgeAttributes(styleRules.edgeRules).all(edge, DesignUtils.PALETTE);
        return {
            color: attributes.color,
            shape: attributes.shape || defaultShape,
            width: attributes.width || defaultWidth,
            text: { content: label }
        };
    }
    /**
     * @param {string[]} layersNames
     * @returns {object[]}
     * @private
     */
    _getMapLayersAttributes(layersNames) {
        const leafletLayers = Config.get('leaflet', []);
        // If layersNames is empty
        // return the first layer with overlay != true
        if (layersNames.length === 0) {
            const [layer] = _.filter(leafletLayers, leaflet => !leaflet.overlay);
            return Utils.hasValue(layer) ? [layer] : [];
        }
        const layers = new Map();
        _.forEach(leafletLayers, leaflet => {
            layers.set(leaflet.name, leaflet);
        });
        return _.map(layersNames, layerName => layers.get(layerName));
    }
    /**
     * @param {WidgetInstance} widgetInstance
     * @param {object}         [credentials]
     * @param {WrappedUser}    [credentials.user]
     * @param {string}         [credentials.password]
     * @returns {Bluebird<void>}
     * @private
     * @throws {LkError} If the user cannot access the widget
     */
    _checkCredentials(widgetInstance, credentials) {
        return Promise.resolve().then(() => {
            if (Utils.noValue(widgetInstance.password)) {
                // widget without password, pass along
                return;
            }
            if (Utils.hasValue(credentials.user)) {
                // User own the visualization, allow to read the widget.
                return this._getOwnVisualization(widgetInstance.visualizationId, credentials.user, 'You do not have access to this widget').return();
            }
            if (!widgetInstance.checkPassword(credentials.password)) {
                // incorrect password
                return Errors.access('forbidden', 'Invalid widget password.', true);
            }
        });
    }
    /**
     * Resolve the node caption.
     *
     * Original code from clientV1.
     *
     * @param {LkNode}   node
     * @param {object}   nodeCaptions Node        Captions by category name
     * @param {boolean}  nodeCaptions.enabled     Whether the caption is enabled
     * @param {boolean}  nodeCaptions.displayName Whether the category name should be included in the caption
     * @param {string[]} nodeCaptions.properties  List of properties to include in the caption
     * @returns {string} text to display for the corresponding node
     * @private
     */
    _getNodeCaption(node, nodeCaptions) {
        const propertyNames = {}, text = [];
        let i, j, categoryName, propertyValue, caption;
        if (node.categories.length) {
            // The node has one or multiple categories
            for (i = 0; i < node.categories.length; i++) {
                categoryName = node.categories[i];
                caption = nodeCaptions[categoryName];
                if (!caption || !caption.active) {
                    continue;
                }
                if (caption.displayName) {
                    text.push(categoryName);
                }
                for (j = 0; j < caption.properties.length; j++) {
                    // prevent to display a property twice on nodes with multiple categories:
                    if (!propertyNames[caption.properties[j]]) {
                        propertyNames[caption.properties[j]] = true;
                        propertyValue = node.data[caption.properties[j]];
                        if (propertyValue !== undefined && ('' + propertyValue !== '')) {
                            text.push(propertyValue);
                        }
                    }
                }
            }
        }
        else {
            // The node has no category
            caption = nodeCaptions['No category'];
            if (caption && caption.active) {
                for (j = 0; j < caption.properties.length; j++) {
                    propertyValue = node.data[caption.properties[j]];
                    if (propertyValue !== undefined && ('' + propertyValue !== '')) {
                        text.push(propertyValue);
                    }
                }
            }
        }
        return text.join(' - ');
    }
    /**
     * Resolve the edge caption.
     *
     * Original code from clientV1.
     *
     * @param {LkEdge}   edge
     * @param {object}   edgeCaptions             Captions by edge type
     * @param {object}   edgeCaptions.enabled     Whether the caption is enabled
     * @param {boolean}  edgeCaptions.displayName Whether the type name should be included in the caption
     * @param {string[]} edgeCaptions.properties  List of properties to include in the caption
     * @returns {string} text to display for the corresponding edge
     * @private
     */
    _getEdgeCaption(edge, edgeCaptions) {
        const text = [];
        let j, typeName, propertyValue, caption;
        if (edge.type !== undefined) {
            typeName = edge.type;
            caption = edgeCaptions[typeName];
            if (caption && caption.active) {
                if (caption.displayName) {
                    text.push(typeName);
                }
                for (j = 0; j < caption.properties.length; j++) {
                    propertyValue = edge.data[caption.properties[j]];
                    if (propertyValue !== undefined && ('' + propertyValue !== '')) {
                        text.push(propertyValue);
                    }
                }
            }
        }
        return text.join(' - ');
    }
    /**
     * Update the widget to be compatible with Ogma if widget is version 1.
     *
     * @param {WidgetInstance} widget
     * @returns {Bluebird<WidgetInstance>}
     * @private
     * @backward-compatibility
     */
    _updateWidgetToVersion2(widget) {
        return Promise.resolve().then(() => {
            if (widget.version > 1) {
                return widget;
            }
            widget.content = this._migrateWidgetContentToOgma(widget.content);
            widget.version = 2;
            return widget.save();
        });
    }
    /**
     * Extract schema from `nodes` and `edges` (format: Widget v1)
     *
     * @param {Array<{data: {categories: string[]}}>} nodes
     * @param {Array<{data: {type: string}}>}         edges
     * @returns {SimpleGraphSchemaTypes}
     * @private
     */
    _getTypesSchema(nodes, edges) {
        const nodeCategories = new Set();
        const edgeTypes = new Set();
        _.forEach(nodes, node => {
            _.forEach(node.data.categories, category => {
                nodeCategories.add(category);
            });
        });
        _.forEach(edges, edge => {
            edgeTypes.add(edge.data.type);
        });
        return {
            nodeCategories: Array.from(nodeCategories),
            edgeTypes: Array.from(edgeTypes)
        };
    }
    /**
     * Update the widget content to be compatible with Ogma.
     *
     * @param {object} content Widget content v1
     * @returns {WidgetContent}
     * @backward-compatibility
     * @private
     */
    _migrateWidgetContentToOgma(content) {
        // We don't need the schema Api here, all the required categories/types are already in the widget
        const schema = this._getTypesSchema(content.graph.nodes, content.graph.edges);
        // 1) Build Style Rules
        const widgetStyleRules = DesignUtils.migrateStyles(schema, content.styles, content.palette);
        // 2) Migrate Nodes format
        const nodeStyleRules = new StyleRules(
        /**@type {SharedNodeStyleRule[]}**/ (widgetStyleRules.node));
        const widgetNodes = content.graph.nodes
            .map(node => ({
            id: node.id,
            attributes: this._generateNodeAttributes(node, nodeStyleRules, node.label),
            data: {
                properties: node.data.properties,
                categories: node.data.categories,
                _geo: Tools.getOgmaCoordinates(node.geo)
            }
        }));
        // 3) Migrate Edges format
        const edgeStyleRules = new StyleRules(
        /**@type {SharedEdgeStyleRule[]}**/ (widgetStyleRules.edge));
        const widgetEdges = content.graph.edges
            .map(edge => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            attributes: this._generateEdgeAttributes(edge, edgeStyleRules, edge.label),
            data: edge.data
        }));
        return {
            graph: {
                nodes: widgetNodes,
                edges: widgetEdges
            },
            legend: {
                nodes: nodeStyleRules.generateLegend(widgetNodes, DesignUtils.PALETTE),
                edges: edgeStyleRules.generateLegend(widgetEdges, DesignUtils.PALETTE)
            },
            mapLayers: content.mapLayers,
            mode: content.mode,
            ui: content.ui
        };
    }
}
module.exports = new WidgetService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2lkZ2V0L2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxFQUNKLFVBQVUsRUFDVixjQUFjLEVBQ2QsY0FBYyxFQUNkLEtBQUssRUFDTCxPQUFPLEVBQ1IsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQUVyQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXpDLFNBQVM7QUFDVCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUN2RCxNQUFNLHFCQUFxQixHQUFHLE9BQU8sQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO0FBRTNFLE1BQU0sYUFBYTtJQUNqQjs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsT0FBTyxHQUFHLEVBQUU7UUFDckQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFakUsMERBQTBEO1FBQzFELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBQyxFQUFDLENBQUM7YUFDdEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3JCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDbEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDMUQ7WUFDRCxxREFBcUQ7WUFDckQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLFdBQVcsRUFDM0QsK0RBQStELENBQUM7aUJBQy9ELElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDcEIsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRTtvQkFDakQsR0FBRyxFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQ3ZCLE1BQU0sRUFBRSxXQUFXLENBQUMsRUFBRTtvQkFDdEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO2lCQUMzQixFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNkLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDNUQsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsWUFBWSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsT0FBTyxHQUFHLEVBQUU7UUFDckQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDakUsMERBQTBEO1FBQzFELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsZUFBZSxFQUFFLGVBQWUsRUFBQyxFQUFDLENBQUM7YUFDdEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3JCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDakMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFDaEMsMENBQTBDLGVBQWUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3RFO1lBQ0QscURBQXFEO1lBQ3JELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQzNELGlFQUFpRSxDQUFDO2lCQUNqRSxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3BCLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDaEQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUU7b0JBQ2pELEdBQUcsRUFBRSxjQUFjLENBQUMsR0FBRztvQkFDdkIsTUFBTSxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUN0QixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7aUJBQzNCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNyRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sRUFBRTtvQkFDeEIsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbkM7Z0JBRUQsK0NBQStDO2dCQUMvQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssSUFBSSxFQUFFO29CQUM3QixjQUFjLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztpQkFDaEM7Z0JBRUQsT0FBTyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNsRCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsRUFBRTtRQUNsQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDakMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO2FBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDO2FBQ3hELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILCtCQUErQixDQUFDLGVBQWU7UUFDN0MsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDdkQsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxlQUFlLEVBQUUsZUFBZSxFQUFDLEVBQUMsQ0FBQzthQUN0RSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDYixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3pCLE9BQU8sU0FBUyxDQUFDO2FBQ2xCO1lBQ0QsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILFdBQVcsQ0FBQyxHQUFHLEVBQUUsV0FBVztRQUMxQixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7YUFDOUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUMzRSxpREFBaUQsQ0FBQzthQUNqRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDL0IsTUFBTSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjO1FBQ1osT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDakQscUlBQXFJO2dCQUNySSwrSUFBK0k7Z0JBQy9JLE1BQU0sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM1RSxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILG9CQUFvQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsT0FBTztRQUN4RCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDdkQsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTtZQUN6QyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3pCLEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDeEIsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN6QixVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzdCLElBQUksRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDdkIsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUN6QixHQUFHLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3RCLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7U0FDOUIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILG9CQUFvQixDQUFDLEVBQUUsRUFBRSxXQUFXLEVBQUUsWUFBWTtRQUNoRCxNQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ25ELE9BQU8sZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQzFFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDaEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSwrQkFBK0IsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM1RTtZQUNELE9BQU8scUJBQXFCO2lCQUN6QixRQUFRLENBQUMsRUFBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsYUFBYSxDQUFDLE1BQU0sRUFBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUM7aUJBQzlFLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDWixJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7b0JBQ3JCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUN2RDtZQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsZ0JBQWdCLENBQUMsR0FBRztRQUNsQixPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSwrQkFBK0IsR0FBRyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDakY7WUFDRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILGVBQWUsQ0FBQyxhQUFhLEVBQUUsYUFBYSxFQUFFLFNBQVMsR0FBRyxFQUFFO1FBQzFELE1BQU0sRUFBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBQyxHQUFHLGFBQWEsQ0FBQztRQUM5QyxNQUFNLGNBQWMsR0FBRyxJQUFJLFVBQVU7UUFDbkMsbUNBQW1DLENBQUEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3pFLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDN0UsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFL0MsTUFBTSxjQUFjLEdBQUcsSUFBSSxVQUFVO1FBQ25DLG1DQUFtQyxDQUFBLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN6RSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQzthQUN6RSxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDYixrREFBa0Q7WUFDbEQsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFGLENBQUMsQ0FBQyxDQUFDO1FBRUwsTUFBTSxNQUFNLEdBQUc7WUFDYixLQUFLLEVBQUUsY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQztZQUN0RSxLQUFLLEVBQUUsY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQztTQUN2RSxDQUFDO1FBRUYsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QixNQUFNLEVBQUUsS0FBSztZQUNiLEtBQUssRUFBRSxLQUFLO1lBQ1osVUFBVSxFQUFFLEtBQUs7WUFDakIsTUFBTSxFQUFFLEtBQUs7WUFDYixJQUFJLEVBQUUsS0FBSztZQUNYLE1BQU0sRUFBRSxLQUFLO1lBQ2IsR0FBRyxFQUFFLEtBQUs7U0FDWCxDQUFDO1FBRUYsTUFBTSxhQUFhLEdBQUc7WUFDcEIsS0FBSyxFQUFFLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFDO1lBQy9DLE1BQU0sRUFBRSxNQUFNO1lBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztZQUNqRSxJQUFJLEVBQUUsYUFBYSxDQUFDLElBQUk7WUFDeEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLGdCQUFnQixDQUFDO1NBQzVDLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHO1lBQ3ZCLEtBQUssRUFBRSxhQUFhLENBQUMsS0FBSztZQUMxQixHQUFHLEVBQUUsR0FBRztZQUNSLE9BQU8sRUFBRSxhQUFhO1lBQ3RCLGVBQWUsRUFBRSxhQUFhLENBQUMsRUFBRTtZQUNqQyxNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRSxDQUFDO1NBQ1gsQ0FBQztRQUVGLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1QixvRkFBb0Y7WUFDcEYsZ0JBQWdCLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztTQUN0QztRQUVELE9BQU8sZ0JBQWdCLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsb0JBQW9CLENBQUMsYUFBYSxFQUFFLGNBQWM7UUFDaEQsb0ZBQW9GO1FBQ3BGLE9BQU8sYUFBYSxDQUFDLEtBQUs7YUFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3JFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDWixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxVQUFVLEVBQUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksRUFBRSxjQUFjLEVBQzNELElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDaEUsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDM0IsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNyQixJQUFJLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7YUFDekM7U0FDRixDQUFDLENBQUMsQ0FBQztJQUNSLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG9CQUFvQixDQUFDLGFBQWEsRUFBRSxjQUFjO1FBQ2hELE9BQU8sYUFBYSxDQUFDLEtBQUs7YUFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3JFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDWixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFVBQVUsRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFDM0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNoRSxJQUFJLEVBQUU7Z0JBQ0osSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSTthQUN0QjtTQUNGLENBQUMsQ0FBQyxDQUFDO0lBQ1IsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUF1QixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsS0FBSztRQUM3QyxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hDLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNsRixNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzdGLE1BQU0sVUFBVSxHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzRixPQUFPO1lBQ0wsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLO1lBQ3ZCLE1BQU0sRUFBRSxVQUFVLENBQUMsTUFBTSxJQUFJLGFBQWE7WUFDMUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLElBQUksWUFBWTtZQUN2QyxDQUFDLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xCLENBQUMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJO1lBQ3JCLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSztZQUN2QixJQUFJLEVBQUUsRUFBQyxPQUFPLEVBQUUsS0FBSyxFQUFDO1NBQ3ZCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsdUJBQXVCLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLO1FBQzdDLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2hGLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDNUYsTUFBTSxVQUFVLEdBQUcsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNGLE9BQU87WUFDTCxLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUs7WUFDdkIsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLElBQUksWUFBWTtZQUN2QyxLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUssSUFBSSxZQUFZO1lBQ3ZDLElBQUksRUFBRSxFQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUM7U0FDdkIsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsdUJBQXVCLENBQUMsV0FBVztRQUNqQyxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNoRCwwQkFBMEI7UUFDMUIsOENBQThDO1FBQzlDLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDNUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDckUsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDN0M7UUFDRCxNQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsaUJBQWlCLENBQUMsY0FBYyxFQUFFLFdBQVc7UUFDM0MsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUMxQyxzQ0FBc0M7Z0JBQ3RDLE9BQU87YUFDUjtZQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3BDLHdEQUF3RDtnQkFDeEQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUMsSUFBSSxFQUMvRSx1Q0FBdUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ3JEO1lBRUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUN2RCxxQkFBcUI7Z0JBQ3JCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDckU7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCxlQUFlLENBQUMsSUFBSSxFQUFFLFlBQVk7UUFDaEMsTUFBTSxhQUFhLEdBQUcsRUFBRSxFQUFFLElBQUksR0FBRyxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUNOLFlBQVksRUFDWixhQUFhLEVBQ2IsT0FBTyxDQUFDO1FBRVYsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRTtZQUMxQiwwQ0FBMEM7WUFDMUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0MsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLE9BQU8sR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBRXJDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO29CQUMvQixTQUFTO2lCQUNWO2dCQUVELElBQUksT0FBTyxDQUFDLFdBQVcsRUFBRTtvQkFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDekI7Z0JBRUQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDOUMseUVBQXlFO29CQUN6RSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDekMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7d0JBQzVDLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFakQsSUFBSSxhQUFhLEtBQUssU0FBUyxJQUFJLENBQUMsRUFBRSxHQUFHLGFBQWEsS0FBSyxFQUFFLENBQUMsRUFBRTs0QkFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzt5QkFDMUI7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGO2FBQU07WUFDTCwyQkFBMkI7WUFDM0IsT0FBTyxHQUFHLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUV0QyxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUM3QixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM5QyxhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWpELElBQUksYUFBYSxLQUFLLFNBQVMsSUFBSSxDQUFDLEVBQUUsR0FBRyxhQUFhLEtBQUssRUFBRSxDQUFDLEVBQUU7d0JBQzlELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7cUJBQzFCO2lCQUNGO2FBQ0Y7U0FDRjtRQUVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0gsZUFBZSxDQUFDLElBQUksRUFBRSxZQUFZO1FBQ2hDLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsRUFDSCxRQUFRLEVBQ1IsYUFBYSxFQUNiLE9BQU8sQ0FBQztRQUVWLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDM0IsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDckIsT0FBTyxHQUFHLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUVqQyxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUM3QixJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3JCO2dCQUVELEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzlDLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFakQsSUFBSSxhQUFhLEtBQUssU0FBUyxJQUFJLENBQUMsRUFBRSxHQUFHLGFBQWEsS0FBSyxFQUFFLENBQUMsRUFBRTt3QkFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztxQkFDMUI7aUJBQ0Y7YUFDRjtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsdUJBQXVCLENBQUMsTUFBTTtRQUM1QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksTUFBTSxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUU7Z0JBQ3RCLE9BQU8sTUFBTSxDQUFDO2FBQ2Y7WUFDRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEUsTUFBTSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7WUFDbkIsT0FBTyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdkIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSztRQUMxQixNQUFNLGNBQWMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2pDLE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7UUFFNUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDdEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsRUFBRTtnQkFDekMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDdEIsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2hDLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTztZQUNMLGNBQWMsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUMxQyxTQUFTLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7U0FDakMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsMkJBQTJCLENBQUMsT0FBTztRQUNqQyxpR0FBaUc7UUFDakcsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlFLHVCQUF1QjtRQUN2QixNQUFNLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTVGLDBCQUEwQjtRQUMxQixNQUFNLGNBQWMsR0FBRyxJQUFJLFVBQVU7UUFDbkMsbUNBQW1DLENBQUEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzlELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSzthQUNwQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ1osRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ1gsVUFBVSxFQUFFLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDMUUsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQ2hDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQ2hDLElBQUksRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUN6QztTQUNGLENBQUMsQ0FBQyxDQUFDO1FBRU4sMEJBQTBCO1FBQzFCLE1BQU0sY0FBYyxHQUFHLElBQUksVUFBVTtRQUNuQyxtQ0FBbUMsQ0FBQSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDOUQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLO2FBQ3BDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDWixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFVBQVUsRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQzFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtTQUNoQixDQUFDLENBQUMsQ0FBQztRQUVOLE9BQU87WUFDTCxLQUFLLEVBQUU7Z0JBQ0wsS0FBSyxFQUFFLFdBQVc7Z0JBQ2xCLEtBQUssRUFBRSxXQUFXO2FBQ25CO1lBQ0QsTUFBTSxFQUFFO2dCQUNOLEtBQUssRUFBRSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsT0FBTyxDQUFDO2dCQUN0RSxLQUFLLEVBQUUsY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQzthQUN2RTtZQUNELFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztZQUM1QixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDbEIsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1NBQ2YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxhQUFhLEVBQUUsQ0FBQyJ9