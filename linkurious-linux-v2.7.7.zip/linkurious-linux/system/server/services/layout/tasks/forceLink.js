/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-03-04.
 */
'use strict';
/*
 * grunt-forceLink
 *
 * This task crush and minify ForceLink code.
 */
const uglify = require('uglify-js');
// Shorteners
function minify(string) {
    return uglify.minify(string, { fromString: true }).code;
}
// Crushing function
function crush(fnString) {
    let pattern, i, l;
    const np = [
        'x',
        'y',
        'dx',
        'dy',
        'old_dx',
        'old_dy',
        'mass',
        'convergence',
        'size',
        'fixed'
    ];
    const ep = [
        'source',
        'target',
        'weight'
    ];
    const rp = [
        'node',
        'centerX',
        'centerY',
        'size',
        'nextSibling',
        'firstChild',
        'mass',
        'massCenterX',
        'massCenterY'
    ];
    // Replacing matrix accessors by incremented indexes
    for (i = 0, l = rp.length; i < l; i++) {
        pattern = new RegExp('rp\\(([^,]*), \'' + rp[i] + '\'\\)', 'g');
        fnString = fnString.replace(pattern, (i === 0) ? '$1' : '$1 + ' + i);
    }
    for (i = 0, l = np.length; i < l; i++) {
        pattern = new RegExp('np\\(([^,]*), \'' + np[i] + '\'\\)', 'g');
        fnString = fnString.replace(pattern, (i === 0) ? '$1' : '$1 + ' + i);
    }
    for (i = 0, l = ep.length; i < l; i++) {
        pattern = new RegExp('ep\\(([^,]*), \'' + ep[i] + '\'\\)', 'g');
        fnString = fnString.replace(pattern, (i === 0) ? '$1' : '$1 + ' + i);
    }
    return fnString;
}
// Cleaning function
function clean(string) {
    return string.replace(/function crush\(fnString\)/, 'var crush = null; function no_crush(fnString)');
}
module.exports = function (grunt) {
    // Force atlas grunt multitask
    function multitask() {
        // Iterate over all specified file groups.
        this.files.forEach(f => {
            // Concat specified files.
            let src = f.src.filter(filepath => {
                // Warn on and remove invalid source files (if nonull was set).
                if (!grunt.file.exists(filepath)) {
                    grunt.log.warn('Source file "' + filepath + '" not found.');
                    return false;
                }
                else {
                    return true;
                }
            }).map(filepath => {
                // Read file source.
                return grunt.file.read(filepath);
            }).join('\n');
            // Crushing, cleaning and minifying
            src = crush(src);
            src = clean(src);
            try {
                src = minify(src);
            }
            catch (e) {
                grunt.fail.fatal(`JavaScript parse error while minifying at ${e.line}:${e.col}`);
            }
            // Write the destination file.
            grunt.file.write(f.dest, src);
            // Print a success message.
            grunt.log.writeln('File "' + f.dest + '" created.');
        });
    }
    // Registering the task
    grunt.registerMultiTask('forceLink', 'A grunt task to crush and minify ForceLink.', multitask);
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9yY2VMaW5rLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2xheW91dC90YXNrcy9mb3JjZUxpbmsuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYjs7OztHQUlHO0FBQ0gsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBRXBDLGFBQWE7QUFDYixTQUFTLE1BQU0sQ0FBQyxNQUFNO0lBQ3BCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDeEQsQ0FBQztBQUVELG9CQUFvQjtBQUNwQixTQUFTLEtBQUssQ0FBQyxRQUFRO0lBQ3JCLElBQUksT0FBTyxFQUNULENBQUMsRUFDRCxDQUFDLENBQUM7SUFFSixNQUFNLEVBQUUsR0FBRztRQUNULEdBQUc7UUFDSCxHQUFHO1FBQ0gsSUFBSTtRQUNKLElBQUk7UUFDSixRQUFRO1FBQ1IsUUFBUTtRQUNSLE1BQU07UUFDTixhQUFhO1FBQ2IsTUFBTTtRQUNOLE9BQU87S0FDUixDQUFDO0lBRUYsTUFBTSxFQUFFLEdBQUc7UUFDVCxRQUFRO1FBQ1IsUUFBUTtRQUNSLFFBQVE7S0FDVCxDQUFDO0lBRUYsTUFBTSxFQUFFLEdBQUc7UUFDVCxNQUFNO1FBQ04sU0FBUztRQUNULFNBQVM7UUFDVCxNQUFNO1FBQ04sYUFBYTtRQUNiLFlBQVk7UUFDWixNQUFNO1FBQ04sYUFBYTtRQUNiLGFBQWE7S0FDZCxDQUFDO0lBRUYsb0RBQW9EO0lBQ3BELEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQ3JDLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxrQkFBa0IsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2hFLFFBQVEsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUN6QixPQUFPLEVBQ1AsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FDL0IsQ0FBQztLQUNIO0lBRUQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDckMsT0FBTyxHQUFHLElBQUksTUFBTSxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDaEUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQ3pCLE9BQU8sRUFDUCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUMvQixDQUFDO0tBQ0g7SUFFRCxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUNyQyxPQUFPLEdBQUcsSUFBSSxNQUFNLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNoRSxRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FDekIsT0FBTyxFQUNQLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQy9CLENBQUM7S0FDSDtJQUVELE9BQU8sUUFBUSxDQUFDO0FBQ2xCLENBQUM7QUFFRCxvQkFBb0I7QUFDcEIsU0FBUyxLQUFLLENBQUMsTUFBTTtJQUNuQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQ25CLDRCQUE0QixFQUM1QiwrQ0FBK0MsQ0FDaEQsQ0FBQztBQUNKLENBQUM7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSztJQUU3Qiw4QkFBOEI7SUFDOUIsU0FBUyxTQUFTO1FBRWhCLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNyQiwwQkFBMEI7WUFDMUIsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ2hDLCtEQUErRDtnQkFDL0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNoQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLEdBQUcsUUFBUSxHQUFHLGNBQWMsQ0FBQyxDQUFDO29CQUM1RCxPQUFPLEtBQUssQ0FBQztpQkFDZDtxQkFBTTtvQkFDTCxPQUFPLElBQUksQ0FBQztpQkFDYjtZQUNILENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEIsb0JBQW9CO2dCQUNwQixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUVkLG1DQUFtQztZQUNuQyxHQUFHLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsSUFBSTtnQkFDRixHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ25CO1lBQUMsT0FBTSxDQUFDLEVBQUU7Z0JBQ1QsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsNkNBQTZDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7YUFDbEY7WUFFRCw4QkFBOEI7WUFDOUIsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztZQUU5QiwyQkFBMkI7WUFDM0IsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsdUJBQXVCO0lBQ3ZCLEtBQUssQ0FBQyxpQkFBaUIsQ0FDckIsV0FBVyxFQUNYLDZDQUE2QyxFQUM3QyxTQUFTLENBQ1YsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9