"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-05.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// external libs
const Bluebird = require("bluebird");
const umd_1 = require("linkurious-shared/umd");
const _ = require("lodash");
// services
const LKE = require("../index");
const Log = LKE.getLogger(__filename);
const DbModels = LKE.getSqlDb().models;
const Errors = LKE.getErrors();
const Config = LKE.getConfig();
const GraphSchemaDAO = LKE.getGraphSchemaDAO();
const Utils = LKE.getUtils();
// locals
const DataSource = require('./dataSource');
const DesignUtils = require('../business/designUtils');
const Bug_1 = require("../../models/errors/Bug");
const GraphRequestTimeout_1 = require("../../models/errors/GraphRequestTimeout");
const MalformedQueryTemplate_1 = require("../../models/errors/MalformedQueryTemplate");
const graphQueryParams_1 = require("../../models/parameters/graphQueryParams");
const lkeIsReadOnly = !Config.get('access.dataEdition');
class DataService {
    constructor() {
        this.sources = [];
        // key of the currently indexed data-source (or null)
        this.indexedSource = null;
        // DataSources indexed by sourceKey
        this.sourceByKey = {};
        this.updateNodeMutex = Utils.semaphore(1);
        this.updateEdgeMutex = Utils.semaphore(1);
        this.removeDeletedSources();
        this.loadSources();
        this.templateParser = new umd_1.QueryTemplateParser((validationMessage, highlight) => {
            throw new MalformedQueryTemplate_1.MalformedQueryTemplate(validationMessage, highlight);
        }, bugMessage => {
            throw new Bug_1.Bug(bugMessage);
        });
    }
    /**
     * Remove all source configs where `deleted` is true.
     */
    removeDeletedSources() {
        const sourceConfigs = Config.get('dataSources');
        // sourceConfigs marked for deletion
        const filteredSourceConfigs = _.filter(sourceConfigs, sourceConfig => !sourceConfig.deleted);
        if (sourceConfigs.length === filteredSourceConfigs.length) {
            // nothing to delete
            return;
        }
        // we replace the dataSources configuration array with the filtered one
        Config.set('dataSources', filteredSourceConfigs);
    }
    loadSources() {
        const sources = [];
        Config.get('dataSources').forEach((config, sourceId) => {
            sources.push(new DataSource(sourceId, this));
        });
        if (sources.length === 0) {
            throw Errors.business('dataSource_unavailable', 'no data-source defined in configuration.');
        }
        this.sources = sources;
    }
    /**
     * @param sourceKeyOrConfigIndex The key or the config index of the data-source
     * @param willWrite              Whether the source will be written to
     * @param action
     */
    withSource(sourceKeyOrConfigIndex, willWrite, 
    // since the DataSource is connected it has the graph and index DAOs
    action) {
        const source = this.resolveSource(sourceKeyOrConfigIndex);
        if (willWrite && source.isReadOnly()) {
            return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
        }
        if (willWrite && lkeIsReadOnly) {
            return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
        }
        return Bluebird.resolve()
            .then(() => action(source))
            .catch(err => {
            if (err.key === 'dataSource_unavailable' && source.isConnected()) {
                Log.warn('Source failure: ' + JSON.stringify(err));
                source.indexConnected = false;
                source.graphConnected = false;
                source.connect(true);
            }
            return Bluebird.reject(err);
        });
    }
    /**
     * Resolve a data-source by source key or config index.
     *
     * Note that, if you need to resolve a source that may be offline, you must resolve by configIndex.
     * Throw if the data-source was not found or we were resolving by key and source was offline.
     *
     * @param sourceKeyOrConfigIndex The key or the config index of the data-source
     */
    resolveSource(sourceKeyOrConfigIndex) {
        // TODO Data.resolveSource should return a "ConnectedSource"
        if (Utils.noValue(sourceKeyOrConfigIndex)) {
            throw Errors.technical('dataSource_unavailable', 'Neither sourceKey nor configIndex provided.');
        }
        let i;
        let source;
        // resolve by configIndex (id)
        if (typeof sourceKeyOrConfigIndex === 'number') {
            for (i = 0; i < this.sources.length; ++i) {
                source = this.sources[i];
                if (source.sourceId === sourceKeyOrConfigIndex && !source.destroyed) {
                    return source;
                }
            }
            throw Errors.business('dataSource_unavailable', 'data-source #' + sourceKeyOrConfigIndex + ' was not found');
        }
        // resolve by sourceKey
        if (typeof sourceKeyOrConfigIndex !== 'string') {
            throw Errors.technical('bug', '"sourceKey" must be a string');
        }
        // from cache
        source = this.sourceByKey[sourceKeyOrConfigIndex];
        // we check for the `destroyed` flag (if deleteSourceConfig occurs we don't clean this cache)
        if (source && !source.destroyed) {
            if (!source.isConnected()) {
                throw Errors.business('dataSource_unavailable', 'data-source "' + sourceKeyOrConfigIndex + '" is not connected');
            }
            return source;
        }
        // slow version
        for (i = 0; i < this.sources.length; ++i) {
            if (!this.sources[i].isConnected()) {
                continue;
            }
            if (this.sources[i].getSourceKey() === sourceKeyOrConfigIndex) {
                source = this.sources[i];
                // add to cache
                this.sourceByKey[sourceKeyOrConfigIndex] = source;
                return source;
            }
        }
        throw Errors.business('dataSource_unavailable', 'data-source "' + sourceKeyOrConfigIndex + '" was not found or is not connected.');
    }
    /**
     * Get the current state of all configured data-sources.
     * The DataSourceState of a data-source is an information accessible to everyone using the data-source.
     *
     * @param [options]
     * @param [options.withStyles]   Whether to include the default styles of the data-sources
     * @param [options.withCaptions] Whether to include the default captions of the data-sources
     */
    getSourceStates(options = {}) {
        const { withStyles, withCaptions } = options;
        return Bluebird.resolve(this.sources.map(s => {
            const state = s.getState();
            const response = {
                configIndex: s.sourceId,
                connected: s.isConnected(),
                error: state.error,
                features: s.features,
                key: s.isConnected() ? s.getSourceKey() : null,
                name: s.getDisplayName(),
                reason: state.reason,
                settings: {
                    readOnly: !!s.isReadOnly()
                },
                state: state.code
            };
            if (s.isConnected()) {
                if (withStyles) {
                    response.defaultStyles = s.state.defaultStyles;
                }
                if (withCaptions) {
                    response.defaultCaptions = s.state.defaultCaptions;
                }
            }
            if (Utils.hasValue(s.graph)) {
                const graphDao = s.graph;
                response.settings.alternativeIds = {
                    edge: graphDao.options.alternativeEdgeId,
                    node: graphDao.options.alternativeNodeId
                };
                response.settings.latitudeProperty = graphDao.options.latitudeProperty;
                response.settings.longitudeProperty = graphDao.options.longitudeProperty;
                if (s.isConnected()) {
                    response.settings.specialProperties = graphDao.specialProperties;
                }
            }
            if (Utils.hasValue(s.index)) {
                const indexDao = s.index;
                response.settings.skipEdgeIndexation =
                    !!indexDao.options.skipEdgeIndexation || !indexDao.features.canIndexEdges;
            }
            return response;
        }));
    }
    /**
     * Get the DataSourceInfo of all data-sources, including:
     * - disconnected sources that have been seen in the past (source states).
     * - disconnected sources that have never been seen (source configs).
     * - connected sources (source configs with states).
     *
     * The DataSourceInfo of a data-source is an information accessible only to admins.
     */
    getAllSources() {
        const vizDAO = LKE.getVisualizationDAO();
        // copy the configured sources array
        const configuredSources = this.sources.slice(0);
        // fetch seen sources
        return DbModels.dataSourceState
            .findAll({ where: {} })
            .map((seenSourceInstance) => {
            const seenSource = _.pick(seenSourceInstance.get(), [
                'lastSeen',
                'info',
                'name',
                'indexedDate',
                'key'
            ]);
            // if the seen source matches a configured source, merge them
            const matches = _.remove(configuredSources, s => s.getSourceKey(true) === seenSource.key);
            if (matches.length) {
                seenSource.state = matches[0].getState().code;
                seenSource.configIndex = matches[0].sourceId;
            }
            else {
                seenSource.state = 'offline';
                seenSource.configIndex = null;
            }
            // host + port
            const hostPortStore = seenSource.info.split(':');
            seenSource.host = hostPortStore[0];
            seenSource.port = hostPortStore[1];
            seenSource.storeId = hostPortStore.slice(2).join(':');
            delete seenSource.info;
            return vizDAO.getVisualizationCount(seenSource.key, true).then(c => {
                seenSource.visualizationCount = c;
                return seenSource;
            });
        }, { concurrency: 1 })
            .then(seenSources => {
            // contains only sources that don't have a sourceKey (offline, connecting)
            const noKeySources = configuredSources.map(dataSource => {
                const hostPort = Utils.extractHostPort(dataSource.config.graphdb.url);
                return {
                    configIndex: dataSource.sourceId,
                    host: hostPort.host,
                    indexedDate: null,
                    key: null,
                    lastSeen: null,
                    name: Utils.hasValue(dataSource.config.name)
                        ? dataSource.config.name
                        : null,
                    port: hostPort.port,
                    state: dataSource.getState().code,
                    storeId: null,
                    visualizationCount: 0
                };
            });
            return seenSources.concat(noKeySources);
        });
    }
    /**
     * Create a new data-source.
     * Return the created source's configuration index.
     *
     * @param sourceConfig
     * @param [sourceConfig.name]         Name of the data-source
     * @param sourceConfig.graphdb        The configuration options of the graph database
     * @param sourceConfig.graphdb.vendor The vendor of the graph database ('neo4j', 'allegroGraph'...)
     * @param sourceConfig.index          The configuration options of the index
     * @param sourceConfig.index.vendor   The vendor of the index ('elasticSearch')
     */
    createSource(sourceConfig) {
        Utils.check.properties('config', sourceConfig, {
            graphdb: {
                required: true,
                properties: {
                    vendor: { required: true, type: 'string' }
                },
                policy: 'inclusive'
            },
            index: {
                required: true,
                properties: {
                    vendor: { required: true, type: 'string' }
                },
                policy: 'inclusive'
            },
            name: { type: 'string' }
        });
        return Config.add('dataSources', sourceConfig).then(configCount => {
            const configIndex = configCount - 1;
            const source = new DataSource(configIndex, this);
            this.sources.push(source);
            // don't wait for the connection to succeed (don't return this promise)
            source.connect(true);
            return configIndex;
        });
    }
    /**
     * Delete a data-source config.
     *
     * @param configIndex
     */
    deleteSourceConfig(configIndex) {
        const source = _.find(this.sources, { sourceId: configIndex });
        if (!source) {
            return Errors.business('not_found', `Data-source with configuration index ${configIndex} was not found.`, true);
        }
        if (source.getState().code !== 'offline') {
            return Errors.business('illegal_source_state', 'Data-source must be offline to be deleted.', true);
        }
        // the server cannot run with 0 sources
        if (this.sources.length === 1) {
            return Errors.business('not_implemented', 'Cannot delete the only configured data-source.', true);
        }
        // prevent the source from doing anything
        source.destroy();
        // remove the source from the source array
        _.remove(this.sources, { sourceId: configIndex });
        // mark the source for deletion in the configuration
        // this will allow the `configIndex` of other data-sources to be the same until the next boot
        return Config.set(`dataSources.${configIndex}.deleted`, true);
    }
    /**
     * Delete all data (visualizations, user-groups etc.) of a data-source
     * or, optionally, merge this data into another data-source.
     *
     * @param deletedSourceKey
     * @param [mergeTargetKey]
     */
    deleteSourceData(deletedSourceKey, mergeTargetKey) {
        const source = _.find(this.sources, s => s.getSourceKey(true) === deletedSourceKey);
        const deleteConfigPromise = source
            ? this.deleteSourceConfig(source.sourceId)
            : Bluebird.resolve();
        // 1) delete existing configuration, if any (checks that the source is disconnected)
        let deletedSourceState;
        return deleteConfigPromise
            .then(() => {
            // 2) get sourceStates (deleted and mergeTarget)
            const sourceKeys = [deletedSourceKey];
            if (mergeTargetKey !== undefined) {
                sourceKeys.push(mergeTargetKey);
            }
            return DbModels.dataSourceState.findAll({ where: { key: sourceKeys } });
        })
            .then(sourceStates => {
            // 3) check that the deleted sourceState exists
            const deletedSourceStateLookUp = _.find(sourceStates, { key: deletedSourceKey });
            if (!deletedSourceStateLookUp) {
                throw Errors.business('not_found', `Cannot delete data-source #${deletedSourceKey} (not found).`);
            }
            deletedSourceState = deletedSourceStateLookUp;
            // 4) if merging, check that the mergeTarget sourceState exists
            const mergeTargetSourceState = _.find(sourceStates, { key: mergeTargetKey });
            if (mergeTargetKey !== undefined) {
                if (mergeTargetSourceState === undefined) {
                    throw Errors.business('not_found', `Cannot merge data into data-source #${deletedSourceKey} (not found).`);
                }
                if (mergeTargetKey === deletedSourceKey) {
                    throw Errors.business('invalid_parameter', `Cannot merge data data-source #${deletedSourceKey} into itself.`);
                }
            }
            // 5) merge or delete (widgets, visualizations, visualizationFolders)
            let mergeOrDeletePromise = Bluebird.resolve();
            const affected = {
                visualizations: 0,
                folders: 0,
                groups: 0,
                alerts: 0,
                matches: 0,
                graphQueries: 0
            };
            let merging = false;
            const where = { sourceKey: deletedSourceKey };
            if (mergeTargetKey !== undefined) {
                // 5.a) merge
                merging = true;
                // update parameters
                const values = { sourceKey: mergeTargetKey };
                const options = {
                    // update only items from the deleted source
                    where: where,
                    // update only the sourceKey attribute
                    fields: ['sourceKey'],
                    // don't validate
                    validate: false,
                    // don't update the 'updatedAt' field
                    silent: true
                };
                const vizOptions = Utils.clone(options);
                vizOptions.where.sandbox = false;
                mergeOrDeletePromise = DbModels.visualization
                    .update(values, vizOptions)
                    // @ts-ignore this is correct, it's an error of sequelize or bluebird typing
                    .spread((count) => {
                    affected.visualizations = count;
                    return DbModels.visualizationFolder.update(values, options);
                })
                    .spread((count) => {
                    affected.folders = count;
                    // we only want to migrate non-builtin groups
                    const updateNonBuiltinGroupOptions = Utils.clone(options);
                    updateNonBuiltinGroupOptions.where.builtin = false;
                    return DbModels.group.update(values, updateNonBuiltinGroupOptions);
                })
                    .spread((count) => {
                    affected.groups = count;
                    // and we want to delete the builtin ones
                    const deleteBuiltinGroupWhere = Utils.clone(where);
                    deleteBuiltinGroupWhere.builtin = true;
                    return DbModels.group.destroy({ where: deleteBuiltinGroupWhere });
                })
                    .then(() => {
                    return DbModels.alert.update(values, options);
                })
                    .spread((count) => {
                    affected.alerts = count;
                    return DbModels.match.update(values, options);
                })
                    .spread((count) => {
                    affected.matches = count;
                    return DbModels.graphQuery.update(values, options);
                })
                    .spread((count) => {
                    affected.graphQueries = count;
                });
            }
            else {
                // 5.b) delete
                merging = false;
                mergeOrDeletePromise = DbModels.visualization
                    .destroy({ where: where })
                    .then(count => {
                    affected.visualizations = count;
                    return DbModels.visualizationFolder.destroy({ where: where });
                })
                    .then(count => {
                    affected.folders = count;
                    return DbModels.group.destroy({ where: where });
                })
                    .then(count => {
                    affected.groups = count;
                    return DbModels.alert.destroy({ where: where });
                })
                    .then(count => {
                    affected.alerts = count;
                    return DbModels.match.destroy({ where: where });
                })
                    .then(count => {
                    affected.matches = count;
                    return DbModels.graphQuery.destroy({ where: where });
                })
                    .then(count => {
                    affected.graphQueries = count;
                });
            }
            // 6) delete access rights
            // we don't migrate access rights because we don't want to mess up the access rights of the merge target
            return mergeOrDeletePromise
                .then(() => {
                // delete original access rights
                return DbModels.accessRight.destroy({ where: where });
            })
                .then(() => {
                // 7) delete the original source-state
                return deletedSourceState.destroy();
            })
                .then(() => {
                // 8) return a nice and clean result
                return { migrated: merging, affected: affected };
            });
        });
    }
    /**
     * Add `readAt` attribute to nodes and/or edges.
     *
     * @param options
     * @param [options.nodes]
     * @param [options.edges]
     * @param beginReadDate   Read timestamp in epoch time
     */
    addReadTimestamp(options, beginReadDate) {
        const nodes = options.nodes || [];
        const edges = options.edges || [];
        nodes.forEach(node => {
            node.readAt = beginReadDate;
        });
        edges.forEach(edge => {
            edge.readAt = beginReadDate;
        });
        return {
            nodes: nodes,
            edges: edges
        };
    }
    /**
     * Get the number of nodes in the graph.
     *
     * @param sourceKey Key of the data-source
     */
    getNodeCount(sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const stateCode = source.getState().code;
            // if we are indexing, the count is cached, use it
            if (stateCode === 'indexing' && Utils.hasValue(source.nodeCountCache)) {
                return source.nodeCountCache;
            }
            // if the indexation is done (state=ready) and the index can count, use the index
            if (stateCode === 'ready' && source.index.features.canCount) {
                return source.index.getSize('node');
            }
            // if the graph can count, use the graph
            if (source.graph.features.canCount) {
                return source.graph.getNodeCount(
                // approximate if indexation is ongoing
                // don't approximate in test mode
                stateCode === 'indexing' && !LKE.isTestMode());
            }
            // if we can't count, we soft-fail with the value 0
            return Bluebird.resolve(0);
        });
    }
    /**
     * Get a node of the graph.
     * A subgraph made of the single node is returned.
     *
     * @param options
     * @param options.sourceKey            Key of the data-source
     * @param options.id                   ID of the node
     * @param [options.alternativeId]      The property to match `id` on (instead of the actual ID)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the mutual edges)
     */
    getNode(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph
                .getNodesByID(_.defaults({ ids: [options.id] }, options))
                .get(0)
                .then(node => {
                const { nodes: publicNodes } = this.addReadTimestamp({ nodes: [node] }, currentDate);
                if (Utils.noValue(options.edgesTo)) {
                    return {
                        nodes: publicNodes,
                        edges: []
                    };
                }
                return this.getMutualEdges(options.sourceKey, [node.id], {
                    otherNodeIds: options.edgesTo,
                    edgeTypes: options.readableTypes
                }).then(edges => {
                    return {
                        nodes: publicNodes,
                        edges: edges
                    };
                });
            });
        });
    }
    /**
     * Get a list of nodes by ID.
     *
     * @param options
     * @param options.ids                  IDs of the nodes
     * @param options.sourceKey            Key of the data-source
     * @param [options.alternativeId]      The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing]      Whether to fail if there are missing nodes
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    getNodesByID(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph.getNodesByID(options).then(nodes => {
                const { nodes: publicNodes } = this.addReadTimestamp({ nodes: nodes }, currentDate);
                // we ensure that the order on which nodes are returned is the same as they were asked
                return DataService.orderItems(options.ids, publicNodes, options.alternativeId);
            });
        });
    }
    /**
     * Get a list of edges by ID.
     *
     * @param options
     * @param options.ids             IDs of the nodes
     * @param options.sourceKey       Key of the data-source
     * @param [options.alternativeId] The property to match `options.ids` on (instead of the actual IDs)
     * @param [options.ignoreMissing] Whether to fail if there are missing nodes
     */
    getEdgesByID(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph.getEdgesByID(options).then(edges => {
                const { edges: publicEdges } = this.addReadTimestamp({ edges: edges }, currentDate);
                // we ensure that the order on which edges are returned is the same as they were asked
                return DataService.orderItems(options.ids, publicEdges, options.alternativeId);
            });
        });
    }
    /**
     * Get a list of nodes and edges by ID.
     *
     * @param options
     * @param options.nodeIds                  IDs of the nodes
     * @param options.edgeIds                  IDs of the edges
     * @param options.sourceKey                Key of the data-source
     * @param [options.alternativeNodeId]      The property to match `options.nodeIds` on (instead of the actual IDs)
     * @param [options.alternativeNodeIdIndex] The index to use to resolve nodes by alternativeId
     * @param [options.alternativeEdgeId]      The property to match `options.edgeIds` on (instead of the actual IDs)
     * @param [options.alternativeEdgeIdIndex] The index to use to resolve edges by alternativeId
     * @param [options.ignoreMissing]          Whether to fail if there are missing nodes
     * @param [options.withDigest]             Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]             Whether to include the degree in the returned nodes
     * @param [options.readableCategories]     Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]          Exclusive list of edge types to restrict the result (used for the node degree and the edge digest)
     */
    getNodesAndEdgesByID(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph
                .getNodesByID(_.merge({
                ids: options.nodeIds,
                alternativeId: options.alternativeNodeId,
                alternativeIdIndex: options.alternativeNodeIdIndex
            }, options))
                .then(nodes => {
                return source.graph
                    .getEdgesByID(_.merge({
                    ids: options.edgeIds,
                    alternativeId: options.alternativeEdgeId,
                    alternativeIdIndex: options.alternativeEdgeIdIndex
                }, options))
                    .then(edges => {
                    const { nodes: publicNodes, edges: publicEdges } = this.addReadTimestamp({ nodes: nodes, edges: edges }, currentDate);
                    return {
                        isFiltered: false,
                        result: {
                            nodes: publicNodes,
                            edges: publicEdges
                        }
                    };
                });
            });
        });
    }
    /**
     * Get all the adjacent nodes and edges to one or more source nodes (`nodeIds`).
     * A subgraph made of the items that matched the expand query and the edges between them is returned.
     *
     * @param nodeIds                      IDs of the nodes to retrieve the neighbors for
     * @param options
     * @param [options.limit]              Maximum number of returned nodes
     * @param [options.limitType]          Order direction used to limit the result ('id', 'lowestDegree' or 'highestDegree')
     * @param [options.nodeCategories]     Exclusive list of node categories to restrict the result (used for the expand)
     * @param [options.edgeTypes]          Exclusive list of edge types to restrict the result (used for the expand)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree and the expand)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest, the mutual edges and the expand)
     * @param sourceKey                    Key of the data-source
     */
    getAdjacentNodes(nodeIds, options, sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const currentDate = Date.now();
            let ignoredNodeIds = nodeIds;
            if (Utils.hasValue(options.edgesTo)) {
                ignoredNodeIds = _.uniq(ignoredNodeIds.concat(options.edgesTo));
            }
            return source.graph
                .getAdjacentNodes(nodeIds, _.defaults({ ignoredNodeIds: ignoredNodeIds }, options))
                .then(nodes => {
                const { nodes: publicNodes } = this.addReadTimestamp({ nodes: nodes }, currentDate);
                // S := source nodes
                // N := neighbors nodes
                // V := visible nodes
                //
                // Our response will be made of every node in N
                // with edges of any type in: N-S, N-N, N-V
                // and with edges in: S-V and S-S
                //   - with type in `edgeTypes`
                //   - if S or V have category in `nodeCategories`
                //
                // The following query works by getting all the edges between S+N and S+N+V
                const neighborNodeIds = _.map(nodes, 'id');
                // TODO #1407 get edges in parallel
                // N-N, N-S, N-V
                return this.getMutualEdges(sourceKey, neighborNodeIds, {
                    otherNodeIds: ignoredNodeIds,
                    betweenFirstSet: true,
                    edgeTypes: options.readableTypes
                }).then(neighborsEdges => {
                    // S-V and S-S
                    return this.getMutualEdges(sourceKey, nodeIds, {
                        otherNodeIds: ignoredNodeIds,
                        edgeTypes: options.edgeTypes,
                        nodeCategories: options.nodeCategories
                    }).then(SSandSVEdges => {
                        return {
                            nodes: publicNodes,
                            edges: neighborsEdges.concat(SSandSVEdges)
                        };
                    });
                });
            });
        });
    }
    /**
     * Get the edges between two set of nodes.
     *
     * @param sourceKey                 Key of the data-source
     * @param nodeIds                   IDs of the first set of nodes
     * @param options
     * @param [options.otherNodeIds]    IDs of the second set of nodes
     * @param [options.betweenFirstSet] Whether to include also the edges between the nodes in the first set
     * @param [options.edgeTypes]       Exclusive list of edge types to restrict the result
     * @param [options.nodeCategories]  Exclusive list of node categories (of nodes in `otherNodeIds`) to restrict the result
     */
    getMutualEdges(sourceKey, nodeIds, options) {
        const currentDate = Date.now();
        let allOtherNodeIds = [];
        if (options.betweenFirstSet) {
            allOtherNodeIds = allOtherNodeIds.concat(nodeIds);
        }
        if (Utils.hasValue(options.otherNodeIds)) {
            allOtherNodeIds = _.union(allOtherNodeIds, options.otherNodeIds);
        }
        return this.withSource(sourceKey, false, source => {
            return source.graph
                .getMutualEdges(nodeIds, allOtherNodeIds, {
                edgeTypes: options.edgeTypes,
                nodeCategories: options.nodeCategories
            })
                .then(edges => {
                const { edges: publicEdges } = this.addReadTimestamp({ edges: edges }, currentDate);
                return publicEdges;
            });
        });
    }
    /**
     * Provide a neighborhood edge digest for a specific node.
     *
     * @param sourceKey Key of the data-source
     * @param nodeId    ID of the node
     */
    getEdgeDigest(sourceKey, nodeId) {
        return this.withSource(sourceKey, false, source => {
            return source.graph.getEdgeDigest(nodeId, {});
        });
    }
    /**
     * Get the digest (the number of adjacent nodes and edges grouped by node categories and edge types)
     * and/or the degree of a given subset of nodes (`ids`).
     * You can't get aggregated statistics of a subset of nodes containing one or more supernodes.
     * To get the statistics of a supernode invoke the API with only its node ID.
     *
     * @param ids                          IDs of the nodes to retrieve the statistics for
     * @param sourceKey                    Key of the data-source
     * @param options
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result
     */
    // TODO 2.6.0 getStatistics does not fail in node does not exists
    getStatistics(ids, sourceKey, options) {
        return this.withSource(sourceKey, false, source => {
            source.graph.checkNodeIds('ids', ids, 1);
            if (ids.length === 1) {
                const [id] = ids;
                return source.graph.getStatistics([id], options).then(statisticsResults => {
                    return statisticsResults.get(id);
                });
            }
            const result = {};
            return source.graph
                .isSuperNode(ids)
                .then(isSuperNodeResult => {
                const superNodes = ids.filter(id => isSuperNodeResult.get(id));
                if (superNodes.length > 0) {
                    throw Errors.business('invalid_parameter', 'You can\'t get aggregated statistics of a subset of nodes ' +
                        'containing one or more supernodes.');
                }
                if (options.withDigest) {
                    return source.graph.getAdjacencyDigest(ids).then(digest => {
                        result.digest = digest;
                    });
                }
                return;
            })
                .then(() => {
                if (options.withDegree) {
                    return source.graph
                        .getNodeDegree(ids, {
                        readableCategories: options.readableCategories,
                        readableTypes: options.readableTypes
                    })
                        .then(degree => {
                        result.degree = degree;
                    });
                }
                return;
            })
                .return(result);
        });
    }
    /**
     * Add a node to the graph.
     *
     * @param node
     * @param sourceKey Key of the data-source
     */
    createNode(node, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            const currentDate = Date.now();
            let createdNode;
            // 1) create node in the graph
            return source.graph
                .createNode(node)
                .then(newNode => {
                createdNode = newNode;
                // 2) update schema
                return Utils.neverReject(source.graphSchemaBuilder.nodeCreation(createdNode));
            })
                .then(() => {
                // 3) update index
                return Utils.neverReject(source.index.upsertEntry('node', source.filterNodeProperties(createdNode, true)));
            })
                .then(() => {
                const { nodes: publicNodes } = this.addReadTimestamp({ nodes: [createdNode] }, currentDate);
                return publicNodes[0];
            });
        });
    }
    /**
     * Throw a business error if `lastChangedDate` is after `readDate`.
     */
    checkEditConflict(type, lastChangeDate, readDate) {
        if (Utils.noValue(lastChangeDate) || Utils.noValue(readDate)) {
            return;
        }
        if (lastChangeDate > readDate) {
            throw Errors.business('edit_conflict', `${type} edit conflict. Changed on ${new Date(lastChangeDate)}`);
        }
    }
    /**
     * Update a subset of properties and categories of a node. Keep every other property and category of the node unchanged.
     *
     * @param nodeId                         ID of the node to update
     * @param nodeUpdate
     * @param [nodeUpdate.readAt]            Read timestamp in epoch time
     * @param [nodeUpdate.data]              Properties to update
     * @param [nodeUpdate.deletedProperties] Properties to delete
     * @param [nodeUpdate.addedCategories]   Categories to add
     * @param [nodeUpdate.deletedCategories] Categories to delete
     * @param sourceKey                      Key of the data-source
     */
    updateNode(nodeId, nodeUpdate, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            let updateDate;
            let originalNode;
            let updatedNode;
            return this.updateNodeMutex
                .acquire()
                .then(() => {
                // 1) get the node (check if it exists)
                return source.graph.getNodesByID({ ids: [nodeId] });
            })
                .then(nodes => {
                originalNode = nodes[0];
                // 2) check for edit conflicts
                const lastChangeDate = source.getLastEditDate('node', originalNode.id);
                this.checkEditConflict('Node', lastChangeDate, nodeUpdate.readAt);
                // 3) update the node in the graph
                return source.graph.updateNode(nodeId, nodeUpdate);
            })
                .then(node => {
                updatedNode = node;
                // 4) update the last change date
                updateDate = source.updateLastEditDate('node', originalNode.id);
                // 5) update the graph schema
                return Utils.neverReject(source.graphSchemaBuilder.nodeUpdate(originalNode, updatedNode));
            })
                .then(() => {
                // 6) update the node in the index (done last because this is the most likely to fail)
                return Utils.neverReject(source.index.upsertEntry('node', source.filterNodeProperties(updatedNode, true)));
            })
                .then(() => {
                const { nodes: publicNodes } = this.addReadTimestamp({ nodes: [updatedNode] }, updateDate);
                return publicNodes[0];
            })
                .finally(() => {
                this.updateNodeMutex.release();
            });
        });
    }
    /**
     * Delete a node and its adjacent edges from the graph.
     *
     * @param nodeId    ID of the node to delete
     * @param sourceKey Key of the data-source
     */
    deleteNode(nodeId, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            let nodeToDelete;
            return source.graph
                .getNodesByID({ ids: [nodeId] })
                .then(nodes => {
                nodeToDelete = nodes[0];
                return source.graph.deleteNode(nodeId);
            })
                .then(() => source.index.deleteEntry(nodeId, 'node'))
                .then(() => Utils.neverReject(source.graphSchemaBuilder.nodeDeletion(nodeToDelete)))
                .return(undefined);
        });
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     */
    runGraphQueryByContent(params) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.runGraphQuery(params);
        });
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     *
     * Invoked by both runGraphQueryByContent and runGraphQueryById.
     */
    runGraphQuery(params) {
        return __awaiter(this, void 0, void 0, function* () {
            let timeout;
            const { nodeCategories } = yield this.getSimpleSchema({ dataSource: params.dataSource });
            return this.withSource(params.dataSource, false, source => {
                let queries = [params.query];
                if (Utils.hasValue(params.templateData)) {
                    const templateFields = this.templateParser.parse(params.query, nodeCategories, true);
                    const modifiedQueries = this.templateParser.generateRawQueries(params.query, params.templateData, templateFields, source.graph.quote.bind(source.graph));
                    queries = _.map(modifiedQueries, 'query');
                }
                const maxLimit = Config.get('advanced.rawQueryLimit');
                // set the default value for limit and timeout
                const rawQueryOptions = {
                    dialect: params.dialect,
                    queries: queries,
                    limit: params.limit || maxLimit,
                    withDigest: params.withDigest,
                    withDegree: params.withDegree,
                    readableCategories: params.readableCategories,
                    readableTypes: params.readableTypes
                };
                Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
                const maxTimeout = Config.get('advanced.rawQueryTimeout');
                timeout = params.timeout || maxTimeout;
                Utils.check.integer('options.timeout', timeout, 1, maxTimeout);
                const currentDate = Date.now();
                return source.graph
                    .rawQuery(rawQueryOptions, true)
                    .then(readableStream => {
                    return Utils.mergeReadable(readableStream, timeout);
                })
                    .then((merged) => __awaiter(this, void 0, void 0, function* () {
                    let truncatedByLimit = false;
                    if (merged.result.length === rawQueryOptions.limit) {
                        truncatedByLimit = true;
                    }
                    let truncatedByAccess = false;
                    let filteredResult = yield Promise.all(merged.result.map((subGraph) => __awaiter(this, void 0, void 0, function* () {
                        if (Utils.hasValue(params.filterSubGraph)) {
                            return yield params.filterSubGraph(subGraph);
                        }
                        else {
                            return subGraph;
                        }
                    })));
                    filteredResult = _.filter(filteredResult, r => Utils.hasValue(r));
                    if (filteredResult.length !== merged.result.length) {
                        truncatedByAccess = true;
                    }
                    if (merged.timeout) {
                        Log.warn(`Raw Query "${params.query}" timed out after ${timeout} ms.`);
                        throw new GraphRequestTimeout_1.GraphRequestTimeout(GraphRequestTimeout_1.Vendor.LINKURIOUS);
                    }
                    const nodes = _.uniqBy(_.flatMap(filteredResult, 'nodes'), 'id');
                    const edges = _.uniqBy(_.flatMap(filteredResult, 'edges'), 'id');
                    const { nodes: publicNodes, edges: publicEdges } = this.addReadTimestamp({ nodes: nodes, edges: edges }, currentDate);
                    const nodeIds = _.map(nodes, 'id');
                    // we want the edges between the resulting nodes only if no edge was returned by the query itself
                    let otherNodeIds = publicEdges.length > 0 ? [] : Utils.clone(nodeIds);
                    if (Utils.hasValue(params.edgesTo)) {
                        // plus the edges between these nodes and `edgesTo`
                        otherNodeIds = otherNodeIds.concat(params.edgesTo);
                    }
                    return this.getMutualEdges(params.dataSource, nodeIds, {
                        otherNodeIds: otherNodeIds,
                        edgeTypes: params.readableTypes,
                        nodeCategories: params.readableCategories
                    }).then(mutualEdges => {
                        return {
                            truncatedByLimit: truncatedByLimit,
                            truncatedByAccess: truncatedByAccess,
                            nodes: publicNodes,
                            edges: _.unionBy(publicEdges, mutualEdges, 'id')
                        };
                    });
                }));
            });
        });
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     * An array of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @param params
     * @param params.sourceKey           Key of the data-source
     * @param params.query               The graph query
     * @param [params.columns]           Columns among the returned values of the query to return as scalar values
     * @param params.columns.type        Type of the column
     * @param params.columns.columnName  Name of the column in the query
     * @param [params.dialect]           Dialect of the graph query (defaults to the first supported dialect of the data-source)
     * @param [params.limit]             Maximum number of matched subgraphs
     * @param [params.timeout]           Maximum execution time in milliseconds
     */
    alertPreview(params) {
        Utils.check.exist('options', params);
        let timeout;
        return this.withSource(params.dataSource, false, source => {
            const maxLimit = Config.get('alerts.maxMatchesLimit');
            // set the default value for limit and timeout
            const rawQueryOptions = {
                dialect: params.dialect,
                queries: [params.query],
                limit: params.limit || maxLimit
            };
            Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
            const maxTimeout = Config.get('alerts.maxRuntimeLimit');
            timeout = params.timeout || maxTimeout;
            Utils.check.integer('options.timeout', timeout, 1, maxTimeout);
            const currentDate = Date.now();
            return source.graph
                .rawQuery(rawQueryOptions, true)
                .then((readableStream) => {
                return Utils.mergeReadable(readableStream, timeout);
            })
                .then((mergedStream) => {
                if (mergedStream.timeout) {
                    Log.warn(`Query "${params.query}" timed out after ${timeout} ms.`);
                }
                const matchesToCreate = [];
                for (const match of mergedStream.result) {
                    const matchAttributes = {
                        nodes: match.nodes,
                        edges: match.edges,
                        columns: []
                    };
                    if (Utils.hasValue(params.columns)) {
                        params.columns.forEach(column => {
                            const scalarValue = match.properties[column.columnName];
                            // we apply the same rule as in createMatchesInBulk
                            if ((column.type === 'number' && typeof scalarValue === 'number') ||
                                (column.type === 'string' && Utils.isNEString(scalarValue))) {
                                matchAttributes.columns.push(scalarValue);
                            }
                            else {
                                // else we silently ignore that the scalar value is undefined or of an incorrect type
                                matchAttributes.columns.push(null);
                            }
                        });
                    }
                    matchesToCreate.push(matchAttributes);
                }
                return matchesToCreate;
            })
                .map(match => {
                const { nodes, edges } = this.addReadTimestamp(match, currentDate);
                return {
                    nodes: nodes,
                    edges: edges,
                    columns: _.compact(match.columns)
                };
            });
        }).then(results => ({ results: results }));
    }
    /**
     * Get all the nodes and edges matching the given graph query.
     * A stream of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @param options
     * @param options.sourceKey Key of the data-source
     * @param options.query     The graph query
     * @param [options.dialect] Dialect of the graph query (defaults to the first supported dialect of the data-source)
     * @param [options.limit]   Maximum number of matched subgraphs
     */
    alertQuery(options) {
        Utils.check.exist('options', options);
        return this.withSource(options.sourceKey, false, source => {
            // TODO Configuration should return a default value for optional fields
            const maxLimit = Config.get('alerts.maxMatchesLimit', 5000);
            // set the default value for limit
            const rawQueryOptions = {
                dialect: options.dialect,
                queries: [options.query],
                limit: options.limit || maxLimit
            };
            Utils.check.integer('options.limit', rawQueryOptions.limit, 1, maxLimit);
            // set populated to false, we don't need the data to create matches
            return source.graph.rawQuery(rawQueryOptions, false);
        });
    }
    /**
     * Get the number of edges in the graph.
     *
     * @param sourceKey Key of the data-source
     */
    getEdgeCount(sourceKey) {
        return this.withSource(sourceKey, false, source => {
            const stateCode = source.getState().code;
            // if we are indexing, the count is cached, use it
            if (stateCode === 'indexing' && Utils.hasValue(source.edgeCountCache)) {
                return source.edgeCountCache;
            }
            // if the indexation is done (state=ready) and the index can count, use the index
            if (stateCode === 'ready' && source.index.features.canCount) {
                return source.index.getSize('edge');
            }
            // if the graph can count, use the graph
            if (source.graph.features.canCount) {
                return source.graph.getEdgeCount(
                // approximate if indexation is ongoing
                // don't approximate in test mode
                stateCode === 'indexing' && !LKE.isTestMode());
            }
            // if we can't count, we soft-fail with the value 0
            return Bluebird.resolve(0);
        });
    }
    /**
     * Get an edge of the graph.
     * A subgraph made of the edge and its extremities is returned.
     *
     * @param options
     * @param options.sourceKey            Key of the data-source
     * @param options.id                   ID of the edge
     * @param [options.alternativeId]      The property to match `id` on (instead of the actual ID)
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the mutual edges)
     */
    getEdge(options) {
        return this.withSource(options.sourceKey, false, source => {
            const currentDate = Date.now();
            return source.graph
                .getEdgesByID(_.defaults({ ids: [options.id] }, options))
                .get(0)
                .then(edge => {
                // retrieve the extremities of the edge
                return source.graph
                    .getNodesByID({
                    ids: [edge.source, edge.target],
                    withDigest: options.withDigest,
                    withDegree: options.withDegree,
                    readableCategories: options.readableCategories,
                    readableTypes: options.readableTypes
                })
                    .then(nodes => {
                    // add the read timestamp to the edge and its extremities
                    const { nodes: publicNodes, edges: publicEdges } = this.addReadTimestamp({ nodes: nodes, edges: [edge] }, currentDate);
                    return this.getMutualEdges(options.sourceKey, _.map(nodes, 'id'), {
                        otherNodeIds: options.edgesTo,
                        betweenFirstSet: true,
                        edgeTypes: options.readableTypes
                    }).then(edges => {
                        // return a subgraph made of the two extremities, the edge
                        // and all the edges between the extremities and `edgesTo`
                        return {
                            nodes: publicNodes,
                            // the edge with ID equal to `options.id` comes first
                            edges: _.uniqBy(publicEdges.concat(edges), 'id')
                        };
                    });
                });
            });
        });
    }
    /**
     * Add an edge to the graph.
     *
     * @param edge
     * @param sourceKey Key of the data-source
     */
    createEdge(edge, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            const currentDate = Date.now();
            let createdEdge;
            // 1) create edge in the graph
            return source.graph
                .createEdge(edge)
                .then(newEdge => {
                createdEdge = newEdge;
                // 2) update schema
                return Utils.neverReject(source.graphSchemaBuilder.edgeCreation(createdEdge));
            })
                .then(() => {
                // 3) update index
                return Utils.neverReject(source.index.upsertEntry('edge', source.filterEdgeProperties(createdEdge, true)));
            })
                .then(() => {
                const { edges: publicEdges } = this.addReadTimestamp({ edges: [createdEdge] }, currentDate);
                return publicEdges[0];
            });
        });
    }
    /**
     * Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     *
     * @param edgeId                         ID of the edge to update
     * @param edgeUpdate
     * @param [edgeUpdate.readAt]              Read timestamp in epoch time
     * @param [edgeUpdate.data]              Properties updates
     * @param [edgeUpdate.deletedProperties] Properties to delete
     * @param sourceKey                      Key of the data-source
     */
    updateEdge(edgeId, edgeUpdate, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            let updateDate;
            let originalEdge;
            let updatedEdge;
            return this.updateEdgeMutex
                .acquire()
                .then(() => {
                // 1) get the edge (check if it exists)
                return source.graph.getEdgesByID({ ids: [edgeId] });
            })
                .then(edges => {
                originalEdge = edges[0];
                // 2) check for edit conflicts
                const lastChangeDate = source.getLastEditDate('edge', originalEdge.id);
                this.checkEditConflict('Edge', lastChangeDate, edgeUpdate.readAt);
                // 3) update the edge in the graph
                return source.graph.updateEdge(edgeId, edgeUpdate);
            })
                .then(edge => {
                updatedEdge = edge;
                // 4) update the last change date
                updateDate = source.updateLastEditDate('edge', originalEdge.id);
                // 5) update the schema
                return Utils.neverReject(source.graphSchemaBuilder.edgeUpdate(originalEdge, updatedEdge));
            })
                .then(() => {
                // 6) update the edge in the index
                return Utils.neverReject(source.index.upsertEntry('edge', source.filterEdgeProperties(updatedEdge, true)));
            })
                .then(() => {
                const { edges: publicEdges } = this.addReadTimestamp({ edges: [updatedEdge] }, updateDate);
                return publicEdges[0];
            })
                .finally(() => {
                this.updateEdgeMutex.release();
            });
        });
    }
    /**
     * Delete an edge from the graph.
     *
     * @param edgeId    ID of the edge to delete
     * @param sourceKey Key of the data-source
     */
    deleteEdge(edgeId, sourceKey) {
        return this.withSource(sourceKey, true, source => {
            let edgeToDelete;
            return source.graph
                .getEdgesByID({ ids: [edgeId] })
                .then(edges => {
                edgeToDelete = edges[0];
                return source.graph.deleteEdge(edgeId);
            })
                .then(() => source.index.deleteEntry(edgeId, 'edge'))
                .then(() => Utils.neverReject(source.graphSchemaBuilder.edgeDeletion(edgeToDelete)))
                .return(undefined);
        });
    }
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     *
     * @param searchOptions        The search options
     * @param sourceKey            Key of the data-source
     * @param options
     * @param [options.withDigest] Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree] Whether to include the degree in the returned nodes
     */
    searchIndex(searchOptions, sourceKey, options) {
        return this.withSource(sourceKey, false, source => {
            return source.index.search(searchOptions).then(response => {
                return Bluebird.resolve()
                    .then(() => {
                    if (response.type === 'node') {
                        return this.getNodesByID({
                            ids: response.results,
                            ignoreMissing: true,
                            sourceKey: sourceKey,
                            alternativeId: response.alternativeId,
                            withDigest: options.withDigest,
                            withDegree: options.withDegree
                        });
                    }
                    else {
                        return this.getEdgesByID({
                            ids: response.results,
                            ignoreMissing: true,
                            sourceKey: sourceKey,
                            alternativeId: response.alternativeId
                        });
                    }
                })
                    .then(items => {
                    const missingIds = Utils.checkMissing(response.type, response.results, items, response.alternativeId, undefined, false);
                    // we create a fake entry node/edge for every missing id
                    // a missing id can be the result of:
                    // - a document without alternativeId in the search index
                    //   - in this case the document get a special "[missingAlternativeId]" id
                    // - no node in the graph db with such id or alternativeId
                    // the only purpose of these entries is to throw a frontend error if the user clicks on them
                    let results;
                    if (response.type === 'node') {
                        results = items.concat(_.map(missingIds, id => ({ id: id, categories: [], data: {}, readAt: 0 })));
                    }
                    else {
                        results = items.concat(_.map(missingIds, id => ({
                            id: id,
                            type: '',
                            source: '',
                            target: '',
                            data: {},
                            readAt: 0
                        })));
                    }
                    return {
                        type: response.type,
                        totalHits: response.totalHits,
                        moreResults: response.moreResults,
                        results: results
                    };
                });
            });
        });
    }
    /**
     * Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * A subgraph made of the items that matched the search query and the edges between them is returned.
     *
     * @param searchOptions                The search options
     * @param sourceKey                    Key of the data-source
     * @param options
     * @param [options.edgesTo]            IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @param [options.withDigest]         Whether to include the adjacency digest in the returned nodes
     * @param [options.withDegree]         Whether to include the degree in the returned nodes
     * @param [options.readableCategories] Exclusive list of node categories to restrict the result (used for the node degree)
     * @param [options.readableTypes]      Exclusive list of edge types to restrict the result (used for the node degree, the edge digest and the mutual edges)
     */
    searchFull(searchOptions, sourceKey, options) {
        return this.searchIndex(searchOptions, sourceKey, options)
            .then(r => {
            // if type === 'node'
            // we need to fetch the edges between the nodes of the search response
            // plus the edges between these nodes and `edgesTo`
            // if type === 'edge'
            // we need to fetch the extremities of the edges of the search response
            // plus the edges between these nodes
            // plus the edges between these nodes and `edgesTo`
            return Bluebird.resolve().then(() => {
                if (searchOptions.type === 'edge') {
                    // fetch the extremities of the edges in the search response
                    const edges = r.results;
                    const nodeIdsSet = new Set();
                    edges.forEach(edge => {
                        nodeIdsSet.add(edge.source);
                        nodeIdsSet.add(edge.target);
                    });
                    return this.getNodesByID(_.defaults({
                        ids: Array.from(nodeIdsSet),
                        sourceKey: sourceKey
                    }, 
                    // TODO 2.6.0 ignore missing?
                    options));
                }
                return r.results;
            });
        })
            .then((nodes) => {
            return this.getMutualEdges(sourceKey, _.map(nodes, 'id'), {
                otherNodeIds: options.edgesTo,
                betweenFirstSet: true,
                edgeTypes: options.readableTypes
            }).then(edges => {
                return {
                    nodes: nodes,
                    edges: edges
                };
            });
        });
    }
    /**
     * List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     */
    getSimpleSchema(params) {
        return this.withSource(params.dataSource, false, source => {
            return source.graph.getSimpleSchema();
        });
    }
    /**
     * List all node category names.
     *
     * @param sourceKey Key of the data-source
     */
    getSchemaNodeTypeNames(sourceKey) {
        return this.getSchemaNodeTypes({ sourceKey: sourceKey, omitProperties: true })
            .then(r => {
            return _.map(r.results, (type) => type.name);
        })
            .then(nodeCategories => {
            // remove the null category name representing nodes with no category
            return _.filter(nodeCategories, category => category !== null);
        });
    }
    /**
     * List all edge type names.
     *
     * @param sourceKey Key of the data-source
     */
    getSchemaEdgeTypeNames(sourceKey) {
        return this.getSchemaEdgeTypes({
            sourceKey: sourceKey,
            omitProperties: true
        }).then(r => {
            // the null category name can't exist for edge types
            return _.map(r.results, (type) => type.name);
        });
    }
    /**
     * List all node categories (including property keys, counts and types).
     *
     * @param options options
     * @param options.sourceKey        Key of the data-source
     * @param [options.includeType]    Whether to include detected property types
     * @param [options.omitProperties] Whether to omit properties
     */
    getSchemaNodeTypes(options) {
        return this.withSource(options.sourceKey, false, source => {
            return Bluebird.resolve()
                .then(() => {
                return GraphSchemaDAO.getAllNodeTypes(options.sourceKey, options.omitProperties);
            })
                .then(nodeTypes => {
                // if type not required
                if (options.omitProperties || !options.includeType) {
                    return nodeTypes;
                }
                return DataService.populatePropertyTypes(source, 'node', nodeTypes);
            });
        }).then(schemaTypes => ({ results: schemaTypes }));
    }
    /**
     * List all edge types (including property keys, counts and types).
     *
     * @param options options
     * @param options.sourceKey        Key of the data-source
     * @param [options.includeType]    Whether to include detected property types
     * @param [options.omitProperties] Whether to omit properties
     */
    getSchemaEdgeTypes(options) {
        return this.withSource(options.sourceKey, false, source => {
            // if edges are not indexed with an internal index
            if (source.config.index.skipEdgeIndexation && !source.index.features.external) {
                return this.getSimpleSchema({ dataSource: source.getSourceKey(true) }).then(schema => {
                    return schema.edgeTypes.map(type => ({
                        name: type,
                        count: 1,
                        properties: []
                    }));
                });
            }
            return Bluebird.resolve()
                .then(() => {
                return GraphSchemaDAO.getAllEdgeTypes(options.sourceKey, options.omitProperties);
            })
                .then(edgeTypes => {
                // if type not required
                if (options.omitProperties || !options.includeType) {
                    return edgeTypes;
                }
                return DataService.populatePropertyTypes(source, 'edge', edgeTypes);
            });
        }).then(schemaTypes => ({ results: schemaTypes }));
    }
    /**
     * List all node properties.
     *
     * @param options options
     * @param options.sourceKey     Key of the data-source
     * @param [options.includeType] Whether to include detected property types
     * @param [options.omitNoIndex] Whether to omit no-index properties
     */
    getSchemaNodeProperties(options) {
        // omitNoIndex is implemented in data proxy
        return this.withSource(options.sourceKey, false, source => {
            return Bluebird.resolve()
                .then(() => {
                return GraphSchemaDAO.getAllNodeProperties(options.sourceKey);
            })
                .then(props => {
                if (!options.includeType) {
                    return props;
                }
                return DataService.populatePropertyTypes(source, 'node', [
                    { properties: props }
                ]).return(props);
            });
        });
    }
    /**
     * List all edge properties.
     *
     * @param options options
     * @param options.sourceKey     Key of the data-source
     * @param [options.includeType] Whether to include detected property types
     * @param [options.omitNoIndex] Whether to omit no-index properties
     */
    getSchemaEdgeProperties(options) {
        // omitNoIndex is implemented in data proxy
        return this.withSource(options.sourceKey, false, source => {
            return Bluebird.resolve()
                .then(() => {
                return GraphSchemaDAO.getAllEdgeProperties(options.sourceKey);
            })
                .then(props => {
                if (!options.includeType) {
                    return props;
                }
                return DataService.populatePropertyTypes(source, 'edge', [
                    { properties: props }
                ]).return(props);
            });
        });
    }
    /**
     * Connect all data-sources.
     */
    connectSources() {
        let connectedDataSources = 0;
        return Bluebird.each(this.sources, source => {
            if (source.destroyed) {
                // skip the source if it was deleted concurrently (while iterating)
                return;
            }
            return source.connect(true).then(() => {
                if (source.isConnected()) {
                    connectedDataSources++;
                }
            });
        }).then(() => {
            LKE.getStateMachine().set('DataService', 'up', `${connectedDataSources}/${this.sources.length} data-sources connected.`);
        });
    }
    /**
     * Disconnect all data-sources.
     */
    disconnectAll() {
        this.sources.forEach(source => source.disconnect());
    }
    /**
     * @param [isStartup] Whether this is called at startup
     */
    indexSources(isStartup = false) {
        return Bluebird.each(this.sources, source => {
            if (source.destroyed) {
                // skip the source if it was deleted concurrently (while iterating)
                return;
            }
            if (!source.isConnected()) {
                return Bluebird.resolve();
            }
            // skip index if forceReindex is not true OR index is not configured
            if (isStartup && (source.needConfig() || source.config.index.forceReindex !== true)) {
                return Bluebird.resolve();
            }
            return this.indexSource(source.getSourceKey()).catch(error => {
                Log.error('Indexation of data-source #' + source.sourceId + ' failed.', error);
            });
        }).return();
    }
    /**
     * Get the source key of the currently indexed data-source.
     */
    getIndexedSource() {
        return this.indexedSource;
    }
    /**
     * Reindex the graph database.
     * Don't wait for the indexation to finish.
     *
     * @param sourceKey Key of the data-source
     */
    asyncIndexSource(sourceKey) {
        const source = this.resolveSource(sourceKey);
        const indexedSource = this.getIndexedSource();
        if (indexedSource !== null) {
            if (indexedSource === sourceKey) {
                return Errors.business('illegal_source_state', `Data-source #${source.sourceId} is already indexing.`, true);
            }
            return Errors.business('illegal_source_state', `Cannot index data-source #${source.sourceId}: another data-source is indexing.`, true);
        }
        // note: we don't wait for the indexation to finish, we don't return this promise on purpose
        this.indexSource(sourceKey).catch(() => {
            // ignore the rejection in this non-returned promise
        });
        return Bluebird.resolve();
    }
    /**
     * @param sourceKey Key of the data-source
     */
    indexSource(sourceKey) {
        // ensure that the source is connected
        const source = this.resolveSource(sourceKey);
        if (!source.isConnected()) {
            return Bluebird.resolve();
        }
        // if we are already indexing, don't go further
        if (LKE.getStateMachine().get('DataService').name === 'indexing') {
            return Bluebird.resolve();
        }
        LKE.getStateMachine().set('DataService', 'indexing');
        // set currently indexing source
        this.indexedSource = sourceKey;
        return source
            .indexSource()
            .finally(() => {
            this.indexedSource = null;
            LKE.getStateMachine().set('DataService', 'up');
        })
            .catch((e) => {
            Log.error('Indexation failed: ', e.stack ? e.stack : e);
            return Bluebird.reject(e);
        });
    }
    /**
     * Check that the given graph query is syntactically correct. Parse the query if it's a template.
     */
    checkGraphQuery(params) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.withSource(params.dataSource, false, (source) => __awaiter(this, void 0, void 0, function* () {
                let graphInput;
                let templateFields;
                let type = graphQueryParams_1.GraphQueryType.STATIC;
                let query = params.query;
                let correctionTable = [];
                if (umd_1.QueryTemplateParser.isTemplate(query)) {
                    // 1) parse the query if it's a template
                    type = graphQueryParams_1.GraphQueryType.TEMPLATE;
                    const schema = yield source.graph.getSimpleSchema();
                    templateFields = this.templateParser.parse(query, schema.nodeCategories);
                    graphInput = umd_1.QueryTemplateParser.getInputType(templateFields);
                    const templateData = source.graph.getDummyTemplateData(templateFields);
                    const quote = source.graph.quote.bind(source.graph);
                    const queries = this.templateParser.generateRawQueries(query, templateData, templateFields, quote);
                    // We check the syntax of only the first query
                    // because the dummy template data will only generate one query
                    query = queries[0].query;
                    correctionTable = queries[0].correctionTable;
                }
                // 2) check if the query is syntactically correct and find out if it's a write query or not
                const write = source.graph.checkQuery(query);
                try {
                    // 3) execute a dry run of the query
                    yield source.graph.dryRun(query);
                }
                catch (error) {
                    if (error.data && error.data.offset) {
                        error.data.offset = umd_1.QueryTemplateParser.correctOffset(error.data.offset, correctionTable);
                    }
                    throw error;
                }
                return {
                    write: write,
                    graphInput: graphInput,
                    templateFields: templateFields,
                    type: type
                };
            }));
        });
    }
    /**
     * Add `defaultStyles` and `defaultCaptions` to all dataSourceStates.
     *
     * Since LKE v2.5.0, the styles format and palette have been changed and the default styles and
     * captions have been moved from the configuration file to the data-source states so that they
     * can be configured per data-source.
     *
     * The migration steps are:
     * - Save `palette` , `defaultStyles`, `defaultCaption` from the configuration to the source state
     * - Remove the `palette` from the configuration
     * - Remove the `defaultStyles` from the configuration
     * - Remove the `defaultCaptions` from the configuration
     */
    migrateStyles() {
        // legacy configuration: defaultStyles, defaultCaptions and palette are removed in LKE v2.5.0
        const defaultStyles = Config.get('defaultStyles');
        const defaultCaptions = Config.get('defaultCaptions');
        const palette = Config.get('palette');
        if (Utils.noValue(defaultStyles) || Utils.noValue(defaultCaptions) || Utils.noValue(palette)) {
            // we cannot perform the migration without defaultStyles, defaultCaptions, or the palette
            // from the old configuration so we skip the migration
            // but these fields can also be empty if the config file was deleted before migration
            // so we add defaultStyles and captions to the source states not migrated
            return DbModels.dataSourceState
                .update({
                defaultCaptions: DesignUtils.DEFAULT_CAPTIONS,
                defaultStyles: DesignUtils.DEFAULT_STYLES
            }, { where: { defaultStyles: { $eq: null } } })
                .return();
        }
        // 1) save `defaultStyles`, `defaultCaption`, `palette` in the source state
        // the migration will be completed when the source is connected
        return DbModels.dataSourceState
            .update({
            defaultStyles: {
                'PreV2.5.0Config': true,
                'defaultStyles': defaultStyles,
                'defaultCaptions': defaultCaptions,
                'palette': palette
            }
        }, { where: { defaultStyles: { $eq: null } } })
            .then(() => {
            // 2) delete config.palette
            Config.set('palette', undefined);
            // 3) delete config.defaultStyles
            Config.set('defaultStyles', undefined);
            // 4) delete config.defaultCaptions
            Config.set('defaultCaptions', undefined);
        })
            .return();
    }
    /**
     * Add type information to each property in `schemaTypes`.
     *
     * Possible type values are:
     * - string
     * - integer
     * - float
     * - boolean
     * - date
     *
     * @param source
     * @param itemType    'node' or 'edge'
     * @param schemaTypes
     */
    static populatePropertyTypes(source, itemType, schemaTypes) {
        source.assertReady();
        return source.index
            .getPropertyTypes(itemType)
            .then(mapping => {
            schemaTypes.forEach(type => {
                type.properties.forEach(property => {
                    property.type = mapping[property.key];
                });
            });
        })
            .return(schemaTypes);
    }
    /**
     * Sort nodes or edges in the required order.
     *
     * @param order         Sorted item IDs
     * @param items         Nodes or edges
     * @param alternativeId
     */
    static orderItems(order, items, alternativeId) {
        const byId = Utils.hasValue(alternativeId)
            ? item => [item.data[alternativeId], item]
            : item => [item.id, item];
        const index = new Map(items.map(byId));
        return _.compact(_.map(order, id => index.get(id)));
    }
}
module.exports = new DataService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7OztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsK0NBQTJGO0FBQzNGLDRCQUE0QjtBQUU1QixXQUFXO0FBQ1gsZ0NBQWlDO0FBQ2pDLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUN2QyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0FBQy9DLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUU3QixTQUFTO0FBQ1QsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBb0IsQ0FBQztBQUM5RCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQWdCLENBQUM7QUFTdEUsaURBQTRDO0FBQzVDLGlGQUFvRjtBQUNwRix1RkFBa0Y7QUFPbEYsK0VBQXdFO0FBRXhFLE1BQU0sYUFBYSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBRXhELE1BQU0sV0FBVztJQWFmO1FBWk8sWUFBTyxHQUFpQixFQUFFLENBQUM7UUFFbEMscURBQXFEO1FBQzdDLGtCQUFhLEdBQWtCLElBQUksQ0FBQztRQUU1QyxtQ0FBbUM7UUFDM0IsZ0JBQVcsR0FBOEIsRUFBRSxDQUFDO1FBRTVDLG9CQUFlLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyQyxvQkFBZSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFJM0MsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSx5QkFBbUIsQ0FDM0MsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUMvQixNQUFNLElBQUksK0NBQXNCLENBQUMsaUJBQWlCLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDakUsQ0FBQyxFQUNELFVBQVUsQ0FBQyxFQUFFO1lBQ1gsTUFBTSxJQUFJLFNBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNLLG9CQUFvQjtRQUMxQixNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBK0IsQ0FBQztRQUU5RSxvQ0FBb0M7UUFDcEMsTUFBTSxxQkFBcUIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTdGLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUU7WUFDekQsb0JBQW9CO1lBQ3BCLE9BQU87U0FDUjtRQUVELHVFQUF1RTtRQUN2RSxNQUFNLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFTyxXQUFXO1FBQ2pCLE1BQU0sT0FBTyxHQUFpQixFQUFFLENBQUM7UUFDaEMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFlLEVBQUUsUUFBZ0IsRUFBRSxFQUFFO1lBQ3JGLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDL0MsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3hCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsRUFBRSwwQ0FBMEMsQ0FBQyxDQUFDO1NBQzdGO1FBQ0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDekIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxVQUFVLENBQ2hCLHNCQUF1QyxFQUN2QyxTQUFrQjtJQUNsQixvRUFBb0U7SUFDcEUsTUFLb0I7UUFFcEIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQzFELElBQUksU0FBUyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUNwQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDeEY7UUFDRCxJQUFJLFNBQVMsSUFBSSxhQUFhLEVBQUU7WUFDOUIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGtDQUFrQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2xGO1FBQ0QsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FDVCxNQUFNLENBQUMsTUFHTixDQUFDLENBQ0g7YUFDQSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWCxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssd0JBQXdCLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFFO2dCQUNoRSxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDbkQsTUFBTSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2dCQUM5QixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3RCO1lBQ0QsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSxhQUFhLENBQUMsc0JBQXVDO1FBQzFELDREQUE0RDtRQUM1RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsRUFBRTtZQUN6QyxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQ3BCLHdCQUF3QixFQUN4Qiw2Q0FBNkMsQ0FDOUMsQ0FBQztTQUNIO1FBQ0QsSUFBSSxDQUFDLENBQUM7UUFDTixJQUFJLE1BQU0sQ0FBQztRQUVYLDhCQUE4QjtRQUM5QixJQUFJLE9BQU8sc0JBQXNCLEtBQUssUUFBUSxFQUFFO1lBQzlDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3hDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN6QixJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssc0JBQXNCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO29CQUNuRSxPQUFPLE1BQTZCLENBQUM7aUJBQ3RDO2FBQ0Y7WUFDRCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHdCQUF3QixFQUN4QixlQUFlLEdBQUcsc0JBQXNCLEdBQUcsZ0JBQWdCLENBQzVELENBQUM7U0FDSDtRQUVELHVCQUF1QjtRQUN2QixJQUFJLE9BQU8sc0JBQXNCLEtBQUssUUFBUSxFQUFFO1lBQzlDLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsOEJBQThCLENBQUMsQ0FBQztTQUMvRDtRQUVELGFBQWE7UUFDYixNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQ2xELDZGQUE2RjtRQUM3RixJQUFJLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDekIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQix3QkFBd0IsRUFDeEIsZUFBZSxHQUFHLHNCQUFzQixHQUFHLG9CQUFvQixDQUNoRSxDQUFDO2FBQ0g7WUFDRCxPQUFPLE1BQTZCLENBQUM7U0FDdEM7UUFFRCxlQUFlO1FBQ2YsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDbEMsU0FBUzthQUNWO1lBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxLQUFLLHNCQUFzQixFQUFFO2dCQUM3RCxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekIsZUFBZTtnQkFDZixJQUFJLENBQUMsV0FBVyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsTUFBTSxDQUFDO2dCQUNsRCxPQUFPLE1BQTZCLENBQUM7YUFDdEM7U0FDRjtRQUVELE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsd0JBQXdCLEVBQ3hCLGVBQWUsR0FBRyxzQkFBc0IsR0FBRyxzQ0FBc0MsQ0FDbEYsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksZUFBZSxDQUNwQixVQUEwRCxFQUFFO1FBRTVELE1BQU0sRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLEdBQUcsT0FBTyxDQUFDO1FBQzNDLE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FDckIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDbkIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzNCLE1BQU0sUUFBUSxHQUFvQjtnQkFDaEMsV0FBVyxFQUFFLENBQUMsQ0FBQyxRQUFRO2dCQUN2QixTQUFTLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO2dCQUNsQixRQUFRLEVBQUUsQ0FBQyxDQUFDLFFBQVE7Z0JBQ3BCLEdBQUcsRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDOUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxjQUFjLEVBQUU7Z0JBQ3hCLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtnQkFDcEIsUUFBUSxFQUFFO29CQUNSLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRTtpQkFDM0I7Z0JBQ0QsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJO2FBQ2xCLENBQUM7WUFFRixJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDbkIsSUFBSSxVQUFVLEVBQUU7b0JBQ2QsUUFBUSxDQUFDLGFBQWEsR0FBSSxDQUFDLENBQUMsS0FBaUMsQ0FBQyxhQUFhLENBQUM7aUJBQzdFO2dCQUNELElBQUksWUFBWSxFQUFFO29CQUNoQixRQUFRLENBQUMsZUFBZSxHQUFJLENBQUMsQ0FBQyxLQUFpQyxDQUFDLGVBQWUsQ0FBQztpQkFDakY7YUFDRjtZQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzNCLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3pCLFFBQVEsQ0FBQyxRQUFRLENBQUMsY0FBYyxHQUFHO29CQUNqQyxJQUFJLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBdUM7b0JBQzlELElBQUksRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUF1QztpQkFDL0QsQ0FBQztnQkFDRixRQUFRLENBQUMsUUFBUSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsZ0JBRXpDLENBQUM7Z0JBQ2QsUUFBUSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUUxQyxDQUFDO2dCQUNkLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFO29CQUNuQixRQUFRLENBQUMsUUFBUSxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQztpQkFDbEU7YUFDRjtZQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzNCLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3pCLFFBQVEsQ0FBQyxRQUFRLENBQUMsa0JBQWtCO29CQUNsQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDO2FBQzdFO1lBRUQsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksYUFBYTtRQUNsQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUV6QyxvQ0FBb0M7UUFDcEMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVoRCxxQkFBcUI7UUFDckIsT0FBTyxRQUFRLENBQUMsZUFBZTthQUM1QixPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBRSxFQUFDLENBQUM7YUFDcEIsR0FBRyxDQUNGLENBQUMsa0JBQTJDLEVBQUUsRUFBRTtZQUM5QyxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUNsRCxVQUFVO2dCQUNWLE1BQU07Z0JBQ04sTUFBTTtnQkFDTixhQUFhO2dCQUNiLEtBQUs7YUFDTixDQUE2QyxDQUFDO1lBRS9DLDZEQUE2RDtZQUM3RCxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUYsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUNsQixVQUFVLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0JBQzlDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQzthQUM5QztpQkFBTTtnQkFDTCxVQUFVLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztnQkFDN0IsVUFBVSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7YUFDL0I7WUFFRCxjQUFjO1lBQ2QsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakQsVUFBVSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsVUFBVSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsVUFBVSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0RCxPQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFFdkIsT0FBTyxNQUFNLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLEdBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzNFLFVBQVUsQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUM7Z0JBQ2xDLE9BQU8sVUFBNEIsQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsRUFDRCxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUMsQ0FDakI7YUFDQSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbEIsMEVBQTBFO1lBQzFFLE1BQU0sWUFBWSxHQUFxQixpQkFBaUIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ3hFLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUluRSxDQUFDO2dCQUNGLE9BQU87b0JBQ0wsV0FBVyxFQUFFLFVBQVUsQ0FBQyxRQUFRO29CQUNoQyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7b0JBQ25CLFdBQVcsRUFBRSxJQUFJO29CQUNqQixHQUFHLEVBQUUsSUFBSTtvQkFDVCxRQUFRLEVBQUUsSUFBSTtvQkFDZCxJQUFJLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQzt3QkFDMUMsQ0FBQyxDQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBZTt3QkFDcEMsQ0FBQyxDQUFDLElBQUk7b0JBQ1IsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO29CQUNuQixLQUFLLEVBQUUsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUk7b0JBQ2pDLE9BQU8sRUFBRSxJQUFJO29CQUNiLGtCQUFrQixFQUFFLENBQUM7aUJBQ3RCLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sV0FBVyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMxQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7Ozs7OztPQVVHO0lBQ0ksWUFBWSxDQUFDLFlBSW5CO1FBQ0MsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRTtZQUM3QyxPQUFPLEVBQUU7Z0JBQ1AsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsVUFBVSxFQUFFO29CQUNWLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBQztpQkFDekM7Z0JBQ0QsTUFBTSxFQUFFLFdBQVc7YUFDcEI7WUFDRCxLQUFLLEVBQUU7Z0JBQ0wsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsVUFBVSxFQUFFO29CQUNWLE1BQU0sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBQztpQkFDekM7Z0JBQ0QsTUFBTSxFQUFFLFdBQVc7YUFDcEI7WUFDRCxJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO1NBQ3ZCLENBQUMsQ0FBQztRQUVILE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2hFLE1BQU0sV0FBVyxHQUFHLFdBQVcsR0FBRyxDQUFDLENBQUM7WUFDcEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxVQUFVLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTFCLHVFQUF1RTtZQUN2RSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXJCLE9BQU8sV0FBVyxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxrQkFBa0IsQ0FBQyxXQUFtQjtRQUMzQyxNQUFNLE1BQU0sR0FBMkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUM7UUFFckYsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsV0FBVyxFQUNYLHdDQUF3QyxXQUFXLGlCQUFpQixFQUNwRSxJQUFJLENBQ0wsQ0FBQztTQUNIO1FBRUQsSUFBSSxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRTtZQUN4QyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLHNCQUFzQixFQUN0Qiw0Q0FBNEMsRUFDNUMsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELHVDQUF1QztRQUN2QyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM3QixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQ3BCLGlCQUFpQixFQUNqQixnREFBZ0QsRUFDaEQsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELHlDQUF5QztRQUN6QyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFakIsMENBQTBDO1FBQzFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUMsQ0FBQyxDQUFDO1FBRWhELG9EQUFvRDtRQUNwRCw2RkFBNkY7UUFDN0YsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLGVBQWUsV0FBVyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGdCQUFnQixDQUNyQixnQkFBd0IsRUFDeEIsY0FBdUI7UUFZdkIsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXBGLE1BQU0sbUJBQW1CLEdBQUcsTUFBTTtZQUNoQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDMUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUV2QixvRkFBb0Y7UUFDcEYsSUFBSSxrQkFBMkMsQ0FBQztRQUVoRCxPQUFPLG1CQUFtQjthQUN2QixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1QsZ0RBQWdEO1lBQ2hELE1BQU0sVUFBVSxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUN0QyxJQUFJLGNBQWMsS0FBSyxTQUFTLEVBQUU7Z0JBQ2hDLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDakM7WUFDRCxPQUFPLFFBQVEsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUMsR0FBRyxFQUFFLFVBQVUsRUFBQyxFQUFDLENBQUMsQ0FBQztRQUN0RSxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDbkIsK0NBQStDO1lBQy9DLE1BQU0sd0JBQXdCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBQyxHQUFHLEVBQUUsZ0JBQWdCLEVBQUMsQ0FBQyxDQUFDO1lBQy9FLElBQUksQ0FBQyx3QkFBd0IsRUFBRTtnQkFDN0IsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixXQUFXLEVBQ1gsOEJBQThCLGdCQUFnQixlQUFlLENBQzlELENBQUM7YUFDSDtZQUNELGtCQUFrQixHQUFHLHdCQUF3QixDQUFDO1lBRTlDLCtEQUErRDtZQUMvRCxNQUFNLHNCQUFzQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUMsR0FBRyxFQUFFLGNBQWMsRUFBQyxDQUFDLENBQUM7WUFDM0UsSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFO2dCQUNoQyxJQUFJLHNCQUFzQixLQUFLLFNBQVMsRUFBRTtvQkFDeEMsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixXQUFXLEVBQ1gsdUNBQXVDLGdCQUFnQixlQUFlLENBQ3ZFLENBQUM7aUJBQ0g7Z0JBQ0QsSUFBSSxjQUFjLEtBQUssZ0JBQWdCLEVBQUU7b0JBQ3ZDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQ25CLGtDQUFrQyxnQkFBZ0IsZUFBZSxDQUNsRSxDQUFDO2lCQUNIO2FBQ0Y7WUFFRCxxRUFBcUU7WUFDckUsSUFBSSxvQkFBb0IsR0FBRyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDOUMsTUFBTSxRQUFRLEdBQUc7Z0JBQ2YsY0FBYyxFQUFFLENBQUM7Z0JBQ2pCLE9BQU8sRUFBRSxDQUFDO2dCQUNWLE1BQU0sRUFBRSxDQUFDO2dCQUNULE1BQU0sRUFBRSxDQUFDO2dCQUNULE9BQU8sRUFBRSxDQUFDO2dCQUNWLFlBQVksRUFBRSxDQUFDO2FBQ2hCLENBQUM7WUFDRixJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUM7WUFDcEIsTUFBTSxLQUFLLEdBQUcsRUFBQyxTQUFTLEVBQUUsZ0JBQWdCLEVBQUMsQ0FBQztZQUU1QyxJQUFJLGNBQWMsS0FBSyxTQUFTLEVBQUU7Z0JBQ2hDLGFBQWE7Z0JBQ2IsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFFZixvQkFBb0I7Z0JBQ3BCLE1BQU0sTUFBTSxHQUFHLEVBQUMsU0FBUyxFQUFFLGNBQWMsRUFBQyxDQUFDO2dCQUMzQyxNQUFNLE9BQU8sR0FBMkI7b0JBQ3RDLDRDQUE0QztvQkFDNUMsS0FBSyxFQUFFLEtBQUs7b0JBQ1osc0NBQXNDO29CQUN0QyxNQUFNLEVBQUUsQ0FBQyxXQUFXLENBQUM7b0JBQ3JCLGlCQUFpQjtvQkFDakIsUUFBUSxFQUFFLEtBQUs7b0JBQ2YscUNBQXFDO29CQUNyQyxNQUFNLEVBQUUsSUFBSTtpQkFDYixDQUFDO2dCQUVGLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3hDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFDakMsb0JBQW9CLEdBQUcsUUFBUSxDQUFDLGFBQWE7cUJBQzFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDO29CQUMzQiw0RUFBNEU7cUJBQzNFLE1BQU0sQ0FBQyxDQUFDLEtBQWEsRUFBRSxFQUFFO29CQUN4QixRQUFRLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztvQkFDaEMsT0FBTyxRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDOUQsQ0FBQyxDQUFDO3FCQUNELE1BQU0sQ0FBQyxDQUFDLEtBQWEsRUFBRSxFQUFFO29CQUN4QixRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFFekIsNkNBQTZDO29CQUM3QyxNQUFNLDRCQUE0QixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzFELDRCQUE0QixDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO29CQUNuRCxPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSw0QkFBNEIsQ0FBQyxDQUFDO2dCQUNyRSxDQUFDLENBQUM7cUJBQ0QsTUFBTSxDQUFDLENBQUMsS0FBYSxFQUFFLEVBQUU7b0JBQ3hCLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO29CQUV4Qix5Q0FBeUM7b0JBQ3pDLE1BQU0sdUJBQXVCLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQTZCLENBQUM7b0JBQy9FLHVCQUF1QixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7b0JBQ3ZDLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsdUJBQXVCLEVBQUMsQ0FBQyxDQUFDO2dCQUNsRSxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDVCxPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDaEQsQ0FBQyxDQUFDO3FCQUNELE1BQU0sQ0FBQyxDQUFDLEtBQWEsRUFBRSxFQUFFO29CQUN4QixRQUFRLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2hELENBQUMsQ0FBQztxQkFDRCxNQUFNLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtvQkFDeEIsUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7b0JBQ3pCLE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUM7cUJBQ0QsTUFBTSxDQUFDLENBQUMsS0FBYSxFQUFFLEVBQUU7b0JBQ3hCLFFBQVEsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2dCQUNoQyxDQUFDLENBQUMsQ0FBQzthQUNOO2lCQUFNO2dCQUNMLGNBQWM7Z0JBQ2QsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFFaEIsb0JBQW9CLEdBQUcsUUFBUSxDQUFDLGFBQWE7cUJBQzFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQztxQkFDdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNaLFFBQVEsQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO29CQUNoQyxPQUFPLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztnQkFDOUQsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDWixRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDekIsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO2dCQUNoRCxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNaLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO29CQUN4QixPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7Z0JBQ2hELENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1osUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7b0JBQ3hCLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztnQkFDaEQsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDWixRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztvQkFDekIsT0FBTyxRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNaLFFBQVEsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2dCQUNoQyxDQUFDLENBQUMsQ0FBQzthQUNOO1lBRUQsMEJBQTBCO1lBQzFCLHdHQUF3RztZQUN4RyxPQUFPLG9CQUFvQjtpQkFDeEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxnQ0FBZ0M7Z0JBQ2hDLE9BQU8sUUFBUSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxzQ0FBc0M7Z0JBQ3RDLE9BQU8sa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEMsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1Qsb0NBQW9DO2dCQUNwQyxPQUFPLEVBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFDLENBQUM7WUFDakQsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssZ0JBQWdCLENBQ3RCLE9BQTZDLEVBQzdDLGFBQXFCO1FBRXJCLE1BQU0sS0FBSyxHQUFvQixPQUFPLENBQUMsS0FBd0IsSUFBSSxFQUFFLENBQUM7UUFDdEUsTUFBTSxLQUFLLEdBQW9CLE9BQU8sQ0FBQyxLQUF3QixJQUFJLEVBQUUsQ0FBQztRQUN0RSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU87WUFDTCxLQUFLLEVBQUUsS0FBSztZQUNaLEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWSxDQUFDLFNBQWlCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFFekMsa0RBQWtEO1lBQ2xELElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDckUsT0FBTyxNQUFNLENBQUMsY0FBYyxDQUFDO2FBQzlCO1lBRUQsaUZBQWlGO1lBQ2pGLElBQUksU0FBUyxLQUFLLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQzNELE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDckM7WUFFRCx3Q0FBd0M7WUFDeEMsSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQ2xDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZO2dCQUM5Qix1Q0FBdUM7Z0JBQ3ZDLGlDQUFpQztnQkFDakMsU0FBUyxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FDOUMsQ0FBQzthQUNIO1lBRUQsbURBQW1EO1lBQ25ELE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0ksT0FBTyxDQUFDLE9BU2Q7UUFDQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRS9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ3RELEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNYLE1BQU0sRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFFakYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDbEMsT0FBTzt3QkFDTCxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLEVBQUU7cUJBQ1YsQ0FBQztpQkFDSDtnQkFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDdkQsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPO29CQUM3QixTQUFTLEVBQUUsT0FBTyxDQUFDLGFBQWE7aUJBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2QsT0FBTzt3QkFDTCxLQUFLLEVBQUUsV0FBVzt3QkFDbEIsS0FBSyxFQUFFLEtBQUs7cUJBQ2IsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksWUFBWSxDQUFDLE9BU25CO1FBQ0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDckQsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQ2hGLHNGQUFzRjtnQkFDdEYsT0FBTyxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNqRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0ksWUFBWSxDQUFDLE9BS25CO1FBQ0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDckQsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQ2hGLHNGQUFzRjtnQkFDdEYsT0FBTyxXQUFXLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNqRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0ksb0JBQW9CLENBQUMsT0FhM0I7UUFJQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRS9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFlBQVksQ0FDWCxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNOLEdBQUcsRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDcEIsYUFBYSxFQUFFLE9BQU8sQ0FBQyxpQkFBaUI7Z0JBQ3hDLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxzQkFBc0I7YUFDbkQsRUFBRSxPQUFPLENBQUMsQ0FDWjtpQkFDQSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osT0FBTyxNQUFNLENBQUMsS0FBSztxQkFDaEIsWUFBWSxDQUNYLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ04sR0FBRyxFQUFFLE9BQU8sQ0FBQyxPQUFPO29CQUNwQixhQUFhLEVBQUUsT0FBTyxDQUFDLGlCQUFpQjtvQkFDeEMsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLHNCQUFzQjtpQkFDbkQsRUFBRSxPQUFPLENBQUMsQ0FDWjtxQkFDQSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1osTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FDcEUsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUMsRUFDNUIsV0FBVyxDQUNaLENBQUM7b0JBQ0YsT0FBTzt3QkFDTCxVQUFVLEVBQUUsS0FBSzt3QkFDakIsTUFBTSxFQUFFOzRCQUNOLEtBQUssRUFBRSxXQUFXOzRCQUNsQixLQUFLLEVBQUUsV0FBVzt5QkFDbkI7cUJBQ0YsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnQkc7SUFDSSxnQkFBZ0IsQ0FDckIsT0FBaUIsRUFDakIsT0FVQyxFQUNELFNBQWlCO1FBRWpCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUvQixJQUFJLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFFN0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDbkMsY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNqRTtZQUVELE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsY0FBYyxFQUFFLGNBQWMsRUFBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNoRixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBRWhGLG9CQUFvQjtnQkFDcEIsdUJBQXVCO2dCQUN2QixxQkFBcUI7Z0JBQ3JCLEVBQUU7Z0JBQ0YsK0NBQStDO2dCQUMvQywyQ0FBMkM7Z0JBQzNDLGlDQUFpQztnQkFDakMsK0JBQStCO2dCQUMvQixrREFBa0Q7Z0JBQ2xELEVBQUU7Z0JBQ0YsMkVBQTJFO2dCQUUzRSxNQUFNLGVBQWUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFM0MsbUNBQW1DO2dCQUVuQyxnQkFBZ0I7Z0JBQ2hCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsZUFBZSxFQUFFO29CQUNyRCxZQUFZLEVBQUUsY0FBYztvQkFDNUIsZUFBZSxFQUFFLElBQUk7b0JBQ3JCLFNBQVMsRUFBRSxPQUFPLENBQUMsYUFBYTtpQkFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtvQkFDdkIsY0FBYztvQkFDZCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTt3QkFDN0MsWUFBWSxFQUFFLGNBQWM7d0JBQzVCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUzt3QkFDNUIsY0FBYyxFQUFFLE9BQU8sQ0FBQyxjQUFjO3FCQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO3dCQUNyQixPQUFPOzRCQUNMLEtBQUssRUFBRSxXQUFXOzRCQUNsQixLQUFLLEVBQUUsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7eUJBQzNDLENBQUM7b0JBQ0osQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSyxjQUFjLENBQ3BCLFNBQWlCLEVBQ2pCLE9BQWlCLEVBQ2pCLE9BS0M7UUFFRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFFL0IsSUFBSSxlQUFlLEdBQWEsRUFBRSxDQUFDO1FBRW5DLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtZQUMzQixlQUFlLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNuRDtRQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDeEMsZUFBZSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUNsRTtRQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLGNBQWMsQ0FBQyxPQUFPLEVBQUUsZUFBZSxFQUFFO2dCQUN4QyxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzVCLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYzthQUN2QyxDQUFDO2lCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDWixNQUFNLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDaEYsT0FBTyxXQUFXLENBQUM7WUFDckIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGFBQWEsQ0FBQyxTQUFpQixFQUFFLE1BQWM7UUFDcEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDaEQsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILGlFQUFpRTtJQUMxRCxhQUFhLENBQ2xCLEdBQWEsRUFDYixTQUFpQixFQUNqQixPQUtDO1FBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDaEQsTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUV6QyxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNwQixNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUNqQixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7b0JBQ3hFLE9BQU8saUJBQWlCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBcUIsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQUM7YUFDSjtZQUVELE1BQU0sTUFBTSxHQUFxQixFQUFFLENBQUM7WUFDcEMsT0FBTyxNQUFNLENBQUMsS0FBSztpQkFDaEIsV0FBVyxDQUFDLEdBQUcsQ0FBQztpQkFDaEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQ3hCLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDL0QsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDekIsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUNuQixtQkFBbUIsRUFDbkIsNERBQTREO3dCQUMxRCxvQ0FBb0MsQ0FDdkMsQ0FBQztpQkFDSDtnQkFFRCxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUU7b0JBQ3RCLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ3hELE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUN6QixDQUFDLENBQUMsQ0FBQztpQkFDSjtnQkFFRCxPQUFPO1lBQ1QsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO29CQUN0QixPQUFPLE1BQU0sQ0FBQyxLQUFLO3lCQUNoQixhQUFhLENBQUMsR0FBRyxFQUFFO3dCQUNsQixrQkFBa0IsRUFBRSxPQUFPLENBQUMsa0JBQWtCO3dCQUM5QyxhQUFhLEVBQUUsT0FBTyxDQUFDLGFBQWE7cUJBQ3JDLENBQUM7eUJBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUNiLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBZ0IsQ0FBQztvQkFDbkMsQ0FBQyxDQUFDLENBQUM7aUJBQ047Z0JBRUQsT0FBTztZQUNULENBQUMsQ0FBQztpQkFDRCxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsSUFBc0IsRUFBRSxTQUFpQjtRQUN6RCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDL0IsSUFBSSxXQUFtQixDQUFDO1lBRXhCLDhCQUE4QjtZQUM5QixPQUFPLE1BQU0sQ0FBQyxLQUFLO2lCQUNoQixVQUFVLENBQUMsSUFBSSxDQUFDO2lCQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsV0FBVyxHQUFHLE9BQU8sQ0FBQztnQkFFdEIsbUJBQW1CO2dCQUNuQixPQUFPLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULGtCQUFrQjtnQkFDbEIsT0FBTyxLQUFLLENBQUMsV0FBVyxDQUN0QixNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNqRixDQUFDO1lBQ0osQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUN4RixPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ssaUJBQWlCLENBQUMsSUFBWSxFQUFFLGNBQXVCLEVBQUUsUUFBaUI7UUFDaEYsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUQsT0FBTztTQUNSO1FBQ0QsSUFBSSxjQUFjLEdBQUcsUUFBUSxFQUFFO1lBQzdCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsZUFBZSxFQUNmLEdBQUcsSUFBSSw4QkFBOEIsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FDaEUsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksVUFBVSxDQUNmLE1BQWMsRUFDZCxVQU1DLEVBQ0QsU0FBaUI7UUFFakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDL0MsSUFBSSxVQUFrQixDQUFDO1lBQ3ZCLElBQUksWUFBb0IsQ0FBQztZQUN6QixJQUFJLFdBQW1CLENBQUM7WUFFeEIsT0FBTyxJQUFJLENBQUMsZUFBZTtpQkFDeEIsT0FBTyxFQUFFO2lCQUNULElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsdUNBQXVDO2dCQUN2QyxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1lBQ3BELENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFeEIsOEJBQThCO2dCQUM5QixNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFbEUsa0NBQWtDO2dCQUNsQyxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztZQUNyRCxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNYLFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBRW5CLGlDQUFpQztnQkFDakMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVoRSw2QkFBNkI7Z0JBQzdCLE9BQU8sS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQzVGLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULHNGQUFzRjtnQkFDdEYsT0FBTyxLQUFLLENBQUMsV0FBVyxDQUN0QixNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNqRixDQUFDO1lBQ0osQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUN2RixPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixDQUFDLENBQUM7aUJBQ0QsT0FBTyxDQUFDLEdBQUcsRUFBRTtnQkFDWixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsTUFBYyxFQUFFLFNBQWlCO1FBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQy9DLElBQUksWUFBb0IsQ0FBQztZQUN6QixPQUFPLE1BQU0sQ0FBQyxLQUFLO2lCQUNoQixZQUFZLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBQyxDQUFDO2lCQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDeEIsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6QyxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztpQkFDcEQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2lCQUNuRixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdkIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDVSxzQkFBc0IsQ0FDakMsTUFBcUM7O1lBRXJDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQyxDQUFDO0tBQUE7SUFFRDs7OztPQUlHO0lBQ1UsYUFBYSxDQUN4QixNQUFxQzs7WUFFckMsSUFBSSxPQUFlLENBQUM7WUFFcEIsTUFBTSxFQUFDLGNBQWMsRUFBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVSxFQUFDLENBQUMsQ0FBQztZQUVyRixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBQ3hELElBQUksT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFO29CQUN2QyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDckYsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FDNUQsTUFBTSxDQUFDLEtBQUssRUFDWixNQUFNLENBQUMsWUFBWSxFQUNuQixjQUFjLEVBQ2QsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FDdEMsQ0FBQztvQkFFRixPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQzNDO2dCQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQVcsQ0FBQztnQkFFaEUsOENBQThDO2dCQUM5QyxNQUFNLGVBQWUsR0FBRztvQkFDdEIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO29CQUN2QixPQUFPLEVBQUUsT0FBTztvQkFDaEIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLElBQUksUUFBUTtvQkFDL0IsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO29CQUM3QixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7b0JBQzdCLGtCQUFrQixFQUFFLE1BQU0sQ0FBQyxrQkFBa0I7b0JBQzdDLGFBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTtpQkFDcEMsQ0FBQztnQkFDRixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBRXpFLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQVcsQ0FBQztnQkFDcEUsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDO2dCQUN2QyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUUvRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQy9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7cUJBQ2hCLFFBQVEsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO3FCQUMvQixJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUU7b0JBQ3JCLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ3RELENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsQ0FBTSxNQUFNLEVBQUMsRUFBRTtvQkFDbkIsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7b0JBQzdCLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssZUFBZSxDQUFDLEtBQUssRUFBRTt3QkFDbEQsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO3FCQUN6QjtvQkFFRCxJQUFJLGlCQUFpQixHQUFHLEtBQUssQ0FBQztvQkFDOUIsSUFBSSxjQUFjLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUNwQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFNLFFBQVEsRUFBQyxFQUFFO3dCQUNqQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFOzRCQUN6QyxPQUFPLE1BQU0sTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDOUM7NkJBQU07NEJBQ0wsT0FBTyxRQUFRLENBQUM7eUJBQ2pCO29CQUNILENBQUMsQ0FBQSxDQUFDLENBQ0gsQ0FBQztvQkFDRixjQUFjLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWxFLElBQUksY0FBYyxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTt3QkFDbEQsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO3FCQUMxQjtvQkFFRCxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUU7d0JBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsY0FBYyxNQUFNLENBQUMsS0FBSyxxQkFBcUIsT0FBTyxNQUFNLENBQUMsQ0FBQzt3QkFDdkUsTUFBTSxJQUFJLHlDQUFtQixDQUFDLDRCQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ2xEO29CQUVELE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ2pFLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRWpFLE1BQU0sRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQ3BFLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDLEVBQzVCLFdBQVcsQ0FDWixDQUFDO29CQUVGLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUVuQyxpR0FBaUc7b0JBQ2pHLElBQUksWUFBWSxHQUFHLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBRXRFLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUU7d0JBQ2xDLG1EQUFtRDt3QkFDbkQsWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO3FCQUNwRDtvQkFFRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUU7d0JBQ3JELFlBQVksRUFBRSxZQUFZO3dCQUMxQixTQUFTLEVBQUUsTUFBTSxDQUFDLGFBQWE7d0JBQy9CLGNBQWMsRUFBRSxNQUFNLENBQUMsa0JBQWtCO3FCQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUNwQixPQUFPOzRCQUNMLGdCQUFnQixFQUFFLGdCQUFnQjs0QkFDbEMsaUJBQWlCLEVBQUUsaUJBQWlCOzRCQUNwQyxLQUFLLEVBQUUsV0FBVzs0QkFDbEIsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUM7eUJBQ2pELENBQUM7b0JBQ0osQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFBLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUFBO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNJLFlBQVksQ0FBQyxNQUEwQjtRQUM1QyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDckMsSUFBSSxPQUFlLENBQUM7UUFFcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQVcsQ0FBQztZQUVoRSw4Q0FBOEM7WUFDOUMsTUFBTSxlQUFlLEdBQUc7Z0JBQ3RCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztnQkFDdkIsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDdkIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLElBQUksUUFBUTthQUNoQyxDQUFDO1lBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXpFLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQVcsQ0FBQztZQUNsRSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sSUFBSSxVQUFVLENBQUM7WUFDdkMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztZQUUvRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDL0IsT0FBTyxNQUFNLENBQUMsS0FBSztpQkFDaEIsUUFBUSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7aUJBQy9CLElBQUksQ0FBQyxDQUFDLGNBQTZDLEVBQUUsRUFBRTtnQkFDdEQsT0FBTyxLQUFLLENBQUMsYUFBYSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLENBQUMsWUFBK0QsRUFBRSxFQUFFO2dCQUN4RSxJQUFJLFlBQVksQ0FBQyxPQUFPLEVBQUU7b0JBQ3hCLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxNQUFNLENBQUMsS0FBSyxxQkFBcUIsT0FBTyxNQUFNLENBQUMsQ0FBQztpQkFDcEU7Z0JBRUQsTUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFDO2dCQUUzQixLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQVksQ0FBQyxNQUFNLEVBQUU7b0JBQ3ZDLE1BQU0sZUFBZSxHQUlqQjt3QkFDRixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7d0JBQ2xCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSzt3QkFDbEIsT0FBTyxFQUFFLEVBQUU7cUJBQ1osQ0FBQztvQkFFRixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFO3dCQUNsQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTs0QkFDOUIsTUFBTSxXQUFXLEdBQVksS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBRWpFLG1EQUFtRDs0QkFDbkQsSUFDRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLE9BQU8sV0FBVyxLQUFLLFFBQVEsQ0FBQztnQ0FDN0QsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQzNEO2dDQUNBLGVBQWUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUMzQztpQ0FBTTtnQ0FDTCxxRkFBcUY7Z0NBQ3JGLGVBQWUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDOzZCQUNwQzt3QkFDSCxDQUFDLENBQUMsQ0FBQztxQkFDSjtvQkFFRCxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2lCQUN2QztnQkFFRCxPQUFPLGVBQWUsQ0FBQztZQUN6QixDQUFDLENBQUM7aUJBQ0QsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNYLE1BQU0sRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFFakUsT0FBTztvQkFDTCxLQUFLLEVBQUUsS0FBSztvQkFDWixLQUFLLEVBQUUsS0FBSztvQkFDWixPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2lCQUNsQyxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksVUFBVSxDQUFDLE9BS2pCO1FBQ0MsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN4RCx1RUFBdUU7WUFDdkUsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQVcsQ0FBQztZQUV0RSxrQ0FBa0M7WUFDbEMsTUFBTSxlQUFlLEdBQUc7Z0JBQ3RCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDeEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksUUFBUTthQUNqQyxDQUFDO1lBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXpFLG1FQUFtRTtZQUNuRSxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWSxDQUFDLFNBQWlCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2hELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFFekMsa0RBQWtEO1lBQ2xELElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDckUsT0FBTyxNQUFNLENBQUMsY0FBYyxDQUFDO2FBQzlCO1lBRUQsaUZBQWlGO1lBQ2pGLElBQUksU0FBUyxLQUFLLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQzNELE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDckM7WUFFRCx3Q0FBd0M7WUFDeEMsSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Z0JBQ2xDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZO2dCQUM5Qix1Q0FBdUM7Z0JBQ3ZDLGlDQUFpQztnQkFDakMsU0FBUyxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FDOUMsQ0FBQzthQUNIO1lBRUQsbURBQW1EO1lBQ25ELE9BQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0ksT0FBTyxDQUFDLE9BU2Q7UUFDQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDeEQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRS9CLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ3RELEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNYLHVDQUF1QztnQkFDdkMsT0FBTyxNQUFNLENBQUMsS0FBSztxQkFDaEIsWUFBWSxDQUFDO29CQUNaLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDL0IsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO29CQUM5QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7b0JBQzlCLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxrQkFBa0I7b0JBQzlDLGFBQWEsRUFBRSxPQUFPLENBQUMsYUFBYTtpQkFDckMsQ0FBQztxQkFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1oseURBQXlEO29CQUN6RCxNQUFNLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUNwRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUMsRUFDN0IsV0FBVyxDQUNaLENBQUM7b0JBQ0YsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7d0JBQ2hFLFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTzt3QkFDN0IsZUFBZSxFQUFFLElBQUk7d0JBQ3JCLFNBQVMsRUFBRSxPQUFPLENBQUMsYUFBYTtxQkFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDZCwwREFBMEQ7d0JBQzFELDBEQUEwRDt3QkFDMUQsT0FBTzs0QkFDTCxLQUFLLEVBQUUsV0FBVzs0QkFDbEIscURBQXFEOzRCQUNyRCxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQzt5QkFDakQsQ0FBQztvQkFDSixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsSUFBc0IsRUFBRSxTQUFpQjtRQUN6RCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDL0IsSUFBSSxXQUFtQixDQUFDO1lBRXhCLDhCQUE4QjtZQUM5QixPQUFPLE1BQU0sQ0FBQyxLQUFLO2lCQUNoQixVQUFVLENBQUMsSUFBSSxDQUFDO2lCQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsV0FBVyxHQUFHLE9BQU8sQ0FBQztnQkFFdEIsbUJBQW1CO2dCQUNuQixPQUFPLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULGtCQUFrQjtnQkFDbEIsT0FBTyxLQUFLLENBQUMsV0FBVyxDQUN0QixNQUFNLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUNqRixDQUFDO1lBQ0osQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsTUFBTSxFQUFDLEtBQUssRUFBRSxXQUFXLEVBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBQyxLQUFLLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUN4RixPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSSxVQUFVLENBQ2YsTUFBYyxFQUNkLFVBSUMsRUFDRCxTQUFpQjtRQUVqQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQyxJQUFJLFVBQWtCLENBQUM7WUFDdkIsSUFBSSxZQUFvQixDQUFDO1lBQ3pCLElBQUksV0FBbUIsQ0FBQztZQUV4QixPQUFPLElBQUksQ0FBQyxlQUFlO2lCQUN4QixPQUFPLEVBQUU7aUJBQ1QsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCx1Q0FBdUM7Z0JBQ3ZDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBQyxDQUFDLENBQUM7WUFDcEQsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDWixZQUFZLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV4Qiw4QkFBOEI7Z0JBQzlCLE1BQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDdkUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUVsRSxrQ0FBa0M7Z0JBQ2xDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQ3JELENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ1gsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFFbkIsaUNBQWlDO2dCQUNqQyxVQUFVLEdBQUcsTUFBTSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRWhFLHVCQUF1QjtnQkFDdkIsT0FBTyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDNUYsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1Qsa0NBQWtDO2dCQUNsQyxPQUFPLEtBQUssQ0FBQyxXQUFXLENBQ3RCLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsb0JBQW9CLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQ2pGLENBQUM7WUFDSixDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxNQUFNLEVBQUMsS0FBSyxFQUFFLFdBQVcsRUFBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFDLEtBQUssRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ3ZGLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hCLENBQUMsQ0FBQztpQkFDRCxPQUFPLENBQUMsR0FBRyxFQUFFO2dCQUNaLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFVBQVUsQ0FBQyxNQUFjLEVBQUUsU0FBaUI7UUFDakQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDL0MsSUFBSSxZQUFvQixDQUFDO1lBQ3pCLE9BQU8sTUFBTSxDQUFDLEtBQUs7aUJBQ2hCLFlBQVksQ0FBQyxFQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFDLENBQUM7aUJBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDWixZQUFZLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4QixPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3pDLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2lCQUNwRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7aUJBQ25GLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSSxXQUFXLENBQ2hCLGFBQTRCLEVBQzVCLFNBQWlCLEVBQ2pCLE9BR0M7UUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNoRCxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDeEQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO3FCQUN0QixJQUFJLENBQ0gsR0FBOEMsRUFBRTtvQkFDOUMsSUFBSSxRQUFRLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTt3QkFDNUIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDOzRCQUN2QixHQUFHLEVBQUUsUUFBUSxDQUFDLE9BQU87NEJBQ3JCLGFBQWEsRUFBRSxJQUFJOzRCQUNuQixTQUFTLEVBQUUsU0FBUzs0QkFDcEIsYUFBYSxFQUFFLFFBQVEsQ0FBQyxhQUFhOzRCQUNyQyxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7NEJBQzlCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTt5QkFDL0IsQ0FBQyxDQUFDO3FCQUNKO3lCQUFNO3dCQUNMLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQzs0QkFDdkIsR0FBRyxFQUFFLFFBQVEsQ0FBQyxPQUFPOzRCQUNyQixhQUFhLEVBQUUsSUFBSTs0QkFDbkIsU0FBUyxFQUFFLFNBQVM7NEJBQ3BCLGFBQWEsRUFBRSxRQUFRLENBQUMsYUFBYTt5QkFDdEMsQ0FBQyxDQUFDO3FCQUNKO2dCQUNILENBQUMsQ0FDRjtxQkFDQSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1osTUFBTSxVQUFVLEdBQWEsS0FBSyxDQUFDLFlBQVksQ0FDN0MsUUFBUSxDQUFDLElBQUksRUFDYixRQUFRLENBQUMsT0FBTyxFQUNoQixLQUFLLEVBQ0wsUUFBUSxDQUFDLGFBQWEsRUFDdEIsU0FBUyxFQUNULEtBQUssQ0FDTixDQUFDO29CQUVGLHdEQUF3RDtvQkFDeEQscUNBQXFDO29CQUNyQyx5REFBeUQ7b0JBQ3pELDBFQUEwRTtvQkFDMUUsMERBQTBEO29CQUMxRCw0RkFBNEY7b0JBRTVGLElBQUksT0FBd0MsQ0FBQztvQkFFN0MsSUFBSSxRQUFRLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTt3QkFDNUIsT0FBTyxHQUFJLEtBQXdCLENBQUMsTUFBTSxDQUN4QyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUN6RSxDQUFDO3FCQUNIO3lCQUFNO3dCQUNMLE9BQU8sR0FBSSxLQUF3QixDQUFDLE1BQU0sQ0FDeEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDOzRCQUN2QixFQUFFLEVBQUUsRUFBRTs0QkFDTixJQUFJLEVBQUUsRUFBRTs0QkFDUixNQUFNLEVBQUUsRUFBRTs0QkFDVixNQUFNLEVBQUUsRUFBRTs0QkFDVixJQUFJLEVBQUUsRUFBRTs0QkFDUixNQUFNLEVBQUUsQ0FBQzt5QkFDVixDQUFDLENBQUMsQ0FDSixDQUFDO3FCQUNIO29CQUVELE9BQU87d0JBQ0wsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO3dCQUNuQixTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVM7d0JBQzdCLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVzt3QkFDakMsT0FBTyxFQUFFLE9BQU87cUJBQ2pCLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNJLFVBQVUsQ0FDZixhQUE0QixFQUM1QixTQUFpQixFQUNqQixPQU1DO1FBRUQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDO2FBQ3ZELElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNSLHFCQUFxQjtZQUNyQixzRUFBc0U7WUFDdEUsbURBQW1EO1lBQ25ELHFCQUFxQjtZQUNyQix1RUFBdUU7WUFDdkUscUNBQXFDO1lBQ3JDLG1EQUFtRDtZQUVuRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQzVCLEdBQThDLEVBQUU7Z0JBQzlDLElBQUksYUFBYSxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7b0JBQ2pDLDREQUE0RDtvQkFDNUQsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQXlCLENBQUM7b0JBQzFDLE1BQU0sVUFBVSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7b0JBQzdCLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQ25CLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM1QixVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUIsQ0FBQyxDQUFDLENBQUM7b0JBRUgsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUN0QixDQUFDLENBQUMsUUFBUSxDQUNSO3dCQUNFLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQzt3QkFDM0IsU0FBUyxFQUFFLFNBQVM7cUJBQ3JCO29CQUNELDZCQUE2QjtvQkFDN0IsT0FBTyxDQUNSLENBQ0YsQ0FBQztpQkFDSDtnQkFFRCxPQUFPLENBQUMsQ0FBQyxPQUF5QixDQUFDO1lBQ3JDLENBQUMsQ0FDRixDQUFDO1FBQ0osQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLENBQUMsS0FBcUIsRUFBRSxFQUFFO1lBQzlCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hELFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDN0IsZUFBZSxFQUFFLElBQUk7Z0JBQ3JCLFNBQVMsRUFBRSxPQUFPLENBQUMsYUFBYTthQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNkLE9BQU87b0JBQ0wsS0FBSyxFQUFFLEtBQUs7b0JBQ1osS0FBSyxFQUFFLEtBQUs7aUJBQ2IsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksZUFBZSxDQUFDLE1BQXlCO1FBQzlDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN4RCxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLHNCQUFzQixDQUFDLFNBQWlCO1FBQzdDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFDLENBQUM7YUFDekUsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1IsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFxQixFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO1lBQ3JCLG9FQUFvRTtZQUNwRSxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxLQUFLLElBQUksQ0FBYSxDQUFDO1FBQzdFLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxzQkFBc0IsQ0FBQyxTQUFpQjtRQUM3QyxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUM3QixTQUFTLEVBQUUsU0FBUztZQUNwQixjQUFjLEVBQUUsSUFBSTtTQUNyQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1Ysb0RBQW9EO1lBQ3BELE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBcUIsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBYSxDQUFDO1FBQzVFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSxrQkFBa0IsQ0FBQyxPQUl6QjtRQUNDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRTtZQUN4RCxPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUU7aUJBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1QsT0FBTyxjQUFjLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ25GLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ2hCLHVCQUF1QjtnQkFDdkIsSUFBSSxPQUFPLENBQUMsY0FBYyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQkFDbEQsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2dCQUVELE9BQU8sV0FBVyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDdEUsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLGtCQUFrQixDQUFDLE9BSXpCO1FBQ0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELGtEQUFrRDtZQUNsRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUM3RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUNqRixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDbkMsSUFBSSxFQUFFLElBQUk7d0JBQ1YsS0FBSyxFQUFFLENBQUM7d0JBQ1IsVUFBVSxFQUFFLEVBQUU7cUJBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBQ04sQ0FBQyxDQUFDLENBQUM7YUFDSjtZQUVELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTtpQkFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxPQUFPLGNBQWMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbkYsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDaEIsdUJBQXVCO2dCQUN2QixJQUFJLE9BQU8sQ0FBQyxjQUFjLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO29CQUNsRCxPQUFPLFNBQVMsQ0FBQztpQkFDbEI7Z0JBRUQsT0FBTyxXQUFXLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztZQUN0RSxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxPQUFPLEVBQUUsV0FBVyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksdUJBQXVCLENBQUMsT0FJOUI7UUFDQywyQ0FBMkM7UUFDM0MsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ3hELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTtpQkFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxPQUFPLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEUsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDWixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtvQkFDeEIsT0FBTyxLQUFLLENBQUM7aUJBQ2Q7Z0JBRUQsT0FBTyxXQUFXLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRTtvQkFDdkQsRUFBQyxVQUFVLEVBQUUsS0FBSyxFQUFvQjtpQkFDdkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSx1QkFBdUIsQ0FBQyxPQUk5QjtRQUNDLDJDQUEyQztRQUMzQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDeEQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2lCQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULE9BQU8sY0FBYyxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNoRSxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNaLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFO29CQUN4QixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFFRCxPQUFPLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFO29CQUN2RCxFQUFDLFVBQVUsRUFBRSxLQUFLLEVBQW9CO2lCQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25CLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxjQUFjO1FBQ25CLElBQUksb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQzFDLElBQUksTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDcEIsbUVBQW1FO2dCQUNuRSxPQUFPO2FBQ1I7WUFFRCxPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDcEMsSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7b0JBQ3hCLG9CQUFvQixFQUFFLENBQUM7aUJBQ3hCO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FDdkIsYUFBYSxFQUNiLElBQUksRUFDSixHQUFHLG9CQUFvQixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSwwQkFBMEIsQ0FDekUsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksYUFBYTtRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFFRDs7T0FFRztJQUNJLFlBQVksQ0FBQyxZQUFxQixLQUFLO1FBQzVDLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQzFDLElBQUksTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDcEIsbUVBQW1FO2dCQUNuRSxPQUFPO2FBQ1I7WUFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFFO2dCQUN6QixPQUFPLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUMzQjtZQUVELG9FQUFvRTtZQUNwRSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ25GLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQzNCO1lBRUQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDM0QsR0FBRyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsR0FBRyxNQUFNLENBQUMsUUFBUSxHQUFHLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOztPQUVHO0lBQ0ksZ0JBQWdCO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxnQkFBZ0IsQ0FBQyxTQUFpQjtRQUN2QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTdDLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzlDLElBQUksYUFBYSxLQUFLLElBQUksRUFBRTtZQUMxQixJQUFJLGFBQWEsS0FBSyxTQUFTLEVBQUU7Z0JBQy9CLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsc0JBQXNCLEVBQ3RCLGdCQUFnQixNQUFNLENBQUMsUUFBUSx1QkFBdUIsRUFDdEQsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUNELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsc0JBQXNCLEVBQ3RCLDZCQUE2QixNQUFNLENBQUMsUUFBUSxvQ0FBb0MsRUFDaEYsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELDRGQUE0RjtRQUM1RixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDckMsb0RBQW9EO1FBQ3RELENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVEOztPQUVHO0lBQ0ssV0FBVyxDQUFDLFNBQWlCO1FBQ25DLHNDQUFzQztRQUN0QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUU7WUFDekIsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFFRCwrQ0FBK0M7UUFDL0MsSUFBSSxHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUU7WUFDaEUsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFDRCxHQUFHLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUVyRCxnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUM7UUFFL0IsT0FBTyxNQUFNO2FBQ1YsV0FBVyxFQUFFO2FBQ2IsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNaLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzFCLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxDQUFDLENBQVEsRUFBRSxFQUFFO1lBQ2xCLEdBQUcsQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEQsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOztPQUVHO0lBQ1UsZUFBZSxDQUFDLE1BQTZCOztZQUN4RCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUsQ0FBTSxNQUFNLEVBQUMsRUFBRTtnQkFDOUQsSUFBSSxVQUFVLENBQUM7Z0JBQ2YsSUFBSSxjQUEyQyxDQUFDO2dCQUNoRCxJQUFJLElBQUksR0FBRyxpQ0FBYyxDQUFDLE1BQU0sQ0FBQztnQkFFakMsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDekIsSUFBSSxlQUFlLEdBQXVCLEVBQUUsQ0FBQztnQkFFN0MsSUFBSSx5QkFBbUIsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3pDLHdDQUF3QztvQkFDeEMsSUFBSSxHQUFHLGlDQUFjLENBQUMsUUFBUSxDQUFDO29CQUMvQixNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQ3BELGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUN6RSxVQUFVLEdBQUcseUJBQW1CLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUU5RCxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUN2RSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUNwRCxLQUFLLEVBQ0wsWUFBWSxFQUNaLGNBQWMsRUFDZCxLQUFLLENBQ04sQ0FBQztvQkFFRiw4Q0FBOEM7b0JBQzlDLCtEQUErRDtvQkFDL0QsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ3pCLGVBQWUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO2lCQUM5QztnQkFFRCwyRkFBMkY7Z0JBQzNGLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QyxJQUFJO29CQUNGLG9DQUFvQztvQkFDcEMsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDbEM7Z0JBQUMsT0FBTyxLQUFLLEVBQUU7b0JBQ2QsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO3dCQUNuQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBbUIsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7cUJBQzNGO29CQUNELE1BQU0sS0FBSyxDQUFDO2lCQUNiO2dCQUVELE9BQU87b0JBQ0wsS0FBSyxFQUFFLEtBQUs7b0JBQ1osVUFBVSxFQUFFLFVBQVU7b0JBQ3RCLGNBQWMsRUFBRSxjQUFjO29CQUM5QixJQUFJLEVBQUUsSUFBSTtpQkFDWCxDQUFDO1lBQ0osQ0FBQyxDQUFBLENBQUMsQ0FBQztRQUNMLENBQUM7S0FBQTtJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNJLGFBQWE7UUFDbEIsNkZBQTZGO1FBQzdGLE1BQU0sYUFBYSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDbEQsTUFBTSxlQUFlLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3RELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFdEMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUM1Rix5RkFBeUY7WUFDekYsc0RBQXNEO1lBQ3RELHFGQUFxRjtZQUNyRix5RUFBeUU7WUFDekUsT0FBTyxRQUFRLENBQUMsZUFBZTtpQkFDNUIsTUFBTSxDQUNMO2dCQUNFLGVBQWUsRUFBRSxXQUFXLENBQUMsZ0JBQWdCO2dCQUM3QyxhQUFhLEVBQUUsV0FBVyxDQUFDLGNBQWM7YUFDMUMsRUFDRCxFQUFDLEtBQUssRUFBRSxFQUFDLGFBQWEsRUFBRSxFQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUMsRUFBQyxFQUFDLENBQ3RDO2lCQUNBLE1BQU0sRUFBRSxDQUFDO1NBQ2I7UUFFRCwyRUFBMkU7UUFDM0UsK0RBQStEO1FBQy9ELE9BQU8sUUFBUSxDQUFDLGVBQWU7YUFDNUIsTUFBTSxDQUNMO1lBQ0UsYUFBYSxFQUFFO2dCQUNiLGlCQUFpQixFQUFFLElBQUk7Z0JBQ3ZCLGVBQWUsRUFBRSxhQUFhO2dCQUM5QixpQkFBaUIsRUFBRSxlQUFlO2dCQUNsQyxTQUFTLEVBQUUsT0FBTzthQUNuQjtTQUNGLEVBQ0QsRUFBQyxLQUFLLEVBQUUsRUFBQyxhQUFhLEVBQUUsRUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFDLEVBQUMsRUFBQyxDQUN0QzthQUNBLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDVCwyQkFBMkI7WUFDM0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDakMsaUNBQWlDO1lBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZDLG1DQUFtQztZQUNuQyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQzthQUNELE1BQU0sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSyxNQUFNLENBQUMscUJBQXFCLENBQ2xDLE1BQWtCLEVBQ2xCLFFBQWtCLEVBQ2xCLFdBQThCO1FBRTlCLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNyQixPQUFRLE1BQStELENBQUMsS0FBSzthQUMxRSxnQkFBZ0IsQ0FBQyxRQUFRLENBQUM7YUFDMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2QsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ2pDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDeEMsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQzthQUNELE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssTUFBTSxDQUFDLFVBQVUsQ0FDdkIsS0FBZSxFQUNmLEtBQVUsRUFDVixhQUFzQjtRQUV0QixNQUFNLElBQUksR0FBNkIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7WUFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBVyxFQUFFLElBQUksQ0FBQztZQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDNUIsTUFBTSxLQUFLLEdBQW1CLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN2RCxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLFdBQVcsRUFBRSxDQUFDIn0=