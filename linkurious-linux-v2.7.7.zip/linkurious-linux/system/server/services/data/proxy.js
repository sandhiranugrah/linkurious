"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-09.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// external libs
const Bluebird = require("bluebird");
const _ = require("lodash");
// services
const LKE = require("../index");
const Utils = LKE.getUtils();
const Data = LKE.getData();
const Access = LKE.getAccess();
const audit = LKE.getAuditTrail();
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
// locals
const proxy_1 = require("../../../lib/proxy");
const lkeIsReadOnly = !Config.get('access.dataEdition');
// TODO the WrappedUser should be optional. We check in the proxy if the user is defined
class DataProxyFactory extends proxy_1.ProxyFactory {
    constructor() {
        super();
        this.proxy('resolveSource');
        this.check('getSourceStates', undefined, (user, result) => {
            return user.hasAction('admin.connect', undefined, false).then(canConnect => {
                return result.filter(source => {
                    // visible: (not connected AND user can connect sources) OR (connected AND visible to current user)
                    return ((!source.key && canConnect) || (source.key && user.canSeeDataSource(source.key, false)));
                });
            });
        });
        this.check('getNodeCount', (user, sourceKey) => {
            return Bluebird.resolve().then(() => {
                user.canSeeDataSource(sourceKey);
            });
        });
        this.check('getNode', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options).then(() => {
                // check if the alternative ID is readable (if any)
                return user.canReadProperty('node', options.sourceKey, options.alternativeId);
            });
        }, (user, result, options) => {
            return user
                .filterSubGraph(options.sourceKey, result, {
                withAccess: false
            })
                .then(filteredSubGraph => {
                return audit
                    .read(user, options.sourceKey, 'getNode', { id: options.id }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('getNodesByID', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options).then(() => {
                // check if the alternative ID is readable (if any)
                return user.canReadProperty('node', options.sourceKey, options.alternativeId);
            });
        }, (user, result, options) => {
            return user.filterNodesContent(options.sourceKey, result).then(filteredNodes => {
                // if (proxyOptions.withAccess) {
                //   return user.addNodesAccess(options.sourceKey, filteredNodes);
                // }
                return filteredNodes;
            });
        });
        this.check('getEdgesByID', (user, options) => {
            // check if the alternative ID is readable (if any)
            return user.canReadProperty('edge', options.sourceKey, options.alternativeId);
        }, (user, result, options) => {
            return user.filterEdgesContent(options.sourceKey, result).then(filteredEdges => {
                // if (proxyOptions.withAccess) {
                //   return user.addEdgesAccess(options.sourceKey, filteredEdges);
                // }
                return filteredEdges;
            });
        });
        this.check('getNodesAndEdgesByID', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options)
                .then(() => {
                // check if the alternative IDs are readable (if any)
                return user.canReadProperty('node', options.sourceKey, options.alternativeNodeId);
            })
                .then(() => {
                return user.canReadProperty('edge', options.sourceKey, options.alternativeEdgeId);
            });
        }, (user, result, options) => {
            const originalNodesLength = result.result.nodes.length;
            const originalEdgesLength = result.result.edges.length;
            return user
                .filterSubGraph(options.sourceKey, result.result, {
                withAccess: false
            })
                .then(filteredSubGraph => {
                let isFiltered = false;
                if (filteredSubGraph.nodes.length !== originalNodesLength ||
                    filteredSubGraph.edges.length !== originalEdgesLength) {
                    isFiltered = true;
                }
                return {
                    isFiltered: isFiltered,
                    result: filteredSubGraph
                };
            });
        });
        this.check(
        // TODO fail if the user cannot see data-source
        // TODO fail if I can't read the main node or edge in getNode getEdge
        'getAdjacentNodes', (user, nodeIds, options, sourceKey) => {
            return addReadableCategoriesOrTypes(user, sourceKey, options).then(() => {
                return user.canReadNodes(sourceKey, nodeIds);
            });
        }, (user, result, nodeIds, options, sourceKey) => {
            return user
                .filterSubGraph(sourceKey, result, {
                withAccess: false
            })
                .then(filteredSubGraph => {
                return audit
                    .read(user, sourceKey, 'getAdjacentNodes', { nodeIds: nodeIds }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('getStatistics', (user, ids, sourceKey, options) => {
            return addReadableCategoriesOrTypes(user, sourceKey, options)
                .then(() => {
                return user.canReadNodes(sourceKey, ids);
            })
                .return();
        }, (user, result, ids, sourceKey, options) => {
            return Bluebird.props({
                supernode: result.supernode,
                supernodeDegree: result.supernodeDegree,
                supernodeDigest: result.supernodeDigest,
                degree: result.degree,
                digest: Bluebird.resolve().then(() => {
                    if (Utils.hasValue(result.digest)) {
                        return user.filterDigest(sourceKey, result.digest);
                    }
                    return;
                })
            });
        });
        this.check('createNode', (user, node, sourceKey) => {
            user.checkHiddenNodeProperties(sourceKey, node);
            return user.canEditCategories(sourceKey, node.categories);
        }, (user, result, node, sourceKey) => {
            return user
                .filterNodeContent(sourceKey, result)
                .then(filteredNode => {
                // if (proxyOptions.withAccess) {
                //   return user.addNodesAccess(sourceKey, [filteredNode]).return(filteredNode);
                // }
                return filteredNode;
            })
                .then(filteredNode => {
                return audit
                    .write(user, sourceKey, 'createNode', { createInfo: node }, { node: filteredNode })
                    .return(filteredNode);
            });
        });
        this.check('updateNode', (user, nodeId, nodeUpdate, sourceKey) => {
            user.checkHiddenNodeProperties(sourceKey, nodeUpdate, nodeUpdate.deletedProperties);
            return user.canEditNode(sourceKey, nodeId).then(() => {
                const categoriesToEdit = []
                    .concat(nodeUpdate.addedCategories || [])
                    .concat(nodeUpdate.deletedCategories || []);
                return user.canEditCategories(sourceKey, categoriesToEdit);
            });
        }, (user, result, nodeId, nodeUpdate, sourceKey) => {
            return user.filterNodeContent(sourceKey, result).then(filteredNode => {
                return audit
                    .write(user, sourceKey, 'updateNode', {
                    updateInfo: _.defaults(nodeUpdate, {
                        data: {},
                        deletedCategories: [],
                        addedCategories: [],
                        deletedProperties: []
                    }),
                    nodeId: nodeId
                }, { node: filteredNode })
                    .return(filteredNode);
            });
        });
        this.check('deleteNode', (user, nodeId, sourceKey) => {
            return user.canDeleteNode(sourceKey, nodeId).return();
        }, (user, result, nodeId, sourceKey) => {
            return audit
                .write(user, sourceKey, 'deleteNode', {
                nodeId: nodeId
            })
                .return(result);
        });
        this.check('runGraphQuery', (user, params) => __awaiter(this, void 0, void 0, function* () {
            const source = Data.resolveSource(params.dataSource);
            const isWrite = source.graph.checkQuery(params.query);
            if (isWrite) {
                if (source.isReadOnly()) {
                    return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
                }
                if (lkeIsReadOnly) {
                    return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
                }
            }
            params.filterSubGraph = filterSubGraphWholeOrNothing(user, params.dataSource);
            return addReadableCategoriesOrTypes(user, params.dataSource, params);
        }), (user, result, params) => __awaiter(this, void 0, void 0, function* () {
            return audit
                .readWrite(user, params.dataSource, 'rawQuery', { query: params.query, dialect: params.dialect }, result)
                .return(result);
        }));
        this.check('runGraphQueryByContent', (user, params) => __awaiter(this, void 0, void 0, function* () {
            const source = Data.resolveSource(params.dataSource);
            const isWrite = source.graph.checkQuery(params.query);
            if (!isWrite) {
                const currentUser = yield Access.checkAuth(user, 'graph.rawRead');
                yield currentUser.hasAction('rawReadQuery', params.dataSource);
            }
            else {
                const currentUser = yield Access.checkAuth(user, 'graph.rawWrite');
                yield currentUser.hasAction('rawWriteQuery', params.dataSource);
                if (source.isReadOnly()) {
                    return Errors.access('write_forbidden', 'The data-source is in read-only mode.', true);
                }
                if (lkeIsReadOnly) {
                    return Errors.access('readonly_right', 'Linkurious is in read-only mode.', true);
                }
            }
            params.filterSubGraph = filterSubGraphWholeOrNothing(user, params.dataSource);
            return addReadableCategoriesOrTypes(user, params.dataSource, params);
        }), (user, result, params) => __awaiter(this, void 0, void 0, function* () {
            return audit
                .readWrite(user, params.dataSource, 'rawQuery', { query: params.query, dialect: params.dialect }, result)
                .return(result);
        }));
        this.check('alertPreview', (user, options) => __awaiter(this, void 0, void 0, function* () {
            yield user.hasAction('admin.alerts', options.dataSource);
        }), (user, result, options) => {
            return Bluebird.reduce(result.results, (filteredMatches, match) => {
                return user.filterSubGraph(options.dataSource, match, {}).then(filteredMatch => {
                    if (filteredMatch.nodes.length > 0) {
                        filteredMatch.columns = match.columns;
                        filteredMatches.push(filteredMatch);
                    }
                    return filteredMatches;
                });
            }, []).then(results => ({ results: results }));
        });
        this.check('getEdgeCount', (user, sourceKey) => {
            return Bluebird.resolve().then(() => {
                user.canSeeDataSource(sourceKey);
            });
        });
        this.check('getEdge', (user, options) => {
            return addReadableCategoriesOrTypes(user, options.sourceKey, options).then(() => {
                // check if the alternative ID is readable (if any)
                return user.canReadProperty('edge', options.sourceKey, options.alternativeId);
            });
        }, (user, result, options) => {
            return user
                .filterSubGraph(options.sourceKey, result, {
                withAccess: false,
                discardNodesWithNoEdges: true
            })
                .then(filteredSubGraph => {
                return audit
                    .read(user, options.sourceKey, 'getEdge', { id: options.id }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('createEdge', (user, edge, sourceKey) => {
            user.checkHiddenEdgeProperties(sourceKey, edge);
            return user.canEditType(sourceKey, edge.type).return();
        }, (user, result, edge, sourceKey) => {
            return Bluebird.resolve()
                .then(() => {
                const filteredEdge = user.filterEdgeProperties(sourceKey, result);
                // if (proxyOptions.withAccess) {
                //   return user.addEdgesAccess(sourceKey, [filteredEdge]).return(filteredEdge);
                // }
                return filteredEdge;
            })
                .then(filteredEdge => {
                return audit
                    .write(user, sourceKey, 'createEdge', { createInfo: edge }, { edge: filteredEdge })
                    .return(filteredEdge);
            });
        });
        this.check('updateEdge', (user, edgeId, edgeUpdate, sourceKey) => {
            user.checkHiddenEdgeProperties(sourceKey, edgeUpdate, edgeUpdate.deletedProperties);
            return user.canEditEdge(sourceKey, edgeId).return();
        }, (user, result, edgeId, edgeUpdate, sourceKey) => {
            const filteredEdge = user.filterEdgeProperties(sourceKey, result);
            return audit
                .write(user, sourceKey, 'updateEdge', {
                updateInfo: _.defaults(edgeUpdate, {
                    data: {},
                    deletedProperties: []
                }),
                edgeId: edgeId
            }, { edge: filteredEdge })
                .return(filteredEdge);
        });
        this.check('deleteEdge', (user, edgeId, sourceKey) => {
            return user.canDeleteEdge(sourceKey, edgeId).return();
        }, (user, result, edgeId, sourceKey) => {
            return audit.write(user, sourceKey, 'deleteEdge', { edgeId: edgeId }).return(result);
        });
        this.check('searchIndex', (user, searchOptions, sourceKey, options) => {
            const getReadable = searchOptions.type === 'node'
                ? user.readableCategories(sourceKey)
                : user.readableTypes(sourceKey);
            return getReadable.then(readable => {
                // if all is readable, don't touch the filter in options
                if (readable[0] === '*') {
                    return;
                }
                if (Utils.noValue(searchOptions.categoriesOrTypes)) {
                    searchOptions.categoriesOrTypes = readable;
                }
                // if both filters (user input and access rights) are defined, we take the intersection
                searchOptions.categoriesOrTypes = _.intersection(searchOptions.categoriesOrTypes, readable);
            });
        }, (user, result, searchOptions, sourceKey, options) => {
            return Bluebird.resolve()
                .then(() => {
                if (searchOptions.type === 'node') {
                    return user.filterNodesContent(sourceKey, result.results);
                }
                else {
                    return user.filterEdgesContent(sourceKey, result.results);
                }
            })
                .then(filteredItems => {
                result.results = filteredItems;
                return result;
            });
        });
        this.check('searchFull', (user, searchOptions, sourceKey, options) => {
            return addReadableCategoriesOrTypes(user, sourceKey, options);
        }, (user, result, searchOptions, sourceKey, options) => {
            // we don't keep nodes with no edges if we are requesting edges
            const discardNodesWithNoEdges = searchOptions.type === 'edge';
            return user
                .filterSubGraph(sourceKey, result, {
                withAccess: false,
                discardNodesWithNoEdges: discardNodesWithNoEdges
            })
                .then(filteredSubGraph => {
                return audit
                    .read(user, sourceKey, 'searchFull', { searchString: searchOptions.q }, filteredSubGraph)
                    .return(filteredSubGraph);
            });
        });
        this.check('getSimpleSchema', (user, params) => __awaiter(this, void 0, void 0, function* () {
            yield Access.checkAuth(user, 'schema', true);
            user.canSeeDataSource(params.dataSource);
        }));
        this.check('getSchemaNodeTypes', undefined, (user, result, options) => {
            const hidden = Data.resolveSource(options.sourceKey).getHiddenNodeProperties();
            result.results.map(type => {
                type.properties = filterHiddenProperties(type.properties, hidden);
            });
            return user.getSchemaWithAccess(options.sourceKey, 'node', result).then(schemaWithAccess => {
                schemaWithAccess.results = schemaWithAccess.results.filter(type => type.access !== 'none');
                return schemaWithAccess;
            });
        });
        this.check('getSchemaEdgeTypes', undefined, (user, result, options) => {
            const hidden = Data.resolveSource(options.sourceKey).getHiddenEdgeProperties();
            result.results.map(type => {
                type.properties = filterHiddenProperties(type.properties, hidden);
            });
            return user.getSchemaWithAccess(options.sourceKey, 'edge', result).then(schemaWithAccess => {
                schemaWithAccess.results = schemaWithAccess.results.filter(type => type.access !== 'none');
                return schemaWithAccess;
            });
        });
        this.check('getSchemaEdgeProperties', undefined, (user, result, options) => {
            const hidden = options.omitNoIndex
                ? Data.resolveSource(options.sourceKey).getNoIndexEdgeProperties(true)
                : Data.resolveSource(options.sourceKey).getHiddenEdgeProperties();
            return Bluebird.resolve(filterHiddenProperties(result, hidden));
        });
        this.check('getSchemaNodeProperties', undefined, (user, result, options) => {
            const hidden = options.omitNoIndex
                ? Data.resolveSource(options.sourceKey).getNoIndexNodeProperties(true)
                : Data.resolveSource(options.sourceKey).getHiddenNodeProperties();
            return Bluebird.resolve(filterHiddenProperties(result, hidden));
        });
        this.check('asyncIndexSource', (user, sourceKey) => __awaiter(this, void 0, void 0, function* () {
            yield user.hasAction('admin.index', sourceKey);
        }));
        this.check('checkGraphQuery', (user, params) => __awaiter(this, void 0, void 0, function* () {
            yield Access.checkAuth(user, 'graph.rawRead', true);
            yield user.hasAction('rawReadQuery', params.dataSource);
        }));
    }
}
function filterSubGraphWholeOrNothing(user, sourceKey) {
    return (subGraph) => __awaiter(this, void 0, void 0, function* () {
        if (subGraph.nodes.length === 0 && subGraph.edges.length === 0) {
            return Promise.resolve(subGraph);
        }
        return user
            .filterSubGraph(sourceKey, subGraph, {
            allOrNothing: true
        })
            .then(filteredSubGraph => {
            if (filteredSubGraph.nodes.length === 0 && filteredSubGraph.edges.length === 0) {
                return null;
            }
            return filteredSubGraph;
        });
    });
}
function filterHiddenProperties(properties, hiddenProperties) {
    const hiddenByName = Utils.arrayToMap(hiddenProperties);
    return _.filter(properties, property => !hiddenByName[property.key]);
}
/**
 * Add to the object `options` the keys `readableCategories` and `readableTypes`.
 *
 * @param user
 * @param sourceKey Key of the data-source
 * @param options
 */
function addReadableCategoriesOrTypes(user, sourceKey, options) {
    return Bluebird.join(user.readableCategories(sourceKey).then(categories => {
        if (categories[0] !== '*') {
            options.readableCategories = categories;
        } // else, if all is readable, the filter `readableCategories` is left undefined
    }), user.readableTypes(sourceKey).then(types => {
        if (types[0] !== '*') {
            options.readableTypes = types;
        }
    })).return();
}
module.exports = new DataProxyFactory().proxify(Data);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJveHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9wcm94eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7OztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFDckMsNEJBQTRCO0FBRTVCLFdBQVc7QUFDWCxnQ0FBaUM7QUFDakMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUMzQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQ2xDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULDhDQUFnRDtBQUloRCxNQUFNLGFBQWEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUV4RCx3RkFBd0Y7QUFDeEYsTUFBTSxnQkFBaUIsU0FBUSxvQkFBc0M7SUFDbkU7UUFDRSxLQUFLLEVBQUUsQ0FBQztRQUVSLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7UUFFNUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDeEQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUN6RSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzVCLG1HQUFtRztvQkFDbkcsT0FBTyxDQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUN4RixDQUFDO2dCQUNKLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzdDLE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNuQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLEtBQUssQ0FDUixTQUFTLEVBQ1QsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDaEIsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUM5RSxtREFBbUQ7Z0JBQ25ELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDaEYsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3hCLE9BQU8sSUFBSTtpQkFDUixjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUU7Z0JBQ3pDLFVBQVUsRUFBRSxLQUFLO2FBQ2xCLENBQUM7aUJBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ3ZCLE9BQU8sS0FBSztxQkFDVCxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLEVBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEVBQUMsRUFBRSxnQkFBZ0IsQ0FBQztxQkFDNUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsY0FBYyxFQUNkLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2hCLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDOUUsbURBQW1EO2dCQUNuRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2hGLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN4QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDN0UsaUNBQWlDO2dCQUNqQyxrRUFBa0U7Z0JBQ2xFLElBQUk7Z0JBQ0osT0FBTyxhQUFhLENBQUM7WUFDdkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsY0FBYyxFQUNkLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2hCLG1EQUFtRDtZQUNuRCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ2hGLENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDeEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQzdFLGlDQUFpQztnQkFDakMsa0VBQWtFO2dCQUNsRSxJQUFJO2dCQUNKLE9BQU8sYUFBYSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUNGLENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxDQUNSLHNCQUFzQixFQUN0QixDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNoQixPQUFPLDRCQUE0QixDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQztpQkFDbEUsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxxREFBcUQ7Z0JBQ3JELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUNwRixDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDVCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3hCLE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ3ZELE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBRXZELE9BQU8sSUFBSTtpQkFDUixjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUNoRCxVQUFVLEVBQUUsS0FBSzthQUNsQixDQUFDO2lCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO2dCQUN2QixJQUFJLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQ3ZCLElBQ0UsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxtQkFBbUI7b0JBQ3JELGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssbUJBQW1CLEVBQ3JEO29CQUNBLFVBQVUsR0FBRyxJQUFJLENBQUM7aUJBQ25CO2dCQUVELE9BQU87b0JBQ0wsVUFBVSxFQUFFLFVBQVU7b0JBQ3RCLE1BQU0sRUFBRSxnQkFBZ0I7aUJBQ3pCLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUs7UUFDUiwrQ0FBK0M7UUFDL0MscUVBQXFFO1FBQ3JFLGtCQUFrQixFQUNsQixDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ3BDLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUN0RSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQy9DLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzVDLE9BQU8sSUFBSTtpQkFDUixjQUFjLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRTtnQkFDakMsVUFBVSxFQUFFLEtBQUs7YUFDbEIsQ0FBQztpQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxLQUFLO3FCQUNULElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxFQUFFLGdCQUFnQixDQUFDO3FCQUMvRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixlQUFlLEVBQ2YsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNoQyxPQUFPLDRCQUE0QixDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDO2lCQUMxRCxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO2lCQUNELE1BQU0sRUFBRSxDQUFDO1FBQ2QsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3hDLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFDcEIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO2dCQUMzQixlQUFlLEVBQUUsTUFBTSxDQUFDLGVBQWU7Z0JBQ3ZDLGVBQWUsRUFBRSxNQUFNLENBQUMsZUFBZTtnQkFDdkMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO2dCQUNyQixNQUFNLEVBQUUsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FDN0IsR0FBcUQsRUFBRTtvQkFDckQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsTUFBd0IsQ0FBQyxDQUFDO3FCQUN0RTtvQkFDRCxPQUFPO2dCQUNULENBQUMsQ0FDRjthQUNGLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDaEQsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1RCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUNoQyxPQUFPLElBQUk7aUJBQ1IsaUJBQWlCLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQztpQkFDcEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUNuQixpQ0FBaUM7Z0JBQ2pDLGdGQUFnRjtnQkFDaEYsSUFBSTtnQkFDSixPQUFPLFlBQVksQ0FBQztZQUN0QixDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO2dCQUNuQixPQUFPLEtBQUs7cUJBQ1QsS0FBSyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLEVBQUMsVUFBVSxFQUFFLElBQUksRUFBQyxFQUFFLEVBQUMsSUFBSSxFQUFFLFlBQVksRUFBQyxDQUFDO3FCQUM5RSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsWUFBWSxFQUNaLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDdEMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDcEYsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNuRCxNQUFNLGdCQUFnQixHQUFJLEVBQWU7cUJBQ3RDLE1BQU0sQ0FBQyxVQUFVLENBQUMsZUFBZSxJQUFJLEVBQUUsQ0FBQztxQkFDeEMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFFOUMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDN0QsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDOUMsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDbkUsT0FBTyxLQUFLO3FCQUNULEtBQUssQ0FDSixJQUFJLEVBQ0osU0FBUyxFQUNULFlBQVksRUFDWjtvQkFDRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUU7d0JBQ2pDLElBQUksRUFBRSxFQUFFO3dCQUNSLGlCQUFpQixFQUFFLEVBQUU7d0JBQ3JCLGVBQWUsRUFBRSxFQUFFO3dCQUNuQixpQkFBaUIsRUFBRSxFQUFFO3FCQUN0QixDQUFDO29CQUNGLE1BQU0sRUFBRSxNQUFNO2lCQUNmLEVBQ0QsRUFBQyxJQUFJLEVBQUUsWUFBWSxFQUFDLENBQ3JCO3FCQUNBLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEQsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDbEMsT0FBTyxLQUFLO2lCQUNULEtBQUssQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRTtnQkFDcEMsTUFBTSxFQUFFLE1BQU07YUFDZixDQUFDO2lCQUNELE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsZUFBZSxFQUNmLENBQU8sSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JCLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3JELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUV0RCxJQUFJLE9BQU8sRUFBRTtnQkFDWCxJQUFJLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBRTtvQkFDdkIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUN4RjtnQkFFRCxJQUFJLGFBQWEsRUFBRTtvQkFDakIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGtDQUFrQyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNsRjthQUNGO1lBRUQsTUFBTSxDQUFDLGNBQWMsR0FBRyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRTlFLE9BQU8sNEJBQTRCLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsQ0FBQyxDQUFBLEVBQ0QsQ0FBTyxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzdCLE9BQU8sS0FBSztpQkFDVCxTQUFTLENBQ1IsSUFBSSxFQUNKLE1BQU0sQ0FBQyxVQUFVLEVBQ2pCLFVBQVUsRUFDVixFQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxFQUFDLEVBQzlDLE1BQU0sQ0FDUDtpQkFDQSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsQ0FBQyxDQUFBLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1Isd0JBQXdCLEVBQ3hCLENBQU8sSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JCLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXJELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUV0RCxJQUFJLENBQUMsT0FBTyxFQUFFO2dCQUNaLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ2xFLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ2hFO2lCQUFNO2dCQUNMLE1BQU0sV0FBVyxHQUFHLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDbkUsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBRWhFLElBQUksTUFBTSxDQUFDLFVBQVUsRUFBRSxFQUFFO29CQUN2QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3hGO2dCQUNELElBQUksYUFBYSxFQUFFO29CQUNqQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ2xGO2FBQ0Y7WUFFRCxNQUFNLENBQUMsY0FBYyxHQUFHLDRCQUE0QixDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFOUUsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxDQUFDLENBQUEsRUFDRCxDQUFPLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDN0IsT0FBTyxLQUFLO2lCQUNULFNBQVMsQ0FDUixJQUFJLEVBQ0osTUFBTSxDQUFDLFVBQVUsRUFDakIsVUFBVSxFQUNWLEVBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLEVBQUMsRUFDOUMsTUFBTSxDQUNQO2lCQUNBLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixDQUFDLENBQUEsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixjQUFjLEVBQ2QsQ0FBTyxJQUFJLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDdEIsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFBLEVBQ0QsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3hCLE9BQU8sUUFBUSxDQUFDLE1BQU0sQ0FDcEIsTUFBTSxDQUFDLE9BQU8sRUFDZCxDQUFDLGVBQWUsRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDekIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtvQkFDN0UsSUFBSSxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ2xDLGFBQWEsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQzt3QkFDdEMsZUFBZSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztxQkFDckM7b0JBRUQsT0FBTyxlQUFlLENBQUM7Z0JBQ3pCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxFQUNELEVBSUUsQ0FDSCxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDN0MsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUNSLFNBQVMsRUFDVCxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNoQixPQUFPLDRCQUE0QixDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQzlFLG1EQUFtRDtnQkFDbkQsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNoRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDeEIsT0FBTyxJQUFJO2lCQUNSLGNBQWMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRTtnQkFDekMsVUFBVSxFQUFFLEtBQUs7Z0JBQ2pCLHVCQUF1QixFQUFFLElBQUk7YUFDOUIsQ0FBQztpQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxLQUFLO3FCQUNULElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsRUFBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUUsRUFBQyxFQUFFLGdCQUFnQixDQUFDO3FCQUM1RSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDaEQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDekQsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDaEMsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFO2lCQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNULE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ2xFLGlDQUFpQztnQkFDakMsZ0ZBQWdGO2dCQUNoRixJQUFJO2dCQUNKLE9BQU8sWUFBWSxDQUFDO1lBQ3RCLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQ25CLE9BQU8sS0FBSztxQkFDVCxLQUFLLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsRUFBQyxVQUFVLEVBQUUsSUFBSSxFQUFDLEVBQUUsRUFBQyxJQUFJLEVBQUUsWUFBWSxFQUFDLENBQUM7cUJBQzlFLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUN0QyxJQUFJLENBQUMseUJBQXlCLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUNwRixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RELENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUM5QyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2xFLE9BQU8sS0FBSztpQkFDVCxLQUFLLENBQ0osSUFBSSxFQUNKLFNBQVMsRUFDVCxZQUFZLEVBQ1o7Z0JBQ0UsVUFBVSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO29CQUNqQyxJQUFJLEVBQUUsRUFBRTtvQkFDUixpQkFBaUIsRUFBRSxFQUFFO2lCQUN0QixDQUFDO2dCQUNGLE1BQU0sRUFBRSxNQUFNO2FBQ2YsRUFDRCxFQUFDLElBQUksRUFBRSxZQUFZLEVBQUMsQ0FDckI7aUJBQ0EsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixZQUFZLEVBQ1osQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEQsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUU7WUFDbEMsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JGLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FDUixhQUFhLEVBQ2IsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUMxQyxNQUFNLFdBQVcsR0FDZixhQUFhLENBQUMsSUFBSSxLQUFLLE1BQU07Z0JBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDO2dCQUNwQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwQyxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ2pDLHdEQUF3RDtnQkFDeEQsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO29CQUN2QixPQUFPO2lCQUNSO2dCQUVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsRUFBRTtvQkFDbEQsYUFBYSxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQztpQkFDNUM7Z0JBRUQsdUZBQXVGO2dCQUN2RixhQUFhLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FDOUMsYUFBYSxDQUFDLGlCQUFpQixFQUMvQixRQUFRLENBQ1QsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUNELENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ2xELE9BQU8sUUFBUSxDQUFDLE9BQU8sRUFBRTtpQkFDdEIsSUFBSSxDQUNILEdBQThDLEVBQUU7Z0JBQzlDLElBQUksYUFBYSxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7b0JBQ2pDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsT0FBeUIsQ0FBQyxDQUFDO2lCQUM3RTtxQkFBTTtvQkFDTCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLE9BQXlCLENBQUMsQ0FBQztpQkFDN0U7WUFDSCxDQUFDLENBQ0Y7aUJBQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUNwQixNQUFNLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQztnQkFFL0IsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxLQUFLLENBQ1IsWUFBWSxFQUNaLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDMUMsT0FBTyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hFLENBQUMsRUFDRCxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUNsRCwrREFBK0Q7WUFDL0QsTUFBTSx1QkFBdUIsR0FBRyxhQUFhLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQztZQUU5RCxPQUFPLElBQUk7aUJBQ1IsY0FBYyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUU7Z0JBQ2pDLFVBQVUsRUFBRSxLQUFLO2dCQUNqQix1QkFBdUIsRUFBRSx1QkFBdUI7YUFDakQsQ0FBQztpQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxLQUFLO3FCQUNULElBQUksQ0FDSCxJQUFJLEVBQ0osU0FBUyxFQUNULFlBQVksRUFDWixFQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUFDLEVBQy9CLGdCQUFnQixDQUNqQjtxQkFDQSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFPLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUNuRCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQSxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixFQUFFLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDcEUsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUMvRSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3BFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7Z0JBQ3pGLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQztnQkFDM0YsT0FBTyxnQkFBZ0IsQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3BFLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0UsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNwRSxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO2dCQUN6RixnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUM7Z0JBQzNGLE9BQU8sZ0JBQWdCLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRTtZQUN6RSxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsV0FBVztnQkFDaEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQztnQkFDdEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDcEUsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsRUFBRSxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFO1lBQ3pFLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxXQUFXO2dCQUNoQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDO2dCQUN0RSxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUNwRSxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLENBQU8sSUFBSSxFQUFFLFNBQVMsRUFBRSxFQUFFO1lBQ3ZELE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFBLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBTyxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDbkQsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDcEQsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUQsQ0FBQyxDQUFBLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELFNBQVMsNEJBQTRCLENBQ25DLElBQWlCLEVBQ2pCLFNBQWlCO0lBRWpCLE9BQU8sQ0FBTyxRQUE2QixFQUF1QyxFQUFFO1FBQ2xGLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDbEM7UUFFRCxPQUFPLElBQUk7YUFDUixjQUFjLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRTtZQUNuQyxZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDO2FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDdkIsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDOUUsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUNELE9BQU8sZ0JBQWdCLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLENBQUEsQ0FBQztBQUNKLENBQUM7QUFFRCxTQUFTLHNCQUFzQixDQUM3QixVQUFpQyxFQUNqQyxnQkFBMEI7SUFFMUIsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3hELE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN2RSxDQUFDO0FBRUQ7Ozs7OztHQU1HO0FBQ0gsU0FBUyw0QkFBNEIsQ0FDbkMsSUFBaUIsRUFDakIsU0FBaUIsRUFDakIsT0FBZ0I7SUFFaEIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUNsQixJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ25ELElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtZQUN4QixPQUEyQyxDQUFDLGtCQUFrQixHQUFHLFVBQVUsQ0FBQztTQUM5RSxDQUFDLDhFQUE4RTtJQUNsRixDQUFDLENBQUMsRUFDRixJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUN6QyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7WUFDbkIsT0FBc0MsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1NBQy9EO0lBQ0gsQ0FBQyxDQUFDLENBQ0gsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUNiLENBQUM7QUFFRCxpQkFBUyxJQUFJLGdCQUFnQixFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDIn0=