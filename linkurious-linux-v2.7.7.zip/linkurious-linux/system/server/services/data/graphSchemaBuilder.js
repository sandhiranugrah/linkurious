/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-14.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const DbModels = LKE.getSqlDb().models;
const sqlDb = LKE.getSqlDb();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
/**
 *
 * @param {string} name
 * @constructor
 */
function TypeMapEntry(name) {
    this.name = name;
    this.properties = new Map();
}
TypeMapEntry.prototype = {
    name: null,
    count: 0,
    properties: null,
    /**
     * Add an item to this type.
     * Increments the count for the type and each contained property.
     *
     * @param {string[]} properties item properties
     */
    addProperties: function (properties) {
        this.count++;
        let count, key;
        for (let i = 0, l = properties.length; i < l; ++i) {
            key = properties[i];
            count = this.properties.get(key);
            this.properties.set(key, count === undefined ? 1 : count + 1);
        }
    }
};
/**
 * @param {DataSource} dataSource
 * @constructor
 */
function GraphSchemaBuilder(dataSource) {
    this.source = dataSource;
    this.nodeTypesByName = new Map();
    this.edgeTypesByName = new Map();
}
GraphSchemaBuilder.prototype = {
    freeze: false,
    /**
     * @type {Map<string, TypeMapEntry>}
     */
    nodeTypesByName: null,
    /**
     * @type {Map<string, TypeMapEntry>}
     */
    edgeTypesByName: null,
    /**
     * Reset `nodeTypesByName` and `edgeTypesByName` maps.
     */
    init: function () {
        this.nodeTypesByName.clear();
        this.edgeTypesByName.clear();
    },
    /**
     * @param {string} itemType "node" or "edge"
     * @param {{name:string, count:number, properties:{key:string, count:number}[]}[]} types
     */
    ingestTypes: function (itemType, types) {
        const map = itemType === 'node' ? this.nodeTypesByName : this.edgeTypesByName;
        types.forEach(type => {
            const entry = new TypeMapEntry(type.name);
            entry.count = type.count;
            if (Utils.hasValue(type.properties)) {
                type.properties.forEach(property => {
                    entry.properties.set(property.key, property.count);
                });
            }
            map.set(entry.name, entry);
        });
    },
    /**
     * Clear the schema info for a data-source.
     *
     * @param {string} sourceKey Key of the data-source
     * @returns {Promise}
     */
    deleteAll: function (sourceKey) {
        Utils.checkSourceKey(sourceKey);
        // removing properties before types because of foreign key constraints
        return Promise.props({
            removeNodeProperties: DbModels.nodeProperty.destroy({ where: { sourceKey: sourceKey } }),
            removeEdgeProperty: DbModels.edgeProperty.destroy({ where: { sourceKey: sourceKey } })
        }).then(() => Promise.props({
            removeNodeTypes: DbModels.nodeType.destroy({ where: { sourceKey: sourceKey } }),
            removeEdgeType: DbModels.edgeType.destroy({ where: { sourceKey: sourceKey } })
        }));
    },
    /**
     * This methods takes as an argument an array of nodes. It builds up the the node Types in memory.
     *
     *  When created from a category, node types have a name
     *  and the properties are not strictly assigned to a type. Ergo, some nodes can be part of a node
     *  type without having all the node type properties.
     *
     *  When the node does not have a category, it is not included in the schema.
     *
     * @param {LkNode[]} nodes list of nodes. As an abstracted view of a specific implementation of the used
     * @param {number} nodes.id
     * @param {string[]} nodes.categories name of the node categories
     * @param {object} nodes.data properties by key
     */
    ingestNodes: function (nodes) {
        for (let i = 0, l = nodes.length; i < l; ++i) {
            this.ingestNode(nodes[i]);
        }
    },
    /**
     *
     * @param {LkNode} node
     */
    ingestNode: function (node) {
        const properties = itemProperties(node);
        // update/create each node type
        const typeNames = this._getNodeTypeNames(node);
        let typeName, nodeTypeEntry;
        for (let i = 0, l = typeNames.length; i < l; ++i) {
            typeName = typeNames[i];
            /**
             * @type {TypeMapEntry}
             */
            nodeTypeEntry = this.nodeTypesByName.get(typeName);
            // create node type if not already existing
            if (nodeTypeEntry === undefined) {
                nodeTypeEntry = new TypeMapEntry(typeName);
                this.nodeTypesByName.set(typeName, nodeTypeEntry);
            }
            // update the type info
            nodeTypeEntry.addProperties(properties);
        }
    },
    /**
     * This methods takes as an argument an array of edges. It creates the edge schema in memory.
     *
     *  An edge type is defined as a Linkurious abstraction is defined as the unique tuple
     *  composed with a starting nodeType an ending node Type and the String that characterises the
     *  nature of the edge between the two nodeTypes
     *
     * That way we store the most information about our graph, statistics can be inferred from there.
     *
     * @param {LkEdge[]} edges list of edges
     * @param {number} edges.id
     * @param {string} edges.type name of the edge type
     * @param {object} edges.data properties by key
     */
    ingestEdges: function (edges) {
        for (let i = 0, l = edges.length; i < l; ++i) {
            this.ingestEdge(edges[i]);
        }
    },
    /**
     *
     * @param {LkEdge} edge
     */
    ingestEdge: function (edge) {
        // add properties field
        const properties = itemProperties(edge);
        // update/create each edge type
        const edgeTypeNames = this._getEdgeTypeNames(edge);
        let edgeTypeName, edgeTypeEntry;
        for (let i = 0, l = edgeTypeNames.length; i < l; ++i) {
            edgeTypeName = edgeTypeNames[i];
            /**
             * @type {TypeMapEntry}
             */
            edgeTypeEntry = this.edgeTypesByName.get(edgeTypeName);
            // create edge type if not already existing
            if (edgeTypeEntry === undefined) {
                edgeTypeEntry = new TypeMapEntry(edgeTypeName);
                this.edgeTypesByName.set(edgeTypeName, edgeTypeEntry);
            }
            // update the type info
            edgeTypeEntry.addProperties(properties);
        }
    },
    /**
     * Saves the detected schema to the database.
     *
     * @returns {Promise}
     */
    saveSchema: function () {
        return this._saveTypes('node').then(() => {
            return this._saveTypes('edge');
        }).then(() => {
            this.init(this.freeze);
            return sqlDb.sync();
        });
    },
    /**
     * Persist node and edge types stored in `nodeTypesByName` and `edgeTypesName`.
     * Type instances are created 20 by 20 to avoid generating huge SQL statements.
     *
     * @param {string} type 'node' or 'edge'
     * @returns {Promise}
     * @private
     */
    _saveTypes: function (type) {
        const typesByName = type === 'node' ? this.nodeTypesByName : this.edgeTypesByName;
        const typeModel = type === 'node' ? 'nodeType' : 'edgeType';
        const propertyModel = type === 'node' ? 'nodeProperty' : 'edgeProperty';
        const sourceKey = this.source.getSourceKey();
        const typesToCreate = [];
        typesByName.forEach(type => {
            typesToCreate.push({
                name: type.name,
                count: type.count,
                sourceKey: sourceKey
            });
        });
        Log.info(`Saving new database schema: ${typesToCreate.length} detected ${type} types.`);
        return Utils.sliceMap(typesToCreate, 20, typesSlice => {
            // create 20 node/edge types
            return Promise.resolve(DbModels[typeModel].bulkCreate(typesSlice)).then(() => {
                // read the created type instances back
                const names = typesSlice.map(t => t.name);
                return Promise.resolve(DbModels[typeModel].findAll({
                    where: { sourceKey: sourceKey, name: names }
                }));
            }).map(typeInstance => {
                // match types and type instances
                const typeEntry = typesByName.get(typeInstance.name);
                // cannot find the original type?
                if (!typeEntry) {
                    Log.warn(`"${type}" type not found: ${typeInstance.name}`);
                    return;
                }
                // build properties array for node-type
                const propertiesToAdd = [];
                typeEntry.properties.forEach((value, key) => {
                    propertiesToAdd.push({
                        sourceKey: sourceKey,
                        key: key,
                        count: value,
                        // explicitly set the foreign key to type instance to enable bulk creation
                        typeId: typeInstance.id
                    });
                });
                // add properties for type instance
                return DbModels[propertyModel].bulkCreate(propertiesToAdd);
            });
        });
    },
    // ------------------------------------------------------------------------------------------
    //                           Schema maintenance on Nodes operations
    // ------------------------------------------------------------------------------------------
    /**
     * Updates the graph schema upon node creation.
     *
     * @param {LkNode} newNode created node
     * @returns {Promise}
     */
    nodeCreation: function (newNode) {
        return this._itemCreation('node', newNode);
    },
    /**
     * Updates the graph schema upon node deletion.
     *
     * @param {LkNode} oldNode node that was deleted
     * @returns {Promise}
     */
    nodeDeletion: function (oldNode) {
        return this._itemDeletion('node', oldNode);
    },
    /**
     * Updates the graph schema upon node modification.
     *
     * @param {LkNode} nodeBefore node before the update
     * @param {LkNode} nodeAfter node after the update
     * @returns {Promise}
     */
    nodeUpdate: function (nodeBefore, nodeAfter) {
        return this._itemUpdate('node', nodeBefore, nodeAfter);
    },
    /**
     * List node type names for a node.
     *
     * @param {LkNode} node
     * @returns {string[]} nodeTypeNames
     * @private
     */
    _getNodeTypeNames: function (node) {
        if (Utils.hasValue(node.categories) && node.categories.length > 0) {
            return node.categories.concat(['*']);
        }
        return ['*'];
    },
    // ------------------------------------------------------------------------------------------
    //                     Schema maintenance on Edges operations
    // ------------------------------------------------------------------------------------------
    /**
     * Updates the graph schema upon edge creation
     *
     * @param {LkEdge} newEdge created edge
     * @returns {Promise}
     */
    edgeCreation: function (newEdge) {
        return this._itemCreation('edge', newEdge);
    },
    /**
     * Updates the graph schema when an edge is deleted
     *
     * @param {LkEdge} oldEdge edge that was deleted
     * @returns {Promise}
     */
    edgeDeletion: function (oldEdge) {
        return this._itemDeletion('edge', oldEdge);
    },
    /**
     * Updates the graph schema when an edge is updated
     *
     * @param {LkEdge} edgeBefore edge before the update
     * @param {LkEdge} edgeAfter edge after the update
     * @returns {Promise}
     */
    edgeUpdate: function (edgeBefore, edgeAfter) {
        return this._itemUpdate('edge', edgeBefore, edgeAfter);
    },
    /**
     * List edge type names for an edge.
     *
     * @param {LkEdge} edge
     * @returns {string[]} edgeTypeNames
     * @private
     */
    _getEdgeTypeNames: function (edge) {
        if (Utils.hasValue(edge.type)) {
            return [edge.type, '*'];
        }
        return ['*'];
    },
    // ------------------------------------------------------------------------------------------
    //                     Abstract Schema maintenance operations
    // ------------------------------------------------------------------------------------------
    /**
     * Updates the graph schema upon node/edge creation.
     *
     * @param {string} type 'node' or 'edge'
     * @param {LkNode|LkEdge} newItem
     * @returns {Promise}
     * @private
     */
    _itemCreation: function (type, newItem) {
        return this._getOrCreateTypeInstances(type, newItem).each(typeInstance => {
            return incrementInstanceCount(typeInstance).then(() => {
                return this._incrementTypeProperties(type, typeInstance, itemProperties(newItem));
            });
        });
    },
    /**
     * Updates the graph schema upon node/edge deletion.
     *
     * @param {string} type 'node' or 'edge'
     * @param {LkNode|LkEdge} oldItem
     * @returns {Promise}
     * @private
     */
    _itemDeletion: function (type, oldItem) {
        return this._getOrCreateTypeInstances(type, oldItem).each(typeInstance => {
            return this._decrementTypeProperties(type, typeInstance, itemProperties(oldItem)).then(() => {
                return decrementInstanceCount(typeInstance, this.freeze);
            });
        });
    },
    /**
     * Updates the graph schema upon node/edge modification.
     *
     * @param {string} type 'node' or 'edge'
     * @param {LkNode|LkEdge} itemBefore
     * @param {LkNode|LkEdge} itemAfter
     * @returns {Promise}
     * @private
     */
    _itemUpdate: function (type, itemBefore, itemAfter) {
        const typeChanged = this._checkTypesChanged(type, itemBefore, itemAfter);
        if (typeChanged) {
            // the types/categories have changed
            return this._itemDeletion(type, itemBefore).then(() => {
                return this._itemCreation(type, itemAfter);
            });
        }
        // the types/categories have not changed
        const propertyChanges = getPropertyChanges(itemBefore, itemAfter);
        return this._getOrCreateTypeInstances(type, itemAfter).each(typeInstance => {
            // increment/create added properties of type instance
            return this._incrementTypeProperties(type, typeInstance, propertyChanges.added).then(() => {
                // decrement/delete removed properties of type instance
                return this._decrementTypeProperties(type, typeInstance, propertyChanges.deleted);
            });
        });
    },
    /**
     * Get edgeTypes or nodeTypes by name. Does not create missing ones.
     *
     * @param {string} type 'node' or 'edge'
     * @param {string[]} typeNames
     * @returns {Bluebird<edgeType[]|nodeType[]>} edgeType or nodeType instances
     * @private
     */
    _getTypeInstances: function (type, typeNames) {
        const typeModel = type === 'node' ? 'nodeType' : 'edgeType';
        const propertyModel = type === 'node' ? 'nodeProperty' : 'edgeProperty';
        // cast sequelize promise into bluebird A+ promise
        return Promise.resolve(DbModels[typeModel].findAll({
            where: {
                name: typeNames,
                sourceKey: this.source.getSourceKey()
            },
            include: [{ model: DbModels[propertyModel] }]
        }));
    },
    /**
     * Creates edgeTypes or nodeTypes by name (count set to 0)
     *
     * @param {string} type 'node' or 'edge'
     * @param {string[]} typeNames
     * @returns {Bluebird<edgeType[]|nodeType[]>}
     * @private
     */
    _createTypeInstances: function (type, typeNames) {
        const typeModel = type === 'node' ? 'nodeType' : 'edgeType';
        const typesToCreate = typeNames.map(typeName => ({
            name: typeName,
            sourceKey: this.source.getSourceKey(),
            count: 0
        }));
        // update user groups for access to new types
        return DbModels[typeModel].bulkCreate(typesToCreate);
    },
    /**
     * Increment property counts for a node type or an edge type.
     * Missing properties are created.
     *
     * @param {string} type 'node' or 'edge'
     * @param {edgeType|nodeType} typeInstance nodeType or edgeType sequelize instance
     * @param {String[]} propertyKeys list of properties keys to create or increment
     * @returns {Promise}
     * @private
     */
    _incrementTypeProperties: function (type, typeInstance, propertyKeys) {
        const propertiesField = type === 'node' ? 'nodeProperties' : 'edgeProperties';
        const propertyModel = type === 'node' ? 'nodeProperty' : 'edgeProperty';
        const propertiesToCreate = [];
        // index existing properties by key
        const existingPropertiesByKey = _.keyBy(typeInstance[propertiesField], 'key');
        // update each property
        return Promise.each(propertyKeys, propertyKey => {
            const propertyInstance = existingPropertiesByKey[propertyKey];
            // if the property already exists in DB, just increment it
            if (propertyInstance !== undefined) {
                return incrementInstanceCount(propertyInstance);
            }
            // else, create a new property for bulk creation
            propertiesToCreate.push({
                key: propertyKey,
                count: 1,
                sourceKey: typeInstance.sourceKey,
                // explicitly set the foreign key to type instance to enable bulk creation
                typeId: typeInstance.id
            });
        }).then(() => {
            // create missing edge properties in DB
            if (propertiesToCreate.length === 0) {
                return;
            }
            return DbModels[propertyModel].bulkCreate(propertiesToCreate);
        });
    },
    /**
     * Decrement property counts for edge type.
     * Properties with a count reaching 0 are deleted.
     *
     * @param {string} type 'node' or 'edge'
     * @param {edgeType|nodeType} typeInstance nodeType or edgeType sequelize instance
     * @param {String[]} propertyKeys list of properties keys to decrement or destroy
     * @returns {Promise}
     * @private
     */
    _decrementTypeProperties: function (type, typeInstance, propertyKeys) {
        const propertiesField = type === 'node' ? 'nodeProperties' : 'edgeProperties';
        // index existing properties by name
        const existingPropertiesByKey = _.keyBy(typeInstance[propertiesField], 'key');
        // update each property
        return Promise.each(propertyKeys, propertyKey => {
            const propertyInstance = existingPropertiesByKey[propertyKey];
            // if the property does not exist, ignore
            if (propertyInstance === undefined) {
                return;
            }
            // else, decrement or delete
            return decrementInstanceCount(propertyInstance, this.freeze);
        });
    },
    /**
     * Get types instances for an item. If some types are missing from DB, creates them.
     *
     * @param {string} type 'node' or 'edge'
     * @param {LkNode|LkEdge} item
     * @returns {Bluebird<edgeType>|Bluebird<nodeType>}
     * @private
     */
    _getOrCreateTypeInstances: function (type, item) {
        const typeNames = type === 'node'
            ? this._getNodeTypeNames(item)
            : this._getEdgeTypeNames(item);
        // read types instances from DB
        return this._getTypeInstances(type, typeNames).then(typeInstances => {
            // compute list of types names NOT already in DB
            const missingTypeNames = _.difference(typeNames, typeInstances.map(t => t.name));
            // no missing instance types, return now
            if (missingTypeNames.length === 0) {
                return typeInstances;
            }
            // create missing types instances in DB
            return this._createTypeInstances(type, missingTypeNames).then(() => {
                // return complete list, after creation of missing instances
                return this._getTypeInstances(type, typeNames);
            });
        });
    },
    /**
     * Detect if the item's types (node categories or edge types) have changed.
     *
     * @param {string} type 'node' or 'edge'
     * @param {LkNode|LkEdge} itemBefore
     * @param {LkNode|LkEdge} itemAfter
     * @returns {boolean} true if the types have changed
     * @private
     */
    _checkTypesChanged: function (type, itemBefore, itemAfter) {
        let typesBefore, typesAfter;
        if (type === 'node') {
            typesBefore = this._getNodeTypeNames(itemBefore);
            typesAfter = this._getNodeTypeNames(itemAfter);
        }
        else {
            typesBefore = this._getEdgeTypeNames(itemBefore);
            typesAfter = this._getEdgeTypeNames(itemAfter);
        }
        if (typesBefore.length !== typesAfter.length) {
            // added or removed
            return true;
        }
        if (_.difference(typesBefore, typesAfter).length > 0) {
            // some removed types
            return true;
        }
        if (_.difference(typesAfter, typesBefore).length > 0) {
            // some added types
            return true;
        }
        return false;
    }
};
// Private helpers
/**
 * Decrements the count of the instance argument.
 * If the count reaches zero, the instance is destroyed from DB.
 *
 * @param {nodeType|edgeType|nodeProperty|edgeProperty} instance Sequelize instance
 * @param {number}  instance.count value to decrement
 * @param {boolean} keep           Whether to keep instances with count zero in the schema
 * @returns {Promise}
 */
function decrementInstanceCount(instance, keep) {
    if (instance.count > 1) {
        instance.count--;
        return instance.save({ fields: ['count'] });
    }
    else {
        if (keep) {
            return Promise.resolve();
        }
        return instance.destroy();
    }
}
/**
 * Increments the count of the instance argument.
 *
 * @param {nodeType|edgeType|nodeProperty|edgeProperty} instance Sequelize instance
 * @param {number} instance.count value to increment
 * @returns {Promise}
 */
function incrementInstanceCount(instance) {
    instance.count++;
    return instance.save({ fields: ['count'] });
}
/**
 * Compute the property changes for an item (node / edge)
 *
 * @param {object} itemBefore
 * @param {object} itemBefore.data property values by key (before)
 * @param {object} itemAfter
 * @param {object} itemAfter.data property values by key (after)
 * @returns {{added: string[], deleted: string[]}}
 */
function getPropertyChanges(itemBefore, itemAfter) {
    const propertiesBefore = itemProperties(itemBefore);
    const propertiesAfter = itemProperties(itemAfter);
    return {
        added: _.difference(propertiesAfter, propertiesBefore),
        deleted: _.difference(propertiesBefore, propertiesAfter)
    };
}
/**
 *
 * @param {LkNode|LkEdge} item
 * @param {object} item.data
 * @returns {string[]} sorted list of property names
 */
function itemProperties(item) {
    if (!item.data) {
        return [];
    }
    return Object.keys(item.data).sort();
}
module.exports = GraphSchemaBuilder;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWFCdWlsZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL2RhdGEvZ3JhcGhTY2hlbWFCdWlsZGVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ3ZDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0Qzs7OztHQUlHO0FBQ0gsU0FBUyxZQUFZLENBQUMsSUFBSTtJQUN4QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztJQUNqQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7QUFDOUIsQ0FBQztBQUVELFlBQVksQ0FBQyxTQUFTLEdBQUc7SUFDdkIsSUFBSSxFQUFFLElBQUk7SUFDVixLQUFLLEVBQUUsQ0FBQztJQUNSLFVBQVUsRUFBRSxJQUFJO0lBRWhCOzs7OztPQUtHO0lBQ0gsYUFBYSxFQUFFLFVBQVMsVUFBVTtRQUNoQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDYixJQUFJLEtBQUssRUFBRSxHQUFHLENBQUM7UUFDZixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2pELEdBQUcsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDcEIsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztTQUMvRDtJQUNILENBQUM7Q0FDRixDQUFDO0FBRUY7OztHQUdHO0FBQ0gsU0FBUyxrQkFBa0IsQ0FBQyxVQUFVO0lBQ3BDLElBQUksQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO0lBQ3pCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUNqQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7QUFDbkMsQ0FBQztBQUVELGtCQUFrQixDQUFDLFNBQVMsR0FBRztJQUU3QixNQUFNLEVBQUUsS0FBSztJQUViOztPQUVHO0lBQ0gsZUFBZSxFQUFFLElBQUk7SUFFckI7O09BRUc7SUFDSCxlQUFlLEVBQUUsSUFBSTtJQUVyQjs7T0FFRztJQUNILElBQUksRUFBRTtRQUNKLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsV0FBVyxFQUFFLFVBQVMsUUFBUSxFQUFFLEtBQUs7UUFDbkMsTUFBTSxHQUFHLEdBQUcsUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM5RSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25CLE1BQU0sS0FBSyxHQUFHLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxQyxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFFekIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ2pDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUMsQ0FBQzthQUNKO1lBRUQsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsU0FBUyxFQUFFLFVBQVMsU0FBUztRQUMzQixLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hDLHNFQUFzRTtRQUN0RSxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDbkIsb0JBQW9CLEVBQUUsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQztZQUNwRixrQkFBa0IsRUFBRSxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUMsRUFBQyxDQUFDO1NBQ25GLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUMxQixlQUFlLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQztZQUMzRSxjQUFjLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQztTQUMzRSxDQUFDLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsV0FBVyxFQUFFLFVBQVMsS0FBSztRQUN6QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQzVDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDM0I7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsVUFBVSxFQUFFLFVBQVMsSUFBSTtRQUN2QixNQUFNLFVBQVUsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFeEMsK0JBQStCO1FBQy9CLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQyxJQUFJLFFBQVEsRUFBRSxhQUFhLENBQUM7UUFDNUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNoRCxRQUFRLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhCOztlQUVHO1lBQ0gsYUFBYSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRW5ELDJDQUEyQztZQUMzQyxJQUFJLGFBQWEsS0FBSyxTQUFTLEVBQUU7Z0JBQy9CLGFBQWEsR0FBRyxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2FBQ25EO1lBRUQsdUJBQXVCO1lBQ3ZCLGFBQWEsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDekM7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILFdBQVcsRUFBRSxVQUFTLEtBQUs7UUFDekIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzNCO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNILFVBQVUsRUFBRSxVQUFTLElBQUk7UUFDdkIsdUJBQXVCO1FBQ3ZCLE1BQU0sVUFBVSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV4QywrQkFBK0I7UUFDL0IsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRW5ELElBQUksWUFBWSxFQUFFLGFBQWEsQ0FBQztRQUNoQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3BELFlBQVksR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFaEM7O2VBRUc7WUFDSCxhQUFhLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFdkQsMkNBQTJDO1lBQzNDLElBQUksYUFBYSxLQUFLLFNBQVMsRUFBRTtnQkFDL0IsYUFBYSxHQUFHLElBQUksWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLENBQUM7YUFDdkQ7WUFFRCx1QkFBdUI7WUFDdkIsYUFBYSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUN6QztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsVUFBVSxFQUFFO1FBQ1YsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDdkMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QixPQUFPLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsVUFBVSxFQUFFLFVBQVMsSUFBSTtRQUN2QixNQUFNLFdBQVcsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQ2xGLE1BQU0sU0FBUyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO1FBQzVELE1BQU0sYUFBYSxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO1FBRXhFLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFN0MsTUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDekIsYUFBYSxDQUFDLElBQUksQ0FBQztnQkFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztnQkFDakIsU0FBUyxFQUFFLFNBQVM7YUFDckIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxHQUFHLENBQUMsSUFBSSxDQUFDLCtCQUErQixhQUFhLENBQUMsTUFBTSxhQUFhLElBQUksU0FBUyxDQUFDLENBQUM7UUFFeEYsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxFQUFFLEVBQUUsVUFBVSxDQUFDLEVBQUU7WUFDcEQsNEJBQTRCO1lBQzVCLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFFM0UsdUNBQXVDO2dCQUN2QyxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMxQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztvQkFDakQsS0FBSyxFQUFFLEVBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFDO2lCQUMzQyxDQUFDLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFFcEIsaUNBQWlDO2dCQUNqQyxNQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFckQsaUNBQWlDO2dCQUNqQyxJQUFJLENBQUMsU0FBUyxFQUFFO29CQUNkLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLHFCQUFxQixZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDM0QsT0FBTztpQkFDUjtnQkFFRCx1Q0FBdUM7Z0JBQ3ZDLE1BQU0sZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFDM0IsU0FBUyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7b0JBQzFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7d0JBQ25CLFNBQVMsRUFBRSxTQUFTO3dCQUNwQixHQUFHLEVBQUUsR0FBRzt3QkFDUixLQUFLLEVBQUUsS0FBSzt3QkFDWiwwRUFBMEU7d0JBQzFFLE1BQU0sRUFBRSxZQUFZLENBQUMsRUFBRTtxQkFDeEIsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUVILG1DQUFtQztnQkFDbkMsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzdELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsNkZBQTZGO0lBQzdGLG1FQUFtRTtJQUNuRSw2RkFBNkY7SUFFN0Y7Ozs7O09BS0c7SUFDSCxZQUFZLEVBQUUsVUFBUyxPQUFPO1FBQzVCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBWSxFQUFFLFVBQVMsT0FBTztRQUM1QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxVQUFVLEVBQUUsVUFBUyxVQUFVLEVBQUUsU0FBUztRQUN4QyxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsaUJBQWlCLEVBQUUsVUFBUyxJQUFJO1FBQzlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ2pFLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ3RDO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2YsQ0FBQztJQUVELDZGQUE2RjtJQUM3Riw2REFBNkQ7SUFDN0QsNkZBQTZGO0lBRTdGOzs7OztPQUtHO0lBQ0gsWUFBWSxFQUFFLFVBQVMsT0FBTztRQUM1QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQVksRUFBRSxVQUFTLE9BQU87UUFDNUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsVUFBVSxFQUFFLFVBQVMsVUFBVSxFQUFFLFNBQVM7UUFDeEMsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGlCQUFpQixFQUFFLFVBQVMsSUFBSTtRQUM5QixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3pCO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2YsQ0FBQztJQUVELDZGQUE2RjtJQUM3Riw2REFBNkQ7SUFDN0QsNkZBQTZGO0lBRTdGOzs7Ozs7O09BT0c7SUFDSCxhQUFhLEVBQUUsVUFBUyxJQUFJLEVBQUUsT0FBTztRQUNuQyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3ZFLE9BQU8sc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDcEQsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUNwRixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxhQUFhLEVBQUUsVUFBUyxJQUFJLEVBQUUsT0FBTztRQUNuQyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3ZFLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksRUFBRSxZQUFZLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDMUYsT0FBTyxzQkFBc0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxXQUFXLEVBQUUsVUFBUyxJQUFJLEVBQUUsVUFBVSxFQUFFLFNBQVM7UUFDL0MsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFekUsSUFBSSxXQUFXLEVBQUU7WUFDZixvQ0FBb0M7WUFDcEMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCx3Q0FBd0M7UUFDeEMsTUFBTSxlQUFlLEdBQUcsa0JBQWtCLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDekUscURBQXFEO1lBQ3JELE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksRUFBRSxZQUFZLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3hGLHVEQUF1RDtnQkFDdkQsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsaUJBQWlCLEVBQUUsVUFBUyxJQUFJLEVBQUUsU0FBUztRQUN6QyxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUM1RCxNQUFNLGFBQWEsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztRQUV4RSxrREFBa0Q7UUFDbEQsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDakQsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxTQUFTO2dCQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTthQUN0QztZQUNELE9BQU8sRUFBRSxDQUFDLEVBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBQyxDQUFDO1NBQzVDLENBQUMsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxvQkFBb0IsRUFBRSxVQUFTLElBQUksRUFBRSxTQUFTO1FBQzVDLE1BQU0sU0FBUyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO1FBQzVELE1BQU0sYUFBYSxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9DLElBQUksRUFBRSxRQUFRO1lBQ2QsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFO1lBQ3JDLEtBQUssRUFBRSxDQUFDO1NBQ1QsQ0FBQyxDQUFDLENBQUM7UUFFSiw2Q0FBNkM7UUFDN0MsT0FBTyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCx3QkFBd0IsRUFBRSxVQUFTLElBQUksRUFBRSxZQUFZLEVBQUUsWUFBWTtRQUNqRSxNQUFNLGVBQWUsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7UUFDOUUsTUFBTSxhQUFhLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFDeEUsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLENBQUM7UUFFOUIsbUNBQW1DO1FBQ25DLE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFOUUsdUJBQXVCO1FBQ3ZCLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsV0FBVyxDQUFDLEVBQUU7WUFDOUMsTUFBTSxnQkFBZ0IsR0FBRyx1QkFBdUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUU5RCwwREFBMEQ7WUFDMUQsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLEVBQUU7Z0JBQ2xDLE9BQU8sc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzthQUNqRDtZQUVELGdEQUFnRDtZQUNoRCxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RCLEdBQUcsRUFBRSxXQUFXO2dCQUNoQixLQUFLLEVBQUUsQ0FBQztnQkFDUixTQUFTLEVBQUUsWUFBWSxDQUFDLFNBQVM7Z0JBQ2pDLDBFQUEwRTtnQkFDMUUsTUFBTSxFQUFFLFlBQVksQ0FBQyxFQUFFO2FBQ3hCLENBQUMsQ0FBQztRQUVMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFFWCx1Q0FBdUM7WUFDdkMsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUFFLE9BQU87YUFBRTtZQUNoRCxPQUFPLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNoRSxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCx3QkFBd0IsRUFBRSxVQUFTLElBQUksRUFBRSxZQUFZLEVBQUUsWUFBWTtRQUNqRSxNQUFNLGVBQWUsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7UUFFOUUsb0NBQW9DO1FBQ3BDLE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFOUUsdUJBQXVCO1FBQ3ZCLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsV0FBVyxDQUFDLEVBQUU7WUFDOUMsTUFBTSxnQkFBZ0IsR0FBRyx1QkFBdUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUU5RCx5Q0FBeUM7WUFDekMsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLEVBQUU7Z0JBQUUsT0FBTzthQUFFO1lBRS9DLDRCQUE0QjtZQUM1QixPQUFPLHNCQUFzQixDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gseUJBQXlCLEVBQUUsVUFBUyxJQUFJLEVBQUUsSUFBSTtRQUM1QyxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQUssTUFBTTtZQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQztZQUM5QixDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRWpDLCtCQUErQjtRQUMvQixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBRWxFLGdEQUFnRDtZQUNoRCxNQUFNLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUVqRix3Q0FBd0M7WUFDeEMsSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNqQyxPQUFPLGFBQWEsQ0FBQzthQUN0QjtZQUVELHVDQUF1QztZQUN2QyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUVqRSw0REFBNEQ7Z0JBQzVELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUNqRCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsa0JBQWtCLEVBQUUsVUFBUyxJQUFJLEVBQUUsVUFBVSxFQUFFLFNBQVM7UUFDdEQsSUFBSSxXQUFXLEVBQUUsVUFBVSxDQUFDO1FBRTVCLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtZQUNuQixXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ2pELFVBQVUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDaEQ7YUFBTTtZQUNMLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDakQsVUFBVSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNoRDtRQUVELElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQUMsTUFBTSxFQUFFO1lBQzVDLG1CQUFtQjtZQUNuQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BELHFCQUFxQjtZQUNyQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BELG1CQUFtQjtZQUNuQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0NBQ0YsQ0FBQztBQUVGLGtCQUFrQjtBQUVsQjs7Ozs7Ozs7R0FRRztBQUNILFNBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFLElBQUk7SUFDNUMsSUFBSSxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTtRQUN0QixRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDakIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0tBQzNDO1NBQU07UUFDTCxJQUFJLElBQUksRUFBRTtZQUNSLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsT0FBTyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7S0FDM0I7QUFDSCxDQUFDO0FBRUQ7Ozs7OztHQU1HO0FBQ0gsU0FBUyxzQkFBc0IsQ0FBQyxRQUFRO0lBQ3RDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNqQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsU0FBUyxrQkFBa0IsQ0FBQyxVQUFVLEVBQUUsU0FBUztJQUMvQyxNQUFNLGdCQUFnQixHQUFHLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNwRCxNQUFNLGVBQWUsR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbEQsT0FBTztRQUNMLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxnQkFBZ0IsQ0FBQztRQUN0RCxPQUFPLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxlQUFlLENBQUM7S0FDekQsQ0FBQztBQUNKLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILFNBQVMsY0FBYyxDQUFDLElBQUk7SUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFBRSxPQUFPLEVBQUUsQ0FBQztLQUFFO0lBQzlCLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDdkMsQ0FBQztBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsa0JBQWtCLENBQUMifQ==