/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-02-11.
 */
'use strict';
// services
const LKE = require('../index');
const Utils = LKE.getUtils();
class Progress {
    /**
     * @param {CustomLogger} logger
     * @param {string}       [prefix='']        Used to prefix all log messages
     * @param {number}       [progressStep=0.5] Minimum progress difference (in percentage) between two log messages
     */
    constructor(logger, prefix, progressStep) {
        this._logger = logger;
        this._prefix = prefix || '';
        this._progressStep = progressStep || 0.5;
        // total number of items to index
        this._totalItems = 0;
        // indexation start time
        this._startTime = 0;
        // type of items at latest batch (for logging purpose)
        this._label = 'item';
        // initial number of items already indexed
        this._initialOffset = 0;
        // progress in percentage
        this._progress = 0;
        // estimated time left in milliseconds
        this._timeLeft = 0;
        // total number of indexed items
        this._totalDone = 0;
        // duration in milliseconds
        this._totalDuration = 0;
        // items indexed per milliseconds in average
        this._averageSpeed = 0;
        // total number of items left to be indexed
        this._itemsLeft = 0;
    }
    /**
     * Initialize a progress instance.
     *
     * @param {number} totalItems
     */
    start(totalItems) {
        this._totalItems = totalItems;
        this._startTime = Date.now();
    }
    /**
     * Return a string representing the average indexation speed.
     *
     * @returns {string}
     */
    getRate() {
        return (1000 * this._averageSpeed).toFixed(0) + ' ' + this._label + 's/s';
    }
    /**
     * Return a string representing the percentage of the indexation.
     *
     * @returns {string}
     */
    getPercent() {
        return this._progress.toFixed(2);
    }
    /**
     * Return a string representing the time left for the indexation to finish.
     *
     * @returns {string}
     */
    getTimeLeft() {
        return Utils.humanDuration(this._timeLeft);
    }
    /**
     * Return the count of already indexed items.
     *
     * @returns {number}
     */
    getTotalIndexedItems() {
        return this._totalDone + this._initialOffset;
    }
    /**
     * Log an end message.
     */
    end() {
        this._log(`Done: ${this._totalDone} items in ${Utils.humanDuration(this._totalDuration)} ` +
            `(average speed: ${(1000 * this._averageSpeed).toFixed(0)} items/s)`);
    }
    /**
     * Add an array of items (or a value representing their cardinality) to the progress,
     * without counting them for the average speed.
     *
     * @param {string} label
     * @param {number | Array<any>} items
     */
    setInitialOffset(label, items) {
        let batchLength;
        if (Array.isArray(items)) {
            batchLength = items.length;
        }
        else {
            batchLength = /**@type {number}*/ (items);
        }
        this._totalDone += batchLength;
        this._initialOffset += batchLength;
    }
    /**
     * Add an array of items (or a value representing their cardinality) to the progress.
     *
     * @param {string} label
     * @param {number | Array<any>} items
     */
    add(label, items) {
        let batchLength;
        if (Array.isArray(items)) {
            batchLength = items.length;
        }
        else {
            batchLength = /**@type {number}*/ (items);
        }
        const prevProgress = this._progress;
        this._label = label;
        this._totalDone += batchLength;
        this._totalDuration = Date.now() - this._startTime;
        this._averageSpeed = (this._totalDone - this._initialOffset) / this._totalDuration;
        this._itemsLeft = Math.max(0, this._totalItems - this._totalDone);
        this._progress = 100 * this._totalDone / this._totalItems;
        this._timeLeft = this._itemsLeft / this._averageSpeed;
        if (this._progress + this._progressStep > prevProgress) {
            this._log(`[${this.getPercent()}%]` +
                ` Already indexed ${this._totalDone} items in ${Utils.humanDuration(this._totalDuration)}` +
                ` at ${this.getRate()} (average).` +
                ` Time left: ${this.getTimeLeft()}`);
        }
    }
    /**
     * @param {any} message
     * @private
     */
    _log(message) {
        this._logger.info(this._prefix + ' ' + message);
    }
}
module.exports = Progress;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZ3Jlc3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZGF0YS9wcm9ncmVzcy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBRTdCLE1BQU0sUUFBUTtJQUNaOzs7O09BSUc7SUFDSCxZQUFZLE1BQU0sRUFBRSxNQUFNLEVBQUUsWUFBWTtRQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxZQUFZLElBQUksR0FBRyxDQUFDO1FBRXpDLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUNyQix3QkFBd0I7UUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7UUFDcEIsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3JCLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQztRQUN4Qix5QkFBeUI7UUFDekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbkIsc0NBQXNDO1FBQ3RDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLGdDQUFnQztRQUNoQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztRQUNwQiwyQkFBMkI7UUFDM0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUM7UUFDeEIsNENBQTRDO1FBQzVDLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZCLDJDQUEyQztRQUMzQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztJQUN0QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxVQUFVO1FBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7UUFDOUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxPQUFPO1FBQ0wsT0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUM1RSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVU7UUFDUixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVztRQUNULE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0I7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDL0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsR0FBRztRQUNELElBQUksQ0FBQyxJQUFJLENBQ1AsU0FBUyxJQUFJLENBQUMsVUFBVSxhQUFhLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHO1lBQ2hGLG1CQUFtQixDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQ3JFLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLEtBQUs7UUFDM0IsSUFBSSxXQUFXLENBQUM7UUFDaEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3hCLFdBQVcsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1NBQzVCO2FBQU07WUFDTCxXQUFXLEdBQUcsbUJBQW1CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksQ0FBQyxVQUFVLElBQUksV0FBVyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLElBQUksV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSztRQUNkLElBQUksV0FBVyxDQUFDO1FBQ2hCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUN4QixXQUFXLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztTQUM1QjthQUFNO1lBQ0wsV0FBVyxHQUFHLG1CQUFtQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDM0M7UUFFRCxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBRXBDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBRXBCLElBQUksQ0FBQyxVQUFVLElBQUksV0FBVyxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDbkQsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDbkYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDMUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFFdEQsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLEdBQUcsWUFBWSxFQUFFO1lBQ3RELElBQUksQ0FBQyxJQUFJLENBQ1AsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUk7Z0JBQ3pCLG9CQUFvQixJQUFJLENBQUMsVUFBVSxhQUFhLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUMxRixPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYTtnQkFDbEMsZUFBZSxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FDcEMsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNILElBQUksQ0FBQyxPQUFPO1FBQ1YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsT0FBTyxDQUFDLENBQUM7SUFDbEQsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMifQ==