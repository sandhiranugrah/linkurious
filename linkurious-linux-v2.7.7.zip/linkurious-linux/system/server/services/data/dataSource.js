/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * Used to manage a dataSource (graph server info + searchIndex server info).
 * - to connect to graph server and searchIndex server
 *
 * - Created on 2015-01-09.
 */
'use strict';
// internal libs
const crypto = require('crypto');
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
const Db = LKE.getSqlDb();
const Errors = LKE.getErrors();
// locals
const GraphDAO = require('../../dao/graph/graphDAO');
const IndexDAO = require('../../dao/index/indexDAO');
const GraphSchemaBuilder = require('./graphSchemaBuilder');
const Progress = require('./progress');
const CappedMap = require('../../../lib/CappedMap');
const VisualizationChecker = require('../business/VisualizationChecker');
const DesignUtils = require('../business/designUtils');
const { LkError } = require('../../models/errors/LkError');
// default size of the progress bar when the counts of nodes and edges are not available
const DEFAULT_PROGRESS_BAR_SIZE = 100000;
// number of edited items (nodes and edges) of which we keep the last edit date in memory
const LAST_EDIT_DATE_MAP_SIZE = 200;
/**
 * Data-source features
 *
 * @typedef {object} LkDataSourceFeatures
 * @property {boolean} typing                  whether this source is able to produce type information for properties
 * @property {boolean} edgeProperties          whether edge properties are supported
 * @property {boolean} immutableNodeCategories true if node categories are immutable
 * @property {number} minNodeCategories        the minimum number of categories for a node
 * @property {number} maxNodeCategories        the maximum number of categories for a node
 * @property {boolean} canCount                whether one among the graph or the index can count nodes and edges
 * @property {boolean} alerts                  whether alerts are supported
 * @property {string[]} dialects               list of supported graph-query dialects
 * @property {boolean} externalIndex           whether the index is external
 * @property {boolean} alternativeIds          whether alternative IDs are supported by the Graph DAO
 * @property {boolean} fuzzy                   whether the index allows fuzzy search queries
 * @property {boolean} canIndexEdges           whether the index can index edges
 * @property {boolean} canIndexCategories      whether the index can index categories
 * @property {string}  advancedQueryDialect    whether the index can provide advanced search queries
 * @property {boolean} searchHitsCount         whether the search result will contain 'totalHits' or 'moreResults'
 */
/**
 * Create a DataSource
 *
 * @param {number} sourceId index of the source configuration in the dataSources config array
 * @param {Data} dataService the data service
 * @constructor
 */
function DataSource(sourceId, dataService) {
    if (typeof sourceId !== 'number' || isNaN(sourceId)) {
        throw Errors.technical('bug', '"sourceId" is required');
    }
    this.sourceId = sourceId;
    this.dataService = dataService;
    this.pollIntervalMillis = Config.get('advanced.pollInterval', 10) * 1000;
    this._pollGraphState = { timer: null, promise: null };
    this._pollIndexState = { timer: null, promise: null };
    this.indexationRetries = 10;
    // Map of dates indexed by node/edge IDs refering to the last time a given item was edited
    this._lastEditDateMap = new CappedMap(LAST_EDIT_DATE_MAP_SIZE);
    this._resetSource();
}
/**
 * Computes the information of a data-source by concatenating
 * "[graphServerHost]:[graphServerPort]:[graphStoreId]".
 *
 * @param {string} graphServerHost hostname of the source graph server
 * @param {string|number} graphServerPort port of the source graph server
 * @param {string} graphStoreId unique identifier of the database-store in the source graph server
 * @returns {string} the information of the data-source
 */
DataSource.computeSourceInfo = function (graphServerHost, graphServerPort, graphStoreId) {
    return graphServerHost + ':' + graphServerPort + ':' + graphStoreId;
};
/**
 * @param {string} sourceInfo a data-source identification key
 * @returns {string|undefined} an 8 characters HEX string (truncated from full SHA256 HEX of sourceInfo)
 */
DataSource.computeSourceKey = function (sourceInfo) {
    if (sourceInfo === undefined) {
        return undefined;
    }
    const sha256Hash = crypto.createHash('sha256');
    sha256Hash.update(sourceInfo, 'utf8');
    return sha256Hash.digest('hex').substr(0, 8);
};
DataSource.prototype = {
    config: undefined,
    storeId: undefined,
    /**
     * Set manually when we should not interact with this source anymore:
     * - will stop polling graph/index servers
     * - can be removed from sources list
     *
     * @type boolean
     */
    destroyed: false,
    _connecting: false,
    /**
     * The progress of the indexation of null if the source is not currently indexing.
     *
     * @type Progress
     */
    indexingProgress: null,
    /**
     * The GraphDAO of this data-source
     *
     * @type GraphDAO
     */
    graph: undefined,
    graphConnected: false,
    graphConnectPromise: null,
    graphConnectError: null,
    /**
     * The IndexDAO of this data-source
     *
     * @type IndexDAO
     */
    index: undefined,
    indexConnected: false,
    indexConnectPromise: null,
    indexConnectError: null,
    /**
     * @returns {boolean} true if the data-source is currently connected
     */
    isConnected: function () {
        return this.graphConnected && this.indexConnected;
    },
    /**
     * codes: offline, connecting, needConfig, needFirstIndex, needReindex, indexing, ready
     *
     * return {{code:string, reason:string, error?: string}}
     */
    getState: function () {
        if (this.destroyed) {
            return {
                code: 'offline',
                reason: 'Data-source is invalid (please restart Linkurious).'
            };
        }
        // connecting
        if (this.graphConnectPromise) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to graph database ...',
                error: this.graphConnectError
            };
        }
        if (this.indexConnectPromise) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to search index ...',
                error: this.indexConnectError
            };
        }
        if (this._connecting) {
            return {
                code: 'connecting',
                reason: 'Trying to connect to data-source ...',
                error: null
            };
        }
        // offline
        if (!this.graphConnected || !this.indexConnected) {
            if (!this.graphConnected && this.graphConnectError) {
                return {
                    code: 'offline',
                    reason: 'Could not connect to graph database server.',
                    error: this.graphConnectError
                };
            }
            if (!this.indexConnected && this.indexConnectError) {
                return {
                    code: 'offline',
                    reason: 'Could not connect to index server.',
                    error: this.indexConnectError
                };
            }
            return {
                code: 'offline',
                reason: 'Disconnected from data-source.'
            };
        }
        // online:
        // indexing
        if (this.isIndexing()) {
            const p = this.indexingProgress;
            return {
                code: 'indexing',
                reason: 'Currently indexing ' + p.getRate() +
                    '. Progress: ' + p.getPercent() + '%. Time left: ' + p.getTimeLeft()
            };
        }
        // needConfig (source was never configured and never indexed)
        if (this.needConfig()) {
            return {
                code: 'needConfig',
                reason: 'An administrator needs to configure this data-source for indexation.'
            };
        }
        // needFirstIndex (source was configured, but was NEVER indexed)
        if (this.needFirstIndex()) {
            return {
                code: 'needFirstIndex',
                reason: 'The data-source needs to be indexed at least once.',
                error: this.state.indexationError
            };
        }
        // needReindex (source was already indexed, configuration changed, re-index is required)
        if (this.needReindex()) {
            return {
                code: 'needReindex',
                reason: 'The data-source needs to be re-indexed',
                error: this.state.indexationError
            };
        }
        // ready :)
        return { code: 'ready', reason: 'The data-source is ready.' };
    },
    sourceInfoCache: undefined,
    sourceKeyCache: undefined,
    /**
     * @returns {boolean} true if this source is currently indexing
     */
    isIndexing: function () {
        return !!this.indexingProgress;
    },
    /**
     * The hashed version of the value returned by `getSourceInfo`, shorter and non-human readable.
     * Used for API communication.
     *
     * The sourceKey actually identifies the data-source (a graph database on a specific server/port).
     * This ID is used to make accessRights and visualizations relative to a data-source.
     *
     * @param {boolean} [ignoreOffline] If true, won't throw an error if we cannot read the source info
     * @returns {string} an 8 char HEX string identifying a data-source uniquely.
     */
    getSourceKey: function (ignoreOffline) {
        if (this.sourceKeyCache === undefined) {
            if (Utils.hasValue(this.config.manualSourceKey)) {
                Utils.checkSourceKey(this.config.manualSourceKey, 'manualSourceKey');
                this.sourceKeyCache = this.config.manualSourceKey;
            }
            else {
                this.sourceKeyCache = DataSource.computeSourceKey(this.getSourceInfo(ignoreOffline));
            }
        }
        return this.sourceKeyCache;
    },
    /**
     * A string describing the data-source uniquely, as returned by DataSource.computeSourceInfo.
     *
     * @param {boolean} [ignoreOffline=false] If true, won't throw an error if we cannot read the source info
     * @returns {string|undefined} the long version of this data-source's unique identifier
     */
    getSourceInfo: function (ignoreOffline) {
        if (!this.storeId) {
            if (ignoreOffline) {
                return undefined;
            }
            throw Errors.technical('bug', 'DataSource.getSourceInfo called before storeId is set');
        }
        if (this.sourceInfoCache === undefined) {
            const hp = Utils.extractHostPort(this.config.graphdb.url);
            if (!hp) {
                throw Errors.business('invalid_parameter', 'Cannot extract host and port from graph URL (' + this.getSourceName() + ')');
            }
            this.sourceInfoCache = DataSource.computeSourceInfo(hp.host, hp.port, this.storeId);
        }
        return this.sourceInfoCache;
    },
    /**
     * Returns the name of the source (or a default generated name if config.name if not set).
     *
     * @returns {string}
     */
    getSourceName: function () {
        return 'data-source ' + (this.config.name
            ? ('"' + this.config.name + '"')
            : ('#' + this.sourceId));
    },
    /**
     * A display name for this source.
     *
     * @returns {string}
     */
    getDisplayName: function () {
        if (this.state && this.state.name) {
            return this.state.name;
        }
        else if (this.config.name) {
            return this.config.name;
        }
        else {
            return 'Database #' + this.sourceId;
        }
    },
    /**
     * @private
     * @param {boolean} initial whether this event is the initial connection or not
     * @param {boolean} good true if this is good news
     * @param {string} message
     */
    _onConnectionEvent: function (initial, good, message) {
        if (initial) {
            return;
        }
        Log[good ? 'info' : 'error'](message);
    },
    /**
     * @returns {Promise}
     * @private
     */
    _connectGraph: function () {
        const self = this;
        const name = self.getSourceName();
        const connect = () => {
            self.graphConnectError = null;
            return self.graph.connect().then(version => {
                self.graphVersion = version;
                // if a storeId is already set (reconnecting), check that it has not changed
                if (!self.storeId) {
                    return;
                }
                return self.getStoreId().then(storeId => {
                    if (self.storeId !== storeId) {
                        // reset also cancels the current graph connection promise
                        self._resetSource();
                        const message = 'Please retry connecting the data-source (the database has changed).';
                        return Errors.business('critical', message, true);
                    }
                });
            }).then(() => {
                self.graphConnected = true;
                self._onConnectionEvent(true, true, 'Connected to graph database (' + name + ')');
            }).catch(e => {
                self.graphConnectError = e.message ? e.message : 'Unknown error';
                return Promise.reject(e);
            });
        };
        const actionName = 'connecting to graph database (' + name + ')';
        const maxRetries = Config.get('advanced.connectionRetries', 5);
        const giveUp = error => (
        // used for bad credentials, inconsistent parameters
        error.key === 'invalid_parameter' ||
            // this version of the graph server is not supported: give up
            error.key === 'not_supported' ||
            // a user action is needed to allow this graph server to be used: give up
            error.key === 'source_action_needed' ||
            // there was a credentials error: give up
            error.message.includes('username and password') ||
            // the storeId has changed: give up
            error.message.includes('database has changed'));
        if (self.graphConnectPromise) {
            self.graphConnectPromise.cancel();
            self.graphConnectPromise = null;
        }
        return self.graphConnectPromise = Utils.retryPromise(actionName, connect, { delay: 5000, retries: maxRetries, giveUp: giveUp }).finally(() => {
            self.graphConnectPromise = null;
        });
    },
    /**
     * @returns {Promise}
     * @private
     */
    _connectIndex: function () {
        const self = this;
        const name = self.getSourceName();
        const connect = () => {
            self.indexConnectError = null;
            return self.index.connect().then(version => {
                self.indexVersion = version;
                self.indexConnected = true;
                self._onConnectionEvent(true, true, 'Connected to search index (' + name + ')');
                return Promise.resolve();
            }).catch(e => {
                self.indexConnectError = e.message ? e.message : 'Unknown error';
                return Promise.reject(e);
            });
        };
        const actionName = 'connecting to search index (' + name + ')';
        const retries = Config.get('advanced.connectionRetries', 5);
        if (self.indexConnectPromise) {
            self.indexConnectPromise.cancel();
            self.indexConnectPromise = null;
        }
        return self.indexConnectPromise = Utils.retryPromise(actionName, connect, {
            delay: 5000,
            retries: retries,
            giveUp: error => (
            // used for bad credentials, inconsistent parameters
            error.key === 'invalid_parameter' ||
                // this version of the index server is not supported: give up
                error.key === 'not_supported' ||
                // a user action is needed to allow this index server to be used: give up
                error.key === 'source_action_needed')
        }).finally(() => {
            self.indexConnectPromise = null;
        });
    },
    /**
     * Detect the store ID.
     * Can be called only once the Graph DAO is connected.
     *
     * @returns {Bluebird<String|LkError>}
     */
    getStoreId: function () {
        return this.graph.getStoreId();
    },
    /**
     * Check if a set of alternative IDs is legal for this data-source
     *
     * @param {object} alternativeIds
     * @param {string} [alternativeIds.node]
     * @param {string} [alternativeIds.edge]
     */
    checkAlternativeIdKeys: function (alternativeIds) {
        if (!alternativeIds) {
            return;
        }
        // if an alternative node ID was provided
        if (Utils.hasValue(alternativeIds.node)) {
            const configAltNodeId = this.config.graphdb.alternativeNodeId;
            if (Utils.noValue(configAltNodeId)) {
                // no alternative node ID is authorized
                throw Errors.business('invalid_parameter', `No alternative node ID is authorised for data-source #${this.sourceId}.`);
            }
            else if (configAltNodeId !== alternativeIds.node) {
                // wrong alternative node id
                throw Errors.business('invalid_parameter', `Alternative node ID "${alternativeIds.node}" should be "${configAltNodeId}".`);
            }
        }
        else {
            // todo: might not be needed, adding just be to sure
            // needed to prevent having an "null" value as alternative Node Id
            alternativeIds.node = undefined;
        }
        // if an alternative edge ID was provided
        if (Utils.hasValue(alternativeIds.edge)) {
            const configAltEdgeId = this.config.graphdb.alternativeEdgeId;
            if (Utils.noValue(configAltEdgeId)) {
                // no alternative edge ID is authorized
                throw Errors.business('invalid_parameter', `No alternative edge ID is authorised for data-source #${this.sourceId}.`);
            }
            else if (configAltEdgeId !== alternativeIds.edge) {
                // wrong alternative node id
                throw Errors.business('invalid_parameter', `Alternative edge ID "${alternativeIds.edge}" should be "${configAltEdgeId}".`);
            }
        }
        else {
            // todo: might not be needed, adding just be to sure
            // needed to prevent having an "null" value as alternative Edge Id
            alternativeIds.edge = undefined;
        }
    },
    /**
     * Since LKE v2.5.0, the styles format has been changed and the default styles and
     * captions have been moved from the configuration file to the data-source states so that they
     * can be configured per data-source.
     *
     * The `palette`, `defaultStyles`, `defaultCaptions` from the pre v2.5.0 configuration file
     * were temporarly saved in the `defaultStyles` field at the first boot of Linkurious 2.5.2.
     * This was done because to migrate the styles the data-source has to be connected.
     *
     * The `PreV2.5.0Config` flag indicates that the source state has still the old styles.
     * If the `PreV2.5.0Config` flag is there, migrate the styles to the new format and save
     * them in the source state.
     *
     * @param {SequelizeInstance<object>} sourceState
     * @returns {Bluebird<DataSourceState>}
     * @private
     */
    _migrateSourceStateStyles: function (sourceState) {
        const DataService = LKE.getData();
        if (Utils.noValue(sourceState.defaultStyles['PreV2.5.0Config'])) {
            return Promise.resolve(sourceState);
        }
        const { defaultStyles, defaultCaptions, palette } = sourceState.defaultStyles;
        return Promise.props({
            nodeCategories: DataService.getSchemaNodeTypeNames(sourceState.key),
            edgeTypes: DataService.getSchemaEdgeTypeNames(sourceState.key)
        }).then(schema => {
            // 1) Migrate current styles
            // Auto color nodes by default
            return DesignUtils.migrateStyles(schema, defaultStyles, palette, true);
        }).then(migratedStyles => {
            // 2) Populate dataSourceState.defaultCaptions with current defaultCaptions
            //  - Populate dataSourceState.defaultStyles with the migrated styles
            sourceState.defaultCaptions = defaultCaptions;
            sourceState.defaultStyles = migratedStyles;
            return sourceState.save();
        });
    },
    /**
     * Called once the graph-provider is online, just before connecting to the index-provider.
     *
     * Detects/reads the store ID, then load the state of the current store.
     * Updates the 'lastSeen' field of the state.
     *
     * @returns {Promise}
     * @private
     */
    _initSource: function () {
        const self = this;
        return self.getStoreId().then(storeId => {
            self.storeId = storeId;
            // compute the sourceKey (caches the value)
            const sourceKey = self.getSourceKey();
            return Db.models.group.ensureBuiltins(sourceKey);
        }).then(() => {
            const sourceKey = self.getSourceKey();
            // check for other sources with the same key
            for (const source of this.dataService.sources) {
                if (source.sourceId === this.sourceId) {
                    continue;
                }
                if (source.isConnected() && source.getSourceKey() === sourceKey) {
                    // a different source with the same key exists
                    this._resetSource();
                    const message = 'This data-source is already configured once.';
                    this.graphConnectError = message;
                    return Promise.reject({ message: message });
                }
            }
            const whereAndValues = {
                where: { key: sourceKey },
                defaults: {
                    indexedDate: null,
                    info: self.getSourceInfo(),
                    lastSeen: new Date(),
                    name: self.config.name,
                    graphVendor: this.config.graphdb.vendor,
                    indexVendor: this.config.index.vendor,
                    needReindex: false,
                    defaultCaptions: DesignUtils.DEFAULT_CAPTIONS,
                    defaultStyles: DesignUtils.DEFAULT_STYLES
                }
            };
            // find (or create if never seen before) the data-source state entry in DB
            return Db.models.dataSourceState.findOrCreate(whereAndValues).spread((state, isNew) => {
                self.state = state;
                // if the state is not new
                if (!isNew) {
                    const update = {};
                    // update the lastSeen field
                    update.lastSeen = new Date();
                    // update the data-source name
                    if (self.config.name) {
                        update.name = self.config.name;
                    }
                    // if the index vendor has changed, require a re-index
                    const currentIndexVendor = state.indexVendor || 'elasticSearch';
                    if (currentIndexVendor !== this.config.index.vendor) {
                        update.needReindex = true;
                        update.indexationError = 'The index vendor was changed, please re-index.';
                    }
                    // remember vendors
                    update.indexVendor = this.config.index.vendor;
                    update.graphVendor = this.config.graphdb.vendor;
                    return state.updateAttributes(update);
                }
            });
        }).catch(Errors.LkError, error => {
            // keep the error message for client display
            this.indexConnectError = error.message;
            return Promise.reject(error);
        });
    },
    /**
     * Returns true if the source's index-mapping has changed since last indexation
     *
     * @returns {boolean} true if the source needs to be re-indexed.
     */
    needReindex: function () {
        return this.state.needReindex;
    },
    /**
     * Returns true if the source has NEVER been indexed before.
     *
     * @returns {boolean} true if this source has never been indexed before
     */
    needFirstIndex: function () {
        return !this.state.indexedDate;
    },
    /**
     * Check if no index mapping has been configured.
     *
     * @returns {boolean} true if none of the index mapping has been set
     */
    needConfig: function () {
        if (this.index.features.external) {
            return false;
        }
        return Utils.noValue(this.state.noIndexNodeProperties) &&
            Utils.noValue(this.state.hiddenNodeProperties) &&
            Utils.noValue(this.state.noIndexEdgeProperties) &&
            Utils.noValue(this.state.hiddenEdgeProperties);
    },
    /**
     * - Sets an index mapping field (if unset), in order to disable the `needConfig` check.
     * - Sets needReindex to true if already indexed before
     * - Save the state
     *
     * @returns {Promise}
     * @private
     */
    _setStateBeforeIndexing: function () {
        // disable needConfig
        if (Utils.noValue(this.state.noIndexNodeProperties)) {
            this.state.noIndexNodeProperties = [];
        }
        // if not indexing for the first time, remember that indexing is unfinished
        if (!this.needFirstIndex()) {
            // Set need-reindex to true here, set to false when the indexation is done.
            // This persist the fact that an indexation is needed, even if the indexation fails.
            this.state.needReindex = true;
        }
        this.state.indexationError = 'The indexation was launched but did not complete.';
        return this.state.save();
    },
    /**
     * Set the 'indexedDate' of this dataSource state to now and 'needReindex' to false.
     *
     * @returns {Promise}
     * @private
     */
    _setIndexationSuccess: function () {
        this.state.indexedDate = new Date();
        this.state.needReindex = false;
        this.state.indexationError = null;
        return this.state.save();
    },
    /**
     * Persist the indexation error in the state and save the state
     *
     * @param {*} error
     * @returns {Promise}
     * @private
     */
    _setIndexationError: function (error) {
        if (error === undefined || null) {
            error = 'Unknown error';
        }
        else if (typeof (error) !== 'string') {
            if (error.message) {
                error = error.message;
            }
            else if (typeof (error) === 'object') {
                error = JSON.stringify(error);
            }
            else {
                error = error + '';
            }
        }
        this.state.indexationError = error
            ? (error.message ? error.message : error + '')
            : 'Unknown error during indexation.';
        return this.state.save();
    },
    /**
     * @param {boolean} [includeHidden=true] include hidden properties
     * @returns {string[]}
     */
    getNoIndexNodeProperties: function (includeHidden) {
        let noIndex = this.state.noIndexNodeProperties;
        if (Utils.noValue(noIndex)) {
            noIndex = [];
        }
        if (includeHidden !== false) {
            noIndex = noIndex.concat(this.getHiddenNodeProperties());
        }
        return _.sortedUniq(noIndex.sort());
    },
    /**
     * @returns {string[]}
     */
    getHiddenNodeProperties: function () {
        let hidden = this.state.hiddenNodeProperties;
        if (Utils.noValue(hidden)) {
            hidden = [];
        }
        return _.sortedUniq(hidden.sort());
    },
    /**
     * @param {string[]} noIndex
     * @returns {Promise}
     */
    setNoIndexNodeProperties: function (noIndex) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return self._checkNeedReindex('node', null, noIndex).then(() => {
            self.state.noIndexNodeProperties = noIndex;
            return self.state.save();
        });
    },
    /**
     * @param {string[]} hidden
     * @returns {Promise}
     */
    setHiddenNodeProperties: function (hidden) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return this._checkNeedReindex('node', hidden, null).then(() => {
            self.state.hiddenNodeProperties = hidden;
            return self.state.save();
        });
    },
    /**
     * @param {boolean} [includeHidden=true] include hidden properties
     * @returns {string[]}
     */
    getNoIndexEdgeProperties: function (includeHidden) {
        let noIndex = this.state.noIndexEdgeProperties;
        if (Utils.noValue(noIndex)) {
            noIndex = [];
        }
        if (includeHidden !== false) {
            noIndex = noIndex.concat(this.getHiddenEdgeProperties());
        }
        return _.sortedUniq(noIndex.sort());
    },
    /**
     * @returns {string[]}
     */
    getHiddenEdgeProperties: function () {
        let hidden = this.state.hiddenEdgeProperties;
        if (Utils.noValue(hidden)) {
            hidden = [];
        }
        return _.sortedUniq(hidden.sort());
    },
    /**
     * @param {string[]} noIndex
     * @returns {Promise}
     */
    setNoIndexEdgeProperties: function (noIndex) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return self._checkNeedReindex('edge', null, noIndex).then(() => {
            self.state.noIndexEdgeProperties = noIndex;
            return self.state.save();
        });
    },
    /**
     * @param {string[]} hidden
     * @returns {Promise}
     */
    setHiddenEdgeProperties: function (hidden) {
        const self = this;
        if (this.index.features.external) {
            return Promise.resolve();
        }
        return self._checkNeedReindex('edge', hidden, null).then(() => {
            self.state.hiddenEdgeProperties = hidden;
            return self.state.save();
        });
    },
    /**
     * Check if the current state if one of the legal states. Returns a rejected promise if not.
     *
     * @param {string} actionName the name oif the action (to create the error message)
     * @param {string[]} legalStates the list of states that are allowed
     * @param {boolean} [justWarn=false] if true, will no reject the promise but just log a warning
     * @returns {Bluebird<boolean|LkError>}
     * @private
     */
    _checkState: function (actionName, legalStates, justWarn) {
        const state = this.getState().code;
        let message = '';
        let ok = true;
        if (!_.includes(legalStates, state)) {
            message = '"' + actionName + '" requires the data-source to be in one of these states: ' +
                legalStates + ' (current state: ' + state + ')';
            ok = false;
        }
        if (!ok) {
            if (justWarn) {
                Log.warn(message);
            }
            else {
                return Errors.business('illegal_source_state', message, true);
            }
        }
        return Promise.resolve(ok);
    },
    /**
     * Detect actual changes in the index mapping and request a re-index when changes happen.
     *
     * @param {string} type (node or edge)
     * @param {string[]|null} newHidden new hidden properties (or null if no changes were made)
     * @param {string[]|null} newNoIndex new no-index values (or null if no changes were made)
     * @returns {Bluebird<undefined|LkError>}
     *
     * @private
     */
    _checkNeedReindex: function (type, newHidden, newNoIndex) {
        // check if the source state allow this change right now
        const self = this;
        const legalStates = ['ready', 'needConfig', 'needFirstIndex', 'needReindex'];
        return self._checkState('Updating the index-mapping', legalStates).then(() => {
            // check if the params are valid
            if (newHidden !== null && !Array.isArray(newHidden)) {
                return Errors.business('invalid_parameter', 'Hidden ' + type + ' properties must be an array', true);
            }
            if (newNoIndex !== null && !Array.isArray(newNoIndex)) {
                return Errors.business('invalid_parameter', 'Not-indexed ' + type + ' properties must be an array', true);
            }
            // compute the changes that will happen
            const t = _.startCase(type);
            const currentSkipIndex = self['getNoIndex' + t + 'Properties'](true);
            const nextHidden = newHidden || self['getHidden' + t + 'Properties']();
            const nextNoIndex = newNoIndex || self['getNoIndex' + t + 'Properties'](false);
            const nextSkipIndex = _.union(nextHidden, nextNoIndex);
            // differences = added + removed
            const differences = _.union(_.difference(currentSkipIndex, nextSkipIndex), // added
            _.difference(nextSkipIndex, currentSkipIndex) // removed
            );
            // set the re-index flag if the mapping is going to change
            if (differences.length > 0) {
                self.state.needReindex = true;
            }
        });
    },
    /**
     * Filter hidden properties from a node or an array of nodes
     *
     * @param {LkNode|LkNode[]} nodeOrNodes Node (or array thereof)
     * @param {boolean} [filterNoIndex=false] filter NoIndex properties as well
     * @returns {LkNode|LkNode[]}
     */
    filterNodeProperties: function (nodeOrNodes, filterNoIndex) {
        nodeOrNodes = Utils.clone(nodeOrNodes);
        if (!nodeOrNodes) {
            return nodeOrNodes;
        }
        const filter = filterNoIndex ? this.getNoIndexNodeProperties() : this.getHiddenNodeProperties();
        if (Array.isArray(nodeOrNodes)) {
            for (let i = 0; i < nodeOrNodes.length; ++i) {
                nodeOrNodes[i].data = _.omit(nodeOrNodes[i].data, filter);
            }
        }
        else {
            nodeOrNodes.data = _.omit(nodeOrNodes.data, filter);
        }
        return nodeOrNodes;
    },
    /**
     * Filter hidden properties from an edge or an array of edges
     *
     * @param {LkEdge|LkEdge[]} edgeOrEdges Edge (or array thereof)
     * @param {boolean} [filterNoIndex=false] filter NoIndex properties as well
     * @returns {LkEdge|LkEdge[]}
     */
    filterEdgeProperties: function (edgeOrEdges, filterNoIndex) {
        edgeOrEdges = Utils.clone(edgeOrEdges);
        if (!edgeOrEdges) {
            return edgeOrEdges;
        }
        const filter = filterNoIndex ? this.getNoIndexEdgeProperties() : this.getHiddenEdgeProperties();
        if (Array.isArray(edgeOrEdges)) {
            for (let i = 0; i < edgeOrEdges.length; ++i) {
                edgeOrEdges[i].data = _.omit(edgeOrEdges[i].data, filter);
            }
        }
        else {
            edgeOrEdges.data = _.omit(edgeOrEdges.data, filter);
        }
        return edgeOrEdges;
    },
    /**
     * @private
     */
    _initGraphDAO: function () {
        if (this.graph) {
            return;
        }
        try {
            this.graph = GraphDAO.createGraphDAOInstance(this.config.graphdb.vendor, this.config.graphdb);
        }
        catch (e) {
            if (e instanceof Errors.LkError) {
                Log.error(e.message);
                this.graphConnectError = e.message;
            }
            throw e;
        }
    },
    /**
     * Called once the graphDAO is initialized and connected.
     *
     * @private
     */
    _initIndexDAO: function () {
        if (this.index) {
            return;
        }
        try {
            this.index = IndexDAO.createIndexDAOInstance(this.config.index.vendor, this.config.index, this.graph);
        }
        catch (e) {
            if (e instanceof Errors.LkError) {
                this.indexConnectError = e.message;
            }
            throw e;
        }
    },
    /**
     * @throws {LkError} if the source is not ready
     */
    assertReady: function () {
        if (this.getState().code !== 'ready') {
            throw Errors.business('dataSource_unavailable', 'Data-source #' + this.sourceId + ' is not ready.');
        }
    },
    /**
     * Checks if the graph or index config have changed
     *
     * @returns {boolean} whether the graph or index config have changed
     * @private
     */
    _configChanged: function () {
        const original = _.pick(this.config, ['index', 'graphdb']);
        const current = Config.get('dataSources.' + this.sourceId);
        const diff = Utils.objectDiff(original, current, { 'root.index.indexName': true });
        if (diff.length > 0) {
            Log.info('configuration of data-source #' + this.sourceId + ' has changed.');
        }
        return diff.length > 0;
    },
    isReadOnly: function () {
        // Reasoning is a SPARQL feature that infers nodes, edges and properties. We disable edits when
        // the feature is enabled because we cannot distinguish inferred statement from the persisted ones.
        return !!this.config.readOnly || !!this.config.graphdb.reasoning;
    },
    /**
     * Inverse of _initSource (more or less):
     * - forget StoreID
     * - forget state
     * - unset Graph DAO instance
     * - unset Index DAO instance
     * - renew GraphSchemaBuilder
     *
     * @param {boolean} [forceDestroy=false] Force destroying (don't rebuild)
     * @private
     */
    _resetSource: function (forceDestroy) {
        this.config = Config.get('dataSources.' + this.sourceId);
        this.sourceInfoCache = undefined;
        this.sourceKeyCache = undefined;
        this.destroyed = false;
        // stop polling
        this._pollGraphState.promise = null;
        if (this._pollGraphState.timer) {
            clearTimeout(this._pollGraphState.timer);
        }
        this._pollIndexState.promise = null;
        if (this._pollIndexState.timer) {
            clearTimeout(this._pollIndexState.timer);
        }
        // disconnect graph and/or index
        this.disconnect();
        // reset connection state
        this.graphConnected = false;
        if (this.graphConnectPromise) {
            this.graphConnectPromise.cancel();
            this.graphConnectPromise = null;
        }
        this.graphConnectError = null;
        this.indexConnected = false;
        if (this.indexConnectPromise) {
            this.indexConnectPromise.cancel();
            this.indexConnectPromise = null;
        }
        this.indexConnectError = null;
        // forget DAOs
        this.graph = undefined;
        this.index = undefined;
        // set after connection
        this.indexVersion = 'unknown';
        this.graphVersion = 'unknown';
        this.storeId = undefined;
        this.state = undefined;
        this.indexingProgress = null;
        // forget schema builder
        this.graphSchemaBuilder = undefined;
        if (forceDestroy) {
            this.destroyed = true;
        }
        else if (!this.config) {
            this.destroyed = true;
            throw Errors.business('invalid_parameter', 'data-source #' + this.sourceId + ' does not exists anymore (missing configuration).');
        }
        else {
            this.graphSchemaBuilder = new GraphSchemaBuilder(this);
        }
    },
    /**
     * Destroy this data-source
     */
    destroy: function () {
        this._resetSource(true);
    },
    /**
     * Will safely disconnect what needs to be disconnected.
     * Don't worry, this does not throw in case of failure.
     */
    disconnect() {
        if (this.graph) {
            this.graph.disconnect();
        }
        if (this.index) {
            this.index.disconnect();
        }
    },
    /**
     * Connect (or reconnect) to a disconnected data-source
     *
     * @param {boolean} [ignoreErrors=false] whether to catch promise rejections and ignore them
     * @returns {Promise}
     */
    connect: function (ignoreErrors) {
        const self = this;
        const configChanged = this._configChanged();
        // offline, connecting, needConfig, needFirstIndex, needReindex, ready
        const legalStates = configChanged
            ? ['offline', 'connecting', 'needConfig', 'needFirstIndex', 'needReindex', 'ready']
            : ['offline'];
        return self._checkState('Connecting', legalStates, true).then(ok => {
            if (!ok) {
                return;
            }
            if (configChanged) {
                // make the data-source new and fresh again
                self._resetSource();
            }
            return Promise.resolve().then(() => {
                self._initGraphDAO();
                self._connecting = true;
            }).then(() => {
                return self._connectGraph();
            }).then(() => {
                /**
                 * we must init the source _after_ connecting to the graph but _before_ connecting to the
                 * index because we need to detect the storeId from the graph in some cases, and the store Id
                 * is needed to decide to which index we will to connect to.
                 */
                return self._initSource();
            }).then(() => {
                // set the name of the index to connect to in IndexDAO configuration
                self.config.index.indexName = 'linkurious_' + self.getSourceKey();
                self._initIndexDAO();
                return self._connectIndex();
            }).then(() => {
                // start polling graph and index regularly once the both are connected
                self._onConnect();
            }).then(() => {
                return this._migrateSourceStateStyles(self.state);
            }).then(() => {
                // source connected successfully
                Log.info('Data-source #%s connected successfully (graph:%s v%s - index:%s v%s)', self.sourceId, self.config.graphdb.vendor, self.graphVersion, self.config.index.vendor, self.indexVersion);
                if (this.index.features.external) {
                    /**
                     * Schema is frozen. This means that, on node deletion, we don't remove the category
                     * from the schema if the count of nodes with that category reaches 0.
                     * This is due to the impossibility to track removed types without having the counts.
                     */
                    this.graphSchemaBuilder.freeze = true;
                }
            }).catch(error => {
                const indexConfig = self.config.index;
                const graphConfig = self.config.graphdb;
                // source could not connect
                const indexURL = Utils.hasValue(indexConfig.host)
                    ? `http${indexConfig.https ? 's' : ''}://${indexConfig.host}:${indexConfig.port}`
                    : '-';
                const message = error instanceof LkError ? error.message : error;
                // print the stack only if it's a technical error
                const stack = error instanceof LkError && error.isTechnical() ? error.stack : undefined;
                Log.warn('Data-source #%s could not connect (%s: %s / %s: %s): %s', self.sourceId, graphConfig.vendor, graphConfig.url, indexConfig.vendor, indexURL, message, stack);
                Log.debug('Data-source connection error: ', error);
                if (ignoreErrors) {
                    return;
                }
                return Promise.reject(error);
            }).finally(() => {
                self._connecting = false;
            });
        });
    },
    /**
     * Get the status of the search for this data-source.
     * State: "ongoing", "needed", "done", "unknown".
     *
     * @returns {Bluebird<{
     *   indexing:string,
     *   indexing_progress:string,
     *   indexing_status:string,
     *   node_count:number,
     *   edge_count:number,
     *   index_size:number,
     *   indexed_source:string
     * }>}
     */
    getSearchStatus: function () {
        const indexedSourceKey = this.dataService.getIndexedSource();
        // offline, connecting, needConfig, needFirstIndex, needReindex, ready
        const stateCode = this.getState().code;
        // ongoing
        if (stateCode === 'indexing') {
            const status = `Currently indexing ${this.indexingProgress.getRate()}. ` +
                `Time left: ${this.indexingProgress.getTimeLeft()}.`;
            return Promise.resolve({
                indexing: 'ongoing',
                'indexing_progress': this.indexingProgress.getPercent(),
                'indexing_status': status,
                'node_count': this.nodeCountCache,
                'edge_count': this.edgeCountCache,
                'index_size': this.indexingProgress.getTotalIndexedItems(),
                'indexed_source': indexedSourceKey
            });
        }
        // needed
        if (stateCode === 'needConfig' || stateCode === 'needFirstIndex' || stateCode === 'needReindex') {
            return Promise.resolve({
                indexing: 'needed',
                'indexing_progress': null,
                'indexing_status': 'The database needs to be indexed.',
                'node_count': null,
                'edge_count': null,
                'index_size': null,
                'indexed_source': indexedSourceKey
            });
        }
        // done
        if (stateCode === 'ready') {
            return Promise.resolve({
                indexing: 'done',
                'indexing_progress': null,
                'indexing_status': 'The database is fully indexed.',
                'node_count': null,
                'edge_count': null,
                'index_size': null,
                'indexed_source': indexedSourceKey
            });
        }
        // unknown
        return Promise.resolve({
            indexing: 'unknown',
            'indexing_progress': null,
            'indexing_status': 'Unknown indexation status.',
            'node_count': null,
            'edge_count': null,
            'index_size': null,
            'indexed_source': indexedSourceKey
        });
    },
    /**
     * @type {LkDataSourceFeatures}
     */
    get features() {
        if (!this.graph || !this.index) {
            return {};
        }
        //noinspection PointlessBooleanExpressionJS
        return {
            // look at the typedef of LkDataSourceFeatures for the meaning of these features
            typing: !!this.index.features.typing,
            edgeProperties: !!this.graph.features.edgeProperties,
            immutableNodeCategories: !!this.graph.features.immutableNodeCategories,
            minNodeCategories: this.graph.features.minNodeCategories,
            maxNodeCategories: this.graph.features.maxNodeCategories,
            serializeArrayProperties: this.graph.features.serializeArrayProperties,
            canCount: !!this.graph.features.canCount || !!this.index.features.canCount,
            canCountBeforeIndexation: !!this.graph.features.canCount,
            alerts: !!this.graph.features.alerts,
            dialects: this.graph.features.dialects,
            externalIndex: !!this.index.features.external,
            alternativeIds: !!this.graph.features.alternativeIds,
            fuzzy: !!this.index.features.fuzzy,
            canIndexEdges: !!this.index.features.canIndexEdges,
            canIndexCategories: !!this.index.features.canIndexCategories,
            advancedQueryDialect: this.index.features.advancedQueryDialect,
            searchHitsCount: this.index.features.searchHitsCount,
            detectSupernodes: this.graph.features.detectSupernodes,
            canDryRun: this.graph.features.canDryRun
        };
    },
    /**
     * Start polling the graph and Index DAO to detect source disconnection.
     *
     * @private
     */
    _onConnect: function () {
        this._pollGraph();
        this._pollIndex();
    },
    /**
     * Checks the state of the index:
     * - if already checking, uses the promise of the ongoing check
     * - schedules the next check
     * - returns a promise of the check
     *
     * @param {boolean} [pollIfIndexing=false]
     * @returns {Promise}
     * @private
     */
    _pollGraph: function (pollIfIndexing) {
        const self = this;
        // stop polling if we are currently connecting (poll will restart after connect)
        if (self.graphConnectPromise) {
            return Promise.resolve();
        }
        if (self.destroyed || !self.graph) {
            self.graphConnected = false;
            return Promise.resolve();
        }
        // return the existing promise if we are already checking the state
        if (self._pollGraphState.promise) {
            return self._pollGraphState.promise;
        }
        // already scheduled, un-schedule
        if (self._pollGraphState.timer) {
            clearTimeout(self._pollGraphState.timer);
        }
        const reschedule = () => {
            self._pollGraphState.timer = setTimeout(() => {
                self._pollGraph();
            }, self.pollIntervalMillis);
        };
        // don't check the state of the graph/index while indexing
        if (self.isIndexing() && !pollIfIndexing) {
            reschedule();
            return Promise.resolve();
        }
        const name = self.getSourceName();
        Log.debug('polling graph database: ' + name);
        self._pollGraphState.promise = self.graph.checkUp().then(() => {
            reschedule();
        }).catch(() => {
            self.graphConnected = false;
            self._onConnectionEvent(false, false, `Lost connection to graph database ${name}`);
            return self._connectGraph().then(() => {
                self._onConnectionEvent(false, true, `Restored connection to graph database ${name}`);
                reschedule();
            }).catch(() => {
                // swallow error when reconnect fails and we give up
            });
        }).finally(() => {
            self._pollGraphState.promise = null;
        });
        return self._pollGraphState.promise;
    },
    /**
     * Checks the state of the index:
     * - if already checking, uses the promise of the ongoing check
     * - schedules the next check
     * - returns a promise of the check
     *
     * @param {boolean} [pollIfIndexing=false]
     * @returns {Promise}
     * @private
     */
    _pollIndex: function (pollIfIndexing) {
        const self = this;
        // stop polling if we are currently connecting (poll will restart after connect)
        if (self.indexConnectPromise) {
            return Promise.resolve();
        }
        if (self.destroyed || !self.index) {
            self.indexConnected = false;
            return Promise.resolve();
        }
        // return the existing promise if we are already checking the state
        if (self._pollIndexState.promise) {
            return self._pollIndexState.promise;
        }
        // already scheduled, un-schedule
        if (self._pollIndexState.timer) {
            clearTimeout(self._pollIndexState.timer);
        }
        const reschedule = () => {
            self._pollIndexState.timer = setTimeout(() => {
                self._pollIndex();
            }, self.pollIntervalMillis);
        };
        // don't check the state of the index while indexing
        if (self.isIndexing() && !pollIfIndexing) {
            reschedule();
            return Promise.resolve();
        }
        const name = self.getSourceName();
        Log.debug('polling search index: ' + name);
        self._pollIndexState.promise = self.index.checkUp().then(() => {
            reschedule();
        }).catch(() => {
            self.indexConnected = false;
            self._onConnectionEvent(false, false, 'Lost connection to search index (' + name + ')');
            return self._connectIndex().then(() => {
                self._onConnectionEvent(false, true, 'Restored connection to search index (' + name + ')');
                reschedule();
            }).catch(() => {
                // swallow error when reconnect fails and we give up
            });
        }).finally(() => {
            self._pollIndexState.promise = null;
        });
        return self._pollIndexState.promise;
    },
    /**
     * Update the source index/schema.
     *
     * @returns {Promise}
     */
    indexSource: function () {
        return Promise.resolve().then(() => {
            if (!this.index.features.external) {
                return this._indexSource();
            }
            else {
                return this._externalIndexSource();
            }
        });
    },
    /**
     * Get the last edit date of a node/edge if available.
     * Otherwise, return `undefined`.
     *
     * @param {string} itemType "node" or "edge"
     * @param {string} itemId   ID of the node/edge
     * @returns {number | undefined}
     */
    getLastEditDate: function (itemType, itemId) {
        return this._lastEditDateMap.get(itemType + ':' + itemId);
    },
    /**
     * Update the last edit date of a node/edge to the current time.
     *
     * @param {string} itemType   "node" or "edge"
     * @param {string} itemId     ID of the node/edge
     * @returns {number} The date at which the data was changed
     */
    updateLastEditDate: function (itemType, itemId) {
        const changeDate = Date.now();
        this._lastEditDateMap.set(itemType + ':' + itemId, changeDate);
        return changeDate;
    },
    /**
     * Set defaultStyles and defaultCaptions of the current DataSource.
     *
     * @param {VisualizationStyleSheet} [defaultStyles]
     * @param {VisualizationCaptions}   [defaultCaptions]
     * @returns {Bluebird<void>}
     */
    setDesignDefaults: function (defaultStyles, defaultCaptions) {
        if (Utils.hasValue(defaultStyles)) {
            VisualizationChecker.checkStyles('styles', defaultStyles);
            this.state.defaultStyles = defaultStyles;
        }
        if (Utils.hasValue(defaultCaptions)) {
            VisualizationChecker.checkCaptions('captions', defaultCaptions);
            this.state.defaultCaptions = defaultCaptions;
        }
        return this.state.save().return();
    },
    /**
     * Update the graph schema from the index.
     *
     * @returns {Promise}
     * @private
     */
    _externalIndexSource: function () {
        const states = ['needFirstIndex', 'needReindex', 'ready'];
        return this._checkState('Indexing', states).then(() => {
            // create the indexing progress reporter
            this.indexingProgress = new Progress(Log, this.getSourceName() + ':');
            this.graphSchemaBuilder.init();
            return this._setStateBeforeIndexing();
        }).then(() => {
            return this.graphSchemaBuilder.deleteAll(this.getSourceKey());
        }).then(() => {
            // don't index edges if not supported by the index or if explicitly skipped in the index options
            const skipEdges = this.index.getOption('skipEdgeIndexation', false) ||
                this.index.features.canIndexEdges === false;
            return Promise.props({
                // count the nodes in graph
                nodeCount: this.graph.features.canCount
                    ? this.graph.getNodeCount(true)
                    : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE),
                // count the edges in graph
                edgeCount: skipEdges
                    ? 0
                    : this.graph.features.canCount
                        ? this.graph.getEdgeCount(true)
                        : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE)
            });
        }).then(results => {
            this.indexingProgress.start(results.nodeCount + results.edgeCount);
            this.nodeCountCache = results.nodeCount;
            this.edgeCountCache = results.edgeCount;
            Log.info(`Refreshing source ${this.getSourceName()} external index (if required)`);
            return this.index.indexSource(this.indexingProgress);
        }).then(() => {
            this.indexingProgress.end();
        }).then(() => Promise.props({
            nodeTypes: this.index.getSchema('node'),
            edgeTypes: this.index.getSchema('edge')
        })).then(schema => {
            Log.info(`Refreshing source ${this.getSourceName()} schema using external index`);
            this.graphSchemaBuilder.ingestTypes('node', schema.nodeTypes);
            this.graphSchemaBuilder.ingestTypes('edge', schema.edgeTypes);
            return this.graphSchemaBuilder.saveSchema();
        }).then(() => {
            // we signal the GraphDAO and the IndexDAO that the indexation is at the end, so it can perform additional tasks
            return this.graph.onAfterIndexation();
        }).then(() => {
            return this.index.onAfterIndexation();
        }).then(() => {
            // set the indexation date in state
            return this._setIndexationSuccess();
        }).catch(error => {
            // capture the indexation error
            return this._setIndexationError(error).then(() => {
                return Promise.reject(error);
            });
        }).finally(() => {
            this.indexingProgress = null;
        });
    },
    /**
     * Cleans the search-index, reads the whole graph database and writes it to search-index.
     *
     * @returns {Promise}
     */
    _indexSource: function () {
        const self = this;
        // initialize some useful variables
        let sourceKey;
        /**
         * @type {GraphDAO}
         */
        const graph = self.graph;
        /**
         * @type {IndexDAO}
         */
        const index = self.index;
        // don't index edges if not supported by the index or if explicitly skipped in the index options
        const skipEdges = this.index.getOption('skipEdgeIndexation', false);
        const chunkSize = Config.get('advanced.indexationChunkSize', 5000);
        const isBusinessError = err => Errors.LkError.isBusinessType(err.type);
        const legalStates = ['ready', 'needConfig', 'needFirstIndex', 'needReindex'];
        return self._checkState('Indexing', legalStates).then(() => {
            // create the indexing progress reporter
            self.indexingProgress = new Progress(Log, self.getSourceName() + ':');
            // initialize some useful variables
            sourceKey = self.getSourceKey();
            return graph.onInternalIndexation();
        }).then(() => {
            // initialize/reset the schema builder
            self.graphSchemaBuilder.init();
            return self._setStateBeforeIndexing();
        }).then(() => {
            return self.graphSchemaBuilder.deleteAll(sourceKey);
        }).then(() => {
            return Promise.props({
                // empty the ES index
                clear: index.clear(),
                // count the nodes in graph
                nodeCount: graph.features.canCount
                    ? graph.getNodeCount(true)
                    : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE),
                // count the edges in graph
                edgeCount: skipEdges
                    ? 0
                    : graph.features.canCount
                        ? graph.getEdgeCount(true)
                        : Promise.resolve(DEFAULT_PROGRESS_BAR_SIZE)
            });
        }).then(results => {
            Log.info(`Start indexation of ${results.nodeCount} nodes and ${results.edgeCount} edges.`);
            self.indexingProgress.start(results.nodeCount + results.edgeCount);
            self.nodeCountCache = results.nodeCount;
            self.edgeCountCache = results.edgeCount;
            // Index Nodes
            let indexedNodes = 0;
            const ingestNodesChunk = nodes => {
                // add to schema builder
                self.graphSchemaBuilder.ingestNodes(nodes);
                // add to index (we first filter away properties we don't want to index)
                nodes = nodes.map(node => this.filterNodeProperties(node, true));
                return index.addEntries('node', nodes).then(() => {
                    indexedNodes += nodes.length;
                    self.indexingProgress.add('node', nodes);
                });
            };
            const indexNodes = () => {
                if (indexedNodes > 0) {
                    Log.info('Trying to resume nodes indexation at offset ' + indexedNodes);
                }
                // stream nodes and ingest them into the index
                return streamNodes(graph, ingestNodesChunk, chunkSize, indexedNodes);
            };
            return Utils.retryPromise('Index nodes', indexNodes, {
                delay: 15 * 1000,
                retries: self.indexationRetries,
                giveUp: isBusinessError
            });
        }).then(() => {
            if (skipEdges) {
                // skip edge indexation
                return;
                // TODO #918 we need edge schema also with internal indices when edges are not indexed
            }
            // Index edges
            let indexedEdges = 0;
            const ingestEdgesChunk = edges => {
                // add to schema builder
                self.graphSchemaBuilder.ingestEdges(edges);
                // add to index (we first filter away properties we don't want to index)
                edges = edges.map(edge => this.filterEdgeProperties(edge, true));
                return index.addEntries('edge', edges).then(() => {
                    indexedEdges += edges.length;
                    self.indexingProgress.add('edge', edges);
                });
            };
            const indexEdges = () => {
                if (indexedEdges > 0) {
                    Log.info('Trying to resume edges indexation at offset ' + indexedEdges);
                }
                // stream edges and ingest them into the index
                return streamEdges(graph, ingestEdgesChunk, chunkSize, indexedEdges);
            };
            return Utils.retryPromise('Index edges', indexEdges, {
                delay: 15 * 1000,
                retries: self.indexationRetries,
                giveUp: isBusinessError
            });
        }).then(() => {
            self.indexingProgress.end();
            // save the updated graph schema
            return self.graphSchemaBuilder.saveSchema();
        }).then(() => {
            // commit the updated index
            Log.info('Flushing index data to disk ...');
            return index.commit();
        }).then(() => {
            // we signal the IndexDAO that the indexation is at the end, so it can perform additional tasks
            return this.index.onAfterIndexation();
        }).then(() => {
            return self._setIndexationSuccess();
        }).catch(error => {
            // capture the indexation error
            return self._setIndexationError(error).then(() => {
                // if the indexation failed, recheck the state of the graph and index
                // in case then went offline (polling never rejects)
                return self._pollGraph(true);
            }).then(() => {
                return self._pollIndex(true);
            }).then(() => {
                // then, reject the indexation promise with the indexation error
                return Promise.reject(error);
            });
        }).finally(() => {
            self.indexingProgress = null;
        });
    }
};
// private static methods
/**
 * Read nodes stream and ingest them (write them to index)
 *
 * @param {object} graph
 * @param {function} ingestNodes
 * @param {number} chunkSize
 * @param {number} offset
 * @returns {Promise}
 * @private
 */
function streamNodes(graph, ingestNodes, chunkSize, offset) {
    return graph.getNodeStream({ offset: offset, chunkSize: chunkSize }).then(nodeStream => {
        return new Promise((resolve, reject) => {
            let nodesBuffer = [];
            const purgeBufferAndResume = () => {
                nodesBuffer = [];
                nodeStream.resume();
            };
            nodeStream.on('data', lkNode => {
                // add node to buffer
                nodesBuffer.push(lkNode);
                // if the buffer is full, write to elasticSearch
                if (nodesBuffer.length >= chunkSize) {
                    nodeStream.pause();
                    ingestNodes(nodesBuffer).then(purgeBufferAndResume, error => {
                        Log.error('Indexing nodes: ingest failed.', error);
                        reject(error);
                    });
                }
            }).on('end', () => {
                ingestNodes(nodesBuffer).then(resolve, error => {
                    Log.error('Indexing nodes: last ingest failed.', error);
                    reject(error);
                });
            }).on('error', error => {
                Log.error('Indexing nodes: stream error.', error);
                reject(error);
            }).resume();
        });
    });
}
/**
 * Read the edge stream and ingest it
 *
 * @param {object} graph
 * @param {function} ingestEdges
 * @param {number} chunkSize
 * @param {number} offset (to start indexing edges at a given offset from first edge)
 * @returns {Promise}
 * @private
 */
function streamEdges(graph, ingestEdges, chunkSize, offset) {
    return graph.getEdgeStream({ offset: offset, chunkSize: chunkSize }).then(edgeStream => {
        return new Promise((resolve, reject) => {
            let edgesBuffer = [];
            const purgeBufferAndResume = () => {
                edgesBuffer = [];
                edgeStream.resume();
            };
            edgeStream.on('data', lkEdge => {
                // add edge to buffer
                edgesBuffer.push(lkEdge);
                // if the buffer is full, write to elasticSearch
                if (edgesBuffer.length >= chunkSize) {
                    edgeStream.pause();
                    ingestEdges(edgesBuffer).then(purgeBufferAndResume, error => {
                        Log.error('Indexing edges: ingest failed.', error);
                        reject(error);
                    });
                }
            }).on('end', () => {
                ingestEdges(edgesBuffer).then(resolve, error => {
                    Log.error('Indexing edges: last ingest failed.', error);
                    reject(error);
                });
            }).on('error', error => {
                Log.error('Indexing edges: stream error.', error);
                reject(error);
            }).resume();
        });
    });
}
// export DataSource object
Object.seal(DataSource);
module.exports = DataSource;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YVNvdXJjZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9kYXRhL2RhdGFTb3VyY2UuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0dBUUc7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRWpDLGdCQUFnQjtBQUNoQixNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMxQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQ3JELE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQ3JELE1BQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDM0QsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3ZDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3BELE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7QUFDekUsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDdkQsTUFBTSxFQUFDLE9BQU8sRUFBQyxHQUFHLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0FBRXpELHdGQUF3RjtBQUN4RixNQUFNLHlCQUF5QixHQUFHLE1BQU0sQ0FBQztBQUV6Qyx5RkFBeUY7QUFDekYsTUFBTSx1QkFBdUIsR0FBRyxHQUFHLENBQUM7QUFFcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FtQkc7QUFFSDs7Ozs7O0dBTUc7QUFDSCxTQUFTLFVBQVUsQ0FBQyxRQUFRLEVBQUUsV0FBVztJQUN2QyxJQUFJLE9BQU8sUUFBUSxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7UUFDbkQsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO0tBQ3pEO0lBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7SUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDL0IsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ3pFLElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQztJQUNwRCxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUM7SUFFcEQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztJQUU1QiwwRkFBMEY7SUFDMUYsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksU0FBUyxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFFL0QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3RCLENBQUM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxVQUFTLGVBQWUsRUFBRSxlQUFlLEVBQUUsWUFBWTtJQUNwRixPQUFPLGVBQWUsR0FBRyxHQUFHLEdBQUcsZUFBZSxHQUFHLEdBQUcsR0FBRyxZQUFZLENBQUM7QUFDdEUsQ0FBQyxDQUFDO0FBRUY7OztHQUdHO0FBQ0gsVUFBVSxDQUFDLGdCQUFnQixHQUFHLFVBQVMsVUFBVTtJQUMvQyxJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7UUFBRSxPQUFPLFNBQVMsQ0FBQztLQUFFO0lBQ25ELE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDL0MsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDdEMsT0FBTyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDO0FBRUYsVUFBVSxDQUFDLFNBQVMsR0FBRztJQUNyQixNQUFNLEVBQUUsU0FBUztJQUNqQixPQUFPLEVBQUUsU0FBUztJQUVsQjs7Ozs7O09BTUc7SUFDSCxTQUFTLEVBQUUsS0FBSztJQUNoQixXQUFXLEVBQUUsS0FBSztJQUVsQjs7OztPQUlHO0lBQ0gsZ0JBQWdCLEVBQUUsSUFBSTtJQUV0Qjs7OztPQUlHO0lBQ0gsS0FBSyxFQUFFLFNBQVM7SUFDaEIsY0FBYyxFQUFFLEtBQUs7SUFDckIsbUJBQW1CLEVBQUUsSUFBSTtJQUN6QixpQkFBaUIsRUFBRSxJQUFJO0lBRXZCOzs7O09BSUc7SUFDSCxLQUFLLEVBQUUsU0FBUztJQUNoQixjQUFjLEVBQUUsS0FBSztJQUNyQixtQkFBbUIsRUFBRSxJQUFJO0lBQ3pCLGlCQUFpQixFQUFFLElBQUk7SUFFdkI7O09BRUc7SUFDSCxXQUFXLEVBQUU7UUFDWCxPQUFPLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUNwRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVEsRUFBRTtRQUNSLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixPQUFPO2dCQUNMLElBQUksRUFBRSxTQUFTO2dCQUNmLE1BQU0sRUFBRSxxREFBcUQ7YUFDOUQsQ0FBQztTQUNIO1FBRUQsYUFBYTtRQUNiLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzVCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVk7Z0JBQ2xCLE1BQU0sRUFBRSx5Q0FBeUM7Z0JBQ2pELEtBQUssRUFBRSxJQUFJLENBQUMsaUJBQWlCO2FBQzlCLENBQUM7U0FDSDtRQUNELElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQzVCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVk7Z0JBQ2xCLE1BQU0sRUFBRSx1Q0FBdUM7Z0JBQy9DLEtBQUssRUFBRSxJQUFJLENBQUMsaUJBQWlCO2FBQzlCLENBQUM7U0FDSDtRQUNELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNwQixPQUFPO2dCQUNMLElBQUksRUFBRSxZQUFZO2dCQUNsQixNQUFNLEVBQUUsc0NBQXNDO2dCQUM5QyxLQUFLLEVBQUUsSUFBSTthQUNaLENBQUM7U0FDSDtRQUVELFVBQVU7UUFDVixJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFO2dCQUNsRCxPQUFPO29CQUNMLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSw2Q0FBNkM7b0JBQ3JELEtBQUssRUFBRSxJQUFJLENBQUMsaUJBQWlCO2lCQUM5QixDQUFDO2FBQ0g7WUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7Z0JBQ2xELE9BQU87b0JBQ0wsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLG9DQUFvQztvQkFDNUMsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7aUJBQzlCLENBQUM7YUFDSDtZQUVELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsTUFBTSxFQUFFLGdDQUFnQzthQUN6QyxDQUFDO1NBQ0g7UUFFRCxVQUFVO1FBRVYsV0FBVztRQUNYLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFO1lBQ3JCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUNoQyxPQUFPO2dCQUNMLElBQUksRUFBRSxVQUFVO2dCQUNoQixNQUFNLEVBQUUscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTtvQkFDM0MsY0FBYyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsR0FBRyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFO2FBQ3JFLENBQUM7U0FDSDtRQUVELDZEQUE2RDtRQUM3RCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUNyQixPQUFPO2dCQUNMLElBQUksRUFBRSxZQUFZO2dCQUNsQixNQUFNLEVBQUUsc0VBQXNFO2FBQy9FLENBQUM7U0FDSDtRQUVELGdFQUFnRTtRQUNoRSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRTtZQUN6QixPQUFPO2dCQUNMLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLE1BQU0sRUFBRSxvREFBb0Q7Z0JBQzVELEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWU7YUFDbEMsQ0FBQztTQUNIO1FBRUQsd0ZBQXdGO1FBQ3hGLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQ3RCLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLE1BQU0sRUFBRSx3Q0FBd0M7Z0JBQ2hELEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWU7YUFDbEMsQ0FBQztTQUNIO1FBRUQsV0FBVztRQUNYLE9BQU8sRUFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSwyQkFBMkIsRUFBQyxDQUFDO0lBQzlELENBQUM7SUFFRCxlQUFlLEVBQUUsU0FBUztJQUMxQixjQUFjLEVBQUUsU0FBUztJQUV6Qjs7T0FFRztJQUNILFVBQVUsRUFBRTtRQUNWLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsWUFBWSxFQUFFLFVBQVMsYUFBYTtRQUNsQyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssU0FBUyxFQUFFO1lBQ3JDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFO2dCQUMvQyxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGlCQUFpQixDQUFDLENBQUM7Z0JBQ3JFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUM7YUFDbkQ7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO2FBQ3RGO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsYUFBYSxFQUFFLFVBQVMsYUFBYTtRQUNuQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQixJQUFJLGFBQWEsRUFBRTtnQkFBRSxPQUFPLFNBQVMsQ0FBQzthQUFFO1lBQ3hDLE1BQU0sTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsdURBQXVELENBQUMsQ0FBQztTQUN4RjtRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUU7WUFDdEMsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxRCxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUNQLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDdkMsK0NBQStDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FDN0UsQ0FBQzthQUNIO1lBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNyRjtRQUNELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGFBQWEsRUFBRTtRQUNiLE9BQU8sY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDeEIsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsY0FBYyxFQUFFO1FBQ2QsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO1lBQ2pDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7U0FDeEI7YUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQzNCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDekI7YUFBTTtZQUNMLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7U0FDckM7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxrQkFBa0IsRUFBRSxVQUFTLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTztRQUNqRCxJQUFJLE9BQU8sRUFBRTtZQUFFLE9BQU87U0FBRTtRQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxhQUFhLEVBQUU7UUFDYixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRWxDLE1BQU0sT0FBTyxHQUFHLEdBQUcsRUFBRTtZQUNuQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1lBQzlCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ3pDLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO2dCQUU1Qiw0RUFBNEU7Z0JBQzVFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO29CQUFFLE9BQU87aUJBQUU7Z0JBQzlCLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDdEMsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRTt3QkFDNUIsMERBQTBEO3dCQUMxRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBQ3BCLE1BQU0sT0FBTyxHQUFHLHFFQUFxRSxDQUFDO3dCQUN0RixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDbkQ7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSwrQkFBK0IsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNYLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7Z0JBQ2pFLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE1BQU0sVUFBVSxHQUFHLGdDQUFnQyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7UUFDakUsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUMvRCxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3RCLG9EQUFvRDtRQUNwRCxLQUFLLENBQUMsR0FBRyxLQUFLLG1CQUFtQjtZQUVqQyw2REFBNkQ7WUFDN0QsS0FBSyxDQUFDLEdBQUcsS0FBSyxlQUFlO1lBRTdCLHlFQUF5RTtZQUN6RSxLQUFLLENBQUMsR0FBRyxLQUFLLHNCQUFzQjtZQUVwQyx5Q0FBeUM7WUFDekMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUM7WUFFL0MsbUNBQW1DO1lBQ25DLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLENBQy9DLENBQUM7UUFFRixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztTQUNqQztRQUNELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxZQUFZLENBQ2xELFVBQVUsRUFDVixPQUFPLEVBQ1AsRUFBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBQyxDQUNuRCxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDYixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILGFBQWEsRUFBRTtRQUNiLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUNsQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFbEMsTUFBTSxPQUFPLEdBQUcsR0FBRyxFQUFFO1lBQ25CLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7WUFDOUIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSw2QkFBNkIsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQ2hGLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO2dCQUNqRSxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7UUFFRixNQUFNLFVBQVUsR0FBRyw4QkFBOEIsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQy9ELE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFNUQsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7U0FDakM7UUFFRCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUU7WUFDeEUsS0FBSyxFQUFFLElBQUk7WUFDWCxPQUFPLEVBQUUsT0FBTztZQUNoQixNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNmLG9EQUFvRDtZQUNwRCxLQUFLLENBQUMsR0FBRyxLQUFLLG1CQUFtQjtnQkFFakMsNkRBQTZEO2dCQUM3RCxLQUFLLENBQUMsR0FBRyxLQUFLLGVBQWU7Z0JBRTdCLHlFQUF5RTtnQkFDekUsS0FBSyxDQUFDLEdBQUcsS0FBSyxzQkFBc0IsQ0FDckM7U0FDRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxVQUFVLEVBQUU7UUFDVixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHNCQUFzQixFQUFFLFVBQVMsY0FBYztRQUM3QyxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBRWhDLHlDQUF5QztRQUN6QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDbEMsdUNBQXVDO2dCQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUMxRSxDQUFDO2FBQ0g7aUJBQU0sSUFBSSxlQUFlLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtnQkFDbEQsNEJBQTRCO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix3QkFBd0IsY0FBYyxDQUFDLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxDQUMvRSxDQUFDO2FBQ0g7U0FDRjthQUFNO1lBQ0wsb0RBQW9EO1lBQ3BELGtFQUFrRTtZQUNsRSxjQUFjLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztTQUNqQztRQUVELHlDQUF5QztRQUN6QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3ZDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDO1lBQzlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBRTtnQkFDbEMsdUNBQXVDO2dCQUN2QyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix5REFBeUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUMxRSxDQUFDO2FBQ0g7aUJBQU0sSUFBSSxlQUFlLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtnQkFDbEQsNEJBQTRCO2dCQUM1QixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLG1CQUFtQixFQUNuQix3QkFBd0IsY0FBYyxDQUFDLElBQUksZ0JBQWdCLGVBQWUsSUFBSSxDQUMvRSxDQUFDO2FBQ0g7U0FDRjthQUFNO1lBQ0wsb0RBQW9EO1lBQ3BELGtFQUFrRTtZQUNsRSxjQUFjLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztTQUNqQztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILHlCQUF5QixFQUFFLFVBQVMsV0FBVztRQUM3QyxNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDbEMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFO1lBQy9ELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUNyQztRQUVELE1BQU0sRUFBQyxhQUFhLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBQyxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUM7UUFFNUUsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDO1lBQ25CLGNBQWMsRUFBRSxXQUFXLENBQUMsc0JBQXNCLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQztZQUNuRSxTQUFTLEVBQUUsV0FBVyxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUM7U0FDL0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNmLDRCQUE0QjtZQUM1Qiw4QkFBOEI7WUFDOUIsT0FBTyxXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUN2QiwyRUFBMkU7WUFDM0UscUVBQXFFO1lBQ3JFLFdBQVcsQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDO1lBQzlDLFdBQVcsQ0FBQyxhQUFhLEdBQUcsY0FBYyxDQUFDO1lBQzNDLE9BQU8sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUV2QiwyQ0FBMkM7WUFDM0MsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXRDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFdEMsNENBQTRDO1lBQzVDLEtBQUssTUFBTSxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUU7Z0JBQzdDLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFO29CQUFFLFNBQVM7aUJBQUU7Z0JBQ3BELElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUUsS0FBSyxTQUFTLEVBQUU7b0JBQy9ELDhDQUE4QztvQkFDOUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO29CQUNwQixNQUFNLE9BQU8sR0FBRyw4Q0FBOEMsQ0FBQztvQkFDL0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQztvQkFDakMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQyxDQUFDLENBQUM7aUJBQzNDO2FBQ0Y7WUFFRCxNQUFNLGNBQWMsR0FBRztnQkFDckIsS0FBSyxFQUFFLEVBQUMsR0FBRyxFQUFFLFNBQVMsRUFBQztnQkFDdkIsUUFBUSxFQUFFO29CQUNSLFdBQVcsRUFBRSxJQUFJO29CQUNqQixJQUFJLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDMUIsUUFBUSxFQUFFLElBQUksSUFBSSxFQUFFO29CQUNwQixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO29CQUN0QixXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTTtvQkFDdkMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU07b0JBQ3JDLFdBQVcsRUFBRSxLQUFLO29CQUNsQixlQUFlLEVBQUUsV0FBVyxDQUFDLGdCQUFnQjtvQkFDN0MsYUFBYSxFQUFFLFdBQVcsQ0FBQyxjQUFjO2lCQUMxQzthQUNGLENBQUM7WUFDRiwwRUFBMEU7WUFDMUUsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUNwRixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztnQkFFbkIsMEJBQTBCO2dCQUMxQixJQUFJLENBQUMsS0FBSyxFQUFFO29CQUNWLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztvQkFFbEIsNEJBQTRCO29CQUM1QixNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7b0JBRTdCLDhCQUE4QjtvQkFDOUIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTt3QkFBRSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3FCQUFFO29CQUV6RCxzREFBc0Q7b0JBQ3RELE1BQU0sa0JBQWtCLEdBQUcsS0FBSyxDQUFDLFdBQVcsSUFBSSxlQUFlLENBQUM7b0JBQ2hFLElBQUksa0JBQWtCLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO3dCQUNuRCxNQUFNLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzt3QkFDMUIsTUFBTSxDQUFDLGVBQWUsR0FBRyxnREFBZ0QsQ0FBQztxQkFDM0U7b0JBRUQsbUJBQW1CO29CQUNuQixNQUFNLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztvQkFDOUMsTUFBTSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7b0JBRWhELE9BQU8sS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUN2QztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDL0IsNENBQTRDO1lBQzVDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQ3ZDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztJQUNoQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGNBQWMsRUFBRTtRQUNkLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVUsRUFBRTtRQUNWLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxLQUFLLENBQUM7U0FBRTtRQUNuRCxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztZQUNwRCxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUM7WUFDOUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDO1lBQy9DLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsdUJBQXVCLEVBQUU7UUFDdkIscUJBQXFCO1FBQ3JCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLEVBQUU7WUFDbkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxFQUFFLENBQUM7U0FDdkM7UUFFRCwyRUFBMkU7UUFDM0UsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRTtZQUMxQiwyRUFBMkU7WUFDM0Usb0ZBQW9GO1lBQ3BGLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMvQjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLG1EQUFtRCxDQUFDO1FBRWpGLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxxQkFBcUIsRUFBRTtRQUNyQixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxtQkFBbUIsRUFBRSxVQUFTLEtBQUs7UUFDakMsSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksRUFBRTtZQUMvQixLQUFLLEdBQUcsZUFBZSxDQUFDO1NBQ3pCO2FBQU0sSUFBSSxPQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQ3JDLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDakIsS0FBSyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7YUFDdkI7aUJBQU0sSUFBSSxPQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUNyQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxLQUFLLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQzthQUNwQjtTQUNGO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsS0FBSztZQUNoQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1lBQzlDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQztRQUN2QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7T0FHRztJQUNILHdCQUF3QixFQUFFLFVBQVMsYUFBYTtRQUM5QyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDO1FBQy9DLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUFFLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FBRTtRQUU3QyxJQUFJLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDM0IsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUMsQ0FBQztTQUMxRDtRQUNELE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCx1QkFBdUIsRUFBRTtRQUN2QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDO1FBQzdDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7U0FBRTtRQUMzQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7T0FHRztJQUNILHdCQUF3QixFQUFFLFVBQVMsT0FBTztRQUN4QyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUFFO1FBQy9ELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM3RCxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixHQUFHLE9BQU8sQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsdUJBQXVCLEVBQUUsVUFBUyxNQUFNO1FBQ3RDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtZQUFFLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQUU7UUFDL0QsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQzVELElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSCx3QkFBd0IsRUFBRSxVQUFTLGFBQWE7UUFDOUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztRQUMvQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFBRSxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFFN0MsSUFBSSxhQUFhLEtBQUssS0FBSyxFQUFFO1lBQzNCLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLENBQUM7U0FDMUQ7UUFDRCxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsdUJBQXVCLEVBQUU7UUFDdkIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztRQUM3QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO1NBQUU7UUFDM0MsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRDs7O09BR0c7SUFDSCx3QkFBd0IsRUFBRSxVQUFTLE9BQU87UUFDeEMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FBRTtRQUMvRCxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDN0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxPQUFPLENBQUM7WUFDM0MsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNILHVCQUF1QixFQUFFLFVBQVMsTUFBTTtRQUN0QyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFBRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUFFO1FBQy9ELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1RCxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixHQUFHLE1BQU0sQ0FBQztZQUN6QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxXQUFXLEVBQUUsVUFBUyxVQUFVLEVBQUUsV0FBVyxFQUFFLFFBQVE7UUFDckQsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztRQUNuQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRWQsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ25DLE9BQU8sR0FBRyxHQUFHLEdBQUcsVUFBVSxHQUFHLDJEQUEyRDtnQkFDdEYsV0FBVyxHQUFHLG1CQUFtQixHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDbEQsRUFBRSxHQUFHLEtBQUssQ0FBQztTQUNaO1FBRUQsSUFBSSxDQUFDLEVBQUUsRUFBRTtZQUNQLElBQUksUUFBUSxFQUFFO2dCQUNaLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDbkI7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMvRDtTQUNGO1FBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxpQkFBaUIsRUFBRSxVQUFTLElBQUksRUFBRSxTQUFTLEVBQUUsVUFBVTtRQUNyRCx3REFBd0Q7UUFDeEQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLE1BQU0sV0FBVyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUM3RSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsNEJBQTRCLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUUzRSxnQ0FBZ0M7WUFDaEMsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDbkQsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUNwQixtQkFBbUIsRUFDbkIsU0FBUyxHQUFHLElBQUksR0FBRyw4QkFBOEIsRUFDakQsSUFBSSxDQUNMLENBQUM7YUFDSDtZQUNELElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ3JELE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FDcEIsbUJBQW1CLEVBQ25CLGNBQWMsR0FBRyxJQUFJLEdBQUcsOEJBQThCLEVBQ3RELElBQUksQ0FDTCxDQUFDO2FBQ0g7WUFFRCx1Q0FBdUM7WUFDdkMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3JFLE1BQU0sVUFBVSxHQUFHLFNBQVMsSUFBSSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ3ZFLE1BQU0sV0FBVyxHQUFHLFVBQVUsSUFBSSxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvRSxNQUFNLGFBQWEsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUV2RCxnQ0FBZ0M7WUFDaEMsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FDekIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsRUFBRSxRQUFRO1lBQ3ZELENBQUMsQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLGdCQUFnQixDQUFDLENBQUMsVUFBVTthQUN6RCxDQUFDO1lBRUYsMERBQTBEO1lBQzFELElBQUksV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQzFCLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzthQUMvQjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILG9CQUFvQixFQUFFLFVBQVMsV0FBVyxFQUFFLGFBQWE7UUFDdkQsV0FBVyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFdkMsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUFFLE9BQU8sV0FBVyxDQUFDO1NBQUU7UUFFekMsTUFBTSxNQUFNLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDaEcsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUMzQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQzthQUMzRDtTQUNGO2FBQU07WUFDTCxXQUFXLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztTQUNyRDtRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxvQkFBb0IsRUFBRSxVQUFTLFdBQVcsRUFBRSxhQUFhO1FBQ3ZELFdBQVcsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXZDLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFBRSxPQUFPLFdBQVcsQ0FBQztTQUFFO1FBRXpDLE1BQU0sTUFBTSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQ2hHLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUM5QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDM0MsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDM0Q7U0FDRjthQUFNO1lBQ0wsV0FBVyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDckQ7UUFDRCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxhQUFhLEVBQUU7UUFDYixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFBRSxPQUFPO1NBQUU7UUFDM0IsSUFBSTtZQUNGLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLHNCQUFzQixDQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQzFCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUNwQixDQUFDO1NBQ0g7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULElBQUksQ0FBQyxZQUFZLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQy9CLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNyQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQzthQUNwQztZQUNELE1BQU0sQ0FBQyxDQUFDO1NBQ1Q7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGFBQWEsRUFBRTtRQUNiLElBQUksSUFBSSxDQUFDLEtBQUssRUFBRTtZQUFFLE9BQU87U0FBRTtRQUMzQixJQUFJO1lBQ0YsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsc0JBQXNCLENBQzFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQ2pCLElBQUksQ0FBQyxLQUFLLENBQ1gsQ0FBQztTQUNIO1FBQUMsT0FBTSxDQUFDLEVBQUU7WUFDVCxJQUFJLENBQUMsWUFBWSxNQUFNLENBQUMsT0FBTyxFQUFFO2dCQUMvQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQzthQUNwQztZQUNELE1BQU0sQ0FBQyxDQUFDO1NBQ1Q7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxXQUFXLEVBQUU7UUFDWCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO1lBQ3BDLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsd0JBQXdCLEVBQ3hCLGVBQWUsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUNuRCxDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLEVBQUU7UUFDZCxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUMzRCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0QsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLEVBQUMsc0JBQXNCLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztRQUNqRixJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ25CLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUMsQ0FBQztTQUM5RTtRQUNELE9BQU8sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVELFVBQVUsRUFBRTtRQUNWLCtGQUErRjtRQUMvRixtR0FBbUc7UUFDbkcsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztJQUNuRSxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILFlBQVksRUFBRSxVQUFTLFlBQVk7UUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7UUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7UUFFaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFFdkIsZUFBZTtRQUNmLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFO1lBQzlCLFlBQVksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7WUFDOUIsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUM7UUFFRCxnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRWxCLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztTQUNqQztRQUNELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7UUFFOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7UUFDNUIsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7U0FDakM7UUFDRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1FBRTlCLGNBQWM7UUFDZCxJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztRQUN2QixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztRQUV2Qix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7UUFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7UUFDekIsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7UUFDdkIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUU3Qix3QkFBd0I7UUFDeEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLFNBQVMsQ0FBQztRQUVwQyxJQUFJLFlBQVksRUFBRTtZQUNoQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztTQUV2QjthQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ3RCLE1BQU0sTUFBTSxDQUFDLFFBQVEsQ0FDbkIsbUJBQW1CLEVBQ25CLGVBQWUsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLG1EQUFtRCxDQUN0RixDQUFDO1NBRUg7YUFBTTtZQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3hEO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsT0FBTyxFQUFFO1FBQ1AsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsVUFBVTtRQUNSLElBQUksSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7U0FDekI7UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDZCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3pCO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsT0FBTyxFQUFFLFVBQVMsWUFBWTtRQUM1QixNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFFbEIsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzVDLHNFQUFzRTtRQUN0RSxNQUFNLFdBQVcsR0FBRyxhQUFhO1lBQy9CLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUM7WUFDbkYsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFaEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFO1lBQ2pFLElBQUksQ0FBQyxFQUFFLEVBQUU7Z0JBQUUsT0FBTzthQUFFO1lBRXBCLElBQUksYUFBYSxFQUFFO2dCQUNqQiwyQ0FBMkM7Z0JBQzNDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUNyQjtZQUVELE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDckIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYOzs7O21CQUlHO2dCQUNILE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsb0VBQW9FO2dCQUNwRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsYUFBYSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDbEUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUVyQixPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNYLHNFQUFzRTtnQkFDdEUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsZ0NBQWdDO2dCQUNoQyxHQUFHLENBQUMsSUFBSSxDQUFDLHNFQUFzRSxFQUM3RSxJQUFJLENBQUMsUUFBUSxFQUNiLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxFQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FDNUMsQ0FBQztnQkFFRixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtvQkFDaEM7Ozs7dUJBSUc7b0JBQ0gsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQ3ZDO1lBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNmLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUN0QyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFFeEMsMkJBQTJCO2dCQUMzQixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7b0JBQy9DLENBQUMsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLFdBQVcsQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDakYsQ0FBQyxDQUFDLEdBQUcsQ0FBQztnQkFFUixNQUFNLE9BQU8sR0FBRyxLQUFLLFlBQVksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ2pFLGlEQUFpRDtnQkFDakQsTUFBTSxLQUFLLEdBQUcsS0FBSyxZQUFZLE9BQU8sSUFBSSxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDeEYsR0FBRyxDQUFDLElBQUksQ0FBQyx5REFBeUQsRUFDaEUsSUFBSSxDQUFDLFFBQVEsRUFDYixXQUFXLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxHQUFHLEVBQ25DLFdBQVcsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUM1QixPQUFPLEVBQ1AsS0FBSyxDQUNOLENBQUM7Z0JBRUYsR0FBRyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFFbkQsSUFBSSxZQUFZLEVBQUU7b0JBQUUsT0FBTztpQkFBRTtnQkFDN0IsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsZUFBZSxFQUFFO1FBQ2YsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDN0Qsc0VBQXNFO1FBQ3RFLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFFdkMsVUFBVTtRQUNWLElBQUksU0FBUyxLQUFLLFVBQVUsRUFBRTtZQUM1QixNQUFNLE1BQU0sR0FBRyxzQkFBc0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxJQUFJO2dCQUN0RSxjQUFjLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDO1lBRXZELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDckIsUUFBUSxFQUFFLFNBQVM7Z0JBQ25CLG1CQUFtQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUU7Z0JBQ3ZELGlCQUFpQixFQUFFLE1BQU07Z0JBQ3pCLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYztnQkFDakMsWUFBWSxFQUFFLElBQUksQ0FBQyxjQUFjO2dCQUNqQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLG9CQUFvQixFQUFFO2dCQUMxRCxnQkFBZ0IsRUFBRSxnQkFBZ0I7YUFDbkMsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxTQUFTO1FBQ1QsSUFDRSxTQUFTLEtBQUssWUFBWSxJQUFJLFNBQVMsS0FBSyxnQkFBZ0IsSUFBSSxTQUFTLEtBQUssYUFBYSxFQUMzRjtZQUNBLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDckIsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLG1CQUFtQixFQUFFLElBQUk7Z0JBQ3pCLGlCQUFpQixFQUFFLG1DQUFtQztnQkFDdEQsWUFBWSxFQUFFLElBQUk7Z0JBQ2xCLFlBQVksRUFBRSxJQUFJO2dCQUNsQixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsZ0JBQWdCLEVBQUUsZ0JBQWdCO2FBQ25DLENBQUMsQ0FBQztTQUNKO1FBRUQsT0FBTztRQUNQLElBQUksU0FBUyxLQUFLLE9BQU8sRUFBRTtZQUN6QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7Z0JBQ3JCLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixtQkFBbUIsRUFBRSxJQUFJO2dCQUN6QixpQkFBaUIsRUFBRSxnQ0FBZ0M7Z0JBQ25ELFlBQVksRUFBRSxJQUFJO2dCQUNsQixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsWUFBWSxFQUFFLElBQUk7Z0JBQ2xCLGdCQUFnQixFQUFFLGdCQUFnQjthQUNuQyxDQUFDLENBQUM7U0FDSjtRQUVELFVBQVU7UUFDVixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsbUJBQW1CLEVBQUUsSUFBSTtZQUN6QixpQkFBaUIsRUFBRSw0QkFBNEI7WUFDL0MsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsZ0JBQWdCLEVBQUUsZ0JBQWdCO1NBQ25DLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILElBQUksUUFBUTtRQUNWLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUFFLE9BQU8sRUFBRSxDQUFDO1NBQUU7UUFFOUMsMkNBQTJDO1FBQzNDLE9BQU87WUFFTCxnRkFBZ0Y7WUFDaEYsTUFBTSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNO1lBQ3BDLGNBQWMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYztZQUNwRCx1QkFBdUIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCO1lBQ3RFLGlCQUFpQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGlCQUFpQjtZQUN4RCxpQkFBaUIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUI7WUFDeEQsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsd0JBQXdCO1lBQ3RFLFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRO1lBQzFFLHdCQUF3QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRO1lBQ3hELE1BQU0sRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTTtZQUNwQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTtZQUN0QyxhQUFhLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVE7WUFDN0MsY0FBYyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjO1lBQ3BELEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSztZQUNsQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWE7WUFDbEQsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGtCQUFrQjtZQUM1RCxvQkFBb0IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0I7WUFDOUQsZUFBZSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWU7WUFDcEQsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0JBQWdCO1lBQ3RELFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTO1NBQ3pDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFVBQVUsRUFBRTtRQUNWLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILFVBQVUsRUFBRSxVQUFTLGNBQWM7UUFDakMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRWxCLGdGQUFnRjtRQUNoRixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUM1QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxtRUFBbUU7UUFDbkUsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRTtZQUNoQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO1NBQ3JDO1FBRUQsaUNBQWlDO1FBQ2pDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7WUFDOUIsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUM7UUFFRCxNQUFNLFVBQVUsR0FBRyxHQUFHLEVBQUU7WUFDdEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLENBQUMsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFFRiwwREFBMEQ7UUFDMUQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDeEMsVUFBVSxFQUFFLENBQUM7WUFDYixPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxQjtRQUVELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsQyxHQUFHLENBQUMsS0FBSyxDQUFDLDBCQUEwQixHQUFHLElBQUksQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1RCxVQUFVLEVBQUUsQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxxQ0FBcUMsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUVuRixPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNwQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSx5Q0FBeUMsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDdEYsVUFBVSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUNaLG9EQUFvRDtZQUN0RCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSCxVQUFVLEVBQUUsVUFBUyxjQUFjO1FBQ2pDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUVsQixnRkFBZ0Y7UUFDaEYsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1lBQzVCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFCO1FBRUQsbUVBQW1FO1FBQ25FLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUU7WUFDaEMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQztTQUNyQztRQUVELGlDQUFpQztRQUNqQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFO1lBQzlCLFlBQVksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsR0FBRyxFQUFFO1lBQ3RCLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixDQUFDLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDOUIsQ0FBQyxDQUFDO1FBRUYsb0RBQW9EO1FBQ3BELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQ3hDLFVBQVUsRUFBRSxDQUFDO1lBQ2IsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUI7UUFFRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDbEMsR0FBRyxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDNUQsVUFBVSxFQUFFLENBQUM7UUFDZixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO1lBQ1osSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsbUNBQW1DLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBRXhGLE9BQU8sSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3BDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLHVDQUF1QyxHQUFHLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztnQkFDM0YsVUFBVSxFQUFFLENBQUM7WUFDZixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUNaLG9EQUFvRDtZQUN0RCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsV0FBVyxFQUFFO1FBQ1gsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO2dCQUNqQyxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUM1QjtpQkFBTTtnQkFDTCxPQUFPLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQ3BDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILGVBQWUsRUFBRSxVQUFTLFFBQVEsRUFBRSxNQUFNO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxrQkFBa0IsRUFBRSxVQUFTLFFBQVEsRUFBRSxNQUFNO1FBQzNDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQy9ELE9BQU8sVUFBVSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxpQkFBaUIsRUFBRSxVQUFTLGFBQWEsRUFBRSxlQUFlO1FBQ3hELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNqQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztTQUMxQztRQUNELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRTtZQUNuQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLGVBQWUsQ0FBQztTQUM5QztRQUNELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNwQyxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxvQkFBb0IsRUFBRTtRQUNwQixNQUFNLE1BQU0sR0FBRyxDQUFDLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMxRCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDcEQsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBRXRFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLGdHQUFnRztZQUNoRyxNQUFNLFNBQVMsR0FDYixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsS0FBSyxLQUFLLENBQUM7WUFFOUMsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDO2dCQUNyQiwyQkFBMkI7Z0JBQ3pCLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRO29CQUNyQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO29CQUMvQixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQztnQkFFOUMsMkJBQTJCO2dCQUMzQixTQUFTLEVBQUUsU0FBUztvQkFDbEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVE7d0JBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7d0JBQy9CLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDO2FBQ2pELENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUN4QyxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFFeEMsR0FBRyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsSUFBSSxDQUFDLGFBQWEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1lBQ25GLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDdkQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUMxQixTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1lBQ3ZDLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7U0FDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2hCLEdBQUcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLElBQUksQ0FBQyxhQUFhLEVBQUUsOEJBQThCLENBQUMsQ0FBQztZQUNsRixJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDOUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzlELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxnSEFBZ0g7WUFDaEgsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxtQ0FBbUM7WUFDbkMsT0FBTyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZiwrQkFBK0I7WUFDL0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDL0MsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksRUFBRTtRQUNaLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQztRQUVsQixtQ0FBbUM7UUFDbkMsSUFBSSxTQUFTLENBQUM7UUFDZDs7V0FFRztRQUNILE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDekI7O1dBRUc7UUFDSCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRXpCLGdHQUFnRztRQUNoRyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVwRSxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDhCQUE4QixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25FLE1BQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXZFLE1BQU0sV0FBVyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUM3RSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFFekQsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLFFBQVEsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBRXRFLG1DQUFtQztZQUNuQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBRWhDLE9BQU8sS0FBSyxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUVYLHNDQUFzQztZQUN0QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFL0IsT0FBTyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1gsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ25CLHFCQUFxQjtnQkFDckIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7Z0JBRXBCLDJCQUEyQjtnQkFDM0IsU0FBUyxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTtvQkFDaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO29CQUMxQixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQztnQkFFOUMsMkJBQTJCO2dCQUMzQixTQUFTLEVBQUUsU0FBUztvQkFDbEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTt3QkFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO3dCQUMxQixDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQzthQUNqRCxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEIsR0FBRyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsT0FBTyxDQUFDLFNBQVMsY0FBYyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsQ0FBQztZQUUzRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztZQUN4QyxJQUFJLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFFeEMsY0FBYztZQUNkLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztZQUVyQixNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxFQUFFO2dCQUMvQix3QkFBd0I7Z0JBQ3hCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNDLHdFQUF3RTtnQkFDeEUsS0FBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pFLE9BQU8sS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDL0MsWUFBWSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUM7b0JBQzdCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUMzQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQztZQUVGLE1BQU0sVUFBVSxHQUFHLEdBQUcsRUFBRTtnQkFDdEIsSUFBSSxZQUFZLEdBQUcsQ0FBQyxFQUFFO29CQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxHQUFHLFlBQVksQ0FBQyxDQUFDO2lCQUN6RTtnQkFDRCw4Q0FBOEM7Z0JBQzlDLE9BQU8sV0FBVyxDQUFDLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDdkUsQ0FBQyxDQUFDO1lBRUYsT0FBTyxLQUFLLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUU7Z0JBQ25ELEtBQUssRUFBRSxFQUFFLEdBQUcsSUFBSTtnQkFDaEIsT0FBTyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7Z0JBQy9CLE1BQU0sRUFBRSxlQUFlO2FBQ3hCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLFNBQVMsRUFBRTtnQkFDYix1QkFBdUI7Z0JBQ3ZCLE9BQU87Z0JBQ1Asc0ZBQXNGO2FBQ3ZGO1lBRUQsY0FBYztZQUNkLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztZQUVyQixNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxFQUFFO2dCQUMvQix3QkFBd0I7Z0JBQ3hCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNDLHdFQUF3RTtnQkFDeEUsS0FBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pFLE9BQU8sS0FBSyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtvQkFDL0MsWUFBWSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUM7b0JBQzdCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUMzQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQztZQUVGLE1BQU0sVUFBVSxHQUFHLEdBQUcsRUFBRTtnQkFDdEIsSUFBSSxZQUFZLEdBQUcsQ0FBQyxFQUFFO29CQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxHQUFHLFlBQVksQ0FBQyxDQUFDO2lCQUN6RTtnQkFDRCw4Q0FBOEM7Z0JBQzlDLE9BQU8sV0FBVyxDQUFDLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDdkUsQ0FBQyxDQUFDO1lBRUYsT0FBTyxLQUFLLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUU7Z0JBQ25ELEtBQUssRUFBRSxFQUFFLEdBQUcsSUFBSTtnQkFDaEIsT0FBTyxFQUFFLElBQUksQ0FBQyxpQkFBaUI7Z0JBQy9CLE1BQU0sRUFBRSxlQUFlO2FBQ3hCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDNUIsZ0NBQWdDO1lBQ2hDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCwyQkFBMkI7WUFDM0IsR0FBRyxDQUFDLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1lBQzVDLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCwrRkFBK0Y7WUFDL0YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsK0JBQStCO1lBQy9CLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQy9DLHFFQUFxRTtnQkFDckUsb0RBQW9EO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxnRUFBZ0U7Z0JBQ2hFLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGLENBQUM7QUFFRix5QkFBeUI7QUFFekI7Ozs7Ozs7OztHQVNHO0FBQ0gsU0FBUyxXQUFXLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTTtJQUN4RCxPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsRUFBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtRQUNuRixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztZQUVyQixNQUFNLG9CQUFvQixHQUFHLEdBQUcsRUFBRTtnQkFDaEMsV0FBVyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQztZQUVGLFVBQVUsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUU3QixxQkFBcUI7Z0JBQ3JCLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRXpCLGdEQUFnRDtnQkFDaEQsSUFBSSxXQUFXLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRTtvQkFDbkMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNuQixXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxFQUFFO3dCQUMxRCxHQUFHLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3dCQUNuRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2hCLENBQUMsQ0FBQyxDQUFDO2lCQUNKO1lBQ0gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7Z0JBQ2hCLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFO29CQUM3QyxHQUFHLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUN4RCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2hCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDckIsR0FBRyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDbEQsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7Ozs7Ozs7O0dBU0c7QUFDSCxTQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxNQUFNO0lBQ3hELE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ25GLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDO1lBRXJCLE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxFQUFFO2dCQUNoQyxXQUFXLEdBQUcsRUFBRSxDQUFDO2dCQUNqQixVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdEIsQ0FBQyxDQUFDO1lBRUYsVUFBVSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUU7Z0JBRTdCLHFCQUFxQjtnQkFDckIsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFekIsZ0RBQWdEO2dCQUNoRCxJQUFJLFdBQVcsQ0FBQyxNQUFNLElBQUksU0FBUyxFQUFFO29CQUNuQyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ25CLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLEVBQUU7d0JBQzFELEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQ25ELE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDaEIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtnQkFDaEIsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQzdDLEdBQUcsQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ3hELE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDaEIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNyQixHQUFHLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNsRCxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVELDJCQUEyQjtBQUUzQixNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3hCLE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDIn0=