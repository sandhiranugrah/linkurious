/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-18.
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../index');
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// We can't sleep for more than 24 days (setTimeout() use a 32 bit int to store the delay)
const MAX_MILLISEC_TIMEOUT = 7 * 24 * 60 * 60 * 1000; // A week
class Task {
    /**
     * @param {number}        id
     * @param {Bluebird<any>} promise
     * @param {string}        timeToSchedule Date of next run in ISO-8601 format
     * @param {string}        status         ("waiting", "running", "cancelled")
     */
    constructor(id, promise, timeToSchedule, status) {
        this.id = id;
        this.promise = promise;
        this.timeToSchedule = timeToSchedule;
        this.status = status;
    }
}
class SchedulerService {
    constructor() {
        /**
         * @type {Map<string, Semaphore>}
         */
        this._semaphores = new Map();
        /**
         * @type {Map<number, Task>}
         */
        this._tasks = new Map();
        this._nextId = 0;
    }
    /**
     * Set the concurrency for task group with name `groupName` to `maxGroupConcurrency`.
     * All the functions scheduled with this key will run accordingly to the group max concurrency.
     *
     * @param {string} groupName
     * @param {number} [maxGroupConcurrency] Concurrency limit
     *
     * @throws {LkError} if `groupName` is not valid
     */
    setGroupConcurrency(groupName, maxGroupConcurrency) {
        Utils.check.string('groupName', groupName, true);
        this._semaphores.set(groupName, maxGroupConcurrency ? Utils.semaphore(maxGroupConcurrency) : undefined);
    }
    /**
     * Cancel the execution of a given task by id.
     *
     * @param {number}  taskId
     * @returns {boolean} True, if cancelled
     */
    cancel(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            if (task.status !== 'running') {
                Log.debug(`Scheduler: Task #${taskId} was cancelled (wasn't running).`);
                task.promise.cancel();
            }
            else {
                Log.debug(`Scheduler: Task #${taskId} was cancelled (interrupting running task).`);
                task.promise.cancel();
            }
            task.status = 'cancelled';
            return true;
        }
        return false;
    }
    /**
     * Get the date of the next execution of a given task by id.
     *
     * @param {number} taskId
     *
     * @returns {string} Date of next run in ISO-8601 format
     */
    getTimeToSchedule(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.timeToSchedule;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            throw Errors.technical('invalid_parameter', 'This task is not available anymore (the task was deleted).');
        }
        throw Errors.technical('invalid_parameter', '"taskId" is not valid.');
    }
    /**
     * Get the promise of the next execution of a given task by id.
     * If the task was deleted, it will return a rejected promise.
     *
     * @param {number} taskId
     *
     * @returns {Bluebird<any>} Promise of the task fulfilment
     */
    getPromise(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.promise;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            return Errors.technical('invalid_parameter', 'This task is not available anymore (the task was deleted).', true);
        }
        return Errors.technical('invalid_parameter', '"taskId" is not valid.', true);
    }
    /**
     * Get the status of a given task by id.
     * Possible status are: "waiting", "running", "cancelled", "unavailable".
     *
     * @param {number} taskId
     *
     * @returns {string | null} null (if invalid ID), "waiting", "running", "cancelled",
     *                               "unavailable"
     */
    getStatus(taskId) {
        const task = this._tasks.get(taskId);
        if (task) {
            return task.status;
        }
        else if (taskId > 0 && taskId < this._nextId) {
            return 'unavailable';
        }
        else {
            return null;
        }
    }
    /**
     * Return a resolved promise when Date.now() equals `epoch`.
     *
     * @param {number} epoch
     * @returns {Bluebird<any>}
     * @private
     */
    _delay(epoch) {
        const loop = () => {
            const millisToWait = epoch - Date.now();
            if (millisToWait <= 0) {
                // if epoch is minor or equal to Date.now() we resolve immediately
                return Promise.resolve();
            }
            const timeToWaitThisLoop = Math.min(millisToWait, MAX_MILLISEC_TIMEOUT);
            return Promise.delay(timeToWaitThisLoop).then(loop);
        };
        return loop();
    }
    /**
     * Look at scheduleTaskOnce.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string} cronExpression    A CRON expression
     * @param {object} options
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group]   Group of this task (used for concurrency control)
     * @param {number} taskId            ID of the scheduled task
     * @private
     */
    _scheduleTaskOnce(f, cronExpression, options, taskId) {
        const semaphore = this._semaphores.get(options.group);
        try {
            const timeToSchedule = Utils.nextTimeToSchedule(cronExpression, options.lastRun);
            const promise = this._delay(timeToSchedule.getTime()).then(() => {
                if (semaphore) {
                    return semaphore.acquire();
                }
            }).then(() => {
                if (this.getStatus(taskId) === 'cancelled') {
                    return;
                }
                this._tasks.get(taskId).status = 'running';
                Log.debug(`Scheduler: Task #${taskId} is now running.`);
                return f().finally(() => {
                    Log.debug(`Scheduler: Task #${taskId} is no longer running.`);
                });
            }).catch(Promise.CancellationError, () => {
                // ignore cancellation rejections
            });
            promise.catch(err => {
                Log.error(`Scheduler: Task ${taskId} threw an error while running.`, err);
            }).finally(() => {
                if (semaphore) {
                    semaphore.release();
                }
            });
            this._tasks.set(taskId, new Task(taskId, promise, timeToSchedule.toISOString(), 'waiting'));
        }
        catch (e) {
            Log.error('We should never be here since we assumed that both cron and lastRun were valid', cronExpression, options.lastRun.toISOString());
        }
    }
    /**
     * @param {function(): Bluebird<any>} f
     * @param {string} cron            A CRON expression
     * @param {object} options
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group] Within a group the functions will run accordingly to the group max
     *                                 concurrency. If the function returns a promise, the semaphore will
     *                                 be released only after the returned promise is resolved.
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     * @private
     */
    static _checkArgs(f, cron, options) {
        Utils.check.function('function', f);
        Utils.check.cronExpression('cron', cron);
        if (options.group) {
            Utils.check.string('group', options.group);
        }
        Utils.check.date('lastRun', options.lastRun);
    }
    /**
     * Schedule a task to run only once at the first time after a given date (lastRun) that match
     * the CRON expression.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string} cronExpression  A CRON expression
     * @param {object} [options]
     * @param {Date}   [options.lastRun=new Date()] Date of the last run
     * @param {string} [options.group] Within a group the functions will run accordingly to the group max
     *                                 concurrency. If the function returns a promise, the semaphore will
     *                                 be released only after the returned promise is resolved.
     *
     * @returns {number} id
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     */
    scheduleTaskOnce(f, cronExpression, options) {
        options = Utils.hasValue(options) ? _.cloneDeep(options) : {};
        if (Utils.noValue(options.lastRun)) {
            options.lastRun = new Date();
        }
        SchedulerService._checkArgs(f, cronExpression, options);
        const id = this._nextId++;
        this._scheduleTaskOnce(f, cronExpression, options, id);
        this.getPromise(id).catch(() => {
            // We have already logged the error on _scheduleTaskOnce
        }).finally(() => {
            this._tasks.delete(id);
        });
        return id;
    }
    /**
     * Schedule a task to run periodically according to a given CRON expression.
     * if options.lastRun is defined, it checks if it should have been executed between lastRun and
     * currentDate. If yes, it will also execute the function immediately.
     *
     * @param {function(): Bluebird<any>} f
     * @param {string}  cronExpression  A CRON expression
     * @param {object}  [options]
     * @param {Date}    [options.lastRun=new Date()] Date of the last run
     * @param {string}  [options.group] Within a group the functions will run accordingly to the group max
     *                                  concurrency. If the function returns a promise, the semaphore will
     *                                  be released only after the returned promise is resolved.
     * @param {boolean} [options.cancelOnError=false]
     *
     * @returns {number} id
     * @throws {LkError} if `f`, `cron`, `options.group` or `options.lastRun` are not valid.
     */
    scheduleTask(f, cronExpression, options) {
        options = Utils.hasValue(options) ? _.cloneDeep(options) : {};
        if (Utils.noValue(options.lastRun)) {
            options.lastRun = new Date();
        }
        SchedulerService._checkArgs(f, cronExpression, options);
        const id = this._nextId++;
        /**
         * @returns {Bluebird<any>}
         */
        const loop = () => {
            if (this.getStatus(id) === 'cancelled') {
                return Promise.resolve();
            }
            this._scheduleTaskOnce(f, cronExpression, options, id);
            if (options.lastRun) {
                options.lastRun = undefined;
            }
            return this.getPromise(id)
                .then(loop)
                .catch(() => {
                if (options.cancelOnError) {
                    return;
                }
                return loop();
            }).finally(() => {
                this._tasks.delete(id);
            });
        };
        loop();
        return id;
    }
}
module.exports = new SchedulerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc2NoZWR1bGVyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsMEZBQTBGO0FBQzFGLE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLFNBQVM7QUFFL0QsTUFBTSxJQUFJO0lBQ1I7Ozs7O09BS0c7SUFDSCxZQUFZLEVBQUUsRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU07UUFDN0MsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDYixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztJQUN2QixDQUFDO0NBQ0Y7QUFFRCxNQUFNLGdCQUFnQjtJQUVwQjtRQUNFOztXQUVHO1FBQ0gsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTdCOztXQUVHO1FBQ0gsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILG1CQUFtQixDQUFDLFNBQVMsRUFBRSxtQkFBbUI7UUFDaEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVqRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FDbEIsU0FBUyxFQUNULG1CQUFtQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDdkUsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILE1BQU0sQ0FBQyxNQUFNO1FBQ1gsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckMsSUFBSSxJQUFJLEVBQUU7WUFDUixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFO2dCQUM3QixHQUFHLENBQUMsS0FBSyxDQUFDLG9CQUFvQixNQUFNLGtDQUFrQyxDQUFDLENBQUM7Z0JBQ3hFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7YUFFdkI7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsTUFBTSw2Q0FBNkMsQ0FBQyxDQUFDO2dCQUNuRixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ3ZCO1lBRUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUM7WUFFMUIsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGlCQUFpQixDQUFDLE1BQU07UUFDdEIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckMsSUFBSSxJQUFJLEVBQUU7WUFDUixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDNUI7YUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDOUMsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUNwQixtQkFBbUIsRUFBRSw0REFBNEQsQ0FBQyxDQUFDO1NBQ3RGO1FBQ0QsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLHdCQUF3QixDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSCxVQUFVLENBQUMsTUFBTTtRQUNmLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksSUFBSSxFQUFFO1lBQ1IsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO1NBQ3JCO2FBQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzlDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FDckIsbUJBQW1CLEVBQUUsNERBQTRELEVBQUUsSUFBSSxDQUN4RixDQUFDO1NBQ0g7UUFDRCxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsU0FBUyxDQUFDLE1BQU07UUFDZCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyQyxJQUFJLElBQUksRUFBRTtZQUNSLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUNwQjthQUFNLElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUM5QyxPQUFPLGFBQWEsQ0FBQztTQUN0QjthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUM7U0FDYjtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxNQUFNLENBQUMsS0FBSztRQUNWLE1BQU0sSUFBSSxHQUFHLEdBQUcsRUFBRTtZQUNoQixNQUFNLFlBQVksR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBRXhDLElBQUksWUFBWSxJQUFJLENBQUMsRUFBRTtnQkFDckIsa0VBQWtFO2dCQUNsRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUMxQjtZQUVELE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztZQUV4RSxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsQ0FBQyxDQUFDO1FBRUYsT0FBTyxJQUFJLEVBQUUsQ0FBQztJQUNoQixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILGlCQUFpQixDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTyxFQUFFLE1BQU07UUFDbEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXRELElBQUk7WUFDRixNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNqRixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQzlELElBQUksU0FBUyxFQUFFO29CQUNiLE9BQU8sU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUM1QjtZQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1gsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFdBQVcsRUFBRTtvQkFDMUMsT0FBTztpQkFDUjtnQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO2dCQUUzQyxHQUFHLENBQUMsS0FBSyxDQUFDLG9CQUFvQixNQUFNLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3hELE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtvQkFDdEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsTUFBTSx3QkFBd0IsQ0FBQyxDQUFDO2dCQUNoRSxDQUFDLENBQUMsQ0FBQztZQUVMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxFQUFFO2dCQUN2QyxpQ0FBaUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7WUFFSCxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNsQixHQUFHLENBQUMsS0FBSyxDQUFDLG1CQUFtQixNQUFNLGdDQUFnQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzVFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxTQUFTLEVBQUU7b0JBQ2IsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUNyQjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxDQUFDLFdBQVcsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7U0FFN0Y7UUFBQyxPQUFNLENBQUMsRUFBRTtZQUNULEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0ZBQWdGLEVBQ3hGLGNBQWMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7U0FDbEQ7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNILE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPO1FBQ2hDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQyxLQUFLLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFekMsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO1lBQ2pCLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDNUM7UUFFRCxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILGdCQUFnQixDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTztRQUN6QyxPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRTlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1NBQzlCO1FBRUQsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFeEQsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUV2RCxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDN0Isd0RBQXdEO1FBQzFELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsWUFBWSxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTztRQUNyQyxPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRTlELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1NBQzlCO1FBRUQsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFeEQsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRTFCOztXQUVHO1FBQ0gsTUFBTSxJQUFJLEdBQUcsR0FBRyxFQUFFO1lBQ2hCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQUUsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7YUFBRTtZQUVyRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdkQsSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFO2dCQUNuQixPQUFPLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQzthQUM3QjtZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7aUJBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUM7aUJBQ1YsS0FBSyxDQUFDLEdBQUcsRUFBRTtnQkFDVixJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQUUsT0FBTztpQkFBRTtnQkFDdEMsT0FBTyxJQUFJLEVBQUUsQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBRUYsSUFBSSxFQUFFLENBQUM7UUFFUCxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDIn0=