/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-04-20.
 */
'use strict';
// external libs
const _ = require('lodash');
// services
const LKE = require('../index');
const Utils = LKE.getUtils();
const Errors = LKE.getErrors();
// locals
const VisualizationChecker = require('../business/VisualizationChecker');
/**
 * @backward-compatibility Pre v2.5 design palette
 */
const OLD_PALETTE_PROPERTIES = {
    nodes: {
        properties: {
            qualitative: {
                // keys: name of qualitative palette
                anyProperty: {
                    // keys: size of the palette
                    anyProperty: {
                        // color OR array of hex colors
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                return Utils.check.cssColor(key, value);
                            }
                            else {
                                return Utils.check.property(key, value, {
                                    arrayItem: { check: 'hexColor' }
                                });
                            }
                        }
                    }
                }
            },
            sequential: {
                // keys: size of the palette
                anyProperty: {
                    // array of hex colors
                    arrayItem: { check: 'hexColor' }
                }
            },
            icons: {
                // keys: name of the property on which the icon is mapped
                anyProperty: {
                    // keys: value of the property for this icon
                    anyProperty: {
                        properties: {
                            font: { check: 'nonEmpty' },
                            color: { check: 'hexColor' },
                            scale: { check: ['number', 0] },
                            content: { check: 'nonEmpty' }
                        }
                    }
                }
            },
            images: {
                // by image palette name (.e.g. "crunchbase")
                anyProperty: {
                    // by property/node-category/edge-type value (e.g. "CITY" for a node-category scheme, or "Paris" for a property scheme)
                    anyProperty: {
                        properties: {
                            // URL of the image
                            url: { required: true, type: 'string' },
                            // scaling ratio of the image
                            scale: { type: 'number' },
                            // clip ratio of the image (?)
                            clip: { type: 'number' }
                        }
                    }
                }
            }
        }
    },
    edges: {
        properties: {
            qualitative: {
                // keys: name of qualitative palette
                anyProperty: {
                    // keys: size of the palette
                    anyProperty: {
                        // color OR array of hex colors
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                return Utils.check.cssColor(key, value);
                            }
                            else {
                                return Utils.check.property(key, value, {
                                    arrayItem: { check: 'hexColor' }
                                });
                            }
                        }
                        //arrayItem: {check: 'hexColor'}
                    }
                }
            },
            sequential: {
                // keys: size of the palette
                anyProperty: {
                    // array of hex colors
                    arrayItem: { check: 'hexColor' }
                }
            }
        }
    }
};
const CONFIG_PROPERTIES = {
    // data-source array
    dataSources: {
        required: true,
        arrayItem: {
            required: true,
            properties: {
                deleted: { type: 'boolean' },
                name: { type: 'string' },
                manualSourceKey: { check: (key, value) => Utils.checkSourceKey(value) },
                readOnly: { type: 'boolean' },
                graphdb: {
                    required: true,
                    type: 'object',
                    check: (key, value) => ConfigChecker.checkGraph(key, value)
                },
                index: {
                    required: true,
                    type: 'object',
                    check: (key, value) => ConfigChecker.checkIndex(key, value)
                }
            }
        }
    },
    // cross-sources parameters
    advanced: {
        required: true,
        properties: {
            supernodeThreshold: { required: true, check: ['integer', 1] },
            expandThreshold: { required: true, check: ['integer', 1] },
            rawQueryLimit: { required: true, check: ['integer', 1] },
            searchAddAllThreshold: { required: true, check: ['integer', 1] },
            minSearchQueryLength: { required: true, check: ['integer', 1] },
            rawQueryTimeout: { required: true, check: ['integer', 1] },
            connectionRetries: { check: ['posInt'] },
            pollInterval: { check: ['integer', 1] },
            indexationChunkSize: { check: ['integer', 1] },
            layoutWorkers: { check: 'posInt' },
            defaultFuzziness: { check: ['number', 0, 1] },
            extraCertificateAuthorities: { check: 'file' },
            obfuscation: { type: 'boolean' },
            edgesBetweenSupernodes: { type: 'boolean' }
        }
    },
    // internal database config
    db: {
        required: true,
        properties: {
            name: { required: true, check: 'nonEmpty' },
            username: { check: 'nonEmpty' },
            password: { check: 'nonEmpty' },
            connectionRetries: { check: ['posInt', 1] },
            options: {
                type: 'object',
                check: (key, value) => ConfigChecker.checkDbOptions(key, value)
            }
        }
    },
    // backend http server configuration
    server: {
        required: true,
        properties: {
            listenPort: { required: true, check: 'port' },
            clientFolder: { required: true, check: 'nonEmpty' },
            cookieSecret: { check: 'nonEmpty' },
            allowOrigin: { type: ['string', 'array'] },
            domain: { check: 'nonEmpty' },
            baseFolder: { check: ['regexp', /^[a-zA-Z0-9\-_]+$/] },
            publicPortHttp: { check: 'integer' },
            publicPortHttps: { check: 'integer' },
            cookieDomain: { check: 'nonEmpty' },
            // https
            listenPortHttps: { check: 'port' },
            useHttps: { type: 'boolean' },
            forceHttps: { type: 'boolean' },
            forcePublicHttps: { type: 'boolean' },
            certificateFile: { check: 'nonEmpty' },
            certificateKeyFile: { check: 'nonEmpty' },
            certificatePassphrase: { check: 'nonEmpty' } // custom certificate pass-phrase
        }
    },
    defaultPreferences: {
        required: true,
        type: 'object',
        check: (key, value) => ConfigChecker.checkPreferences(key, value)
    },
    guestPreferences: {
        required: true,
        type: 'object',
        check: (key, value) => ConfigChecker.checkPreferences(key, value, true)
    },
    // Captions used by default in visualizations
    // @backward-compatibility default captions removed in LKE v2.5.0
    defaultCaptions: { check: (key, value) => VisualizationChecker.checkCaptions(key, value) },
    alerts: {
        properties: {
            enabled: { type: 'boolean' },
            maxMatchTTL: { check: ['integer', 0] },
            maxMatchesLimit: { check: ['integer', 1] },
            maxRuntimeLimit: { check: ['integer', 1] },
            maxConcurrency: { check: ['integer', 1] }
        }
    },
    // audit-trail configuration
    auditTrail: {
        required: true,
        properties: {
            enabled: { type: 'boolean' },
            logFolder: { check: 'nonEmpty' },
            fileSizeLimit: { check: ['integer', 100 * 1024] },
            strictMode: { type: 'boolean' },
            logResult: { type: 'boolean' },
            mode: { values: ['r', 'w', 'rw'] }
        }
    },
    // authentication configuration
    access: {
        required: true,
        properties: {
            floatingLicenses: { check: ['integer', 1] },
            authRequired: { type: 'boolean' },
            guestMode: { type: 'boolean' },
            defaultPage: { type: 'string' },
            defaultPageParams: { type: 'object' },
            dataEdition: { type: 'boolean' },
            widget: { type: 'boolean' },
            loginTimeout: { check: ['integer', 60] },
            externalUsersAllowedGroups: { arrayItem: { type: ['string', 'number'] } },
            externalUserDefaultGroupId: { check: (key, value) => {
                    Utils.check.type(key, value, ['number', 'array']);
                    if (Array.isArray(value)) {
                        Utils.check.intArray(key, value);
                    }
                    else {
                        Utils.check.integer(key, value);
                    }
                } },
            externalUsersGroupMapping: {
                anyProperty: {
                    check: (key, value) => {
                        Utils.check.type(key, value, ['number', 'array']);
                        if (Array.isArray(value)) {
                            Utils.check.intArray(key, value);
                        }
                        else {
                            Utils.check.integer(key, value);
                        }
                    }
                }
            },
            // @backward-compatibility old Azure AD configuration
            azureActiveDirectory: {
                deprecated: 'Use "access.oauth2" with provider "azure" instead'
            },
            // Microsoft AD configuration
            msActiveDirectory: {
                properties: {
                    enabled: { type: 'boolean' },
                    url: { check: 'nonEmpty' },
                    baseDN: { check: 'nonEmpty' },
                    domain: { check: 'nonEmpty' },
                    netbiosDomain: { check: 'nonEmpty' },
                    tls: {
                        required: false,
                        policy: 'inclusive',
                        // actually accepts for all `tls.connect` options
                        // see https://nodejs.org/api/tls.html#tls_tls_connect_options_callback
                        properties: {
                            // whether to reject servers with self signed certificates
                            rejectUnauthorized: { type: 'boolean' }
                        }
                    }
                }
            },
            // OpenLDAP configuration
            ldap: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    url: { required: true, check: 'nonEmpty' },
                    bindDN: { requiredIf: 'bindPassword', type: 'string' },
                    bindPassword: { requiredIf: 'bindDN', type: 'string' },
                    baseDN: { required: true,
                        check: (key, value) => {
                            if (typeof value === 'string') {
                                Utils.check.nonEmpty(key, value);
                            }
                            else {
                                Utils.check.stringArray(key, value, 1, undefined, true);
                            }
                        }
                    },
                    usernameField: { required: true, check: 'nonEmpty' },
                    emailField: { check: 'nonEmpty' },
                    groupField: { check: 'nonEmpty' },
                    // @backward-compatibility old way to filter authorized groups in LDAP
                    authorizedGroups: { deprecated: 'Use "access.externalUsersAllowedGroups" instead' },
                    tls: {
                        required: false,
                        policy: 'inclusive',
                        // actually accepts for all `tls.connect` options
                        // see https://nodejs.org/api/tls.html#tls_tls_connect_options_callback
                        properties: {
                            // whether to reject servers with self signed certificates
                            rejectUnauthorized: { type: 'boolean' }
                        }
                    }
                }
            },
            // saml2 configuration
            saml2: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    url: { required: true, check: 'nonEmpty' },
                    identityProviderCertificate: { required: true, check: 'nonEmpty' },
                    groupAttribute: { check: 'nonEmpty' },
                    emailAttribute: { check: 'nonEmpty' }
                }
            },
            // oauth2 configuration
            oauth2: {
                properties: {
                    enabled: { required: true, type: 'boolean' },
                    provider: { required: true, check: 'nonEmpty' },
                    authorizationURL: { required: true, check: 'url' },
                    tokenURL: { required: true, check: 'url' },
                    clientID: { required: true, check: 'nonEmpty' },
                    clientSecret: { required: true, check: 'nonEmpty' },
                    openidconnect: {
                        properties: {
                            userinfoURL: { requiredIf: 'groupClaim', check: 'url' },
                            scope: { requiredIf: 'groupClaim', check: 'nonEmpty' },
                            groupClaim: { check: 'nonEmpty' }
                        }
                    },
                    azure: {
                        properties: {
                            tenantID: { check: 'nonEmpty' }
                        }
                    }
                }
            }
        }
    },
    // leaflet tile layers configuration
    leaflet: {
        required: true,
        arrayItem: {
            required: true,
            properties: {
                name: { required: true, check: 'nonEmpty' },
                urlTemplate: { required: true, check: 'httpUrl' },
                attribution: { required: true, check: 'nonEmpty' },
                minZoom: { required: true, check: ['integer', 1] },
                maxZoom: { required: true, check: ['integer', 1, 60] },
                thumbnail: { required: true, check: 'string' },
                subdomains: { check: 'nonEmpty' },
                id: { check: 'nonEmpty' },
                accessToken: { check: 'nonEmpty' },
                overlay: { type: 'boolean' } // whether this layer is an overlay
            }
        }
    },
    // ogma configuration
    ogma: {
        required: true,
        properties: {
            renderer: { values: ['webgl', 'canvas'] },
            webglOptions: {
                properties: {
                    antiAliasing: { values: ['super-sampling', 'native', 'none'] },
                    fontSamplingSize: { check: ['integer', 1] }
                }
            },
            imgCrossOrigin: { values: ['anonymous', 'use-credentials'] },
            options: { type: 'object' }
        }
    },
    // @backward-compatibility default styles removed in LKE v2.5.0
    defaultStyles: {
        required: false,
        properties: {
            nodes: { type: 'object' },
            edges: { type: 'object' }
        }
    },
    // palettes config
    palette: {
        check: (key, value) => {
            // @backward-compatibility palette removed in LKE v2.5.0
            Utils.check.properties(key, value, OLD_PALETTE_PROPERTIES);
        }
    },
    // first run flag
    firstRun: { type: 'boolean' },
    // config version
    version: { type: 'string' },
    // Unique Id of the customer in Linkurious
    customerId: {
        type: 'string',
        check: Utils.validateCustomerId
    },
    // used in tests
    testSetting: {}
};
class ConfigChecker {
    /**
     * @param {any} config
     * @throws {LkError} the configuration validation error, if any.
     */
    static check(config) {
        Utils.check.properties('configuration', config, CONFIG_PROPERTIES);
    }
    /**
     * @param {string} key
     * @param {any}    dbOptions
     */
    static checkDbOptions(key, dbOptions) {
        Utils.check.values(key + '.dialect', dbOptions.dialect, ['sqlite', 'mysql', 'mariadb', 'mssql']);
        if (dbOptions.dialect === 'sqlite') {
            Utils.check.properties(key, dbOptions, {
                dialect: { values: [dbOptions.dialect] },
                storage: { check: 'nonEmpty' }
            });
        }
        else {
            Utils.check.properties(key, dbOptions, {
                dialect: { values: [dbOptions.dialect] },
                host: { check: 'nonEmpty' },
                port: { check: 'port' }
            });
        }
    }
    /**
     * @param {string}  key
     * @param {any}     preferences
     * @param {boolean} [isGuestPreferences]
     */
    static checkPreferences(key, preferences, isGuestPreferences) {
        let properties = {
            locale: { required: true, check: (key, value) => {
                    Utils.check.string(key, value, true, true, 5, 5); // valid example: "en-US"
                    // if 3rd character is not '-' throw an error
                    if (value[2] !== '-') {
                        throw Errors.business('invalid_parameter', `"${key}" must be a valid locale.`);
                    }
                } }
        };
        if (isGuestPreferences) {
            properties = _.merge(properties, {
                uiWorkspaceSearch: { required: true, type: 'boolean' },
                uiExport: { required: true, type: 'boolean' },
                uiLayout: { required: true, values: ['regular', 'simple', 'none'] },
                uiDesign: { required: true, type: 'boolean' },
                uiFilter: { required: true, type: 'boolean' }
            });
        }
        else {
            // User preferences
            properties = _.merge(properties, {
                pinOnDrag: { required: true, type: 'boolean' }
            });
        }
        Utils.check.properties('configuration', preferences, properties);
    }
    /**
     * @param {string} key
     * @param {any}    graphdb
     */
    static checkGraph(key, graphdb) {
        Utils.check.values(key + '.vendor', graphdb.vendor, [
            'neo4j', 'allegroGraph', 'dse', 'janusGraph', 'janusGraphForCompose', 'stardog', 'cosmosDb'
        ]);
        let properties = {
            vendor: { required: true, values: [graphdb.vendor] },
            latitudeProperty: { check: 'nonEmpty' },
            longitudeProperty: { check: 'nonEmpty' },
            // Every GraphDAO "should" allowSelfSigned
            allowSelfSigned: { type: 'boolean' }
        };
        const alternativeIdsProperties = {
            alternativeEdgeId: { check: 'nonEmpty' },
            alternativeNodeId: { check: 'nonEmpty' },
            alternativeNodeIdIndex: { check: 'nonEmpty' },
            alternativeEdgeIdIndex: { check: 'nonEmpty' }
        };
        const userPasswordAuthProperties = {
            user: { check: 'nonEmpty' },
            password: { check: 'nonEmpty' }
        };
        const sparqlProperties = {
            namespace: { check: 'url' },
            categoryPredicate: { check: 'nonEmpty' },
            idPropertyName: { check: 'nonEmpty' }
        };
        // These options are applicable when the GraphDAO uses a session to communicate with gremlin server
        const gremlinSessionProperties = {
            maxStale: { check: 'posInt' },
            sessionPool: { check: ['integer', 1] }
        };
        const disableIndexExistCheckProperties = {
            disableIndexExistCheck: { type: 'boolean' }
        };
        switch (graphdb.vendor) {
            case 'neo4j':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    proxy: { check: 'nonEmpty' },
                    writeURL: { check: 'httpUrl' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                break;
            case 'janusGraph':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    // At least one of the three has to be defined
                    graphAlias: { check: 'nonEmpty' },
                    traversalSourceAlias: { check: 'nonEmpty' },
                    configurationPath: { check: 'nonEmpty' },
                    configuration: { type: 'object' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                properties = _.merge(properties, disableIndexExistCheckProperties);
                properties = _.merge(properties, gremlinSessionProperties);
                Utils.check.exclusive(key, graphdb, ['graphAlias', 'configurationPath', 'configuration'], true);
                break;
            case 'janusGraphForCompose':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    graphName: { required: true, check: 'nonEmpty' },
                    create: { type: 'boolean' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, alternativeIdsProperties);
                properties = _.merge(properties, disableIndexExistCheckProperties);
                properties = _.merge(properties, gremlinSessionProperties);
                break;
            case 'dse':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    graphName: { required: true, check: 'nonEmpty' },
                    create: { type: 'boolean' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, gremlinSessionProperties);
                break;
            case 'allegroGraph':
                properties = _.merge(properties, {
                    url: { required: true, check: 'httpUrl' },
                    repository: { required: true, check: 'nonEmpty' },
                    catalog: { check: 'nonEmpty' },
                    create: { type: 'boolean' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, sparqlProperties);
                break;
            case 'stardog':
                properties = _.merge(properties, {
                    url: { required: true, check: 'httpUrl' },
                    repository: { required: true, check: 'nonEmpty' },
                    reasoning: { type: 'boolean' }
                });
                properties = _.merge(properties, userPasswordAuthProperties);
                properties = _.merge(properties, sparqlProperties);
                break;
            case 'cosmosDb':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    database: { required: true, check: 'nonEmpty' },
                    collection: { required: true, check: 'nonEmpty' },
                    primaryKey: { required: true, check: 'nonEmpty' }
                });
                break;
        }
        Utils.check.properties(key, graphdb, properties);
    }
    /**
     * @param {string} key
     * @param {any}    index
     */
    static checkIndex(key, index) {
        Utils.check.values(key + '.vendor', index.vendor, [
            'elasticSearch', 'elasticSearch2', 'neo2es',
            'neo4jSearch', 'allegroGraphSearch', 'dseSearch', 'janusGraphSearch', 'stardogSearch',
            'solrUnmanaged', 'azureSearch'
        ]);
        let properties = {
            vendor: { required: true, values: [index.vendor] }
        };
        const disableIndexExistCheckProperties = {
            disableIndexExistCheck: { type: 'boolean' }
        };
        switch (index.vendor) {
            case 'elasticSearch':
                properties = _.merge(properties, {
                    host: { required: true, check: 'nonEmpty' },
                    port: { required: true, check: 'port' },
                    forceReindex: { type: 'boolean' },
                    skipEdgeIndexation: { type: 'boolean' },
                    dynamicMapping: { type: 'boolean' },
                    dateDetection: { type: 'boolean' },
                    //url: {check: 'httpUrl'},
                    https: { type: 'boolean' },
                    indexName: { type: 'string' },
                    mapping: { type: 'object' },
                    analyzer: { type: 'string' },
                    user: { check: 'nonEmpty' },
                    password: { check: 'nonEmpty' }
                });
                break;
            case 'elasticSearch2':
                properties = _.merge(properties, {
                    host: { required: true, check: 'nonEmpty' },
                    port: { required: true, check: 'port' },
                    forceReindex: { type: 'boolean' },
                    https: { type: 'boolean' },
                    user: { check: 'nonEmpty' },
                    password: { check: 'nonEmpty' },
                    dynamicMapping: { type: 'boolean' },
                    forceStringMapping: { arrayItem: { check: 'nonEmpty' } },
                    analyzer: { type: 'string' },
                    // "indexName" is a internal option of the DAO, it should never be in the configuration
                    skipEdgeIndexation: { type: 'boolean' },
                    caCert: { type: 'string' },
                    simplifiedSearch: { type: 'boolean' }
                });
                break;
            case 'neo2es':
                properties = _.merge(properties, {
                    simplifiedSearch: { type: 'boolean' }
                });
                break;
            case 'neo4jSearch':
                properties = _.merge(properties, {
                    initialization: { check: 'boolean' },
                    categoriesToIndex: { arrayItem: { type: 'string' } },
                    edgeTypesToIndex: { arrayItem: { type: 'string' } },
                    nodeIndexName: { type: 'string' },
                    edgeIndexName: { type: 'string' },
                    indexEdges: { type: 'boolean' },
                    simplifiedSearch: { type: 'boolean' },
                    // @backward-compatibility
                    batchSize: { check: 'number' },
                    numberOfThreads: { check: 'number' },
                    initialOffsetNodes: { check: 'number' },
                    initialOffsetEdges: { check: 'number' }
                });
                break;
            case 'janusGraphSearch':
                properties = _.merge(properties, {
                    create: { type: 'boolean' },
                    indexEdges: { type: 'boolean' },
                    nodeIndexName: { type: 'string' },
                    edgeIndexName: { type: 'string' }
                });
                break;
            case 'stardogSearch':
                break;
            case 'allegroGraphSearch':
            case 'dseSearch':
                properties = _.merge(properties, disableIndexExistCheckProperties);
                break;
            case 'solrUnmanaged':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    collectionName: { required: true, type: 'string' },
                    user: { check: 'nonEmpty' },
                    password: { check: 'nonEmpty' },
                    allowSelfSigned: { type: 'boolean' },
                    searchKeys: { required: true, check: ['stringArray', 1] },
                    categoriesKey: { required: true, type: 'string' },
                    indexAlternativeId: { type: 'string' },
                    graphAlternativeId: { type: 'string' }
                });
                break;
            case 'azureSearch':
                properties = _.merge(properties, {
                    url: { required: true, check: 'url' },
                    apiKey: { required: true, check: 'nonEmpty' },
                    nodeIndexName: { required: true, check: 'nonEmpty' },
                    edgeIndexName: { check: 'nonEmpty' }
                });
                break;
        }
        Utils.check.properties(key, index, properties);
    }
}
module.exports = ConfigChecker;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29uZmlnQ2hlY2tlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9zZXJ2aWNlcy9jb25maWd1cmF0aW9uL0NvbmZpZ0NoZWNrZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTVCLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUUvQixTQUFTO0FBQ1QsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsa0NBQWtDLENBQUMsQ0FBQztBQUV6RTs7R0FFRztBQUNILE1BQU0sc0JBQXNCLEdBQUc7SUFDN0IsS0FBSyxFQUFFO1FBQ0wsVUFBVSxFQUFFO1lBQ1YsV0FBVyxFQUFFO2dCQUNYLG9DQUFvQztnQkFDcEMsV0FBVyxFQUFFO29CQUNYLDRCQUE0QjtvQkFDNUIsV0FBVyxFQUFFO3dCQUNYLCtCQUErQjt3QkFDL0IsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFOzRCQUNwQixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtnQ0FDN0IsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7NkJBQ3pDO2lDQUFNO2dDQUNMLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtvQ0FDdEMsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQ0FDL0IsQ0FBQyxDQUFDOzZCQUNKO3dCQUNILENBQUM7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUNELFVBQVUsRUFBRTtnQkFDViw0QkFBNEI7Z0JBQzVCLFdBQVcsRUFBRTtvQkFDWCxzQkFBc0I7b0JBQ3RCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUJBQy9CO2FBQ0Y7WUFDRCxLQUFLLEVBQUU7Z0JBQ0wseURBQXlEO2dCQUN6RCxXQUFXLEVBQUU7b0JBQ1gsNENBQTRDO29CQUM1QyxXQUFXLEVBQUU7d0JBQ1gsVUFBVSxFQUFFOzRCQUNWLElBQUksRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7NEJBQ3pCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7NEJBQzFCLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBQzs0QkFDN0IsT0FBTyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQzt5QkFDN0I7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUNELE1BQU0sRUFBRTtnQkFDTiw2Q0FBNkM7Z0JBQzdDLFdBQVcsRUFBRTtvQkFDWCx1SEFBdUg7b0JBQ3ZILFdBQVcsRUFBRTt3QkFDWCxVQUFVLEVBQUU7NEJBQ1YsbUJBQW1COzRCQUNuQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7NEJBQ3JDLDZCQUE2Qjs0QkFDN0IsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQzs0QkFDdkIsOEJBQThCOzRCQUM5QixJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO3lCQUN2QjtxQkFDRjtpQkFDRjthQUNGO1NBQ0Y7S0FDRjtJQUNELEtBQUssRUFBRTtRQUNMLFVBQVUsRUFBRTtZQUNWLFdBQVcsRUFBRTtnQkFDWCxvQ0FBb0M7Z0JBQ3BDLFdBQVcsRUFBRTtvQkFDWCw0QkFBNEI7b0JBQzVCLFdBQVcsRUFBRTt3QkFDWCwrQkFBK0I7d0JBQy9CLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTs0QkFDcEIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0NBQzdCLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDOzZCQUN6QztpQ0FBTTtnQ0FDTCxPQUFPLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7b0NBQ3RDLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUNBQy9CLENBQUMsQ0FBQzs2QkFDSjt3QkFDSCxDQUFDO3dCQUNELGdDQUFnQztxQkFDakM7aUJBQ0Y7YUFDRjtZQUNELFVBQVUsRUFBRTtnQkFDViw0QkFBNEI7Z0JBQzVCLFdBQVcsRUFBRTtvQkFDWCxzQkFBc0I7b0JBQ3RCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7aUJBQy9CO2FBQ0Y7U0FDRjtLQUNGO0NBQ0YsQ0FBQztBQUVGLE1BQU0saUJBQWlCLEdBQUc7SUFDeEIsb0JBQW9CO0lBQ3BCLFdBQVcsRUFBRTtRQUNYLFFBQVEsRUFBRSxJQUFJO1FBQ2QsU0FBUyxFQUFFO1lBQ1QsUUFBUSxFQUFFLElBQUk7WUFDZCxVQUFVLEVBQUU7Z0JBQ1YsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDMUIsSUFBSSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztnQkFDdEIsZUFBZSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBQztnQkFDckUsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDM0IsT0FBTyxFQUFFO29CQUNQLFFBQVEsRUFBRSxJQUFJO29CQUNkLElBQUksRUFBRSxRQUFRO29CQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztpQkFDNUQ7Z0JBQ0QsS0FBSyxFQUFFO29CQUNMLFFBQVEsRUFBRSxJQUFJO29CQUNkLElBQUksRUFBRSxRQUFRO29CQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztpQkFDNUQ7YUFDRjtTQUNGO0tBQ0Y7SUFFRCwyQkFBMkI7SUFDM0IsUUFBUSxFQUFFO1FBQ1IsUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixrQkFBa0IsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQzNELGVBQWUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3hELGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3RELHFCQUFxQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDOUQsb0JBQW9CLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUM3RCxlQUFlLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN4RCxpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDO1lBQ3RDLFlBQVksRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUNyQyxtQkFBbUIsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUM1QyxhQUFhLEVBQUUsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFDO1lBQ2hDLGdCQUFnQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUMzQywyQkFBMkIsRUFBRSxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7WUFDNUMsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM5QixzQkFBc0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7U0FDMUM7S0FDRjtJQUVELDJCQUEyQjtJQUMzQixFQUFFLEVBQUU7UUFDRixRQUFRLEVBQUUsSUFBSTtRQUNkLFVBQVUsRUFBRTtZQUNWLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN6QyxRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQzdCLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDN0IsaUJBQWlCLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDekMsT0FBTyxFQUFFO2dCQUNQLElBQUksRUFBRSxRQUFRO2dCQUNkLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoRTtTQUNGO0tBQ0Y7SUFFRCxvQ0FBb0M7SUFDcEMsTUFBTSxFQUFFO1FBQ04sUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUM7WUFFM0MsWUFBWSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ2pELFlBQVksRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDakMsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFDO1lBRXhDLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDM0IsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLEVBQUM7WUFDcEQsY0FBYyxFQUFFLEVBQUMsS0FBSyxFQUFFLFNBQVMsRUFBQztZQUNsQyxlQUFlLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDO1lBQ25DLFlBQVksRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFFakMsUUFBUTtZQUNSLGVBQWUsRUFBRSxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7WUFDaEMsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMzQixVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQzdCLGdCQUFnQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUNuQyxlQUFlLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3BDLGtCQUFrQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN2QyxxQkFBcUIsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUMsQ0FBQyxpQ0FBaUM7U0FDN0U7S0FDRjtJQUVELGtCQUFrQixFQUFFO1FBQ2xCLFFBQVEsRUFBRSxJQUFJO1FBQ2QsSUFBSSxFQUFFLFFBQVE7UUFDZCxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztLQUNsRTtJQUNELGdCQUFnQixFQUFFO1FBQ2hCLFFBQVEsRUFBRSxJQUFJO1FBQ2QsSUFBSSxFQUFFLFFBQVE7UUFDZCxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUM7S0FDeEU7SUFFRCw2Q0FBNkM7SUFDN0MsaUVBQWlFO0lBQ2pFLGVBQWUsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLG9CQUFvQixDQUFDLGFBQWEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUM7SUFFeEYsTUFBTSxFQUFFO1FBQ04sVUFBVSxFQUFFO1lBQ1YsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUMxQixXQUFXLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFDcEMsZUFBZSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1lBQ3hDLGVBQWUsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN4QyxjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7U0FDeEM7S0FDRjtJQUVELDRCQUE0QjtJQUM1QixVQUFVLEVBQUU7UUFDVixRQUFRLEVBQUUsSUFBSTtRQUNkLFVBQVUsRUFBRTtZQUNWLE9BQU8sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDMUIsU0FBUyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUM5QixhQUFhLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxFQUFDO1lBQy9DLFVBQVUsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDN0IsU0FBUyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM1QixJQUFJLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxFQUFDO1NBQ2pDO0tBQ0Y7SUFFRCwrQkFBK0I7SUFDL0IsTUFBTSxFQUFFO1FBQ04sUUFBUSxFQUFFLElBQUk7UUFDZCxVQUFVLEVBQUU7WUFDVixnQkFBZ0IsRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBQztZQUN6QyxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQy9CLFNBQVMsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7WUFDNUIsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztZQUM3QixpQkFBaUIsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7WUFDbkMsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztZQUM5QixNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1lBQ3pCLFlBQVksRUFBRSxFQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBQztZQUN0QywwQkFBMEIsRUFBRSxFQUFDLFNBQVMsRUFBRSxFQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsRUFBQyxFQUFDO1lBQ3JFLDBCQUEwQixFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO29CQUNqRCxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7b0JBQ2xELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNsQzt5QkFBTTt3QkFDTCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ2pDO2dCQUNILENBQUMsRUFBQztZQUVGLHlCQUF5QixFQUFFO2dCQUN6QixXQUFXLEVBQUU7b0JBQ1gsS0FBSyxFQUFFLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO3dCQUNwQixLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7d0JBQ2xELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTs0QkFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUNsQzs2QkFBTTs0QkFDTCxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7eUJBQ2pDO29CQUNILENBQUM7aUJBQ0Y7YUFDRjtZQUVELHFEQUFxRDtZQUNyRCxvQkFBb0IsRUFBRTtnQkFDcEIsVUFBVSxFQUFFLG1EQUFtRDthQUNoRTtZQUVELDZCQUE2QjtZQUM3QixpQkFBaUIsRUFBRTtnQkFDakIsVUFBVSxFQUFFO29CQUNWLE9BQU8sRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQzFCLEdBQUcsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3hCLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzNCLE1BQU0sRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzNCLGFBQWEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ2xDLEdBQUcsRUFBRTt3QkFDSCxRQUFRLEVBQUUsS0FBSzt3QkFDZixNQUFNLEVBQUUsV0FBVzt3QkFDbkIsaURBQWlEO3dCQUNqRCx1RUFBdUU7d0JBQ3ZFLFVBQVUsRUFBRTs0QkFDViwwREFBMEQ7NEJBQzFELGtCQUFrQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQzt5QkFDdEM7cUJBQ0Y7aUJBQ0Y7YUFDRjtZQUVELHlCQUF5QjtZQUN6QixJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFO29CQUNWLE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDMUMsR0FBRyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUN4QyxNQUFNLEVBQUUsRUFBQyxVQUFVLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQ3BELFlBQVksRUFBRSxFQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDcEQsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUk7d0JBQ3JCLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFBRTs0QkFDcEIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0NBQzdCLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzs2QkFDbEM7aUNBQU07Z0NBQ0wsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDOzZCQUN6RDt3QkFDSCxDQUFDO3FCQUNGO29CQUNELGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDbEQsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0IsVUFBVSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0Isc0VBQXNFO29CQUN0RSxnQkFBZ0IsRUFBRSxFQUFDLFVBQVUsRUFBRSxpREFBaUQsRUFBQztvQkFDakYsR0FBRyxFQUFFO3dCQUNILFFBQVEsRUFBRSxLQUFLO3dCQUNmLE1BQU0sRUFBRSxXQUFXO3dCQUNuQixpREFBaUQ7d0JBQ2pELHVFQUF1RTt3QkFDdkUsVUFBVSxFQUFFOzRCQUNWLDBEQUEwRDs0QkFDMUQsa0JBQWtCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO3lCQUN0QztxQkFDRjtpQkFDRjthQUNGO1lBRUQsc0JBQXNCO1lBQ3RCLEtBQUssRUFBRTtnQkFDTCxVQUFVLEVBQUU7b0JBQ1YsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUMxQyxHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3hDLDJCQUEyQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUNoRSxjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUNuQyxjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO2lCQUNwQzthQUNGO1lBRUQsdUJBQXVCO1lBQ3ZCLE1BQU0sRUFBRTtnQkFDTixVQUFVLEVBQUU7b0JBQ1YsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUMxQyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzdDLGdCQUFnQixFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDO29CQUNoRCxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7b0JBQ3hDLFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDN0MsWUFBWSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUNqRCxhQUFhLEVBQUU7d0JBQ2IsVUFBVSxFQUFFOzRCQUNWLFdBQVcsRUFBRSxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQzs0QkFDckQsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDOzRCQUNwRCxVQUFVLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO3lCQUNoQztxQkFDRjtvQkFDRCxLQUFLLEVBQUU7d0JBQ0wsVUFBVSxFQUFFOzRCQUNWLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7eUJBQzlCO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRjtLQUNGO0lBRUQsb0NBQW9DO0lBQ3BDLE9BQU8sRUFBRTtRQUNQLFFBQVEsRUFBRSxJQUFJO1FBQ2QsU0FBUyxFQUFFO1lBQ1QsUUFBUSxFQUFFLElBQUk7WUFDZCxVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO2dCQUN6QyxXQUFXLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUM7Z0JBQy9DLFdBQVcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDaEQsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7Z0JBQ2hELE9BQU8sRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBQztnQkFDcEQsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFDO2dCQUM1QyxVQUFVLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO2dCQUMvQixFQUFFLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO2dCQUN2QixXQUFXLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO2dCQUNoQyxPQUFPLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDLENBQUMsbUNBQW1DO2FBQy9EO1NBQ0Y7S0FDRjtJQUVELHFCQUFxQjtJQUNyQixJQUFJLEVBQUU7UUFDSixRQUFRLEVBQUUsSUFBSTtRQUNkLFVBQVUsRUFBRTtZQUNWLFFBQVEsRUFBRSxFQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBQztZQUN2QyxZQUFZLEVBQUU7Z0JBQ1osVUFBVSxFQUFFO29CQUNWLFlBQVksRUFBRSxFQUFDLE1BQU0sRUFBRSxDQUFDLGdCQUFnQixFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBQztvQkFDNUQsZ0JBQWdCLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUM7aUJBQzFDO2FBQ0Y7WUFDRCxjQUFjLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUMsRUFBQztZQUMxRCxPQUFPLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO1NBQzFCO0tBQ0Y7SUFFRCwrREFBK0Q7SUFDL0QsYUFBYSxFQUFFO1FBQ2IsUUFBUSxFQUFFLEtBQUs7UUFDZixVQUFVLEVBQUU7WUFDVixLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO1lBQ3ZCLEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7U0FDeEI7S0FDRjtJQUVELGtCQUFrQjtJQUNsQixPQUFPLEVBQUU7UUFDUCxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDcEIsd0RBQXdEO1lBQ3hELEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUM3RCxDQUFDO0tBQ0Y7SUFFRCxpQkFBaUI7SUFDakIsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztJQUUzQixpQkFBaUI7SUFDakIsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztJQUV6QiwwQ0FBMEM7SUFDMUMsVUFBVSxFQUFFO1FBQ1YsSUFBSSxFQUFFLFFBQVE7UUFDZCxLQUFLLEVBQUUsS0FBSyxDQUFDLGtCQUFrQjtLQUNoQztJQUVELGdCQUFnQjtJQUNoQixXQUFXLEVBQUUsRUFBRTtDQUNoQixDQUFDO0FBRUYsTUFBTSxhQUFhO0lBRWpCOzs7T0FHRztJQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTTtRQUNqQixLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVEOzs7T0FHRztJQUNILE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFNBQVM7UUFDbEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVUsRUFBRSxTQUFTLENBQUMsT0FBTyxFQUNwRCxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFM0MsSUFBSSxTQUFTLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTtZQUNsQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO2dCQUNyQyxPQUFPLEVBQUUsRUFBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUM7Z0JBQ3RDLE9BQU8sRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7YUFDN0IsQ0FBQyxDQUFDO1NBQ0o7YUFBTTtZQUNMLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7Z0JBQ3JDLE9BQU8sRUFBRSxFQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBQztnQkFDdEMsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDekIsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQzthQUN0QixDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsa0JBQWtCO1FBQzFELElBQUksVUFBVSxHQUFHO1lBQ2YsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUU7b0JBQzdDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUI7b0JBQzNFLDZDQUE2QztvQkFDN0MsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO3dCQUNwQixNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxHQUFHLDJCQUEyQixDQUFDLENBQUM7cUJBQ2hGO2dCQUNILENBQUMsRUFBQztTQUNILENBQUM7UUFFRixJQUFJLGtCQUFrQixFQUFFO1lBQ3RCLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtnQkFDL0IsaUJBQWlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7Z0JBQ3BELFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQztnQkFDM0MsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFDO2dCQUNqRSxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUM7Z0JBQzNDLFFBQVEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBQzthQUM1QyxDQUFDLENBQUM7U0FDSjthQUFNO1lBQ0wsbUJBQW1CO1lBQ25CLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtnQkFDL0IsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFDO2FBQzdDLENBQUMsQ0FBQztTQUNKO1FBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsZUFBZSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsT0FBTztRQUM1QixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsU0FBUyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDbEQsT0FBTyxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUFFLHNCQUFzQixFQUFFLFNBQVMsRUFBRSxVQUFVO1NBQzVGLENBQUMsQ0FBQztRQUVILElBQUksVUFBVSxHQUFHO1lBQ2YsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUM7WUFDbEQsZ0JBQWdCLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3JDLGlCQUFpQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUV0QywwQ0FBMEM7WUFDMUMsZUFBZSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztTQUNuQyxDQUFDO1FBRUYsTUFBTSx3QkFBd0IsR0FBRztZQUMvQixpQkFBaUIsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7WUFDdEMsaUJBQWlCLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLHNCQUFzQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUMzQyxzQkFBc0IsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7U0FDNUMsQ0FBQztRQUVGLE1BQU0sMEJBQTBCLEdBQUc7WUFDakMsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztZQUN6QixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1NBQzlCLENBQUM7UUFFRixNQUFNLGdCQUFnQixHQUFHO1lBQ3ZCLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUM7WUFDekIsaUJBQWlCLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO1lBQ3RDLGNBQWMsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7U0FDcEMsQ0FBQztRQUVGLG1HQUFtRztRQUNuRyxNQUFNLHdCQUF3QixHQUFHO1lBQy9CLFFBQVEsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFDM0IsV0FBVyxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFDO1NBQ3JDLENBQUM7UUFFRixNQUFNLGdDQUFnQyxHQUFHO1lBQ3ZDLHNCQUFzQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztTQUMxQyxDQUFDO1FBRUYsUUFBUSxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ3RCLEtBQUssT0FBTztnQkFDVixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFDbkMsS0FBSyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDMUIsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFNBQVMsRUFBQztpQkFDN0IsQ0FBQyxDQUFDO2dCQUNILFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUM3RCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztnQkFDM0QsTUFBTTtZQUVSLEtBQUssWUFBWTtnQkFDZixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFFbkMsOENBQThDO29CQUM5QyxVQUFVLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMvQixvQkFBb0IsRUFBRSxFQUFDLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3pDLGlCQUFpQixFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDdEMsYUFBYSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztpQkFDaEMsQ0FBQyxDQUFDO2dCQUNILFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUM3RCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztnQkFDM0QsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLGdDQUFnQyxDQUFDLENBQUM7Z0JBQ25FLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO2dCQUMzRCxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUNoQyxDQUFDLFlBQVksRUFBRSxtQkFBbUIsRUFBRSxlQUFlLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDOUQsTUFBTTtZQUVSLEtBQUssc0JBQXNCO2dCQUN6QixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFDbkMsU0FBUyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUM5QyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO2lCQUMxQixDQUFDLENBQUM7Z0JBQ0gsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLDBCQUEwQixDQUFDLENBQUM7Z0JBQzdELFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO2dCQUMzRCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQztnQkFDbkUsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLHdCQUF3QixDQUFDLENBQUM7Z0JBQzNELE1BQU07WUFFUixLQUFLLEtBQUs7Z0JBQ1IsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7b0JBQ25DLFNBQVMsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDOUMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztpQkFDMUIsQ0FBQyxDQUFDO2dCQUNILFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUM3RCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztnQkFDM0QsTUFBTTtZQUVSLEtBQUssY0FBYztnQkFDakIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixHQUFHLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUM7b0JBQ3ZDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0MsT0FBTyxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDNUIsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztpQkFDMUIsQ0FBQyxDQUFDO2dCQUNILFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUM3RCxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDbkQsTUFBTTtZQUVSLEtBQUssU0FBUztnQkFDWixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBQztvQkFDdkMsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUMvQyxTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO2lCQUM3QixDQUFDLENBQUM7Z0JBQ0gsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLDBCQUEwQixDQUFDLENBQUM7Z0JBQzdELFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNuRCxNQUFNO1lBRVIsS0FBSyxVQUFVO2dCQUNiLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDL0IsR0FBRyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDO29CQUNuQyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzdDLFVBQVUsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDL0MsVUFBVSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFDO2lCQUNoRCxDQUFDLENBQUM7Z0JBQ0gsTUFBTTtTQUNUO1FBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsS0FBSztRQUMxQixLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsU0FBUyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDaEQsZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7WUFDM0MsYUFBYSxFQUFFLG9CQUFvQixFQUFFLFdBQVcsRUFBRSxrQkFBa0IsRUFBRSxlQUFlO1lBQ3JGLGVBQWUsRUFBRSxhQUFhO1NBQy9CLENBQUMsQ0FBQztRQUNILElBQUksVUFBVSxHQUFHO1lBQ2YsTUFBTSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUM7U0FDakQsQ0FBQztRQUVGLE1BQU0sZ0NBQWdDLEdBQUc7WUFDdkMsc0JBQXNCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO1NBQzFDLENBQUM7UUFFRixRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDcEIsS0FBSyxlQUFlO2dCQUNsQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekMsSUFBSSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFDO29CQUNyQyxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUMvQixrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ3JDLGNBQWMsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ2pDLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQ2hDLDBCQUEwQjtvQkFDMUIsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDeEIsU0FBUyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDM0IsT0FBTyxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztvQkFDMUIsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQkFDOUIsQ0FBQyxDQUFDO2dCQUNILE1BQU07WUFFUixLQUFLLGdCQUFnQjtnQkFDbkIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixJQUFJLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQ3pDLElBQUksRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQztvQkFDckMsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDL0IsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDeEIsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDekIsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDN0IsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFDakMsa0JBQWtCLEVBQUUsRUFBQyxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDLEVBQUM7b0JBQ3BELFFBQVEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQzFCLHVGQUF1RjtvQkFDdkYsa0JBQWtCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUNyQyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUN4QixnQkFBZ0IsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7aUJBQ3BDLENBQUMsQ0FBQztnQkFDSCxNQUFNO1lBRVIsS0FBSyxRQUFRO2dCQUNYLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDL0IsZ0JBQWdCLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO2lCQUNwQyxDQUFDLENBQUM7Z0JBQ0gsTUFBTTtZQUVSLEtBQUssYUFBYTtnQkFDaEIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixjQUFjLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDO29CQUNsQyxpQkFBaUIsRUFBRSxFQUFDLFNBQVMsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUMsRUFBQztvQkFDaEQsZ0JBQWdCLEVBQUUsRUFBQyxTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDLEVBQUM7b0JBQy9DLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQy9CLGFBQWEsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQy9CLFVBQVUsRUFBRSxFQUFDLElBQUksRUFBRSxTQUFTLEVBQUM7b0JBQzdCLGdCQUFnQixFQUFFLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBQztvQkFFbkMsMEJBQTBCO29CQUMxQixTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFDO29CQUM1QixlQUFlLEVBQUUsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFDO29CQUNsQyxrQkFBa0IsRUFBRSxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUM7b0JBQ3JDLGtCQUFrQixFQUFFLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBQztpQkFFdEMsQ0FBQyxDQUFDO2dCQUNILE1BQU07WUFFUixLQUFLLGtCQUFrQjtnQkFDckIsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO29CQUMvQixNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUN6QixVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUM3QixhQUFhLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUMvQixhQUFhLEVBQUUsRUFBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO2lCQUNoQyxDQUFDLENBQUM7Z0JBQ0gsTUFBTTtZQUVSLEtBQUssZUFBZTtnQkFDbEIsTUFBTTtZQUVSLEtBQUssb0JBQW9CLENBQUM7WUFDMUIsS0FBSyxXQUFXO2dCQUNkLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxnQ0FBZ0MsQ0FBQyxDQUFDO2dCQUNuRSxNQUFNO1lBRVIsS0FBSyxlQUFlO2dCQUNsQixVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7b0JBQy9CLEdBQUcsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztvQkFDbkMsY0FBYyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUNoRCxJQUFJLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUN6QixRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsVUFBVSxFQUFDO29CQUM3QixlQUFlLEVBQUUsRUFBQyxJQUFJLEVBQUUsU0FBUyxFQUFDO29CQUNsQyxVQUFVLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFBQztvQkFDdkQsYUFBYSxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFDO29CQUMvQyxrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7b0JBQ3BDLGtCQUFrQixFQUFFLEVBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztpQkFDckMsQ0FBQyxDQUFDO2dCQUNILE1BQU07WUFFUixLQUFLLGFBQWE7Z0JBQ2hCLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtvQkFDL0IsR0FBRyxFQUFFLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFDO29CQUNuQyxNQUFNLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUM7b0JBQzNDLGFBQWEsRUFBRSxFQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBQztvQkFDbEQsYUFBYSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztpQkFDbkMsQ0FBQyxDQUFDO2dCQUNILE1BQU07U0FDVDtRQUVELEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDakQsQ0FBQztDQUNGO0FBRUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMifQ==