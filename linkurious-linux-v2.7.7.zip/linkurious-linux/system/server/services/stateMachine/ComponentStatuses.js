/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-26.
 */
'use strict';
// Codes and/or names should identify any status unically
// Codes are inspired from http codes:
// - 1** : Processing / information
// - 2** : Ok
// - 4** : backend external error
// - 5** : backend related error
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const STATUSES = {
    Linkurious: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting Linkurious in ' + Config.mode + ' mode...'
        },
        {
            code: 200,
            name: 'initialized',
            message: 'Linkurious ready to go :)'
        },
        {
            code: 400,
            name: 'error',
            message: 'Some components of Linkurious are not working properly.'
        },
        {
            code: 500,
            name: 'unknown_error',
            message: 'Linkurious encountered an unexpected error.'
        }
    ],
    SqlDB: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting SQL database'
        },
        {
            code: 101,
            name: 'up',
            message: 'The SQL database is up.'
        },
        {
            code: 200,
            name: 'synced',
            message: 'The SQL database is synced.'
        },
        {
            code: 401,
            name: 'down',
            message: 'Could not connect to the SQL database.'
        },
        {
            code: 402,
            name: 'sync_error',
            message: 'We could not write to the SQL database, please check its status and configuration'
        }
    ],
    DataService: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting data service.'
        },
        {
            code: 200,
            name: 'up',
            message: 'Data-sources ready.'
        },
        {
            code: 201,
            name: 'indexing',
            message: 'A data-source is currently indexing.'
        },
        {
            code: 401,
            name: 'down',
            message: 'Could not connect to any data-source.'
        }
    ],
    WebServer: [
        {
            code: 100,
            name: 'starting',
            message: 'Starting Web Server'
        },
        {
            code: 200,
            name: 'ready',
            message: 'The Web Server ready.'
        },
        {
            code: 400,
            name: 'error',
            message: 'The Web Server could not start.'
        },
        {
            code: 401,
            name: 'port_busy',
            message: 'The Web Server could not start: the port is busy.'
        },
        {
            code: 403,
            name: 'port_restricted',
            message: 'The Web Server could not start: root access is required to listen to ports under 1024'
        }
    ]
};
module.exports = STATUSES;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcG9uZW50U3RhdHVzZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvc3RhdGVNYWNoaW5lL0NvbXBvbmVudFN0YXR1c2VzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIseURBQXlEO0FBQ3pELHNDQUFzQztBQUN0QyxtQ0FBbUM7QUFDbkMsYUFBYTtBQUNiLGlDQUFpQztBQUNqQyxnQ0FBZ0M7QUFFaEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsTUFBTSxRQUFRLEdBQUc7SUFFZixVQUFVLEVBQUU7UUFDVjtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyxJQUFJLEdBQUcsVUFBVTtTQUM5RDtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsYUFBYTtZQUNuQixPQUFPLEVBQUUsMkJBQTJCO1NBQ3JDO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxPQUFPO1lBQ2IsT0FBTyxFQUFFLHlEQUF5RDtTQUNuRTtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsZUFBZTtZQUNyQixPQUFPLEVBQUUsNkNBQTZDO1NBQ3ZEO0tBQ0Y7SUFFRCxLQUFLLEVBQUU7UUFDTDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLHVCQUF1QjtTQUNqQztRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBRSx5QkFBeUI7U0FDbkM7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFFBQVE7WUFDZCxPQUFPLEVBQUUsNkJBQTZCO1NBQ3ZDO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxNQUFNO1lBQ1osT0FBTyxFQUFFLHdDQUF3QztTQUNsRDtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsWUFBWTtZQUNsQixPQUFPLEVBQUUsbUZBQW1GO1NBQzdGO0tBQ0Y7SUFFRCxXQUFXLEVBQUU7UUFDWDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLHdCQUF3QjtTQUNsQztRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsSUFBSTtZQUNWLE9BQU8sRUFBRSxxQkFBcUI7U0FDL0I7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFLHNDQUFzQztTQUNoRDtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsTUFBTTtZQUNaLE9BQU8sRUFBRSx1Q0FBdUM7U0FDakQ7S0FDRjtJQUVELFNBQVMsRUFBRTtRQUNUO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsVUFBVTtZQUNoQixPQUFPLEVBQUUscUJBQXFCO1NBQy9CO1FBQ0Q7WUFDRSxJQUFJLEVBQUUsR0FBRztZQUNULElBQUksRUFBRSxPQUFPO1lBQ2IsT0FBTyxFQUFFLHVCQUF1QjtTQUNqQztRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsT0FBTztZQUNiLE9BQU8sRUFBRSxpQ0FBaUM7U0FDM0M7UUFDRDtZQUNFLElBQUksRUFBRSxHQUFHO1lBQ1QsSUFBSSxFQUFFLFdBQVc7WUFDakIsT0FBTyxFQUFFLG1EQUFtRDtTQUM3RDtRQUNEO1lBQ0UsSUFBSSxFQUFFLEdBQUc7WUFDVCxJQUFJLEVBQUUsaUJBQWlCO1lBQ3ZCLE9BQU8sRUFDTCx1RkFBdUY7U0FDMUY7S0FDRjtDQUNGLENBQUM7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyJ9