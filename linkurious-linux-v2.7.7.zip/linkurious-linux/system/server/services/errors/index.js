"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-02.
 */
// external libs
const Bluebird = require("bluebird");
// locals
const LkError_1 = require("../../models/errors/LkError");
class ErrorService {
    /**
     * To access the LkError constructor directly.
     */
    get LkError() {
        return LkError_1.LkError;
    }
    /**
     * @param error
     * @param [promise] Whether to return a rejected promise or just the error
     */
    wrap(error, promise) {
        // return a rejected promise
        if (promise === true) {
            return Bluebird.reject(error);
        }
        // or just the error
        return error;
    }
    access(key, message, promise) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.ACCESS, key, message), promise);
    }
    business(key, message, promise, data) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.BUSINESS, key, message, data), promise);
    }
    technical(key, message, promise) {
        return this.wrap(new LkError_1.LkError(LkError_1.LkError.Type.TECHNICAL, key, message), promise);
    }
}
module.exports = new ErrorService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvZXJyb3JzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFFckMsU0FBUztBQUNULHlEQUFvRDtBQUVwRCxNQUFNLFlBQVk7SUFDaEI7O09BRUc7SUFDSCxJQUFJLE9BQU87UUFDVCxPQUFPLGlCQUFPLENBQUM7SUFDakIsQ0FBQztJQUVEOzs7T0FHRztJQUNLLElBQUksQ0FBQyxLQUFjLEVBQUUsT0FBaUI7UUFDNUMsNEJBQTRCO1FBQzVCLElBQUksT0FBTyxLQUFLLElBQUksRUFBRTtZQUNwQixPQUFPLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDL0I7UUFFRCxvQkFBb0I7UUFDcEIsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBV00sTUFBTSxDQUFDLEdBQVcsRUFBRSxPQUFnQixFQUFFLE9BQWlCO1FBQzVELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLGlCQUFPLENBQUMsaUJBQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBc0JNLFFBQVEsQ0FDYixHQUFXLEVBQ1gsT0FBZ0IsRUFDaEIsT0FBaUIsRUFDakIsSUFBNkI7UUFFN0IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksaUJBQU8sQ0FBQyxpQkFBTyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNwRixDQUFDO0lBV00sU0FBUyxDQUFDLEdBQVcsRUFBRSxPQUFnQixFQUFFLE9BQWlCO1FBQy9ELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLGlCQUFPLENBQUMsaUJBQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMvRSxDQUFDO0NBQ0Y7QUFFRCxpQkFBUyxJQUFJLFlBQVksRUFBRSxDQUFDIn0=