"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-04.
 */
// internal libs
const fs = require("fs");
const path = require("path");
class ServiceManager {
    constructor() {
        this.MODE_DEV = 'development';
        this.MODE_TEST = 'test';
        this.MODE_PRE_PROD = 'preprod';
        this.MODE_PROD = 'production';
        this.services = {};
        this.currentlyCreating = [];
        this.initDone = false;
        this.mode = this.DEFAULT_MODE;
        this.resetConfig = false;
    }
    /**
     * Must be called before anything LKE related.
     *
     * @param options
     * @param [options.mode='production'] Runtime mode ('production','preprod','development','test')
     * @param [options.resetConfig]       Whether to request a configuration reset
     */
    init(options) {
        if (this.initDone) {
            this.logger.warn('LKE: ignoring additional init');
            return;
        }
        if (options.resetConfig === true) {
            this.resetConfig = true;
        }
        this.initDone = true;
        this.logger = this.getLogger(__filename);
        const Utils = this.getUtils();
        if (Utils.hasValue(options.mode)) {
            Utils.check.values('mode', options.mode, this.MODES);
            this.mode = options.mode;
        }
    }
    get options() {
        return {
            mode: this.mode,
            resetConfig: this.resetConfig
        };
    }
    get DEFAULT_MODE() {
        return this.MODE_PROD;
    }
    /**
     * While parsing CLA, modes are parsed in this order (so the latter overrides the former).
     */
    get MODES() {
        return [this.MODE_DEV, this.MODE_TEST, this.MODE_PROD, this.MODE_PRE_PROD];
    }
    /**
     * Return true if we are in 'development' mode.
     */
    isDevMode() {
        return this.options.mode === this.MODE_DEV;
    }
    /**
     * Return true if we are in 'test' mode.
     */
    isTestMode() {
        return this.options.mode === this.MODE_TEST;
    }
    /**
     * Return true if we are in 'preprod' mode.
     */
    isPreProdMode() {
        return this.options.mode === this.MODE_PRE_PROD;
    }
    /**
     * Return true if we are in 'production' mode.
     */
    isProdMode() {
        return this.options.mode === this.MODE_PROD;
    }
    /**
     * Resolve a file path relative to Linkurious system directory.
     * Return an absolute file path.
     *
     * @param filePath a file path relative to the linkurious system root
     */
    systemFile(filePath) {
        return path.resolve(__dirname, '..', '..', filePath);
    }
    /**
     * Resolve a file path relative to Linkurious data directory.
     * Return an absolute file path.
     *
     * @param filePath a file path relative to the linkurious data root
     */
    dataFile(filePath) {
        if (filePath && path.isAbsolute(filePath)) {
            return filePath;
        }
        return this.systemFile('../data/' + filePath);
    }
    getRelease() {
        if (!this.releaseCache) {
            const release = JSON.parse(fs.readFileSync(this.systemFile('release.json')).toString());
            delete release.bodyFile;
            this.releaseCache = release;
        }
        return this.releaseCache;
    }
    /**
     * Get the current SemVer.
     */
    getVersion() {
        return this.getRelease().tag_name.substr(1);
    }
    /**
     * Get the version string (e.g.: 'Enterprise v0.9.4 (Snappy Squid)').
     */
    getVersionString() {
        return 'Enterprise ' + this.getRelease().tag_name + ' (' + this.getRelease().name + ')';
    }
    getAccess() {
        return this.get('access');
    }
    getAccessRightDAO() {
        return this.get('access/AccessRightDAO');
    }
    getOldGroupDAO() {
        return this.get('access/OldGroupDAO');
    }
    getUserDAO() {
        return this.get('access/UserDAO');
    }
    getAlert() {
        return this.get('alert');
    }
    getAnalytics() {
        return this.get('analytics');
    }
    getApplication() {
        return this.get('application');
    }
    getAuditTrail() {
        return this.get('auditTrail');
    }
    getGraphQuery() {
        return this.get('graphQuery');
    }
    getGraphSchemaDAO() {
        return this.get('business/GraphSchemaDAO');
    }
    getVisualizationDAO() {
        return this.get('business/VisualizationDAO');
    }
    getVisualizationShareDAO() {
        return this.get('business/VisualizationShareDAO');
    }
    getWidget() {
        return this.get('widget');
    }
    getConfig() {
        return this.get('configuration');
    }
    getCustomFile() {
        return this.get('customFile');
    }
    getDataProxy() {
        return this.get('data/proxy');
    }
    getData() {
        return this.get('data');
    }
    getErrors() {
        return this.get('errors');
    }
    getFirstRun() {
        return this.get('firstRun');
    }
    getLayout() {
        return this.get('layout');
    }
    /**
     * @param targetFilePath Caller `__filename`
     * @param [subPackage]   An additional package to append to the chain generated by `targetFile`
     */
    getLogger(targetFilePath, subPackage) {
        return this.get('logger').createCustomLogger(targetFilePath, subPackage);
    }
    getScheduler() {
        return this.get('scheduler');
    }
    getSqlDb() {
        return this.get('sqlDb');
    }
    getStateMachine() {
        return this.get('stateMachine');
    }
    getUtils() {
        return this.get('utils');
    }
    getWebServer() {
        return this.get('webServer');
    }
    /**
     * Generate the url of Linkurious from the configuration file.
     *
     * @param [pathSuffix]
     */
    getBaseURL(pathSuffix = '') {
        const Config = this.getConfig();
        let url = '';
        const isHttps = Config.get('server.useHttps', false) ||
            Config.get('server.forcePublicHttps', false);
        // 1) scheme
        const scheme = isHttps ? 'https' : 'http';
        url += scheme + '://';
        // 2) domain
        url += Config.get('server.domain', '127.0.0.1');
        // 3) port
        const urlPort = '' +
            (isHttps
                ? Config.get('server.publicPortHttps', Config.get('server.listenPortHttps'))
                : Config.get('server.publicPortHttp', Config.get('server.listenPort')));
        if (scheme === 'http' ? urlPort !== '80' : urlPort !== '443') {
            // only add the port if it is not the default port for the scheme
            url += ':' + urlPort;
        }
        // 4) base path
        const baseFolder = Config.get('server.baseFolder');
        url += baseFolder !== null && baseFolder !== undefined ? `/${baseFolder}/` : '/';
        // 5) path suffix
        if (pathSuffix.startsWith('/')) {
            pathSuffix = pathSuffix.substring(1);
        }
        url += pathSuffix;
        return url;
    }
    /**
     * Create a new service instance for a given service key.
     *
     * @param key Key of the service
     */
    createService(key) {
        // track circular dependencies
        if (this.currentlyCreating.includes(key)) {
            this.currentlyCreating.push(key);
            throw new Error('Circular dependency detected while loading service (' +
                this.currentlyCreating.join(' -> ') +
                ').');
        }
        this.currentlyCreating.push(key);
        // find service folder/file and create service instance
        const servicePath = path.resolve(__dirname, key);
        if (fs.existsSync(servicePath + '.js') || fs.existsSync(servicePath + '/index.js')) {
            if (key !== 'logger') {
                this.logger.debug('Creating service instance: "' + key + '"');
            }
            const service = require('./' + key);
            this.currentlyCreating.pop();
            return service;
        }
        else {
            const m = 'Service does not exist: "' + key + '"';
            if (key !== 'logger') {
                this.logger.error(m);
                return;
            }
            else {
                throw m;
            }
        }
    }
    /**
     * Get a service singleton for a given service key.
     *
     * @param key Key of the service
     */
    get(key) {
        if (!this.initDone) {
            throw new Error('LKE.init must be called before any LKE.get calls (key: ' + key + ').');
        }
        // resolve the service
        let s = this.services[key];
        // if the service was not yet initialized, initialize the service
        if (s === undefined || s === null) {
            s = this.services[key] = this.createService(key);
        }
        return s;
    }
}
module.exports = new ServiceManager();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBRUgsZ0JBQWdCO0FBQ2hCLHlCQUF5QjtBQUN6Qiw2QkFBNkI7QUFFN0IsTUFBTSxjQUFjO0lBQXBCO1FBQ2tCLGFBQVEsR0FBRyxhQUFhLENBQUM7UUFDekIsY0FBUyxHQUFHLE1BQU0sQ0FBQztRQUNuQixrQkFBYSxHQUFHLFNBQVMsQ0FBQztRQUMxQixjQUFTLEdBQUcsWUFBWSxDQUFDO1FBRWpDLGFBQVEsR0FBMkIsRUFBRSxDQUFDO1FBQ3RDLHNCQUFpQixHQUFhLEVBQUUsQ0FBQztRQUVqQyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBRWpCLFNBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3pCLGdCQUFXLEdBQUcsS0FBSyxDQUFDO0lBb1Y5QixDQUFDO0lBaFZDOzs7Ozs7T0FNRztJQUNJLElBQUksQ0FBQyxPQUErQztRQUN6RCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDaEIsSUFBSSxDQUFDLE1BQXVCLENBQUMsSUFBSSxDQUFDLCtCQUErQixDQUFDLENBQUM7WUFDcEUsT0FBTztTQUNSO1FBRUQsSUFBSSxPQUFPLENBQUMsV0FBVyxLQUFLLElBQUksRUFBRTtZQUNoQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUN6QjtRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBRXJCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFFOUIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO1NBQzFCO0lBQ0gsQ0FBQztJQUVELElBQVcsT0FBTztRQUNoQixPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO1NBQzlCLENBQUM7SUFDSixDQUFDO0lBRUQsSUFBVyxZQUFZO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUN4QixDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFXLEtBQUs7UUFDZCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFRDs7T0FFRztJQUNJLFNBQVM7UUFDZCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDN0MsQ0FBQztJQUVEOztPQUVHO0lBQ0ksVUFBVTtRQUNmLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUM5QyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxhQUFhO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUNsRCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxVQUFVO1FBQ2YsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFVBQVUsQ0FBQyxRQUFnQjtRQUNoQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksUUFBUSxDQUFDLFFBQWdCO1FBQzlCLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDekMsT0FBTyxRQUFRLENBQUM7U0FDakI7UUFDRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFTSxVQUFVO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDdEIsTUFBTSxPQUFPLEdBS1QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1lBQzVFLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUV4QixJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQztTQUM3QjtRQUVELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUMzQixDQUFDO0lBRUQ7O09BRUc7SUFDSSxVQUFVO1FBQ2YsT0FBTyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxnQkFBZ0I7UUFDckIsT0FBTyxhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7SUFDMUYsQ0FBQztJQUVNLFNBQVM7UUFDZCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFrQixDQUFDO0lBQzdDLENBQUM7SUFFTSxpQkFBaUI7UUFDdEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFtQixDQUFDO0lBQzdELENBQUM7SUFFTSxjQUFjO1FBQ25CLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBZ0IsQ0FBQztJQUN2RCxDQUFDO0lBRU0sVUFBVTtRQUNmLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBWSxDQUFDO0lBQy9DLENBQUM7SUFFTSxRQUFRO1FBQ2IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBaUIsQ0FBQztJQUMzQyxDQUFDO0lBRU0sWUFBWTtRQUNqQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFxQixDQUFDO0lBQ25ELENBQUM7SUFFTSxjQUFjO1FBQ25CLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQXVCLENBQUM7SUFDdkQsQ0FBQztJQUVNLGFBQWE7UUFDbEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBc0IsQ0FBQztJQUNyRCxDQUFDO0lBRU0sYUFBYTtRQUNsQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFzQixDQUFDO0lBQ3JELENBQUM7SUFFTSxpQkFBaUI7UUFDdEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFtQixDQUFDO0lBQy9ELENBQUM7SUFFTSxtQkFBbUI7UUFDeEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFxQixDQUFDO0lBQ25FLENBQUM7SUFFTSx3QkFBd0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxDQUEwQixDQUFDO0lBQzdFLENBQUM7SUFFTSxTQUFTO1FBQ2QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBa0IsQ0FBQztJQUM3QyxDQUFDO0lBRU0sU0FBUztRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQXlCLENBQUM7SUFDM0QsQ0FBQztJQUVNLGFBQWE7UUFDbEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBc0IsQ0FBQztJQUNyRCxDQUFDO0lBRU0sWUFBWTtRQUNqQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFjLENBQUM7SUFDN0MsQ0FBQztJQUVNLE9BQU87UUFDWixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFnQixDQUFDO0lBQ3pDLENBQUM7SUFFTSxTQUFTO1FBQ2QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBaUIsQ0FBQztJQUM1QyxDQUFDO0lBRU0sV0FBVztRQUNoQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFvQixDQUFDO0lBQ2pELENBQUM7SUFFTSxTQUFTO1FBQ2QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBa0IsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksU0FBUyxDQUFDLGNBQXNCLEVBQUUsVUFBbUI7UUFDMUQsT0FBUSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBbUIsQ0FBQyxrQkFBa0IsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVNLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBcUIsQ0FBQztJQUNuRCxDQUFDO0lBRU0sUUFBUTtRQUNiLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQWlCLENBQUM7SUFDM0MsQ0FBQztJQUVNLGVBQWU7UUFDcEIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBd0IsQ0FBQztJQUN6RCxDQUFDO0lBRU0sUUFBUTtRQUNiLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQWlCLENBQUM7SUFDM0MsQ0FBQztJQUVNLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBcUIsQ0FBQztJQUNuRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFVBQVUsQ0FBQyxhQUFxQixFQUFFO1FBQ3ZDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNoQyxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFFYixNQUFNLE9BQU8sR0FDWCxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQztZQUNwQyxNQUFNLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRS9DLFlBQVk7UUFDWixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQzFDLEdBQUcsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBRXRCLFlBQVk7UUFDWixHQUFHLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFaEQsVUFBVTtRQUNWLE1BQU0sT0FBTyxHQUNYLEVBQUU7WUFDRixDQUFDLE9BQU87Z0JBQ04sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUM1RSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVFLElBQUksTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssRUFBRTtZQUM1RCxpRUFBaUU7WUFDakUsR0FBRyxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUM7U0FDdEI7UUFFRCxlQUFlO1FBQ2YsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ25ELEdBQUcsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLFVBQVUsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUVqRixpQkFBaUI7UUFDakIsSUFBSSxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzlCLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3RDO1FBQ0QsR0FBRyxJQUFJLFVBQVUsQ0FBQztRQUVsQixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssYUFBYSxDQUFDLEdBQVc7UUFDL0IsOEJBQThCO1FBQzlCLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN4QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pDLE1BQU0sSUFBSSxLQUFLLENBQ2Isc0RBQXNEO2dCQUNwRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDbkMsSUFBSSxDQUNQLENBQUM7U0FDSDtRQUNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFakMsdURBQXVEO1FBQ3ZELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2pELElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLEVBQUU7WUFDbEYsSUFBSSxHQUFHLEtBQUssUUFBUSxFQUFFO2dCQUNuQixJQUFJLENBQUMsTUFBdUIsQ0FBQyxLQUFLLENBQUMsOEJBQThCLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ2pGO1lBQ0QsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDN0IsT0FBTyxPQUFPLENBQUM7U0FDaEI7YUFBTTtZQUNMLE1BQU0sQ0FBQyxHQUFHLDJCQUEyQixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7WUFDbEQsSUFBSSxHQUFHLEtBQUssUUFBUSxFQUFFO2dCQUNuQixJQUFJLENBQUMsTUFBdUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZDLE9BQU87YUFDUjtpQkFBTTtnQkFDTCxNQUFNLENBQUMsQ0FBQzthQUNUO1NBQ0Y7SUFDSCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLEdBQUcsQ0FBQyxHQUFXO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2xCLE1BQU0sSUFBSSxLQUFLLENBQUMseURBQXlELEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQ3pGO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFM0IsaUVBQWlFO1FBQ2pFLElBQUksQ0FBQyxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2pDLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbEQ7UUFFRCxPQUFPLENBQUMsQ0FBQztJQUNYLENBQUM7Q0FDRjtBQUVELGlCQUFTLElBQUksY0FBYyxFQUFFLENBQUMifQ==