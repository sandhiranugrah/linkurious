/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-15.
 */
'use strict';
// internal libs
const fs = require('fs-extra');
const path = require('path');
const urlParser = require('url');
// external libs
const Promise = require('bluebird');
const serveStatic = require('serve-static');
const express = require('express');
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Log = LKE.getLogger(__filename);
// constants
// Tells any cache that it does not need to send a HEAD request to re-validate the response
// during 30 seconds. After that a HEAD request if sent to check the etag.
const WIDGET_MAX_AGE_SECONDS = 30;
const STATIC_MAX_AGE_SECONDS = 30;
function loadPlugins(app) {
    try {
        // create base router for plugins
        const basePluginsRouter = express.Router({ caseSensitive: false });
        const pluginsRoute = '/api/plugin';
        app.use(pluginsRoute, basePluginsRouter);
        // check root folder for plugin files
        const pluginRoot = LKE.dataFile('plugins');
        if (!fs.existsSync(pluginRoot)) {
            // plugin root does not exist
            return;
        }
        if (!fs.statSync(pluginRoot).isDirectory()) {
            // plugin root is not a directory
            return;
        }
        // read all JS files in plugin root
        fs.readdirSync(pluginRoot).filter(file => file.endsWith('.js')).forEach(filename => {
            const pluginName = filename.slice(0, -3);
            // load plugin
            try {
                Log.info(`Loading plugin "${pluginName}"...`);
                const pluginPath = path.join(pluginRoot, filename);
                const plugin = require(pluginPath);
                if (plugin && typeof plugin.load === 'function') {
                    const pluginRouter = express.Router({});
                    basePluginsRouter.use('/' + pluginName, pluginRouter);
                    plugin.load(LKE, pluginRouter);
                }
                Log.info(`Successfully loaded plugin "${pluginName}" in route "${pluginsRoute}/${pluginName}".`);
            }
            catch (error) {
                Log.error(`Could not load plugin "${pluginName}"`, error);
            }
        });
    }
    catch (error) {
        Log.error('Error while loading Linkurious plugins', error);
    }
}
/**
 * @param {Express.Router} router
 * @param {string} basePath (must start and end with a "/")
 */
module.exports = function routesLoader(router, basePath) {
    const api = require('./api');
    // 1) force HTTPS
    const forceHttps = Config.get('server.forceHttps');
    const httpsPort = Config.get('server.publicPortHttps', Config.get('server.listenPortHttps'));
    router.all('*', api.proxy((req, res) => {
        const isHttps = Utils.isRequestHTTPS(req);
        if (!isHttps && forceHttps) {
            if (req.method === 'GET') {
                // redirect to https version
                const targetUrl = `https://${req.hostname.split(':')[0]}:${httpsPort}${req.originalUrl}`;
                res.redirect(302, targetUrl);
                return null;
            }
            else {
                // fail
                return Errors.business('https_required', null, true);
            }
        }
        return Promise.resolve();
    }, true));
    // 2) client CUSTOM static files
    const customFilesPath = LKE.dataFile('server/customFiles');
    const defaultCustomFilesPath = path.resolve(__dirname, 'customFiles');
    const previousCustomCSS = LKE.systemFile('server.old/public/assets/css/override.css');
    if (!fs.existsSync(customFilesPath)) {
        // custom files dir does not exist in "data/" yet : create it from default files
        Log.debug('Creating "customFiles" from default files');
        fs.copySync(defaultCustomFilesPath, customFilesPath);
        if (fs.existsSync(previousCustomCSS)) {
            Log.debug('Copying override.css from "server.old" to "data"');
            // a previous custom CSS file exists: move it to the custom files dir
            fs.copySync(previousCustomCSS, path.resolve(customFilesPath, 'assets', 'css', 'override.css'));
        }
    }
    // 2.1) create icons folder under customFiles
    const iconsFolderPath = path.resolve(customFilesPath, 'icons');
    fs.ensureDirSync(iconsFolderPath);
    // see https://github.com/expressjs/serve-static#servestaticroot-options
    const serveStaticOptions = {
        fallthrough: true,
        extensions: false,
        dotfiles: 'ignore',
        etag: true,
        cacheControl: false,
        setHeaders: res => {
            res.setHeader('Cache-Control', 'public, must-revalidate, max-age=' + STATIC_MAX_AGE_SECONDS);
        }
    };
    router.use(serveStatic(customFilesPath, serveStaticOptions));
    const clientRoot = LKE.systemFile(Config.get('server.clientFolder'));
    // 3.1) index.html
    const indexPath = path.resolve(clientRoot, 'index.html');
    let indexHtml = null;
    const serveIndex = (req, res) => {
        if (indexHtml === null || !LKE.isProdMode()) {
            // first pass OR not in prod: load index.html from disk
            if (!fs.existsSync(indexPath)) {
                // index not found: respond with 404
                return res.status(404).send();
            }
            // read index.html from disk
            indexHtml = fs.readFileSync(indexPath, { encoding: 'utf8' });
        }
        // patch "<base>" element (needed for the Angular router)
        const indexBody = indexHtml.replace('<base href="/">', `<base href="${basePath}">`);
        res
            .status(200)
            .header('Cache-control', catchAllSendOptions.headers['Cache-control'])
            .send(indexBody);
    };
    router.get('/', serveIndex);
    // 3.2) client BUILTIN static files
    router.use(serveStatic(clientRoot, serveStaticOptions));
    // 4.1) Builtin API routes
    function requireRoutesFiles(directory) {
        fs.readdirSync(directory).filter(file => {
            return (file.indexOf('.') !== 0); // skip files starting with a '.'
        }).forEach(file => {
            const filePath = path.join(directory, file);
            if (fs.statSync(filePath).isDirectory()) {
                requireRoutesFiles(filePath);
            }
            else {
                require(filePath)(router);
            }
        });
    }
    requireRoutesFiles(path.resolve(__dirname, '..', '..', 'routes'));
    // 4.2) Plugin API routes
    loadPlugins(router);
    // 5) fail correctly on bad API calls
    router.all('/api/*', api.respond(() => {
        throw Errors.business('api_not_found');
    }));
    // 6) Widget
    // see https://expressjs.com/en/api.html#res.sendFile
    const widgetSendOptions = {
        maxAge: WIDGET_MAX_AGE_SECONDS * 1000,
        root: clientRoot
    };
    const WidgetRoute = require('./WidgetRoute');
    new WidgetRoute(widgetSendOptions).load(router);
    // 7) serve 'index.html' for all the rest
    // see https://expressjs.com/en/api.html#res.sendFile
    const catchAllSendOptions = {
        cacheControl: false,
        lastModified: false,
        root: clientRoot,
        headers: {
            'Cache-control': 'public, must-revalidate, max-age=' + STATIC_MAX_AGE_SECONDS
        }
    };
    const extensionsWith404 = ['ico', 'js', 'map', 'css', 'jpg', 'png', 'gif'].reduce((acc, ext) => {
        acc[ext] = true;
        return acc;
    }, {});
    router.get('/*', (req, res) => {
        // If URL ends in extensionsWith404 (which should have been served at step #2 or #3),
        // send an actual 404
        let actual404 = false;
        const pathname = urlParser.parse(req.url).pathname;
        const dotIndex = pathname.lastIndexOf('.');
        if (dotIndex > 0) {
            const extension = pathname.substr(dotIndex + 1);
            actual404 = (extensionsWith404[extension] === true);
        }
        if (actual404) {
            // cache 404s for 60 seconds
            res.status(404).send('Not found.');
            return;
        }
        // For all other URLs, send index.html
        serveIndex(req, res);
    });
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVzTG9hZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3dlYlNlcnZlci9yb3V0ZXNMb2FkZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQy9CLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFFakMsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDNUMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBRW5DLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDaEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUV0QyxZQUFZO0FBQ1osMkZBQTJGO0FBQzNGLDBFQUEwRTtBQUMxRSxNQUFNLHNCQUFzQixHQUFHLEVBQUUsQ0FBQztBQUNsQyxNQUFNLHNCQUFzQixHQUFHLEVBQUUsQ0FBQztBQUVsQyxTQUFTLFdBQVcsQ0FBQyxHQUFHO0lBQ3RCLElBQUk7UUFDRixpQ0FBaUM7UUFDakMsTUFBTSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsYUFBYSxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7UUFDakUsTUFBTSxZQUFZLEdBQUcsYUFBYSxDQUFDO1FBQ25DLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFFekMscUNBQXFDO1FBQ3JDLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDOUIsNkJBQTZCO1lBQzdCLE9BQU87U0FDUjtRQUNELElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQzFDLGlDQUFpQztZQUNqQyxPQUFPO1NBQ1I7UUFFRCxtQ0FBbUM7UUFDbkMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pGLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFekMsY0FBYztZQUNkLElBQUk7Z0JBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsVUFBVSxNQUFNLENBQUMsQ0FBQztnQkFDOUMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ25ELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFbkMsSUFBSSxNQUFNLElBQUksT0FBTyxNQUFNLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtvQkFDL0MsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDeEMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxVQUFVLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBQ3RELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxDQUFDO2lCQUNoQztnQkFDRCxHQUFHLENBQUMsSUFBSSxDQUNOLCtCQUErQixVQUFVLGVBQWUsWUFBWSxJQUFJLFVBQVUsSUFBSSxDQUN2RixDQUFDO2FBQ0g7WUFBQyxPQUFNLEtBQUssRUFBRTtnQkFDYixHQUFHLENBQUMsS0FBSyxDQUFDLDBCQUEwQixVQUFVLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUMzRDtRQUNILENBQUMsQ0FBQyxDQUFDO0tBRUo7SUFBQyxPQUFNLEtBQUssRUFBRTtRQUNiLEdBQUcsQ0FBQyxLQUFLLENBQUMsd0NBQXdDLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDNUQ7QUFDSCxDQUFDO0FBRUQ7OztHQUdHO0FBQ0gsTUFBTSxDQUFDLE9BQU8sR0FBRyxTQUFTLFlBQVksQ0FBQyxNQUFNLEVBQUUsUUFBUTtJQUNyRCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFN0IsaUJBQWlCO0lBQ2pCLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNuRCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO0lBQzdGLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7UUFFckMsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxQyxJQUFJLENBQUMsT0FBTyxJQUFJLFVBQVUsRUFBRTtZQUMxQixJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssS0FBSyxFQUFFO2dCQUN4Qiw0QkFBNEI7Z0JBQzVCLE1BQU0sU0FBUyxHQUFHLFdBQVcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksU0FBUyxHQUFHLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDekYsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQzdCLE9BQU8sSUFBSSxDQUFDO2FBQ2I7aUJBQU07Z0JBQ0wsT0FBTztnQkFDUCxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3REO1NBQ0Y7UUFDRCxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUUzQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUVWLGdDQUFnQztJQUNoQyxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDM0QsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUN0RSxNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsMkNBQTJDLENBQUMsQ0FBQztJQUN0RixJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsRUFBRTtRQUNuQyxnRkFBZ0Y7UUFDaEYsR0FBRyxDQUFDLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDO1FBQ3ZELEVBQUUsQ0FBQyxRQUFRLENBQUMsc0JBQXNCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFckQsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7WUFDcEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1lBQzlELHFFQUFxRTtZQUNyRSxFQUFFLENBQUMsUUFBUSxDQUNULGlCQUFpQixFQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUMvRCxDQUFDO1NBQ0g7S0FDRjtJQUVELDZDQUE2QztJQUM3QyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMvRCxFQUFFLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBRWxDLHdFQUF3RTtJQUN4RSxNQUFNLGtCQUFrQixHQUFHO1FBQ3pCLFdBQVcsRUFBRSxJQUFJO1FBQ2pCLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLElBQUksRUFBRSxJQUFJO1FBQ1YsWUFBWSxFQUFFLEtBQUs7UUFDbkIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxFQUFFO1lBQ2hCLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLG1DQUFtQyxHQUFHLHNCQUFzQixDQUFDLENBQUM7UUFDL0YsQ0FBQztLQUNGLENBQUM7SUFDRixNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0lBRTdELE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFFckUsa0JBQWtCO0lBQ2xCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ3pELElBQUksU0FBUyxHQUFHLElBQUksQ0FBQztJQUNyQixNQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtRQUM5QixJQUFJLFNBQVMsS0FBSyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDM0MsdURBQXVEO1lBQ3ZELElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM3QixvQ0FBb0M7Z0JBQ3BDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUMvQjtZQUNELDRCQUE0QjtZQUM1QixTQUFTLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQztTQUM1RDtRQUVELHlEQUF5RDtRQUN6RCxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLGVBQWUsUUFBUSxJQUFJLENBQUMsQ0FBQztRQUNwRixHQUFHO2FBQ0EsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLE1BQU0sQ0FBQyxlQUFlLEVBQUUsbUJBQW1CLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO2FBQ3JFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNyQixDQUFDLENBQUM7SUFDRixNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUU1QixtQ0FBbUM7SUFDbkMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQztJQUV4RCwwQkFBMEI7SUFDMUIsU0FBUyxrQkFBa0IsQ0FBQyxTQUFTO1FBQ25DLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsaUNBQWlDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU1QyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3ZDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzlCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUMzQjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUNELGtCQUFrQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUVsRSx5QkFBeUI7SUFDekIsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBRXBCLHFDQUFxQztJQUNyQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtRQUNwQyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKLFlBQVk7SUFDWixxREFBcUQ7SUFDckQsTUFBTSxpQkFBaUIsR0FBRztRQUN4QixNQUFNLEVBQUUsc0JBQXNCLEdBQUcsSUFBSTtRQUNyQyxJQUFJLEVBQUUsVUFBVTtLQUNqQixDQUFDO0lBQ0YsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzdDLElBQUksV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBRWhELHlDQUF5QztJQUN6QyxxREFBcUQ7SUFDckQsTUFBTSxtQkFBbUIsR0FBRztRQUMxQixZQUFZLEVBQUUsS0FBSztRQUNuQixZQUFZLEVBQUUsS0FBSztRQUNuQixJQUFJLEVBQUUsVUFBVTtRQUNoQixPQUFPLEVBQUU7WUFDUCxlQUFlLEVBQUUsbUNBQW1DLEdBQUcsc0JBQXNCO1NBQzlFO0tBQ0YsQ0FBQztJQUNGLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7UUFDN0YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNoQixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBRTVCLHFGQUFxRjtRQUNyRixxQkFBcUI7UUFDckIsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNuRCxNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNDLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTtZQUNoQixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNoRCxTQUFTLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQztTQUNyRDtRQUNELElBQUksU0FBUyxFQUFFO1lBQ2IsNEJBQTRCO1lBQzVCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ25DLE9BQU87U0FDUjtRQUVELHNDQUFzQztRQUN0QyxVQUFVLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDIn0=