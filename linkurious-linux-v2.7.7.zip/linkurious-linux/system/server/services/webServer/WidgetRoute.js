/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-23.
 */
'use strict';
// internal libs
const path = require('path');
const fs = require('fs-extra');
// external libs
const MiniTemplate = require('../../../lib/MiniTemplate');
const basicAuth = require('basic-auth');
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const WidgetService = LKE.getWidget();
class WidgetRoute {
    /**
     * @param {object} staticFileOptions
     * @param {string} staticFileOptions.root Static files root
     */
    constructor(staticFileOptions) {
        this.template = null;
        this.staticFileOptions = staticFileOptions;
    }
    /**
     * @param {string} widgetData The widget data
     * @returns {string}
     */
    getWidgetPage(widgetData) {
        if (!this.template || !LKE.isProdMode()) {
            this.template = WidgetRoute.makeTemplate(path.resolve(this.staticFileOptions.root, 'widget.html'));
        }
        return this.template.compile({ tracker: '', data: widgetData });
    }
    /**
     *
     * @param {string} filePath path of the file to make a template with
     * @returns {MiniTemplate}
     */
    static makeTemplate(filePath) {
        const fileContent = fs.readFileSync(filePath, { encoding: 'utf8' });
        return new MiniTemplate(fileContent, {
            data: '\'WIDGET_DATA\''
        });
    }
    /**
     * @param {Express.Router} router
     */
    load(router) {
        // serve widget template if enabled (default: true)
        const widget = Config.get('access.widget', true);
        if (!widget) {
            return;
        }
        router.get('/widget/:key', (req, res) => {
            let responseBody = '';
            let status = 200;
            /** @type {{name: string, pass: string}} */
            const auth = basicAuth(req) || {};
            WidgetService.getWidgetByKey(req.param('key'), { password: auth.pass }).then(widgetData => {
                responseBody = this.getWidgetPage(JSON.stringify({
                    widget: widgetData,
                    ogmaOptions: Config.get('ogma')
                }));
            }).catch(Errors.LkError, e => {
                if (e.isAccess()) {
                    // respond with the basic-auth challenge in case of access error
                    status = 401;
                    res.setHeader('WWW-Authenticate', 'Basic realm="Linkurious Widget (user field is ignored)"');
                    responseBody = '<h1>' + e.message + '</h1>';
                }
                else {
                    // generic case of other errors
                    status = 400;
                    responseBody = '<h1>' + e.message + '</h1>';
                }
            }).catch(e => {
                // handler for non-linkurious errors
                status = 500;
                responseBody = '<h1>Internal server error</h1>' +
                    '<pre>' + (e && e.stack ? e.stack : e) + '</pre>';
            }).finally(() => {
                // don't cache widget for more than 30 seconds
                res.setHeader('Cache-control', 'max-age=30');
                res.status(status).send(responseBody);
            });
        });
        router.get('/widget', (req, res) => {
            res.sendFile('widget.html', this.staticFileOptions);
        });
    }
}
module.exports = WidgetRoute;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiV2lkZ2V0Um91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL1dpZGdldFJvdXRlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QixNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFL0IsZ0JBQWdCO0FBQ2hCLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQzFELE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUV4QyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRXRDLE1BQU0sV0FBVztJQUVmOzs7T0FHRztJQUNILFlBQVksaUJBQWlCO1FBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQztJQUM3QyxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsYUFBYSxDQUFDLFVBQVU7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUN0QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQ3pELENBQUM7U0FDSDtRQUNELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRO1FBQzFCLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBQyxDQUFDLENBQUM7UUFFbEUsT0FBTyxJQUFJLFlBQVksQ0FBQyxXQUFXLEVBQUU7WUFDbkMsSUFBSSxFQUFFLGlCQUFpQjtTQUN4QixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxJQUFJLENBQUMsTUFBTTtRQUVULG1EQUFtRDtRQUNuRCxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsT0FBTztTQUNSO1FBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDdEMsSUFBSSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3RCLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztZQUVqQiwyQ0FBMkM7WUFDM0MsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUVsQyxhQUFhLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUN0RixZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUMvQyxNQUFNLEVBQUUsVUFBVTtvQkFDbEIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO2lCQUNoQyxDQUFDLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUMzQixJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtvQkFDaEIsZ0VBQWdFO29CQUNoRSxNQUFNLEdBQUcsR0FBRyxDQUFDO29CQUNiLEdBQUcsQ0FBQyxTQUFTLENBQ1gsa0JBQWtCLEVBQ2xCLHlEQUF5RCxDQUMxRCxDQUFDO29CQUNGLFlBQVksR0FBRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7aUJBQzdDO3FCQUFNO29CQUNMLCtCQUErQjtvQkFDL0IsTUFBTSxHQUFHLEdBQUcsQ0FBQztvQkFDYixZQUFZLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2lCQUM3QztZQUNILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDWCxvQ0FBb0M7Z0JBQ3BDLE1BQU0sR0FBRyxHQUFHLENBQUM7Z0JBQ2IsWUFBWSxHQUFHLGdDQUFnQztvQkFDN0MsT0FBTyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFO2dCQUNkLDhDQUE4QztnQkFDOUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQzdDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3hDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUNqQyxHQUFHLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDIn0=