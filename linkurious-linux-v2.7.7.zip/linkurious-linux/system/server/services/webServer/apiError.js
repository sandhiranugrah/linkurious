"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
// services
const LKE = require("../index");
const Log = LKE.getLogger(__filename);
const Errors = LKE.getErrors();
const ERRORS_MAP = {
    // GENERIC errors
    /**
     * Two (or more) parameters of a function/API are mutually exclusive.
     */
    conflict_parameter: {
        code: 400,
        message: 'Conflict in parameters.'
    },
    /**
     * A strong code assertion has failed.
     *
     * E.g.: "DataSource.getSourceInfo cannot be called before 'storeId' is set"
     */
    bug: {
        code: 500,
        message: 'Critical internal error.'
    },
    /**
     * An unexpected technical error has occurred.
     * The error often involves a third party that did not respond as expected.
     *
     * E.g.: "Could not create group in SQL database"
     */
    critical: {
        code: 500,
        message: 'Critical Error'
    },
    /**
     * A parameter provided to a function or API does not have the expected type/value.
     *
     * E.g.: "Parameter 'withDigest' must be a boolean"
     */
    invalid_parameter: {
        code: 400,
        message: 'Invalid Parameters.'
    },
    /**
     * A required parameter provided to a function or API is missing.
     *
     * E.g.: "The 'sourceKey' parameter is required"
     */
    missing_field: {
        code: 400,
        message: 'Missing field.'
    },
    /**
     * Generic not found error, used for:
     * - Folder
     * - Visualization
     * - DataSource
     * - Group
     * - AccessRight
     * - Alert
     * - AlertMatch
     *
     * For nodes, edges and users, use node_not_found, edge_not_found and user_not_found.
     *
     * E.g.: "The Folder #888 was not found"
     */
    not_found: {
        code: 404,
        message: 'Not Found.'
    },
    redundant_action: {
        code: 409,
        message: 'The action you are trying to perform is redundant (nothing to do).'
    },
    /**
     * Error in the communication with a service used by Linkurious.
     *
     * E.g.: "The other side of the TCP conversation abruptly closed its end of the connection"
     */
    socket_error: {
        code: 500,
        message: 'Socket error.'
    },
    // Feature-related (expected) Soft Failures
    /**
     * We decided not to implement a feature under certain conditions.
     *
     * E.g.: "Alerts are not available in Linkurious Starter edition"
     */
    not_implemented: {
        code: 501,
        message: 'Not Implemented.'
    },
    /**
     * We don't support a given feature with a particular third party service.
     *
     * E.g.: "Edge properties are not supported by Stardog"
     */
    not_supported: {
        code: 501,
        message: 'Not Supported.'
    },
    /**
     * A feature cannot be used because it was disabled by configuration.
     *
     * E.g.: "Trying to authenticate with Azure AD, but Azure AD is disabled in configuration"
     */
    feature_disabled: {
        code: 400,
        message: 'This feature has been disabled.'
    },
    // HTTP Server
    /**
     * The HTTP server cannot start because the port is already used by another process.
     */
    port_busy: {
        code: 500,
        message: 'The WebServer port is busy.'
    },
    /**
     * The HTTP server cannot start because the port is not usable by the owner of the Linkurious process.
     */
    port_restricted: {
        code: 500,
        message: 'The WebServer port is under 1024, you need root access.'
    },
    https_required: {
        code: 400,
        message: 'Linkurious was configured to refuse HTTP requests, please switch to HTTPS.'
    },
    api_not_found: {
        code: 404,
        message: 'API not found.'
    },
    // User Administration
    email_format: {
        code: 400,
        message: 'Email format is incorrect.'
    },
    user_exists: {
        code: 409,
        message: 'Username or email already registered.'
    },
    group_exists: {
        code: 409,
        message: 'Group name already used.'
    },
    user_not_found: {
        code: 404,
        message: 'Could not find referenced user.'
    },
    // Visualization/Widget/Folder edition
    visualization_locked: {
        code: 409,
        message: 'This visualization is currently locked by another user.'
    },
    widget_exists: {
        code: 409,
        message: 'A widget already exists for this visualization.'
    },
    folder_collision: {
        code: 409,
        message: 'A folder with the same name already exists at this location.'
    },
    folder_deletion_failed: {
        code: 409,
        message: 'Could not delete this folder.'
    },
    // Node/Edge Edition
    creation_failed: {
        code: 500,
        message: 'Could not created this item.'
    },
    edit_conflict: {
        code: 409,
        message: 'The graph item you are trying to edit has changed.'
    },
    // Node/Edge Reading
    edge_not_found: {
        code: 404,
        message: 'Edge not found.'
    },
    node_not_found: {
        code: 404,
        message: 'No node with this Id.'
    },
    // LDAP
    ldap_bind_error: {
        code: 500,
        message: 'Could not connect to LDAP server.'
    },
    // Authentication
    /**
     * The current action required to be authenticated.
     *
     * E.g.: "Cannot open a visualization without being authenticated"
     */
    unauthorized: {
        code: 401,
        message: 'Unauthorized.'
    },
    /**
     * A specific type of 'forbidden' when administrator rights are required.
     *
     * E.g.: "Alerts can only be created by a administrators"
     */
    admin_required: {
        code: 403,
        message: 'You must be an administrator to do this.'
    },
    /**
     * A specific type of 'forbidden' when a user tries to use an API in Guest Mode while Guest Mode
     * is disabled.
     */
    guest_disabled: {
        code: 403,
        message: 'Guest mode is disabled.'
    },
    bad_credentials: {
        code: 401,
        message: 'Incorrect username/email or password.'
    },
    session_expired: {
        code: 401,
        message: 'Your session was evicted because of inactivity.'
    },
    session_evicted: {
        code: 401,
        message: 'Your session was evicted because the server was full and an admin logged in.'
    },
    server_full: {
        code: 401,
        message: 'The server has too many concurrent users, please try later or buy more licenses.'
    },
    // Access Control
    readonly_right: {
        code: 403,
        message: 'Linkurious is in read-only mode.'
    },
    node_property_hidden: {
        code: 400,
        message: 'You tried to access a hidden node property, contact your system administrator.'
    },
    edge_property_hidden: {
        code: 400,
        message: 'You tried to access a hidden edge property, contact your system administrator.'
    },
    /**
     * The current user cannot do an action.
     *
     * E.g.: "You cannot delete a widget that you don't own"
     */
    forbidden: {
        code: 403,
        message: 'Forbidden.'
    },
    read_forbidden: {
        code: 403,
        message: 'You don\'t have read access to this information.'
    },
    /**
     * The current user is trying to write an information it has no write-access to.
     * Used for:
     * - Editing builtin groups
     * - Running raw queries with write statements without the appropriate action AccessRight
     * - Creating/Updating/Deleting a node without the appropriate action AccessRight
     * - Creating/Updating/Deleting an edge without the appropriate action AccessRight
     * - Trying to edit items in a read-only DataSource
     * - Updating a visualization without the appropriate AccessRight
     * - Updating/Deleting a Folder without the appropriate AccessRight
     *
     * E.g.: "You don't have write-access to this node"
     */
    write_forbidden: {
        code: 403,
        message: 'You don\'t have write access to this information.'
    },
    // Raw Graph Queries
    /**
     * A graph-server request failed because the query was invalid (bad syntax).
     *
     * E.g.: "Neo4j could not run query 'MATCH (a)-[e]-(b)': RETURN statement is missing"
     */
    bad_graph_request: {
        code: 400,
        message: 'You have issued a bad graph request.'
    },
    /**
     * A graph-server request failed because the query violated a constraint.
     *
     * E.g.: "Node(123) already exists with label `Company` and property `name` = 'Linkurious'"
     */
    constraint_violation: {
        code: 400,
        message: 'The graph query failed because a constraint was violated.'
    },
    /**
     * A graph-server request failed because the request timed out.
     *
     * E.g. "Neo4j query timed out after 60 seconds. Query was: 'MATCH (a)-[...]-(b) RETURN *'"
     */
    graph_request_timeout: {
        code: 504,
        message: 'The graph database did not respond in a timely manner.'
    },
    // Configuration
    /**
     * The configuration is invalid.
     *
     * E.g.: "Configuration field 'dataSources.0.graphdb.vendor' must be a string"
     */
    invalid_configuration: {
        code: 400,
        message: 'The current configuration has errors.'
    },
    // Data-source
    /**
     * A data-source needs an user action.
     *
     * E.g.: "A search index doesn't exist in an external indexDAO"
     */
    source_action_needed: {
        code: 400,
        message: 'The data-source needs a user action before it can be used with Linkurious.'
    },
    dataSource_unavailable: {
        code: 404,
        message: 'Data-source not found or not connected.'
    },
    /**
     * The current state of the data-source does not allow for the requested action.
     *
     * E.g.: "Cannot 'reconnect' data-source #2 while it is indexing"
     */
    illegal_source_state: {
        code: 409,
        message: 'The data-source is in the wrong state for this operation.'
    },
    /**
     * Thrown by GraphDAO.connect and GraphDAO.checkUp when the graph server is not reachable.
     *
     * E.g.: "Cannot connect Neo4j: no route to host"
     */
    graph_unreachable: {
        code: 404,
        message: 'Cannot connect to Graph database.'
    },
    /**
     * Thrown by IndexDAO.connect and IndexDAO.checkUp when the index server is not reachable.
     *
     * E.g.: "Cannot connect to ElasticSearch: connection reset"
     */
    index_unreachable: {
        code: 404,
        message: 'Cannot connect to Search Index.'
    },
    index_mapping_error: {
        code: 500,
        message: 'Unexpected property type. ' +
            'Try setting "dynamicMapping:false" in the index configuration.'
    }
};
/**
 * Convert an application error into an HTTP error (with status code).
 * Return an HTTP error description with 'key', 'code' (HTTP status) and 'message'.
 *
 * @param key       An error key found in ERROR_MAP
 * @param [message] A human readable description of the error
 * @param [type]    An LkError error type
 */
const apiError = (key, message, type) => {
    const errorTemplate = ERRORS_MAP[key];
    if (errorTemplate) {
        return {
            code: errorTemplate.code,
            key: key,
            message: message || errorTemplate.message
        };
    }
    else {
        Log.warn('Unknown error key "' + key + '" (' + message + ')');
        if (type === Errors.LkError.Type.ACCESS) {
            return {
                code: 401,
                key: key,
                message: message || 'Unauthorized'
            };
        }
        else if (type === Errors.LkError.Type.BUSINESS) {
            return {
                code: 400,
                key: key,
                message: message || 'Bad request'
            };
        }
        else {
            return {
                code: 500,
                key: key,
                message: message || 'Internal error'
            };
        }
    }
};
module.exports = apiError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpRXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL2FwaUVycm9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7QUFFSCxXQUFXO0FBQ1gsZ0NBQWlDO0FBQ2pDLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sVUFBVSxHQUFtRDtJQUNqRSxpQkFBaUI7SUFFakI7O09BRUc7SUFDSCxrQkFBa0IsRUFBRTtRQUNsQixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSx5QkFBeUI7S0FDbkM7SUFFRDs7OztPQUlHO0lBQ0gsR0FBRyxFQUFFO1FBQ0gsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsMEJBQTBCO0tBQ3BDO0lBRUQ7Ozs7O09BS0c7SUFDSCxRQUFRLEVBQUU7UUFDUixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxnQkFBZ0I7S0FDMUI7SUFFRDs7OztPQUlHO0lBQ0gsaUJBQWlCLEVBQUU7UUFDakIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUscUJBQXFCO0tBQy9CO0lBRUQ7Ozs7T0FJRztJQUNILGFBQWEsRUFBRTtRQUNiLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLGdCQUFnQjtLQUMxQjtJQUVEOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxTQUFTLEVBQUU7UUFDVCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxZQUFZO0tBQ3RCO0lBRUQsZ0JBQWdCLEVBQUU7UUFDaEIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsb0VBQW9FO0tBQzlFO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksRUFBRTtRQUNaLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLGVBQWU7S0FDekI7SUFFRCwyQ0FBMkM7SUFFM0M7Ozs7T0FJRztJQUNILGVBQWUsRUFBRTtRQUNmLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLGtCQUFrQjtLQUM1QjtJQUVEOzs7O09BSUc7SUFDSCxhQUFhLEVBQUU7UUFDYixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxnQkFBZ0I7S0FDMUI7SUFFRDs7OztPQUlHO0lBQ0gsZ0JBQWdCLEVBQUU7UUFDaEIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsaUNBQWlDO0tBQzNDO0lBRUQsY0FBYztJQUVkOztPQUVHO0lBQ0gsU0FBUyxFQUFFO1FBQ1QsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsNkJBQTZCO0tBQ3ZDO0lBRUQ7O09BRUc7SUFDSCxlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSx5REFBeUQ7S0FDbkU7SUFFRCxjQUFjLEVBQUU7UUFDZCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSw0RUFBNEU7S0FDdEY7SUFFRCxhQUFhLEVBQUU7UUFDYixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxnQkFBZ0I7S0FDMUI7SUFFRCxzQkFBc0I7SUFFdEIsWUFBWSxFQUFFO1FBQ1osSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsNEJBQTRCO0tBQ3RDO0lBRUQsV0FBVyxFQUFFO1FBQ1gsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsdUNBQXVDO0tBQ2pEO0lBRUQsWUFBWSxFQUFFO1FBQ1osSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsMEJBQTBCO0tBQ3BDO0lBRUQsY0FBYyxFQUFFO1FBQ2QsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsaUNBQWlDO0tBQzNDO0lBRUQsc0NBQXNDO0lBRXRDLG9CQUFvQixFQUFFO1FBQ3BCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLHlEQUF5RDtLQUNuRTtJQUVELGFBQWEsRUFBRTtRQUNiLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLGlEQUFpRDtLQUMzRDtJQUVELGdCQUFnQixFQUFFO1FBQ2hCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLDhEQUE4RDtLQUN4RTtJQUVELHNCQUFzQixFQUFFO1FBQ3RCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLCtCQUErQjtLQUN6QztJQUVELG9CQUFvQjtJQUVwQixlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSw4QkFBOEI7S0FDeEM7SUFFRCxhQUFhLEVBQUU7UUFDYixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxvREFBb0Q7S0FDOUQ7SUFFRCxvQkFBb0I7SUFFcEIsY0FBYyxFQUFFO1FBQ2QsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsaUJBQWlCO0tBQzNCO0lBRUQsY0FBYyxFQUFFO1FBQ2QsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsdUJBQXVCO0tBQ2pDO0lBRUQsT0FBTztJQUVQLGVBQWUsRUFBRTtRQUNmLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLG1DQUFtQztLQUM3QztJQUVELGlCQUFpQjtJQUVqQjs7OztPQUlHO0lBQ0gsWUFBWSxFQUFFO1FBQ1osSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsZUFBZTtLQUN6QjtJQUVEOzs7O09BSUc7SUFDSCxjQUFjLEVBQUU7UUFDZCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSwwQ0FBMEM7S0FDcEQ7SUFFRDs7O09BR0c7SUFDSCxjQUFjLEVBQUU7UUFDZCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSx5QkFBeUI7S0FDbkM7SUFFRCxlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSx1Q0FBdUM7S0FDakQ7SUFFRCxlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxpREFBaUQ7S0FDM0Q7SUFFRCxlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSw4RUFBOEU7S0FDeEY7SUFFRCxXQUFXLEVBQUU7UUFDWCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxrRkFBa0Y7S0FDNUY7SUFFRCxpQkFBaUI7SUFFakIsY0FBYyxFQUFFO1FBQ2QsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsa0NBQWtDO0tBQzVDO0lBRUQsb0JBQW9CLEVBQUU7UUFDcEIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsZ0ZBQWdGO0tBQzFGO0lBRUQsb0JBQW9CLEVBQUU7UUFDcEIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsZ0ZBQWdGO0tBQzFGO0lBRUQ7Ozs7T0FJRztJQUNILFNBQVMsRUFBRTtRQUNULElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLFlBQVk7S0FDdEI7SUFFRCxjQUFjLEVBQUU7UUFDZCxJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxrREFBa0Q7S0FDNUQ7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSCxlQUFlLEVBQUU7UUFDZixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSxtREFBbUQ7S0FDN0Q7SUFFRCxvQkFBb0I7SUFFcEI7Ozs7T0FJRztJQUNILGlCQUFpQixFQUFFO1FBQ2pCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLHNDQUFzQztLQUNoRDtJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0IsRUFBRTtRQUNwQixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSwyREFBMkQ7S0FDckU7SUFFRDs7OztPQUlHO0lBQ0gscUJBQXFCLEVBQUU7UUFDckIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsd0RBQXdEO0tBQ2xFO0lBRUQsZ0JBQWdCO0lBRWhCOzs7O09BSUc7SUFDSCxxQkFBcUIsRUFBRTtRQUNyQixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSx1Q0FBdUM7S0FDakQ7SUFFRCxjQUFjO0lBRWQ7Ozs7T0FJRztJQUNILG9CQUFvQixFQUFFO1FBQ3BCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLDRFQUE0RTtLQUN0RjtJQUVELHNCQUFzQixFQUFFO1FBQ3RCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLHlDQUF5QztLQUNuRDtJQUVEOzs7O09BSUc7SUFDSCxvQkFBb0IsRUFBRTtRQUNwQixJQUFJLEVBQUUsR0FBRztRQUNULE9BQU8sRUFBRSwyREFBMkQ7S0FDckU7SUFFRDs7OztPQUlHO0lBQ0gsaUJBQWlCLEVBQUU7UUFDakIsSUFBSSxFQUFFLEdBQUc7UUFDVCxPQUFPLEVBQUUsbUNBQW1DO0tBQzdDO0lBRUQ7Ozs7T0FJRztJQUNILGlCQUFpQixFQUFFO1FBQ2pCLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUFFLGlDQUFpQztLQUMzQztJQUVELG1CQUFtQixFQUFFO1FBQ25CLElBQUksRUFBRSxHQUFHO1FBQ1QsT0FBTyxFQUNMLDRCQUE0QjtZQUM1QixnRUFBZ0U7S0FDbkU7Q0FDRixDQUFDO0FBRUY7Ozs7Ozs7R0FPRztBQUNILE1BQU0sUUFBUSxHQUFHLENBQ2YsR0FBVyxFQUNYLE9BQWdCLEVBQ2hCLElBQWEsRUFLYixFQUFFO0lBQ0YsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3RDLElBQUksYUFBYSxFQUFFO1FBQ2pCLE9BQU87WUFDTCxJQUFJLEVBQUUsYUFBYSxDQUFDLElBQUk7WUFDeEIsR0FBRyxFQUFFLEdBQUc7WUFDUixPQUFPLEVBQUUsT0FBTyxJQUFJLGFBQWEsQ0FBQyxPQUFPO1NBQzFDLENBQUM7S0FDSDtTQUFNO1FBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUU5RCxJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDdkMsT0FBTztnQkFDTCxJQUFJLEVBQUUsR0FBRztnQkFDVCxHQUFHLEVBQUUsR0FBRztnQkFDUixPQUFPLEVBQUUsT0FBTyxJQUFJLGNBQWM7YUFDbkMsQ0FBQztTQUNIO2FBQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2hELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLEdBQUc7Z0JBQ1QsR0FBRyxFQUFFLEdBQUc7Z0JBQ1IsT0FBTyxFQUFFLE9BQU8sSUFBSSxhQUFhO2FBQ2xDLENBQUM7U0FDSDthQUFNO1lBQ0wsT0FBTztnQkFDTCxJQUFJLEVBQUUsR0FBRztnQkFDVCxHQUFHLEVBQUUsR0FBRztnQkFDUixPQUFPLEVBQUUsT0FBTyxJQUFJLGdCQUFnQjthQUNyQyxDQUFDO1NBQ0g7S0FDRjtBQUNILENBQUMsQ0FBQztBQUVGLGlCQUFTLFFBQVEsQ0FBQyJ9