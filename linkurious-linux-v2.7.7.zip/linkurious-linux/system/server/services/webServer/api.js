"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-05.
 */
// external libs
const Bluebird = require("bluebird");
// services
const LKE = require("../index");
const Errors = LKE.getErrors();
const Log = LKE.getLogger(__filename);
const Utils = LKE.getUtils();
const apiError = require("./apiError");
class API {
    /**
     * @param timing Whether to include request/response timing information in response headers
     */
    constructor(timing) {
        this.timing = timing;
    }
    /**
     * Set some additional header (response-time, caching).
     *
     * @param response
     * @param requestStart
     */
    setResponseHeaders(response, requestStart) {
        // response timing
        if (this.timing) {
            response.setHeader('X-Response-Time', Date.now() - requestStart + 'ms');
        }
        // prevent HTTP caching
        // see https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control
        // see https://www.fastly.com/blog/headers-we-dont-want
        response.setHeader('Cache-control', 'private, no-store');
    }
    /**
     * @param response
     * @param lkError
     */
    respondToLkError(response, lkError) {
        if (lkError.isTechnical()) {
            Log.error(lkError.type + ':' + lkError.key + ' ' + lkError.message);
            Log.error(lkError.stack);
        }
        else {
            Log.debug(lkError.type + ':' + lkError.key + ' ' + lkError.message);
        }
        const errorPayload = API.error(lkError);
        response.status(errorPayload.code).json({
            key: errorPayload.key,
            message: errorPayload.message,
            data: lkError.data
        });
    }
    /**
     * @param error
     */
    static error(error) {
        return apiError(error.key, error.message, error.type);
    }
    /**
     * @param res
     * @param err
     */
    respondToGenericError(res, err) {
        Log.error(err);
        res.status(500).json({ key: 'critical', message: err + '' });
    }
    respond(promiseFunction, successCode = 200, isProxy, wantResponse) {
        return (request, response, next) => {
            // @ts-ignore we won't use anymore request.param
            request.param = API.getParam.bind(undefined, request);
            // use response timing if required
            const requestStart = this.timing ? Date.now() : 0;
            Bluebird.resolve()
                .then(() => {
                // check promiseFunction
                if (typeof promiseFunction !== 'function') {
                    throw Errors.technical('bug', 'promiseFunction is not a function');
                }
                // run promiseFunction (can throw an exception)
                const promise = wantResponse === true
                    ? promiseFunction.call(null, request, response)
                    : // TODO find a way to overload function with callback params with variable arguments
                        promiseFunction.call(null, request, undefined);
                // check the result of promiseFunction
                if (isProxy && promise === null) {
                    // if isProxy=true and null is returned, consider that the response was sent manually
                }
                else if (promise === null || promise === undefined) {
                    throw Errors.technical('bug', 'promiseFunction returned null or undefined');
                }
                else if (typeof promise.then !== 'function') {
                    throw Errors.technical('bug', 'promiseFunction did not return a promise');
                }
                // return the promise for the next step
                return promise;
            })
                .then(data => {
                // success
                if (isProxy && data === null) {
                    // if isProxy=true and null is returned, consider that the response was sent manually
                }
                else if (isProxy && next) {
                    // call the next matching handler
                    next();
                }
                else {
                    // send a JSON response
                    this.setResponseHeaders(response, requestStart);
                    if (successCode === 204) {
                        // 204 response code allows no response body
                        response.setHeader('Content-Length', 0);
                        response.setHeader('Content-Type', 'application/json');
                        response.status(successCode).end();
                    }
                    else if (successCode === 302 || successCode === 301) {
                        // never do 301 redirects (see https://jacquesmattheij.com/301-redirects-a-dangerous-one-way-street)
                        successCode = 302;
                        // data is url redirection string when successCode is a 302 or 301
                        response.setHeader('Location', data);
                        response.status(successCode).send('Redirecting ...');
                    }
                    else {
                        response.status(successCode).json(data);
                    }
                }
            })
                .catch(Errors.LkError, error => {
                // Linkurious custom errors
                this.setResponseHeaders(response, requestStart);
                this.respondToLkError(response, error);
            })
                .catch(error => {
                // generic errors (critical)
                this.setResponseHeaders(response, requestStart);
                this.respondToGenericError(response, error);
            });
        };
    }
    proxy(promiseFunction, wantResponse) {
        return this.respond(
        // @ts-ignore
        promiseFunction, undefined, true, wantResponse);
    }
    /**
     * Read a param from an http request (from params, body or query)
     * Must be bound to an `http.IncomingMessage`.
     *
     * @param request
     * @param key
     * @param [defaultValue]
     */
    static getParam(request, key, defaultValue) {
        const urlParams = request.params || {};
        const body = request.body || {};
        const query = request.query || {};
        const snakeCaseKey = key
            .split(/(?=[A-Z])/)
            .join('_')
            .toLowerCase();
        if (Utils.hasValue(urlParams[key]) && urlParams.hasOwnProperty(key)) {
            return urlParams[key];
        }
        if (Utils.hasValue(body[key])) {
            return body[key];
        }
        if (Utils.hasValue(query[key])) {
            return query[key];
        }
        if (Utils.hasValue(query[snakeCaseKey])) {
            return query[snakeCaseKey];
        }
        return defaultValue;
    }
}
module.exports = new API(LKE.isTestMode() || LKE.isDevMode());
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3NlcnZpY2VzL3dlYlNlcnZlci9hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7OztHQUtHO0FBRUgsZ0JBQWdCO0FBQ2hCLHFDQUFxQztBQUVyQyxXQUFXO0FBQ1gsZ0NBQWlDO0FBQ2pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUk3Qix1Q0FBd0M7QUFJeEMsTUFBTSxHQUFHO0lBR1A7O09BRUc7SUFDSCxZQUFZLE1BQWU7UUFDekIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFDdkIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssa0JBQWtCLENBQUMsUUFBeUIsRUFBRSxZQUFvQjtRQUN4RSxrQkFBa0I7UUFDbEIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2YsUUFBUSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQ3pFO1FBQ0QsdUJBQXVCO1FBQ3ZCLDhFQUE4RTtRQUM5RSx1REFBdUQ7UUFDdkQsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksZ0JBQWdCLENBQUMsUUFBeUIsRUFBRSxPQUFnQjtRQUNqRSxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRTtZQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNwRSxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMxQjthQUFNO1lBQ0wsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDckU7UUFDRCxNQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztZQUN0QyxHQUFHLEVBQUUsWUFBWSxDQUFDLEdBQUc7WUFDckIsT0FBTyxFQUFFLFlBQVksQ0FBQyxPQUFPO1lBQzdCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtTQUNuQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQWM7UUFDaEMsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0kscUJBQXFCLENBQUMsR0FBb0IsRUFBRSxHQUFVO1FBQzNELEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDZixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLEVBQUMsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUE2RE0sT0FBTyxDQUNaLGVBR3NDLEVBQ3RDLGNBQXNCLEdBQUcsRUFDekIsT0FBaUIsRUFDakIsWUFBc0I7UUFFdEIsT0FBTyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDakMsZ0RBQWdEO1lBQ2hELE9BQU8sQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRXRELGtDQUFrQztZQUNsQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVsRCxRQUFRLENBQUMsT0FBTyxFQUFFO2lCQUNmLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ1Qsd0JBQXdCO2dCQUN4QixJQUFJLE9BQU8sZUFBZSxLQUFLLFVBQVUsRUFBRTtvQkFDekMsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxtQ0FBbUMsQ0FBQyxDQUFDO2lCQUNwRTtnQkFFRCwrQ0FBK0M7Z0JBRS9DLE1BQU0sT0FBTyxHQUNYLFlBQVksS0FBSyxJQUFJO29CQUNuQixDQUFDLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQztvQkFDL0MsQ0FBQyxDQUFDLG9GQUFvRjt3QkFDcEYsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFHLFNBQXdDLENBQUMsQ0FBQztnQkFFckYsc0NBQXNDO2dCQUN0QyxJQUFJLE9BQU8sSUFBSSxPQUFPLEtBQUssSUFBSSxFQUFFO29CQUMvQixxRkFBcUY7aUJBQ3RGO3FCQUFNLElBQUksT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO29CQUNwRCxNQUFNLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLDRDQUE0QyxDQUFDLENBQUM7aUJBQzdFO3FCQUFNLElBQUksT0FBTyxPQUFPLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtvQkFDN0MsTUFBTSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSwwQ0FBMEMsQ0FBQyxDQUFDO2lCQUMzRTtnQkFFRCx1Q0FBdUM7Z0JBQ3ZDLE9BQU8sT0FBTyxDQUFDO1lBQ2pCLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ1gsVUFBVTtnQkFFVixJQUFJLE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO29CQUM1QixxRkFBcUY7aUJBQ3RGO3FCQUFNLElBQUksT0FBTyxJQUFJLElBQUksRUFBRTtvQkFDMUIsaUNBQWlDO29CQUNqQyxJQUFJLEVBQUUsQ0FBQztpQkFDUjtxQkFBTTtvQkFDTCx1QkFBdUI7b0JBQ3ZCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBQ2hELElBQUksV0FBVyxLQUFLLEdBQUcsRUFBRTt3QkFDdkIsNENBQTRDO3dCQUM1QyxRQUFRLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUN4QyxRQUFRLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO3dCQUN2RCxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO3FCQUNwQzt5QkFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHLElBQUksV0FBVyxLQUFLLEdBQUcsRUFBRTt3QkFDckQsb0dBQW9HO3dCQUNwRyxXQUFXLEdBQUcsR0FBRyxDQUFDO3dCQUNsQixrRUFBa0U7d0JBQ2xFLFFBQVEsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQWMsQ0FBQyxDQUFDO3dCQUMvQyxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO3FCQUN0RDt5QkFBTTt3QkFDTCxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDekM7aUJBQ0Y7WUFDSCxDQUFDLENBQUM7aUJBQ0QsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQzdCLDJCQUEyQjtnQkFDM0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN6QyxDQUFDLENBQUM7aUJBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNiLDRCQUE0QjtnQkFDNUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM5QyxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztJQUNKLENBQUM7SUFjTSxLQUFLLENBQ1YsZUFBK0YsRUFDL0YsWUFBc0I7UUFFdEIsT0FBTyxJQUFJLENBQUMsT0FBTztRQUNqQixhQUFhO1FBQ2IsZUFBdUQsRUFDdkQsU0FBUyxFQUNULElBQUksRUFDSixZQUFZLENBQ2IsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUF3QixFQUFFLEdBQVcsRUFBRSxZQUFzQjtRQUNuRixNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUN2QyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQyxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztRQUVsQyxNQUFNLFlBQVksR0FBRyxHQUFHO2FBQ3JCLEtBQUssQ0FBQyxXQUFXLENBQUM7YUFDbEIsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNULFdBQVcsRUFBRSxDQUFDO1FBRWpCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ25FLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzlCLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25CO1FBQ0QsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFO1lBQ3ZDLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQzVCO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztDQUNGO0FBRUQsaUJBQVMsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDIn0=