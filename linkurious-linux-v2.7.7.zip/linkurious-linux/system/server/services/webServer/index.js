/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-04.
 */
'use strict';
// internal libs
const http = require('http');
const https = require('https');
// external libs
const Express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sessionStore = require('express-session');
const compression = require('compression');
const cookieParser = require('../../../lib/CookieParser');
const morgan = require('morgan');
const Promise = require('bluebird');
const onHeaders = require('on-headers');
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
const Log = LKE.getLogger(__filename);
// locals
const certificate = require('./certificate');
// constants
const DOMAIN_PATTERN = '[a-z][a-z0-9\\-]*[a-z0-9]';
const ALLOW_ORIGIN_WILDCARD_RE = new RegExp('^(https?://)?(\\*\\.)((?:' + DOMAIN_PATTERN + '\\.)+[a-z0-9]+(?::[0-9]+)?)$');
const REQUEST_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes
const GLOBAL_HEADERS = {
    // Tell client to only send a Referer header in same-origin requests
    'Referrer-Policy': 'same-origin'
};
class WebServerService {
    /**
     */
    constructor() {
        /** @type {Express} */
        this.app = undefined;
        /** @type {http.Server} */
        this.httpServer = undefined;
        /** @type {https.Server} */
        this.httpsServer = undefined;
    }
    /**
     * @param {Express.Router} router
     * @param {string} basePath
     * @returns {Express} app
     */
    createApp(router, basePath) {
        const app = Express();
        app.disable('x-powered-by');
        app.set('env', LKE.options.mode);
        app.use(basePath, router);
        return app;
    }
    /**
     * @return {Express.Router}
     */
    createRouter() {
        const router = Express.Router();
        // enable compression
        router.use(compression());
        // every request will fail if no response is sent after REQUEST_TIMEOUT_MS
        router.use((req, res, next) => {
            req.setTimeout(REQUEST_TIMEOUT_MS);
            next();
        });
        // logging: use morgan for formatting and forward to our logger
        router.use(morgan('common', {
            stream: { write: message => Log.debug(message.slice(0, -1)) },
            skip: (req, _res) => req.originalUrl.indexOf('/api/') < 0
        }));
        // Key used to store the cookie in the browser
        const cookieName = 'linkurious.session';
        // sessions : set cookie parser
        router.use(cookieParser(Config.get('server.cookieSecret'), cookieName, (cookies, cb) => {
            // Here we decide which cookie to use if more than one is defined. Issue #804
            Promise.map(cookies, cookie => {
                return new Promise(resolve => {
                    Access.sessionStore.get(cookie, (err, res) => { resolve(res); });
                });
            }).then(sessions => {
                // return the first cookie for which a session is defined
                for (const s of sessions) {
                    if (s && s.id) {
                        return cb(s.id);
                    }
                }
                cb();
            });
        }));
        // sessions : use memory store
        const sessionOptions = {
            secret: Config.get('server.cookieSecret'),
            resave: false,
            saveUninitialized: true,
            name: cookieName,
            rolling: false,
            store: Access.sessionStore,
            cookie: {
                // cookies are set https and http
                secure: false,
                // cookies can be set via javascript
                httpOnly: false,
                // cookies are set for all paths
                path: '/',
                // cookies are wiped when the browser is closed (session cookie)
                maxAge: null
            }
        };
        const cookieDomain = Config.get('server.cookieDomain');
        if (cookieDomain && cookieDomain !== 'localhost' && cookieDomain !== '127.0.0.1') {
            sessionOptions.cookie.domain = cookieDomain;
        }
        router.use((req, res, next) => {
            // Headers for all requests
            res.set(GLOBAL_HEADERS);
            onHeaders(res, function () {
                // avoid to do a set-cookie if the session is invalid on the server
                if (Utils.noValue(this.req.session) ||
                    Utils.noValue(this.req.session.userId) && Utils.noValue(this.req.session.twoStageAuth)) {
                    this.removeHeader('set-cookie');
                }
            });
            next();
        });
        router.use(sessionStore(sessionOptions));
        router.use('/api', Access.checkUserSession.bind(Access));
        router.use('/api', Access.checkApplication.bind(Access));
        // parse JSON body (limit POST/PUT size to 2MB)
        router.use(bodyParser.json({
            // deflated (compressed) bodies will be inflated
            inflate: true,
            //  maximum request body size (2MB)
            limit: '2000kb',
            // will only accept arrays and objects;
            strict: true
        }));
        // parse x-www-form-urlencoded body
        router.use(bodyParser.urlencoded({ extended: true }));
        router.use((req, res, nextRoute) => {
            if (req.path.match(/\/api/)) {
                if (LKE.isTestMode() || LKE.isDevMode()) {
                    const requestStart = Date.now();
                    /**
                     * Respond to an API call.
                     * Legacy method, use `api.respond` instead.
                     *
                     * @param {number} code the HTTP response code
                     * @param {object} data the data to send as HTTP response
                     * @deprecated
                     */
                    res.apiReturn = function (code, data) {
                        res.setHeader('X-Response-Time', (Date.now() - requestStart) + 'ms');
                        if (typeof code === 'object' && code.code && code.key) {
                            res.status(code.code).json({
                                key: code.key,
                                message: code.message
                            });
                        }
                        else {
                            res.status(code).json(data);
                        }
                    };
                }
            }
            else {
                // allow any origin for non-API resources
                res.setHeader('Access-Control-Allow-Origin', '*');
            }
            nextRoute();
        });
        return router;
    }
    /**
     * @returns {Promise}
     */
    start() {
        const portHttp = Config.get('server.listenPort', 3000);
        const useHttps = Config.get('server.useHttps', false);
        const portHttps = Config.get('server.listenPortHttps', 3443);
        const baseFolder = Config.get('server.baseFolder');
        const basePath = Utils.hasValue(baseFolder) ? `/${baseFolder}/` : '/';
        // listen for clients
        return Promise.resolve().then(() => {
            this.router = this.createRouter();
            this.app = this.createApp(this.router, basePath);
            // load CORS module
            this._configureCORS();
            // load API routes
            require('./routesLoader')(this.router, basePath);
            if (!useHttps) {
                return;
            }
            // read or generate SSL certificate
            return certificate.getKeyPair().then(certificate => {
                // create + start HTTPS server
                this.httpsServer = https.createServer(certificate, this.app);
                return this._listen(this.httpsServer, portHttps, true);
            });
        }).then(() => {
            // create + start HTTP server
            this.httpServer = http.createServer(this.app);
            return this._listen(this.httpServer, portHttp, false);
        }).then(() => {
            return LKE.getStateMachine().set('WebServer', 'ready', `The Web server is listening on port ${portHttp} (HTTP)` +
                (useHttps ? ` and port ${portHttps} (HTTPS)` : ''));
        });
    }
    _configureCORS() {
        // see https://github.com/expressjs/cors
        const corsOptions = {
            methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'],
            allowHeaders: [
                'X-Requested-With', 'Content-Type', 'Content-Length', 'Accept', 'Authorization'
            ],
            credentials: true
        };
        // fix parameter
        let allowOrigin = Config.get('server.allowOrigin');
        if (Utils.noValue(allowOrigin)) {
            corsOptions.origin = false;
            Log.info('WebServer CORS: disabled.');
        }
        else if (allowOrigin === '*') {
            corsOptions.origin = true;
            Log.info('WebServer CORS: allowing all origins (*).');
        }
        else {
            if (typeof allowOrigin === 'string') {
                allowOrigin = [allowOrigin];
            }
            if (Array.isArray(allowOrigin)) {
                corsOptions.origin = [];
                allowOrigin.forEach(origin => {
                    let m;
                    if ((m = origin.match(ALLOW_ORIGIN_WILDCARD_RE)) !== null) {
                        const scheme = m[1] || 'https?://';
                        if (m[2] === '*.') {
                            const pattern = `^${scheme}(${DOMAIN_PATTERN}\\.)*${m[3].replace(/\./g, '\\.')}$`;
                            corsOptions.origin.push(new RegExp(pattern));
                        }
                    }
                    else if (origin.match(/^https?:\/\//)) {
                        corsOptions.origin.push(origin);
                    }
                    else {
                        corsOptions.origin.push('http://' + origin);
                        corsOptions.origin.push('https://' + origin);
                    }
                });
                corsOptions.origin.forEach(o => {
                    Log.info('WebServer CORS: allowing origin ' +
                        (o instanceof RegExp ? '[pattern] ' + o.toString() : '"' + o + '"'));
                });
            }
            else {
                throw Errors.business('invalid_configuration', 'Configuration key "server.allowOrigin" must be "*", a domain or an array of domains.');
            }
        }
        this.router.use(cors(corsOptions));
    }
    /**
     * @param {HttpServer} server
     * @param {number} port
     * @param {boolean} https
     * @returns {Promise}
     * @private
     */
    _listen(server, port, https) {
        Utils.check.integer('server.listenPort' + (https ? 'Https' : ''), port, 1, 65535);
        return new Promise((resolve, reject) => {
            server.listen(port, () => {
                resolve();
            }).on('error', e => {
                // error handler for ALL uncaught server exceptions
                if (e && e.errno && e.errno === 'EADDRINUSE') {
                    LKE.getStateMachine().set('WebServer', 'port_busy');
                    reject(Errors.technical('port_busy', 'The WebServer HTTP' + (https ? 'S' : '') + ' port (' + port + ') is already used.'));
                }
                else if (e && e.errno && e.errno === 'EACCES') {
                    LKE.getStateMachine().set('WebServer', 'port_restricted');
                    reject(Errors.technical('port_restricted', 'The WebServer HTTP' + (https ? 'S' : '') + ' port (' + port + ') needs root access. ' +
                        'You could use a higher port and redirect it to ' + port + ' using "iptables".'));
                }
                else {
                    LKE.getStateMachine().set('WebServer', 'error');
                    reject(e);
                }
            });
        });
    }
}
module.exports = new WebServerService();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL2luZGV4LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QixNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7QUFFL0IsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNuQyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0IsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzFDLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ2hELE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUMzQyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUMxRCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUV4QyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXRDLFNBQVM7QUFDVCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFFN0MsWUFBWTtBQUNaLE1BQU0sY0FBYyxHQUFHLDJCQUEyQixDQUFDO0FBQ25ELE1BQU0sd0JBQXdCLEdBQUcsSUFBSSxNQUFNLENBQ3pDLDJCQUEyQixHQUFHLGNBQWMsR0FBRyw4QkFBOEIsQ0FDOUUsQ0FBQztBQUNGLE1BQU0sa0JBQWtCLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxhQUFhO0FBQ3hELE1BQU0sY0FBYyxHQUFHO0lBQ3JCLG9FQUFvRTtJQUNwRSxpQkFBaUIsRUFBRSxhQUFhO0NBQ2pDLENBQUM7QUFFRixNQUFNLGdCQUFnQjtJQUVwQjtPQUNHO0lBQ0g7UUFDRSxzQkFBc0I7UUFDdEIsSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLENBQUM7UUFFckIsMEJBQTBCO1FBQzFCLElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDO1FBRTVCLDJCQUEyQjtRQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFNBQVMsQ0FBQyxNQUFNLEVBQUUsUUFBUTtRQUN4QixNQUFNLEdBQUcsR0FBRyxPQUFPLEVBQUUsQ0FBQztRQUV0QixHQUFHLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzVCLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFakMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFMUIsT0FBTyxHQUFHLENBQUM7SUFDYixDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZO1FBQ1YsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLHFCQUFxQjtRQUNyQixNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFMUIsMEVBQTBFO1FBQzFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQzVCLEdBQUcsQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUNuQyxJQUFJLEVBQUUsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO1FBRUgsK0RBQStEO1FBQy9ELE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUMxQixNQUFNLEVBQUUsRUFBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztZQUMzRCxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1NBQzFELENBQUMsQ0FBQyxDQUFDO1FBRUosOENBQThDO1FBQzlDLE1BQU0sVUFBVSxHQUFHLG9CQUFvQixDQUFDO1FBRXhDLCtCQUErQjtRQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFO1lBQ3JGLDZFQUE2RTtZQUM3RSxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRTtnQkFDNUIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDM0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ25FLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNqQix5REFBeUQ7Z0JBQ3pELEtBQUssTUFBTSxDQUFDLElBQUksUUFBUSxFQUFFO29CQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFO3dCQUNiLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztxQkFDakI7aUJBQ0Y7Z0JBQ0QsRUFBRSxFQUFFLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFSiw4QkFBOEI7UUFDOUIsTUFBTSxjQUFjLEdBQUc7WUFDckIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUM7WUFDekMsTUFBTSxFQUFFLEtBQUs7WUFDYixpQkFBaUIsRUFBRSxJQUFJO1lBQ3ZCLElBQUksRUFBRSxVQUFVO1lBQ2hCLE9BQU8sRUFBRSxLQUFLO1lBQ2QsS0FBSyxFQUFFLE1BQU0sQ0FBQyxZQUFZO1lBQzFCLE1BQU0sRUFBRTtnQkFDTixpQ0FBaUM7Z0JBQ2pDLE1BQU0sRUFBRSxLQUFLO2dCQUNiLG9DQUFvQztnQkFDcEMsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsZ0NBQWdDO2dCQUNoQyxJQUFJLEVBQUUsR0FBRztnQkFDVCxnRUFBZ0U7Z0JBQ2hFLE1BQU0sRUFBRSxJQUFJO2FBQ2I7U0FDRixDQUFDO1FBQ0YsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3ZELElBQUksWUFBWSxJQUFJLFlBQVksS0FBSyxXQUFXLElBQUksWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUNoRixjQUFjLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUM7U0FDN0M7UUFFRCxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUM1QiwyQkFBMkI7WUFDM0IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUV4QixTQUFTLENBQUMsR0FBRyxFQUFFO2dCQUNiLG1FQUFtRTtnQkFDbkUsSUFDRSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO29CQUMvQixLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQ3RGO29CQUNBLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7aUJBQ2pDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLEVBQUUsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztRQUN6QyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDekQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBRXpELCtDQUErQztRQUMvQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDekIsZ0RBQWdEO1lBQ2hELE9BQU8sRUFBRSxJQUFJO1lBQ2IsbUNBQW1DO1lBQ25DLEtBQUssRUFBRSxRQUFRO1lBQ2YsdUNBQXVDO1lBQ3ZDLE1BQU0sRUFBRSxJQUFJO1NBQ2IsQ0FBQyxDQUFDLENBQUM7UUFFSixtQ0FBbUM7UUFDbkMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUMsUUFBUSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztRQUVwRCxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsRUFBRTtZQUNqQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUMzQixJQUFJLEdBQUcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxHQUFHLENBQUMsU0FBUyxFQUFFLEVBQUU7b0JBQ3ZDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFFaEM7Ozs7Ozs7dUJBT0c7b0JBQ0gsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFTLElBQUksRUFBRSxJQUFJO3dCQUNqQyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO3dCQUVyRSxJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUU7NEJBQ3JELEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztnQ0FDekIsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHO2dDQUNiLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzs2QkFDdEIsQ0FBQyxDQUFDO3lCQUNKOzZCQUFNOzRCQUNMLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUM3QjtvQkFDSCxDQUFDLENBQUM7aUJBQ0g7YUFDRjtpQkFBTTtnQkFDTCx5Q0FBeUM7Z0JBQ3pDLEdBQUcsQ0FBQyxTQUFTLENBQUMsNkJBQTZCLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDbkQ7WUFFRCxTQUFTLEVBQUUsQ0FBQztRQUNkLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSztRQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN0RCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdELE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuRCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFFdEUscUJBQXFCO1FBQ3JCLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFakQsbUJBQW1CO1lBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUV0QixrQkFBa0I7WUFDbEIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVqRCxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNiLE9BQU87YUFDUjtZQUNELG1DQUFtQztZQUNuQyxPQUFPLFdBQVcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQ2pELDhCQUE4QjtnQkFDOUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzdELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN6RCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDWCw2QkFBNkI7WUFDN0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5QyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNYLE9BQU8sR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUNuRCx1Q0FBdUMsUUFBUSxTQUFTO2dCQUN4RCxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsYUFBYSxTQUFTLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQ25ELENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxjQUFjO1FBQ1osd0NBQXdDO1FBQ3hDLE1BQU0sV0FBVyxHQUFHO1lBQ2xCLE9BQU8sRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQztZQUNyRSxZQUFZLEVBQUU7Z0JBQ1osa0JBQWtCLEVBQUUsY0FBYyxFQUFFLGdCQUFnQixFQUFFLFFBQVEsRUFBRSxlQUFlO2FBQ2hGO1lBQ0QsV0FBVyxFQUFFLElBQUk7U0FDbEIsQ0FBQztRQUVGLGdCQUFnQjtRQUNoQixJQUFJLFdBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDbkQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzlCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQzNCLEdBQUcsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQztTQUN2QzthQUFNLElBQUksV0FBVyxLQUFLLEdBQUcsRUFBRTtZQUM5QixXQUFXLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUMxQixHQUFHLENBQUMsSUFBSSxDQUFDLDJDQUEyQyxDQUFDLENBQUM7U0FDdkQ7YUFBTTtZQUNMLElBQUksT0FBTyxXQUFXLEtBQUssUUFBUSxFQUFFO2dCQUNuQyxXQUFXLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUM3QjtZQUNELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDOUIsV0FBVyxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7Z0JBQ3hCLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzNCLElBQUksQ0FBQyxDQUFDO29CQUNOLElBQUksQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO3dCQUN6RCxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksV0FBVyxDQUFDO3dCQUNuQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7NEJBQ2pCLE1BQU0sT0FBTyxHQUFHLElBQUksTUFBTSxJQUFJLGNBQWMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDOzRCQUNsRixXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO3lCQUM5QztxQkFDRjt5QkFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQUU7d0JBQ3ZDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUVqQzt5QkFBTTt3QkFDTCxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUM7d0JBQzVDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsQ0FBQztxQkFDOUM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsa0NBQWtDO3dCQUN6QyxDQUFDLENBQUMsWUFBWSxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQ3BFLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7YUFDSjtpQkFBTTtnQkFDTCxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQ25CLHVCQUF1QixFQUN2QixzRkFBc0YsQ0FDdkYsQ0FBQzthQUNIO1NBQ0Y7UUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsT0FBTyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSztRQUN6QixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2xGLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFO2dCQUN2QixPQUFPLEVBQUUsQ0FBQztZQUNaLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2pCLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLFlBQVksRUFBRTtvQkFDNUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7b0JBQ3BELE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFDakMsb0JBQW9CLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxHQUFHLElBQUksR0FBRyxvQkFBb0IsQ0FDcEYsQ0FBQyxDQUFDO2lCQUNKO3FCQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxRQUFRLEVBQUU7b0JBQy9DLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLGlCQUFpQixDQUFDLENBQUM7b0JBQzFELE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUN2QyxvQkFBb0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLHVCQUF1Qjt3QkFDdEYsaURBQWlELEdBQUcsSUFBSSxHQUFHLG9CQUFvQixDQUNoRixDQUFDLENBQUM7aUJBQ0o7cUJBQU07b0JBQ0wsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ2hELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDWDtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyJ9