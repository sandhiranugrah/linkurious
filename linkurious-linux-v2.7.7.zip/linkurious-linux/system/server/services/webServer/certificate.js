/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2015-05-07.
 */
'use strict';
// external libs
const Promise = require('bluebird');
const fs = require('fs-extra');
// services
const LKE = require('../index');
const Config = LKE.getConfig();
const Errors = LKE.getErrors();
class Certificate {
    /**
     * @returns {Bluebird<{cert: string, key: string, passphrase: string}>}
     */
    getKeyPair() {
        const certFile = LKE.dataFile(Config.get('server.certificateFile', undefined, true));
        const keyFile = LKE.dataFile(Config.get('server.certificateKeyFile', undefined, true));
        const passphrase = Config.get('server.certificatePassphrase');
        if (!fs.existsSync(certFile)) {
            return Errors.business('invalid_parameter', 'Configuration key "server.certificateFile" refers to an invalid file (' + certFile + ')', true);
        }
        if (!fs.existsSync(keyFile)) {
            return Errors.business('invalid_parameter', 'Configuration key "server.certificateKeyFile" refers to an invalid file (' + keyFile + ')', true);
        }
        return Promise.resolve({
            cert: fs.readFileSync(certFile, { encoding: 'utf8' }),
            key: fs.readFileSync(keyFile, { encoding: 'utf8' }),
            passphrase: passphrase
        });
    }
}
module.exports = new Certificate();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2VydGlmaWNhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zZXJ2ZXIvc2VydmljZXMvd2ViU2VydmVyL2NlcnRpZmljYXRlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsZ0JBQWdCO0FBQ2hCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwQyxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFL0IsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNoQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBRS9CLE1BQU0sV0FBVztJQUNmOztPQUVHO0lBQ0gsVUFBVTtRQUNSLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNyRixNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDdkYsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBRTlELElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzVCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsd0VBQXdFLEdBQUcsUUFBUSxHQUFHLEdBQUcsRUFDekYsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzNCLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFDeEMsMkVBQTJFLEdBQUcsT0FBTyxHQUFHLEdBQUcsRUFDM0YsSUFBSSxDQUNMLENBQUM7U0FDSDtRQUVELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUNyQixJQUFJLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFBQyxRQUFRLEVBQUUsTUFBTSxFQUFDLENBQUM7WUFDbkQsR0FBRyxFQUFFLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBQyxDQUFDO1lBQ2pELFVBQVUsRUFBRSxVQUFVO1NBQ3ZCLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQyJ9