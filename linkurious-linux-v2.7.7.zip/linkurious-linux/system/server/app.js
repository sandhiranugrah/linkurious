"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-11-04.
 */
/**
 * The following exit codes means:
 *  2   Wrong configuration
 *  3   HTTP/HTTPS port is busy or restricted
 *  4   Manually restarted from API (look at `/api/admin/restart`)
 */
// external libs
const Bluebird = require("bluebird");
// services
const LKE = require("./services");
// locals
const Options = require("./options");
class WorkerSignal extends Error {
}
// remove deprecation warning for express-session
// we use our own CookieParser
process.env.NO_DEPRECATION = 'express-session';
/**
 * Resolve when Linkurious is up.
 */
function startApp() {
    // parse command-line options
    const parsedOptions = Options.parse(LKE);
    LKE.init(parsedOptions);
    // configure source-map based error stack trace support
    if (LKE.isDevMode() || LKE.isTestMode()) {
        require('source-map-support').install();
    }
    // configure bluebird
    Bluebird.config({
        // enable cancellation
        cancellation: true,
        // enable long stack traces
        longStackTraces: !!(LKE.isDevMode() || LKE.isTestMode()),
        // note: longStackTraces = true will result in a memory leak
        // due to the use of promise loops in the scheduler service
        // enable monitoring
        monitoring: true,
        // enable all warnings except forgotten return statements
        warnings: {
            wForgottenReturn: false
        }
    });
    // these should never fail
    const Config = LKE.getConfig();
    const Errors = LKE.getErrors();
    const Log = LKE.getLogger(__filename);
    const Utils = LKE.getUtils();
    // services created in init phase
    let StateMachine;
    let Data;
    let Access;
    // init rejects with WorkerSignal if we are a Layout worker
    const init = Bluebird.method(() => {
        // layout cluster init (stop after that if not master)
        const Layout = LKE.getLayout();
        if (!Layout.isMaster) {
            Layout.startWorker();
            throw new WorkerSignal();
        }
        else {
            // load configuration from file
            LKE.getConfig().load();
            // setup a default costumer ID if it's not setup already in the configuration
            if (Utils.noValue(Config.get('customerId'))) {
                Config.set('customerId', Utils.generateUniqueCustomerId());
            }
            Layout.startCluster();
        }
        Log.info('Starting Linkurious ' + LKE.getVersionString());
        StateMachine = LKE.getStateMachine();
        Data = LKE.getData();
        Access = LKE.getAccess();
    });
    return init()
        .then(() => {
        return LKE.getFirstRun().check();
    })
        .then(() => {
        return LKE.getSqlDb().connect();
    })
        .then(() => {
        // register a SIGINT/SIGTERM handler
        process.on('SIGINT', onSignal);
        process.on('SIGTERM', onSignal);
    })
        .then(() => {
        return Access.ensureBuiltinGroups();
    })
        .then(() => {
        return Access.migrateLegacyGroups();
    })
        .then(() => {
        return Access.providersStartupCheck();
    })
        .then(() => {
        return LKE.getWebServer().start();
    })
        .then(() => {
        return Data.migrateStyles();
    })
        .then(() => {
        return LKE.getWidget().migrateWidgets();
    })
        .then(() => {
        return Data.getSourceStates().then(sourceStates => LKE.getGraphQuery().migrateRawQueries(sourceStates));
    })
        .then(() => {
        return LKE.getGraphQuery().migrateQueriesToV2();
    })
        .then(() => {
        return Data.connectSources();
    })
        .then(() => {
        return Data.indexSources(true);
    })
        .then(() => {
        // @backward-compatibility fix matches v2 migration
        return LKE.getAlert().cleanUpDuplicateMatches();
    })
        .then(() => {
        // start the Alert Manager
        return LKE.getAlert().start();
    })
        .catch(WorkerSignal, () => {
        Log.info('Layout worker ready.');
    })
        .catch(Errors.LkError, err => {
        if (StateMachine) {
            StateMachine.set('Linkurious', 'unknown_error');
        }
        if (err && err.isTechnical() && err.stack) {
            Log.error(err.stack);
        }
        else {
            Log.error(err.message);
        }
        if (err && err.key) {
            if (err.key === 'invalid_configuration') {
                process.exit(2);
            }
            else if (err.key === 'port_restricted' || err.key === 'port_busy') {
                process.exit(3);
            }
        }
    })
        .catch(err => {
        if (StateMachine) {
            StateMachine.set('Linkurious', 'unknown_error');
        }
        Log.error(err && err.stack ? err.stack : err.message);
    });
}
/**
 * Clean up open connections and terminate the process.
 */
function onSignal() {
    console.log('Stop signal caught, cleaning up...');
    try {
        LKE.getSqlDb().close();
        LKE.getData().disconnectAll();
    }
    catch (e) {
        // silently ignore
    }
    // we have 3 seconds to clean LKE properly
    Bluebird.delay(3000).then(() => {
        console.log('Stopping.');
        process.exit(0);
    });
}
module.exports = startApp();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc2VydmVyL2FwcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7QUFFSDs7Ozs7R0FLRztBQUVILGdCQUFnQjtBQUNoQixxQ0FBcUM7QUFFckMsV0FBVztBQUNYLGtDQUFtQztBQUVuQyxTQUFTO0FBQ1QscUNBQXNDO0FBRXRDLE1BQU0sWUFBYSxTQUFRLEtBQUs7Q0FBRztBQUVuQyxpREFBaUQ7QUFDakQsOEJBQThCO0FBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLGlCQUFpQixDQUFDO0FBRS9DOztHQUVHO0FBQ0gsU0FBUyxRQUFRO0lBQ2YsNkJBQTZCO0lBQzdCLE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDekMsR0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUV4Qix1REFBdUQ7SUFDdkQsSUFBSSxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksR0FBRyxDQUFDLFVBQVUsRUFBRSxFQUFFO1FBQ3ZDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO0tBQ3pDO0lBRUQscUJBQXFCO0lBQ3JCLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFDZCxzQkFBc0I7UUFDdEIsWUFBWSxFQUFFLElBQUk7UUFFbEIsMkJBQTJCO1FBQzNCLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3hELDREQUE0RDtRQUM1RCwyREFBMkQ7UUFFM0Qsb0JBQW9CO1FBQ3BCLFVBQVUsRUFBRSxJQUFJO1FBRWhCLHlEQUF5RDtRQUN6RCxRQUFRLEVBQUU7WUFDUixnQkFBZ0IsRUFBRSxLQUFLO1NBQ3hCO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsMEJBQTBCO0lBQzFCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUMvQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDL0IsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN0QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7SUFFN0IsaUNBQWlDO0lBQ2pDLElBQUksWUFBaUMsQ0FBQztJQUN0QyxJQUFJLElBQWlCLENBQUM7SUFDdEIsSUFBSSxNQUFxQixDQUFDO0lBRTFCLDJEQUEyRDtJQUMzRCxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtRQUNoQyxzREFBc0Q7UUFDdEQsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO1lBQ3BCLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixNQUFNLElBQUksWUFBWSxFQUFFLENBQUM7U0FDMUI7YUFBTTtZQUNMLCtCQUErQjtZQUMvQixHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFdkIsNkVBQTZFO1lBQzdFLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUU7Z0JBQzNDLE1BQU0sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLENBQUM7YUFDNUQ7WUFFRCxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDdkI7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUM7UUFFMUQsWUFBWSxHQUFHLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUNyQyxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3JCLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDM0IsQ0FBQyxDQUF5QixDQUFDO0lBRTNCLE9BQU8sSUFBSSxFQUFFO1NBQ1YsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUNULE9BQU8sR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ25DLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNsQyxDQUFDLENBQUM7U0FDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1Qsb0NBQW9DO1FBQ3BDLE9BQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQy9CLE9BQU8sQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ2xDLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ3RDLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ3RDLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQ3hDLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNwQyxDQUFDLENBQUM7U0FDRCxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1QsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDOUIsQ0FBQyxDQUFDO1NBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUNULE9BQU8sR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFDLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FDaEQsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxDQUNwRCxDQUFDO0lBQ0osQ0FBQyxDQUFDO1NBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUNULE9BQU8sR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDbEQsQ0FBQyxDQUFDO1NBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUNULE9BQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQy9CLENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakMsQ0FBQyxDQUFDO1NBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUNULG1EQUFtRDtRQUNuRCxPQUFPLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2xELENBQUMsQ0FBQztTQUNELElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDVCwwQkFBMEI7UUFDMUIsT0FBTyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDaEMsQ0FBQyxDQUFDO1NBQ0QsS0FBSyxDQUFDLFlBQVksRUFBRSxHQUFHLEVBQUU7UUFDeEIsR0FBRyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0lBQ25DLENBQUMsQ0FBQztTQUNELEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxFQUFFO1FBQzNCLElBQUksWUFBWSxFQUFFO1lBQ2hCLFlBQVksQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQ2pEO1FBQ0QsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLFdBQVcsRUFBRSxJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7WUFDekMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDdEI7YUFBTTtZQUNMLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRTtZQUNsQixJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssdUJBQXVCLEVBQUU7Z0JBQ3ZDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDakI7aUJBQU0sSUFBSSxHQUFHLENBQUMsR0FBRyxLQUFLLGlCQUFpQixJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO2dCQUNuRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2pCO1NBQ0Y7SUFDSCxDQUFDLENBQUM7U0FDRCxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDWCxJQUFJLFlBQVksRUFBRTtZQUNoQixZQUFZLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxlQUFlLENBQUMsQ0FBQztTQUNqRDtRQUNELEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN4RCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMsUUFBUTtJQUNmLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztJQUNsRCxJQUFJO1FBQ0YsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3ZCLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztLQUMvQjtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1Ysa0JBQWtCO0tBQ25CO0lBRUQsMENBQTBDO0lBQzFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBR0QsaUJBQVMsUUFBUSxFQUFFLENBQUMifQ==