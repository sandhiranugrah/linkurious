"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
// services
const LKE = require("../services/index");
const Access = LKE.getAccess();
const Utils = LKE.getUtils();
const Data = LKE.getData();
const DataProxy = LKE.getDataProxy();
// locals
const SearchOptions = require("../lib/validators/SearchOptions");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {get} /api/:dataSource/search/reindex Run the indexation
     * @apiName SearchReIndex
     * @apiGroup Search
     * @apiPermission authenticated
     * @apiPermission action:admin.index
     * @apiPermission apiright:admin.index
     *
     * @apiDescription Reindex the graph database.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.get('/api/:dataSource/search/reindex', api.respond((req) => {
        return DataProxy.asyncIndexSource(req.param('dataSource'), Access.getUserCheck(req, 'admin.index'));
    }, 204));
    /**
     * @api {get} /api/:dataSource/search/status Get the indexation status
     * @apiName SearchStatus
     * @apiGroup Search
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Get the indexation status for a given data-source.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccess {string="ongoing","needed","done","unknown"} indexing The status of the indexation
     * @apiSuccess {string} indexing_progress Percentage of the indexation (`null` if indexing is not ongoing)
     * @apiSuccess {number} node_count        Number of nodes in the graph database (`null` if indexing is not ongoing)
     * @apiSuccess {number} edge_count        Number of edges in the graph database (`null` if indexing is not ongoing)
     * @apiSuccess {number} index_size        Number of nodes and edges in the index (`null` if indexing is not ongoing)
     * @apiSuccess {string} indexed_source    Key of the data-source (`null` if indexing is not ongoing)
     * @apiSuccess {string} indexing_status   A human readable string describing the indexation status
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "indexing": "ongoing",
     *     "indexing_progress": "62.55",
     *     "indexing_status": "Currently indexing 12375 nodes/s. Time left: 25 seconds.",
     *     "node_count": 10,
     *     "edge_count": 25,
     *     "index_size": 19,
     *     "indexed_source": "c1d3fe"
     *   }
     */
    app.get('/api/:dataSource/search/status', api.respond((req) => {
        Access.getUserCheck(req, 'graphItem.search');
        return Data.resolveSource(req.param('dataSource')).getSearchStatus();
    }));
    /**
     * @api {get|post} /api/:dataSource/search/:type Search nodes or edges
     * @apiName SearchNodesOrEdges
     * @apiGroup Search
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * The list of items that matched the search query is returned.
     *
     * @apiParam {string}                 dataSource          Key of the data-source
     * @apiParam {string="nodes","edges"} type                The item type to search
     * @apiParam {string}                 q                   Search query
     * @apiParam {number{0-1}}            [fuzziness]         Fuzziness value (`0` means exact match, `1` completely fuzzy)
     * @apiParam {number{1-}}             [size]              Page size (maximum number of returned items)
     * @apiParam {number{0-}}             [from]              Offset from the first result
     * @apiParam {string[]}               [categoriesOrTypes] Exclusive list of edge types or node categories to restrict the search on (use `[no_category]` to search nodes with no categories)
     * @apiParam {string[][]}             [filter]            Array of pairs key-value used to filter the result. The keys represent object properties and the values that should match for each property
     *
     * @apiSuccess {string="node","edge"} type          The item type given in input
     * @apiSuccess {number}               [totalHits]   The total number of matching items (not guaranteed to be available)
     * @apiSuccess {boolean}              [moreResults] If `totalHits` is `undefined`, `moreResults` will indicate
     *                                                  if there are more items or not that can be retrieved
     *                                                  (`undefined` if `totalHits` is returned)
     * @apiSuccess {object[]}             results       Nodes or edges that matched the search query
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "type": "node",
     *     "totalHits": 3,
     *     "results": [
     *       {
     *         "id": 123,
     *         "data": {
     *           "name": "Matrix",
     *           "released": 1999
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       },
     *       {
     *         "id": 124,
     *         "data": {
     *           "name": "Matrix Reloaded",
     *           "released": 2003
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       },
     *       {
     *         "id": 125,
     *         "data": {
     *           "name": "Matrix Revolutions",
     *           "released": 2003
     *         },
     *         "categories": [
     *           "Movie"
     *         ],
     *         "readAt": 692362800000
     *       }
     *     ]
     *   }
     */
    const searchHandler = api.respond((req) => {
        return DataProxy.searchIndex(SearchOptions.parse(req), req.param('dataSource'), {}, Access.getUserCheck(req, 'graphItem.search', true));
    });
    app.get('/api/:dataSource/search/:type', searchHandler);
    app.post('/api/:dataSource/search/:type', searchHandler);
    /**
     * @api {get|post} /api/:dataSource/search/:type/full Search subgraph
     * @apiName SearchSubGraph
     * @apiGroup Search
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.search
     *
     * @apiDescription Perform a search of nodes or edges based on a search query, a fuzziness value and filters.
     * A subgraph made of the items that matched the search query and the edges between them is returned.
     *
     * @apiParam {string}                 dataSource          Key of the data-source
     * @apiParam {string="nodes","edges"} type                The item type to search
     * @apiParam {string}                 q                   Search query
     * @apiParam {number{0-1}}            [fuzziness]         Fuzziness value (`0` means exact match, `1` completely fuzzy)
     * @apiParam {number{1-}}             [size]              Page size (maximum number of returned items)
     * @apiParam {number{0-}}             [from]              Offset from the first result
     * @apiParam {string[]}               [categoriesOrTypes] Exclusive list of edge types or node categories to restrict the search on (use `[no_category]` to search nodes with no categories)
     * @apiParam {string[][]}             [filter]            Array of pairs key-value used to filter the result. The keys represent object properties and the values that should match for each property
     * @apiParam {string[]}               [edgesTo]           IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}                [withDigest=false]  Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}                [withDegree=false]  Whether to include the degree in the returned nodes
     * @apiParam {boolean}                [withAccess=false]  Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
     *
     * @apiUse ReturnSubGraph
     */
    const searchFullHandler = api.respond((req) => {
        return DataProxy.searchFull(SearchOptions.parse(req), req.param('dataSource'), {
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree')),
            edgesTo: Utils.parseStringArray(req.param('edgesTo'))
        }, Access.getUserCheck(req, 'graphItem.search', true));
    });
    app.get('/api/:dataSource/search/:type/full', searchFullHandler);
    app.post('/api/:dataSource/search/:type/full', searchFullHandler);
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VhcmNoLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9zZWFyY2gudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBRXJDLFNBQVM7QUFDVCxpRUFBa0U7QUFDbEUsaURBQWtEO0FBRWxELGlCQUFTLENBQUMsR0FBdUIsRUFBUSxFQUFFO0lBQ3pDOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCxpQ0FBaUMsRUFDakMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FDL0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQ3hDLENBQUM7SUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E4Qkc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLGdDQUFnQyxFQUNoQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFDN0MsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUNqRixDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FtRUc7SUFDSCxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ3pELE9BQU8sU0FBUyxDQUFDLFdBQVcsQ0FDMUIsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFDeEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakMsRUFBRSxFQUNGLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksQ0FBQyxDQUNuRCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3hELEdBQUcsQ0FBQyxJQUFJLENBQUMsK0JBQStCLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFFekQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXdCRztJQUNILE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUM3RCxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQ3pCLGFBQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQ3hCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXLEVBQ2pDO1lBQ0UsVUFBVSxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN2RCxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELE9BQU8sRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUN0RCxFQUNELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksQ0FBQyxDQUNuRCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxFQUFFLGlCQUFpQixDQUFDLENBQUM7SUFDakUsR0FBRyxDQUFDLElBQUksQ0FBQyxvQ0FBb0MsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyJ9