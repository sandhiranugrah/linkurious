"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
// services
const LKE = require("../services/index");
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
const DataProxy = LKE.getDataProxy();
// locals
const LkNodeAttributes = require("../lib/validators/LkNodeAttributes");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {get} /api/:dataSource/graph/nodes/count Get nodes count
     * @apiName GetNodesCount
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the number of nodes in the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccess {number} count The number of nodes
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "count": 42
     *   }
     */
    app.get('/api/:dataSource/graph/nodes/count', api.respond((req) => {
        return DataProxy.getNodeCount(req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true)).then(count => ({ count: count }));
    }));
    /**
     * @api {get|post} /api/:dataSource/graph/nodes/expand Get adjacent nodes and edges
     *
     * @apiName GetAdjacentGraph
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get all the adjacent nodes and edges to one or more source nodes (`ids`).
     * A subgraph made of the items that matched the expand query and the edges between them is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string[]} ids                IDs of the nodes to retrieve the neighbors for
     * @apiParam {number}   [limit]            Maximum number of returned nodes
     * @apiParam {string="id","highestDegree","lowestDegree"} [limitType="id"] Order direction used to limit the result
     * @apiParam {string}   [nodeCategories]   Exclusive list of node categories to restrict the result (use `[no_category]` to expand nodes with no categories)
     * @apiParam {string}   [edgeTypes]        Exclusive list of edge types to restrict the result
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     * @apiParam {boolean}  [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
     *
     * @apiUse ReturnSubGraph
     */
    const expandHandler = api.respond((req) => {
        return DataProxy.getAdjacentNodes(Utils.tryParseStringArray(req.param('ids'), 'ids'), {
            limit: Utils.parseInt(req.param('limit')),
            limitType: Utils.parseString(req.param('limitType')),
            nodeCategories: Utils.parseStringArray(req.param('nodeCategories')),
            edgeTypes: Utils.parseStringArray(req.param('edgeTypes')),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/nodes/expand', expandHandler);
    app.post('/api/:dataSource/graph/nodes/expand', expandHandler);
    /**
     * @api {get|post} /api/:dataSource/graph/nodes/:id Get a node
     * @apiName GetNode
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get a node of the graph.
     * A subgraph made of the single node is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string}   id                 ID of the node
     * @apiParam {string}   [alternativeId]    The property to match `id` on (instead of the actual ID)
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     * @apiParam {boolean}  [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
     *
     * @apiUse ReturnSubGraph
     */
    const getNodeHandler = api.respond((req) => {
        return DataProxy.getNode({
            sourceKey: req.param('dataSource'),
            id: req.param('id'),
            alternativeId: Utils.parseString(req.param('alternativeId')),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/nodes/:id', getNodeHandler);
    app.post('/api/:dataSource/graph/nodes/:id', getNodeHandler);
    /**
     * @api {post} /api/:dataSource/graph/neighborhood/statistics Get statistics of adjacent nodes
     * @apiName GetNeighborsStatistics
     * @apiGroup Nodes
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the digest (the number of adjacent nodes and edges grouped by node categories and edge types)
     * and/or the degree of a given subset of nodes (`ids`).
     * You can't get aggregated statistics of a subset of nodes containing one or more supernodes.
     * To get the statistics of a supernode invoke the API with only its node ID.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string[]} ids                IDs of the nodes
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     *
     * @apiSuccess {type:LkDigestItem[]} [digest] Statistics of the neighborhood of the nodes
     * @apiSuccess {number}              [degree] Number of neighbors of the nodes readable by the current user
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "digest": [
     *       {
     *         "edgeType": "ACTED_IN",
     *         "nodeCategories": [
     *           "TheMatrix",
     *           "Movie"
     *         ],
     *         "nodes": 1,
     *         "edges": 1
     *       }
     *     ],
     *     "degree": 1
     *   }
     */
    app.post('/api/:dataSource/graph/neighborhood/statistics', api.respond((req) => {
        return DataProxy.getStatistics(Utils.tryParseStringArray(req.param('ids'), 'ids'), req.param('dataSource'), {
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    }));
    /**
     * @api {post} /api/:dataSource/graph/nodes Create a node
     * @apiName PostNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.create
     *
     * @apiDescription Add a node to the graph.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {object}   [properties]       Properties of the node
     * @apiParam {string[]} [categories]       Categories of the node
     * @apiParam {boolean}  [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node statistics
     *
     * @apiUse ReturnNodeOnCreate
     */
    app.post('/api/:dataSource/graph/nodes', api.respond((req) => {
        return DataProxy.createNode(LkNodeAttributes.parse(req), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.create'));
    }, 201));
    /**
     * @api {patch} /api/:dataSource/graph/nodes/:id Update a node
     * @apiName PatchNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.edit
     *
     * @apiDescription Update a subset of properties and categories of a node. Keep every other property and category of the node unchanged.
     *
     * @apiParam {string}   dataSource          Key of the data-source
     * @apiParam {string}   id                  ID of the node to update
     * @apiParam {object}   [properties]        Properties to update or create
     * @apiParam {string[]} [deletedProperties] Properties to delete
     * @apiParam {string[]} [addedCategories]   Categories of the node to add
     * @apiParam {string[]} [deletedCategories] Categories of the node to delete
     * @apiParam {number}   [readAt]            Read timestamp in epoch time
     *
     * @apiUse ReturnNodeOnUpdate
     */
    app.patch('/api/:dataSource/graph/nodes/:id', api.respond((req) => {
        return DataProxy.updateNode(req.param('id'), {
            data: Utils.parseObject(req.param('properties')),
            readAt: Utils.tryParsePosInt(req.param('readAt'), 'readAt', true),
            deletedProperties: Utils.parseStringArray(req.param('deletedProperties')),
            addedCategories: Utils.parseStringArray(req.param('addedCategories')),
            deletedCategories: Utils.parseStringArray(req.param('deletedCategories'))
        }, req.param('dataSource'), Access.getUserCheck(req, 'graphItem.edit'));
    }));
    /**
     * @api {delete} /api/:dataSource/graph/nodes/:id Delete a node
     * @apiName DeleteNode
     * @apiGroup Nodes
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.delete
     *
     * @apiDescription Delete a node and its adjacent edges from the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string} id         ID of the node to delete
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:dataSource/graph/nodes/:id', api.respond((req) => {
        return DataProxy.deleteNode(req.param('id'), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.delete'));
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhOb2RlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9ncmFwaE5vZGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFFckMsU0FBUztBQUNULHVFQUF3RTtBQUN4RSxpREFBa0Q7QUErSmxELGlCQUFTLENBQUMsR0FBdUIsRUFBUSxFQUFFO0lBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FrQkc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLG9DQUFvQyxFQUNwQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE9BQU8sU0FBUyxDQUFDLFlBQVksQ0FDM0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQ2pELENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXVCRztJQUNILE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDekQsT0FBTyxTQUFTLENBQUMsZ0JBQWdCLENBQy9CLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUNsRDtZQUNFLEtBQUssRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDekMsU0FBUyxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNwRCxjQUFjLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUNuRSxTQUFTLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3JELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdkQsVUFBVSxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUN4RCxFQUNELEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXLEVBRWpDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUNqRCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQzlELEdBQUcsQ0FBQyxJQUFJLENBQUMscUNBQXFDLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFFL0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FtQkc7SUFDSCxNQUFNLGNBQWMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQzFELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FDdEI7WUFDRSxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVc7WUFDNUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFXO1lBQzdCLGFBQWEsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDNUQsT0FBTyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3JELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdkQsVUFBVSxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUN4RCxFQUNELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUNqRCxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBQzVELEdBQUcsQ0FBQyxJQUFJLENBQUMsa0NBQWtDLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFFN0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQW9DRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sZ0RBQWdELEVBQ2hELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsYUFBYSxDQUM1QixLQUFLLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsRUFDbEQsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakM7WUFDRSxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDeEQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUNOLDhCQUE4QixFQUM5QixHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE9BQU8sU0FBUyxDQUFDLFVBQVUsQ0FDekIsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUMzQixHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBVyxFQUNqQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxDQUM3QyxDQUFDO0lBQ0osQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0JHO0lBQ0gsR0FBRyxDQUFDLEtBQUssQ0FDUCxrQ0FBa0MsRUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQ3pCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFXLEVBQ3pCO1lBQ0UsSUFBSSxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNoRCxNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUM7WUFDakUsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUN6RSxlQUFlLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUNyRSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1NBQzFFLEVBQ0QsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FDM0MsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxNQUFNLENBQ1Isa0NBQWtDLEVBQ2xDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsVUFBVSxDQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBVyxFQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBVyxFQUNqQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxrQkFBa0IsQ0FBQyxDQUM3QyxDQUFDO0lBQ0osQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7QUFDSixDQUFDLENBQUMifQ==