"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-01-24.
 */
// services
const LKE = require("../services/index");
const DataProxy = LKE.getDataProxy();
const GraphQuery = LKE.getGraphQuery();
// locals
const graphParams_1 = require("../models/parameters/graphParams");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {post} /api/:dataSource/graph/check/query Check a graph query
     * @apiName CheckGraphQuery
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:rawReadQuery
     * @apiPermission apiright:graph.rawRead
     *
     * @apiDescription Check that the given graph query is syntactically correct. Parse the query if it's a template.
     *
     * @apiUse DataSourceParams
     * @apiUse CheckGraphQueryParams
     *
     * @apiUse CheckGraphQueryResponse
     */
    app.post('/api/:dataSource/graph/check/query', api.respond((req) => {
        const params = new graphParams_1.CheckGraphQueryParams().fromRequest(req);
        // @ts-ignore DataProxy option wrapped user should be optional
        return DataProxy.checkGraphQuery(params, req.wrappedUser);
    }));
    /**
     * @api {post} /api/:dataSource/graph/run/query Execute a graph query
     * @apiName RunGraphQueryByContent
     * @apiGroup Graph
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:graph.raw(Read|Write)
     *
     * @apiDescription Get all the nodes and edges matching the given graph query.
     * A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse RunGraphQueryByContentParams
     * @apiUse RunGraphQueryParams
     * @apiUse GraphParams
     *
     * @apiUse RunGraphQueryResponse
     */
    app.post('/api/:dataSource/graph/run/query', api.respond((req) => {
        const params = new graphParams_1.RunGraphQueryByContentParams().fromRequest(req);
        // @ts-ignore DataProxy option wrapped user should be optional
        return DataProxy.runGraphQueryByContent(params, req.wrappedUser);
    }));
    /**
     * @api {post} /api/:dataSource/graph/run/query/:id Execute a graph query by ID
     * @apiName RunGraphQueryById
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:graph.runQuery
     * @apiPermission apiright:savedGraphQuery.read
     *
     * @apiDescription Get all the nodes and edges matching the given saved graph query by ID.
     * A subgraph made of all the nodes and the edges from each subgraph matching the graph query is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse RunGraphQueryByIdParams
     * @apiUse RunGraphQueryParams
     * @apiUse GraphParams
     *
     * @apiUse RunGraphQueryResponse
     */
    app.post('/api/:dataSource/graph/run/query/:id', api.respond((req) => {
        const params = new graphParams_1.RunGraphQueryByIdParams().fromRequest(req);
        return GraphQuery.runGraphQueryById(params, req.wrappedUser);
    }));
    /**
     * @api {post} /api/:dataSource/graph/alertPreview Preview an alert
     * @apiName AlertPreview
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:admin.alerts
     * @apiPermission apiright:admin.alerts
     *
     * @apiDescription Get all the nodes and edges matching the given graph query.
     * An array of subgraphs, one for each subgraph matching the graph query, is returned.
     *
     * @apiUse DataSourceParams
     * @apiUse AlertPreviewParams
     *
     * @apiUse AlertPreviewResponse
     */
    app.post('/api/:dataSource/graph/alertPreview', api.respond((req) => {
        const params = new graphParams_1.AlertPreviewParams().fromRequest(req);
        // @ts-ignore DataProxy option wrapped user should be optional
        return DataProxy.alertPreview(params, req.wrappedUser);
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2dyYXBoLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztBQUV2QyxTQUFTO0FBQ1Qsa0VBSzBDO0FBQzFDLGlEQUFrRDtBQUVsRCxpQkFBUyxDQUFDLEdBQXVCLEVBQVEsRUFBRTtJQUN6Qzs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sb0NBQW9DLEVBQ3BDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcsSUFBSSxtQ0FBcUIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1RCw4REFBOEQ7UUFDOUQsT0FBTyxTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDNUQsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FDTixrQ0FBa0MsRUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLDBDQUE0QixFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ25FLDhEQUE4RDtRQUM5RCxPQUFPLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ25FLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Ba0JHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FDTixzQ0FBc0MsRUFDdEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLHFDQUF1QixFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlELE9BQU8sVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDL0QsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04scUNBQXFDLEVBQ3JDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcsSUFBSSxnQ0FBa0IsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6RCw4REFBOEQ7UUFDOUQsT0FBTyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDekQsQ0FBQyxDQUFDLENBQ0gsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9