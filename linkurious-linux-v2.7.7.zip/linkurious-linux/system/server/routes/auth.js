/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
'use strict';
// external libs
const _ = require('lodash');
const Promise = require('bluebird');
// services
const LKE = require('../services/index');
const Access = LKE.getAccess();
const Utils = LKE.getUtils();
const UserDAO = LKE.getUserDAO();
// locals
const api = require('../services/webServer/api');
module.exports = function (app) {
    /**
     * @api {post} /api/auth/login Login
     * @apiName Login
     * @apiGroup Auth
     *
     * @apiDescription Log a user in by e-mail or username and password and return it.
     *
     * @apiParam {string} usernameOrEmail User e-mail or username
     * @apiParam {string} password        User password
     *
     * @apiUse ReturnUser
     */
    app.post('/api/auth/login', api.respond(req => {
        return Access.login(req.param('usernameOrEmail'), req.param('password'), req);
    }, 200));
    /**
     * @api {post} /api/auth/loginRedirect Login and redirect
     * @apiName LoginRedirect
     * @apiGroup Auth
     *
     * @apiDescription Log a user in by e-mail or username and password and redirect it to a given path.
     *
     * @apiParam {string} usernameOrEmail  User e-mail or username
     * @apiParam {string} password         User password
     * @apiParam {string} [path="/"]       Path to redirect to
     * @apiParam {string} [errorPath=path] Path to redirect to in case of error
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 302 Redirect
     *   Location: /
     */
    app.post('/api/auth/loginRedirect', api.respond((req, res) => {
        let path = req.param('path');
        if (Utils.noValue(path)) {
            path = '/';
        }
        let errorPath = req.param('errorPath');
        if (Utils.noValue(errorPath)) {
            errorPath = path;
        }
        return Access.login(req.param('usernameOrEmail'), req.param('password'), req).return(path).catch(err => {
            // in case of error
            res.setHeader('Error', JSON.stringify(err));
            return errorPath;
        });
    }, 302, false, true));
    /**
     * @api {get} /api/auth/logout Logout
     * @apiName Logout
     * @apiGroup Auth
     *
     * @apiDescription Log the current user out.
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.get('/api/auth/logout', api.respond(req => {
        return Access.logout(req);
    }, 204));
    /**
     * @api {get} /api/auth/authenticated Check if authenticated
     * @apiName IsAuthenticated
     * @apiGroup Auth
     *
     * @apiDescription Check if a user is authenticated.
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     *
     * @apiErrorExample {json} Error-Response:
     *   HTTP/1.1 401 Unauthorized
     *   {
     *     "key": "unauthorized",
     *     "message": "Unauthorized."
     *   }
     *
     */
    app.get('/api/auth/authenticated', api.respond(req => {
        return Access.isAuthenticated(req);
    }, 204));
    /**
     * @api {get} /api/auth/me Get current user
     * @apiName GetCurrentUser
     * @apiGroup Auth
     * @apiPermission guest_user
     *
     * @apiDescription Get the profile of the current user.
     *
     * @apiUse ReturnUser
     *
     * @apiErrorExample {json} Error-Response:
     *   HTTP/1.1 401 Unauthorized
     *   {
     *     "key": "unauthorized",
     *     "message": "Unauthorized."
     *   }
     */
    app.get('/api/auth/me', api.respond(req => {
        // every user, including apps and guest user can retrieve its own user profile
        const publicUser = Access.getCurrentUser(req);
        // req.user contains the access rights, we want to filter them out
        publicUser.groups = publicUser.groups.map(group => /**@type {PublicGroup}*/ (_.pick(group, ['id', 'name', 'builtin', 'sourceKey'])));
        return Promise.resolve(publicUser);
    }));
    /**
     * @api {patch} /api/auth/me Update current user
     * @apiName UpdateCurrentUser
     * @apiGroup Auth
     * @apiPermission authenticated
     *
     * @apiDescription Update the current user.
     *
     * @apiParam {string} [username]    New username
     * @apiParam {string} [email]       New e-mail
     * @apiParam {string} [password]    New password
     * @apiParam {object} [preferences] New user preferences
     *
     * @apiUse ReturnUser
     */
    app.patch('/api/auth/me', api.respond(req => {
        // check we are not an application or the guest user
        const user = Access.getUserCheck(req);
        return UserDAO.updateUser(user.id, {
            username: req.param('username'),
            email: req.param('email'),
            password: req.param('password'),
            preferences: req.param('preferences')
        }, user);
    }));
    /**
     * @api {get} /api/auth/sso/login Login via OAuth2 or SAML2
     * @apiName LoginSSO
     * @apiGroup Auth
     *
     * @apiDescription Redirect the user to the OAuth2 or SAML2 provider for authorization.
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 302 Redirect
     */
    app.get('/api/auth/sso/login', api.respond(req => {
        return Access.getAuthenticateURLSSO(req);
    }, 302));
    /**
     * @apiIgnore This API is not shown in the API documentation because it's meant to be called only by the OAuth2/SAML2 provider
     * @api {all} /api/auth/sso/return Login via OAuth2 or SAML2 (return callback)
     * @apiName LoginReturnSSO
     * @apiGroup Auth
     *
     * @apiDescription Log a user in via OAuth2 or SAML2 (to be called only after a redirection from
     * the OAuth2/SAML2 provider). It's a GET for OAuth2 and a POST for SAML2.
     *
     * @apiParam {string} [code]         Response by the OAuth2 provider
     * @apiParam {string} [state]        State used by the OAuth2 provider
     * @apiParam {string} [SAMLResponse] Response by the SAML2 provider
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 302 Redirect
     */
    app.all('/api/auth/sso/return', api.respond(req => {
        return Access.handleAuthenticateURLResponseSSO(req.param('code') || req.param('SAMLResponse'), req.param('state'), req).return('/');
    }, 302));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9yb3V0ZXMvYXV0aC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7O0dBR0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUVwQyxXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUM7QUFFakMsU0FBUztBQUNULE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBRWpELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxHQUFHO0lBQzNCOzs7Ozs7Ozs7OztPQVdHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzVDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FDakIsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxFQUM1QixHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUNyQixHQUFHLENBQ0osQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBRVQ7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQzNELElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQUUsSUFBSSxHQUFHLEdBQUcsQ0FBQztTQUFFO1FBRXhDLElBQUksU0FBUyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDdkMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQUUsU0FBUyxHQUFHLElBQUksQ0FBQztTQUFFO1FBRW5ELE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FDakIsR0FBRyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxFQUM1QixHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUNyQixHQUFHLENBQ0osQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3pCLG1CQUFtQjtZQUNuQixHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDNUMsT0FBTyxTQUFTLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRXRCOzs7Ozs7Ozs7T0FTRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUM1QyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDNUIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFVDs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FpQkc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDbkQsT0FBTyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3JDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBRVQ7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnQkc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3hDLDhFQUE4RTtRQUM5RSxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTlDLGtFQUFrRTtRQUNsRSxVQUFVLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUN2QyxLQUFLLENBQUMsRUFBRSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQzFGLENBQUM7UUFFRixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUMxQyxvREFBb0Q7UUFDcEQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN0QyxPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQ3ZCLElBQUksQ0FBQyxFQUFFLEVBQ1A7WUFDRSxRQUFRLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7WUFDL0IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQ3pCLFFBQVEsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztZQUMvQixXQUFXLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUM7U0FDdEMsRUFDRCxJQUFJLENBQ0wsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7O09BU0c7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDL0MsT0FBTyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDM0MsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFVDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEQsT0FBTyxNQUFNLENBQUMsZ0NBQWdDLENBQzVDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFDOUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFDbEIsR0FBRyxDQUNKLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2hCLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDIn0=