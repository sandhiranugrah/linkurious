/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2018-09-20.
 */
'use strict';
// services
const LKE = require('../services/index');
const Access = LKE.getAccess();
const CustomFileService = LKE.getCustomFile();
// locals
const api = require('../services/webServer/api');
module.exports = function (app) {
    app.all('/api/customFiles*', api.proxy(req => {
        return Access.isAuthenticated(req);
    }));
    /**
     * @api {get} /api/customFiles Get the list of custom files
     * @apiName CustomFiles
     * @apiGroup Linkurious
     * @apiPermission authenticated
     *
     * @apiDescription List all custom files in the specified root directory.
     *
     * @apiParam {string} [root="."]   Root directory of the files to be listed
     * @apiParam {string} [extensions] Comma separated list of file extensions to filter the results (e.g: `png,gif,jpg,jpeg`)
     *
     * @apiSuccess {object[]} results      The list of custom files
     * @apiSuccess {string}   results.path The URL path of the file
     * @apiSuccess {string}   results.name The path to the file relative to `root` and separated by `>`
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "results": [
     *       {
     *         "path": "/myImages/ball.png",
     *         "name": "ball"
     *       },
     *       {
     *         "path": "/myImages/illustrations/Le_college_fou_fou_fou.jpg",
     *         "name": "illustrations > Le_college_fou_fou_fou"
     *       },
     *       {
     *         "path": "/myImages/illustrations/black-panther.jpg",
     *         "name": "illustrations > black-panther"
     *       },
     *       {
     *         "path": "/myImages/illustrations/house.png",
     *         "name": "illustrations > house"
     *       },
     *       {
     *         "path": "/myImages/illustrations/trump.jpg",
     *         "name": "illustrations > trump"
     *       }
     *      ]
     *    }
     */
    app.get('/api/customFiles', api.respond(req => {
        return CustomFileService.list(req.param('root'), req.param('extensions')).then(customFiles => ({ results: customFiles }));
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tRmlsZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2N1c3RvbUZpbGVzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztHQUtHO0FBQ0gsWUFBWSxDQUFDO0FBRWIsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3pDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztBQUU5QyxTQUFTO0FBQ1QsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLDJCQUEyQixDQUFDLENBQUM7QUFFakQsTUFBTSxDQUFDLE9BQU8sR0FBRyxVQUFTLEdBQUc7SUFDM0IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzNDLE9BQU8sTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUo7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BeUNHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzVDLE9BQU8saUJBQWlCLENBQUMsSUFBSSxDQUMzQixHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUNqQixHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUN4QixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxPQUFPLEVBQUUsV0FBVyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMifQ==