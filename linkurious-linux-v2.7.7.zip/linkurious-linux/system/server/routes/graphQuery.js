"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2019-01-22.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// services
const LKE = require("../services/index");
const GraphQueryService = LKE.getGraphQuery();
// locals
const graphQueryParams_1 = require("../models/parameters/graphQueryParams");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {post} /api/:dataSource/graph/query Create a graph query
     * @apiName CreateGraphQuery
     * @apiGroup Graph
     * @apiPermission authenticated
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:savedGraphQuery.create
     * @apiDescription Create a graph query for the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse CreateGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.post('/api/:dataSource/graph/query', api.respond((req) => {
        const params = new graphQueryParams_1.CreateGraphQueryParams().fromRequest(req);
        return GraphQueryService.createGraphQuery(params, req.wrappedUser);
    }, 201));
    /**
     * @api {get} /api/:dataSource/graph/query Get all graph queries
     * @apiName GetAllGraphQueries
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:savedGraphQuery.read
     * @apiDescription Get all the graph queries owned by the current user or shared with it.
     *
     * @apiUse DataSourceParams
     * @apiUse GetAllGraphQueriesParams
     *
     * @apiUse GetAllGraphQueriesResponse
     */
    app.get('/api/:dataSource/graph/query', api.respond((req) => {
        const params = new graphQueryParams_1.GetAllGraphQueriesParams().fromRequest(req);
        return GraphQueryService.getAllGraphQueries(params, req.wrappedUser);
    }));
    /**
     * @api {get} /api/:dataSource/graph/query/:id Get a graph query
     * @apiName GetGraphQuery
     * @apiGroup Graph
     * @apiPermission guest_user
     * @apiPermission action:runQuery
     * @apiPermission apiright:savedGraphQuery.read
     * @apiDescription Get a graph query owned by the current user or shared with it.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.get('/api/:dataSource/graph/query/:id', api.respond((req) => {
        const params = new graphQueryParams_1.GetGraphQueryParams().fromRequest(req);
        return GraphQueryService.getGraphQuery(params, req.wrappedUser);
    }));
    /**
     * @api {delete} /api/:dataSource/graph/query/:id Delete a graph query
     * @apiName DeleteGraphQuery
     * @apiGroup Graph
     * @apiPermission owner
     * @apiPermission apiright:savedGraphQuery.delete
     * @apiDescription Delete a graph query owned by the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse GetGraphQueryParams
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:dataSource/graph/query/:id', api.respond((req) => {
        const params = new graphQueryParams_1.DeleteGraphQueryParams().fromRequest(req);
        return GraphQueryService.deleteGraphQuery(params, req.wrappedUser);
    }, 204));
    /**
     * @api {patch} /api/:dataSource/graph/query/:id Update a graph query
     * @apiName UpdateGraphQuery
     * @apiGroup Graph
     * @apiPermission owner
     * @apiPermission action:raw(Read|Write)Query
     * @apiPermission apiright:savedGraphQuery.edit
     * @apiDescription Update a graph query owned by the current user.
     *
     * @apiUse DataSourceParams
     * @apiUse UpdateGraphQueryParams
     *
     * @apiUse GraphQueryResponse
     */
    app.patch('/api/:dataSource/graph/query/:id', api.respond((req) => __awaiter(this, void 0, void 0, function* () {
        const params = yield new graphQueryParams_1.UpdateGraphQueryParams().fromRequest(req);
        return GraphQueryService.updateGraphQuery(params, req.wrappedUser);
    })));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhRdWVyeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9yb3V0ZXMvZ3JhcGhRdWVyeS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7O0dBS0c7Ozs7Ozs7OztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7QUFFOUMsU0FBUztBQUNULDRFQU0rQztBQUMvQyxpREFBa0Q7QUFFbEQsaUJBQVMsQ0FBQyxHQUF1QixFQUFRLEVBQUU7SUFDekM7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sOEJBQThCLEVBQzlCLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcsSUFBSSx5Q0FBc0IsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RCxPQUFPLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDckUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUNSLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCw4QkFBOEIsRUFDOUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLDJDQUF3QixFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQy9ELE9BQU8saUJBQWlCLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN2RSxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsa0NBQWtDLEVBQ2xDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsTUFBTSxNQUFNLEdBQUcsSUFBSSxzQ0FBbUIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxRCxPQUFPLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ2xFLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7OztPQWFHO0lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FDUixrQ0FBa0MsRUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLHlDQUFzQixFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdELE9BQU8saUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNyRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUNQLGtDQUFrQyxFQUNsQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQU8sR0FBb0IsRUFBRSxFQUFFO1FBQ3pDLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSx5Q0FBc0IsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuRSxPQUFPLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDckUsQ0FBQyxDQUFBLENBQUMsQ0FDSCxDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=