"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-10-15.
 */
// services
const LKE = require("../services/index");
const Access = LKE.getAccess();
const Utils = LKE.getUtils();
const DataProxy = LKE.getDataProxy();
// locals
const dataSourceParams_1 = require("../models/parameters/dataSourceParams");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {get} /api/:dataSource/graph/schema/simple Get simple schema
     * @apiName GetSimpleSchema
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all `edgeTypes`, `nodeCategories`, `edgeProperties`, `nodeProperties`
     * that exist in the graph database.
     * The user must belongs to at least one group of the data-source to use this API.
     *
     * @apiUse DataSourceParams
     *
     * @apiUse SimpleSchemaResponse
     */
    app.get('/api/:dataSource/graph/schema/simple', api.respond((req) => {
        const params = new dataSourceParams_1.DataSourceParams().fromRequest(req);
        // @ts-ignore DataProxy option wrapped user should be optional
        return DataProxy.getSimpleSchema(params, req.wrappedUser);
    }));
    /**
     * @api {get} /api/:dataSource/graph/schema/nodeTypes List all node categories
     * @apiName GetSchemaNodeTypes
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all node categories (including property keys, counts and types).
     *
     * @apiParam {string}  dataSource          Key of the data-source
     * @apiParam {boolean} [includeType=false] Whether to include detected property types
     *
     * @apiSuccess {object}                                             any
     * @apiSuccess {string="readable","editable","writable","none"}     any.access                Default access level
     * @apiSuccess {object[]}                                           results                   All known node categories
     * @apiSuccess {string}                                             results.name              Name of the node category
     * @apiSuccess {string="readable","editable","writable"}            results.access            Access level of the node category
     * @apiSuccess {string}                                             results.count             Number of nodes with this category
     * @apiSuccess {object[]}                                           results.properties        Existing properties for the node category
     * @apiSuccess {string}                                             results.properties.key    Key of the property
     * @apiSuccess {string}                                             results.properties.count  Number of properties with this key for this node category
     * @apiSuccess {string="string","boolean","integer","float","date"} [results.properties.type] Type of the property
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "any": {
     *       "access": "writable"
     *     },
     *     "results": [
     *       {
     *         "name": "Movie",
     *         "access": "writable",
     *         "count": 38,
     *         "properties": [
     *           {
     *             "key": "released",
     *             "count": 38,
     *             "type": "date"
     *           },
     *           {
     *             "key": "tagline",
     *             "count": 37,
     *             "type": "string"
     *           },
     *           {
     *             "key": "title",
     *             "count": 38,
     *             "type": "string"
     *           }
     *         ]
     *       }
     *     ]
     *   }
     */
    app.get('/api/:dataSource/graph/schema/nodeTypes', api.respond((req) => {
        return DataProxy.getSchemaNodeTypes({
            sourceKey: req.param('dataSource'),
            includeType: Utils.parseBoolean(req.param('includeType'))
        }, Access.getUserCheck(req, 'schema', true));
    }));
    /**
     * @api {get} /api/:dataSource/graph/schema/edgeTypes List all edge types
     * @apiName GetSchemaEdgeTypes
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all edge types (including property keys, counts and types).
     *
     * @apiParam {string}  dataSource          Key of the data-source
     * @apiParam {boolean} [includeType=false] Whether to include detected property types
     *
     * @apiSuccess {object}                                             any
     * @apiSuccess {string="readable","editable","writable","none"}     any.access                Default access level
     * @apiSuccess {object[]}                                           results                   All known edge types
     * @apiSuccess {string}                                             results.name              Name of the edge type
     * @apiSuccess {string="readable","editable","writable"}            results.access            Access level of the edge type
     * @apiSuccess {string}                                             results.count             Number of edges with this type
     * @apiSuccess {object[]}                                           results.properties        Existing properties for the edge type
     * @apiSuccess {string}                                             results.properties.key    Key of the property
     * @apiSuccess {string}                                             results.properties.count  Number of properties with this key for this edge type
     * @apiSuccess {string="string","boolean","integer","float","date"} [results.properties.type] Type of the property
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "any": {
     *       "access": "writable"
     *     },
     *     "results": [
     *       {
     *         "name": "DIRECTED_BY",
     *         "access": "writable",
     *         "count": 38,
     *         "properties": [
     *           {
     *             "key": "released",
     *             "count": 38,
     *             "type": "date"
     *           },
     *           {
     *             "key": "tagline",
     *             "count": 37,
     *             "type": "string"
     *           },
     *           {
     *             "key": "title",
     *             "count": 38,
     *             "type": "string"
     *           }
     *         ]
     *       },
     *       {
     *         "name": "ACTED_IN",
     *         "access": "writable",
     *         "count": 71,
     *         "properties": [
     *           {
     *             "key": "role",
     *             "count": 4,
     *             "type": "string"
     *           },
     *           {
     *             "key": "salary",
     *             "count": 12,
     *             "type": "integer"
     *           }
     *         ]
     *       }
     *     ]
     *   }
     */
    app.get('/api/:dataSource/graph/schema/edgeTypes', api.respond((req) => {
        return DataProxy.getSchemaEdgeTypes({
            sourceKey: req.param('dataSource'),
            includeType: Utils.parseBoolean(req.param('includeType'))
        }, Access.getUserCheck(req, 'schema', true));
    }));
    /**
     * @api {get} /api/:dataSource/graph/schema/nodeTypes/properties List all node properties
     *
     * @apiName GetSchemaNodeProperties
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all node properties.
     *
     * @apiParam {string}  dataSource          Key of the data-source
     * @apiParam {boolean} [includeType=false] Whether to include detected property types
     * @apiParam {boolean} [omitNoindex=false] Whether to omit no-index properties
     *
     * @apiUse ReturnProperties
     */
    app.get('/api/:dataSource/graph/schema/nodeTypes/properties', api.respond((req) => {
        return DataProxy.getSchemaNodeProperties({
            sourceKey: req.param('dataSource'),
            includeType: Utils.parseBoolean(req.param('includeType')),
            omitNoIndex: Utils.parseBoolean(req.param('omitNoindex'))
        }, Access.getUserCheck(req, 'schema', true)).then(r => ({ properties: r }));
    }));
    /**
     * @api {get} /api/:dataSource/graph/schema/edgeTypes/properties List all edge properties
     *
     * @apiName GetSchemaEdgeProperties
     * @apiGroup Schema
     * @apiPermission guest_user
     * @apiPermission apiright:schema
     *
     * @apiDescription List all edge properties.
     *
     * @apiParam {string}  dataSource          Key of the data-source
     * @apiParam {boolean} [includeType=false] Whether to include detected property types
     * @apiParam {boolean} [omitNoindex=false] Whether to omit no-index properties
     *
     * @apiUse ReturnProperties
     */
    app.get('/api/:dataSource/graph/schema/edgeTypes/properties', api.respond((req) => {
        return DataProxy.getSchemaEdgeProperties({
            sourceKey: req.param('dataSource'),
            includeType: Utils.parseBoolean(req.param('includeType')),
            omitNoIndex: Utils.parseBoolean(req.param('omitNoindex'))
        }, Access.getUserCheck(req, 'schema', true)).then(r => ({ properties: r }));
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhTY2hlbWEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zZXJ2ZXIvcm91dGVzL2dyYXBoU2NoZW1hLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7QUFFckMsU0FBUztBQUNULDRFQUF1RTtBQUN2RSxpREFBa0Q7QUFpQ2xELGlCQUFTLENBQUMsR0FBdUIsRUFBUSxFQUFFO0lBQ3pDOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCxzQ0FBc0MsRUFDdEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLG1DQUFnQixFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZELDhEQUE4RDtRQUM5RCxPQUFPLFNBQVMsQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM1RCxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXNERztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wseUNBQXlDLEVBQ3pDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsa0JBQWtCLENBQ2pDO1lBQ0UsU0FBUyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXO1lBQzVDLFdBQVcsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDMUQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQ3pDLENBQUM7SUFDSixDQUFDLENBQUMsQ0FDSCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BdUVHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FDTCx5Q0FBeUMsRUFDekMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxrQkFBa0IsQ0FDakM7WUFDRSxTQUFTLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVc7WUFDNUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUMxRCxFQUNELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FDekMsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLG9EQUFvRCxFQUNwRCxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE9BQU8sU0FBUyxDQUFDLHVCQUF1QixDQUN0QztZQUNFLFNBQVMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBVztZQUM1QyxXQUFXLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3pELFdBQVcsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDMUQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQ3pDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDakMsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7T0FlRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQ0wsb0RBQW9ELEVBQ3BELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsdUJBQXVCLENBQ3RDO1lBQ0UsU0FBUyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXO1lBQzVDLFdBQVcsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDekQsV0FBVyxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUMxRCxFQUNELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FDekMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsVUFBVSxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNqQyxDQUFDLENBQUMsQ0FDSCxDQUFDO0FBQ0osQ0FBQyxDQUFDIn0=