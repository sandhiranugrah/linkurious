/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-11-04.
 */
'use strict';
// services
const LKE = require('../../services/index');
const Access = LKE.getAccess();
const Application = LKE.getApplication();
const Utils = LKE.getUtils();
// locals
const api = require('../../services/webServer/api');
/**
 * @apiDefine ReturnApplication
 *
 * @apiSuccess {number}       id        ID of the application
 * @apiSuccess {string}       name      Name of the application
 * @apiSuccess {string}       apiKey    Generated key (32 hexadecimal characters)
 * @apiSuccess {boolean}      enabled   Whether the application is enabled
 * @apiSuccess {string[]}     rights    Enabled actions for the application
 * @apiSuccess {type:group[]} groups    Groups the application can act on behalf of
 * @apiSuccess {string[]}     createdAt Creation date in ISO-8601 format
 * @apiSuccess {string[]}     updatedAt Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   {
 *     "id": 1,
 *     "enabled": true,
 *     "apiKey": "76554081e5b0a2d7852deec4990ebc58",
 *     "name": "test_app",
 *     "rights": [
 *       "visualization.create",
 *       "visualization.edit",
 *       "visualization.read",
 *       "visualization.delete"
 *     ],
 *     "groups": [
 *       {
 *         "id": 3,
 *         "name": "read and edit",
 *         "builtin": true,
 *         "sourceKey": "584f2569"
 *       }
 *     ],
 *     "createdAt": "2017-01-24T11:16:03.445Z",
 *     "updatedAt": "2017-01-24T11:16:03.445Z"
 *   }
 */
/**
 * @apiDefine ReturnApplications
 *
 * @apiSuccess {object[]}     applications           Applications
 * @apiSuccess {number}       applications.id        ID of the application
 * @apiSuccess {string}       applications.name      Name of the application
 * @apiSuccess {string}       applications.apiKey    Generated key (32 hexadecimal characters)
 * @apiSuccess {boolean}      applications.enabled   Whether the application is enabled
 * @apiSuccess {string[]}     applications.rights    Enabled actions for the application
 * @apiSuccess {type:group[]} applications.groups    Groups the application can act on behalf of
 * @apiSuccess {string[]}     applications.createdAt Creation date in ISO-8601 format
 * @apiSuccess {string[]}     applications.updatedAt Last update date in ISO-8601 format
 *
 * @apiSuccessExample {json} Success-Response:
 *   HTTP/1.1 200 OK
 *   [
 *     {
 *       "id": 1,
 *       "enabled": true,
 *       "apiKey": "e3fadcbd39ddb21fe8ecb206dadff36d",
 *       "name": "test_app",
 *       "rights": [
 *         "visualization.create",
 *         "visualization.edit",
 *         "visualization.read",
 *         "visualization.delete"
 *       ],
 *       "groups": [
 *         {
 *           "id": 3,
 *           "name": "read and edit",
 *           "builtin": true,
 *           "sourceKey": "584f2569"
 *         }
 *       ],
 *       "createdAt": "2017-01-24T11:14:51.337Z",
 *       "updatedAt": "2017-01-24T11:31:13.769Z"
 *     },
 *     {
 *       "id": 2,
 *       "enabled": true,
 *       "apiKey": "738c9f3b66aad7218c69843a78905ccd",
 *       "name": "test_app_2",
 *       "rights": [
 *         "visualization.read"
 *       ],
 *       "groups": [
 *         {
 *           "id": 2,
 *           "name": "read",
 *           "builtin": true,
 *           "sourceKey": "584f2569"
 *         }
 *       ],
 *       "createdAt": "2017-01-24T11:16:02.417Z",
 *       "updatedAt": "2017-01-24T11:16:02.417Z"
 *     }
 *   ]
 */
module.exports = function (app) {
    app.all('/api/admin/applications*', api.proxy(req => Access.hasAction(req, 'admin.app')));
    // ------------------------------------------------------------------------------------------
    //                                        Applications
    // ------------------------------------------------------------------------------------------
    /**
     * @api {get} /api/admin/applications Get all the applications
     * @apiName GetApplications
     * @apiGroup Applications
     * @apiPermission authenticated
     * @apiPermission action:admin.app
     *
     * @apiDescription Get all the API applications.
     *
     * @apiUse ReturnApplications
     */
    app.get('/api/admin/applications', api.respond(() => {
        return Application.getApplications();
    }));
    /**
     * @api {post} /api/admin/applications Create an application
     * @apiName CreateApplication
     * @apiGroup Applications
     * @apiPermission authenticated
     * @apiPermission action:admin.app
     *
     * @apiDescription Add a new API application.
     *
     * @apiParam {string}   name           Name of the application
     * @apiParam {boolean}  [enabled=true] Whether the application is enabled
     * @apiParam {number[]} groups         IDs of the groups the application can act on behalf of
     * @apiParam {string[]="visualization.read", "visualization.create", "visualization.edit", "visualization.delete", "visualization.list", "visualizationFolder.create", "visualizationFolder.edit", "visualizationFolder.delete", "visualizationShare.read", "visualizationShare.create", "visualizationShare.delete", "sandbox", "widget.read", "widget.create", "widget.edit", "widget.delete", "graphItem.read", "graphItem.create", "graphItem.edit", "graphItem.delete", "graphItem.search", "savedGraphQuery.read", "savedGraphQuery.create", "savedGraphQuery.edit", "savedGraphQuery.delete", "graph.rawRead", "graph.rawWrite", "alert.read", "alert.doAction", "schema", "admin.index"} rights Enabled actions for the application
     *
     * @apiUse ReturnApplication
     */
    app.post('/api/admin/applications', api.respond(req => {
        return Application.createApplication({
            name: req.body.name,
            enabled: req.body.enabled,
            groups: req.body.groups,
            rights: req.body.rights
        });
    }, 201));
    /**
     * @api {patch} /api/admin/applications/:id Update an application
     * @apiName UpdateApplication
     * @apiGroup Applications
     * @apiPermission authenticated
     * @apiPermission action:admin.app
     *
     * @apiDescription Update an API application.
     *
     * @apiParam {string}   [name]         Name of the application
     * @apiParam {boolean}  [enabled=true] Whether the application is enabled
     * @apiParam {number[]} [groups]       IDs of the groups the application can act on behalf of
     * @apiParam {string[]="visualization.read", "visualization.create", "visualization.edit", "visualization.delete", "visualization.list", "visualizationFolder.create", "visualizationFolder.edit", "visualizationFolder.delete", "visualizationShare.read", "visualizationShare.create", "visualizationShare.delete", "sandbox", "widget.read", "widget.create", "widget.edit", "widget.delete", "graphItem.read", "graphItem.create", "graphItem.edit", "graphItem.delete", "graphItem.search", "savedGraphQuery.read", "savedGraphQuery.create", "savedGraphQuery.edit", "savedGraphQuery.delete", "graph.rawRead", "graph.rawWrite", "alert.read", "alert.doAction", "schema"} [rights] Enabled actions for the application
     *
     * @apiUse ReturnApplication
     */
    app.patch('/api/admin/applications/:id', api.respond(req => {
        return Application.updateApplication({
            id: Utils.tryParsePosInt(req.params.id, 'id'),
            name: req.body.name,
            enabled: req.body.enabled,
            groups: req.body.groups,
            rights: req.body.rights
        });
    }, 200));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9hZG1pbi9hcHBsaWNhdGlvbnMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixXQUFXO0FBQ1gsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDNUMsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQy9CLE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztBQUN6QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFFN0IsU0FBUztBQUNULE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0FBRXBEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FvQ0c7QUFFSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTBERztBQUVILE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxHQUFHO0lBRTNCLEdBQUcsQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUUxRiw2RkFBNkY7SUFDN0Ysc0RBQXNEO0lBQ3RELDZGQUE2RjtJQUU3Rjs7Ozs7Ozs7OztPQVVHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRTtRQUNsRCxPQUFPLFdBQVcsQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUo7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3BELE9BQU8sV0FBVyxDQUFDLGlCQUFpQixDQUFDO1lBQ25DLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUk7WUFDbkIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTztZQUN6QixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQ3ZCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU07U0FDeEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFVDs7Ozs7Ozs7Ozs7Ozs7O09BZUc7SUFDSCxHQUFHLENBQUMsS0FBSyxDQUFDLDZCQUE2QixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDekQsT0FBTyxXQUFXLENBQUMsaUJBQWlCLENBQUM7WUFDbkMsRUFBRSxFQUFFLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDO1lBQzdDLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUk7WUFDbkIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTztZQUN6QixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQ3ZCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU07U0FDeEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMifQ==