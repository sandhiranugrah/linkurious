/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2016-05-11.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services/index');
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
const Analytics = LKE.getAnalytics();
const Log = LKE.getLogger(__filename);
// locals
const api = require('../../services/webServer/api');
module.exports = function (app) {
    /**
     * @api {get} /api/admin/report Create a report
     * @apiName CreateReport
     * @apiGroup Linkurious
     * @apiPermission authenticated
     * @apiPermission action:admin.report
     *
     * @apiDescription Collect all the analytics and log files in a compressed tarball and return it.
     *
     * @apiParam {boolean} [with_configuration=false] Whether to include the configuration within the tarball
     *
     * @apiSuccessExample {tar.gz} Success-Response:
     *   HTTP/1.1 200 OK
     */
    app.get('/api/admin/report', api.respond((req, res) => {
        // admin.report on any data-source
        return Access.hasAction(req, 'admin.report').then(() => {
            return Analytics.createReport(Utils.parseBoolean(req.param('with_configuration')));
        }).then(path => {
            res.type('application/gzip');
            res.setHeader('Content-Disposition', `attachment; filename=${Analytics.reportFileName}`);
            res.sendFile(path);
        }).return(null);
    }, 200, true, true));
    /**
     * @api {post} /api/admin/restart Restart Linkurious
     * @apiName RestartLinkurious
     * @apiGroup Linkurious
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     *
     * @apiDescription Restart Linkurious.
     *
     * @apiSuccess {string} url The url of Linkurious to connect to after the restart
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "url": "http://localhost:3000"
     *   }
     */
    app.post('/api/admin/restart', api.respond(req => {
        return Access.hasAction(req, 'admin.config').then(() => {
            // 2 seconds to respond and die
            Promise.delay(2000).then(() => {
                Log.info(`Linkurious restarted from the API by user #${req.user.id}`);
                // exit status code 4 will trigger a restart in the Linkurious manager
                process.exit(4);
            });
            return Promise.resolve({
                url: LKE.getBaseURL()
            });
        });
    }));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VuZXJhbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9yb3V0ZXMvYWRtaW4vZ2VuZXJhbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7R0FLRztBQUNILFlBQVksQ0FBQztBQUViLGdCQUFnQjtBQUNoQixNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFcEMsV0FBVztBQUNYLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQzVDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFDL0IsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7QUFFdEMsU0FBUztBQUNULE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0FBRXBELE1BQU0sQ0FBQyxPQUFPLEdBQUcsVUFBUyxHQUFHO0lBQzNCOzs7Ozs7Ozs7Ozs7O09BYUc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7UUFDcEQsa0NBQWtDO1FBQ2xDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNyRCxPQUFPLFNBQVMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNiLEdBQUcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUM3QixHQUFHLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLHdCQUF3QixTQUFTLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztZQUN6RixHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNsQixDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRXJCOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQy9DLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNyRCwrQkFBK0I7WUFDL0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUM1QixHQUFHLENBQUMsSUFBSSxDQUFDLDhDQUE4QyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBRXRFLHNFQUFzRTtnQkFDdEUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNsQixDQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDckIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxVQUFVLEVBQUU7YUFDdEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDIn0=