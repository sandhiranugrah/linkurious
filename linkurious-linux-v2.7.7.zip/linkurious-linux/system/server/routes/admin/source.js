/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 *
 * - Created on 2014-12-17.
 */
'use strict';
// external libs
const Promise = require('bluebird');
// services
const LKE = require('../../services/index');
const Utils = LKE.getUtils();
const Data = LKE.getData();
const Access = LKE.getAccess();
const VisualizationDAO = LKE.getVisualizationDAO();
// locals
const api = require('../../services/webServer/api');
/**
 * @typedef {object} NodeStyle Node style rules
 * @property {number}                   NodeStyle.index                        Rule index
 * @property {string}                   NodeStyle.type                         Style type (`any`, `novalue`, `nan`, `range`, `is`)
 * @property {string}                   [NodeStyle.itemType]                   Category matched. Note: `null` matches items with no category and `undefined` matches items with any category
 * @property {string[]}                 [NodeStyle.input]                      Property tested. e.g: `["properties", "name"]`, the name property will be tested against `value`
 * @property {string | number | object} [NodeStyle.value]                      Discrete or ranged value for the node attribute
 * @property {number}                   [NodeStyle.value.>]                    Lower bound for numeric properties
 * @property {number}                   [NodeStyle.value.<]                    Upper bound for numeric properties
 * @property {object}                   NodeStyle.style                        Node style
 * @property {number}                   [NodeStyle.style.size]                 Node size
 * @property {string}                   [NodeStyle.style.color]                Node color
 * @property {string | number | object} [NodeStyle.style.icon]                 Node icon
 * @property {string | number}          [NodeStyle.style.icon.content]         Icon string
 * @property {string | number}          [NodeStyle.style.icon.font]            Icon Font-Family
 * @property {string}                   [NodeStyle.style.icon.color]           Icon Color
 * @property {number}                   [NodeStyle.style.icon.scale]           Scaling ratio of the icon
 * @property {number}                   [NodeStyle.style.icon.minVisibleSize]  If the node diameter on screen is less than this value, the icon will not be shown
 * @property {string | object}          [NodeStyle.style.image]                Node image
 * @property {string}                   [NodeStyle.style.image.url]            URL of the image
 * @property {number}                   [NodeStyle.style.image.scale]          Scaling ratio of the image
 * @property {boolean}                  [NodeStyle.style.image.fit]            Clip ratio of the image
 * @property {boolean}                  [NodeStyle.style.image.tile]           Whether to repeat the image pattern
 * @property {number}                   [NodeStyle.style.image.minVisibleSize] If the node diameter on screen is less than this value, the image will not be shown
 * @property {string}                   [NodeStyle.style.shape]                Node shape (`circle`, `cross`, `diamond`, `pentagon`, `square`, `star`, `equilateral`)
 */
/**
 * @typedef {object} EdgeStyle Edge style rules
 * @property {number}                   EdgeStyle.index         Rule index
 * @property {string}                   EdgeStyle.type          Style type (`any`, `novalue`, `nan`, `range`, `is`)
 * @property {string}                   [EdgeStyle.itemType]    Type matched. Note: `undefined` matches items with any type
 * @property {string[]}                 [EdgeStyle.input]       Property tested. e.g: `["properties", "name"]`, the name property will be tested against `value`
 * @property {string | number | object} [EdgeStyle.value]       Discrete or ranged value for the node attribute
 * @property {number}                   [EdgeStyle.value.>]     Lower bound for numeric properties
 * @property {number}                   [EdgeStyle.value.<]     Upper bound for numeric properties
 * @property {object}                   EdgeStyle.style         Edge style
 * @property {number}                   [EdgeStyle.style.width] Edge width
 * @property {string}                   [EdgeStyle.style.color] Edge color
 * @property {string}                   [EdgeStyle.style.shape] Edge shape (`line`, `arrow`, `tapered`, `dashed`, `dotted`)
 */
/**
 * @typedef {object} NodeCaption Node captions indexed by `node-category`
 * @property {object}   [NodeCaption.[node-category]]           `node-category` is a placeholder for the actual node category
 * @property {boolean}  [NodeCaption.node-category].active      Whether to use this caption
 * @property {boolean}  [NodeCaption.node-category].displayName Whether to include the category in the caption
 * @property {string[]} [NodeCaption.node-category].properties  List of properties to include in the caption
 */
/**
 * @typedef {object} EdgeCaption Edge captions indexed by `edge-type`
 * @property {object}   [EdgeCaption.[edge-type]]           `edge-type` is a placeholder for the actual edge type
 * @property {boolean}  [EdgeCaption.edge-type].active      Whether to use this caption
 * @property {boolean}  [EdgeCaption.edge-type].displayName Whether to include the type in the caption
 * @property {string[]} [EdgeCaption.edge-type].properties  List of properties to include in the caption
 */
module.exports = function (app) {
    // source reconnect
    /**
     * @api {post} /api/admin/source/:dataSourceIndex/connect Connect a disconnected data-source
     * @apiName ReconnectSource
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.connect
     * @apiDescription Connect a disconnected data-source
     * @apiParam {string} dataSourceIndex config-index of a data-source
     */
    app.post('/api/admin/source/:dataSourceIndex/connect', api.respond(req => {
        return Access.hasAction(req, 'admin.connect').then(() => {
            // we don't wait for the data-source to connect
            Data.resolveSource(Utils.tryParsePosInt(req.param('dataSourceIndex'), 'dataSourceIndex')).connect(true);
        });
    }));
    // reset sandboxes
    /**
     * @api {post} /api/admin/source/:dataSource/resetDefaults Reset settings for new visualizations
     * @apiName ResetSourceStyles
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.styles
     * @apiDescription Reset design and/or captions of all sandboxes of the given data-source to default values.
     * If `design` is true, set `design.palette` and `design.styles` to default `palette` and `defaultStyles` of the data-source.
     * If `captions` is true, set `nodeFields.captions` and `edgeFields.captions` to current `defaultCaptions.nodes` and `defaultCaptions.edges` of the data-source.
     *
     * @apiParam {string}  dataSource Key of the data-source
     * @apiParam {boolean} design     Whether to reset default design to default values
     * @apiParam {boolean} captions   Whether to reset default captions to default values
     */
    app.post('/api/admin/source/:dataSource/resetDefaults', api.respond(req => {
        const sourceKey = req.param('dataSource');
        return Access.hasAction(req, 'admin.styles', sourceKey).then(() => {
            return VisualizationDAO.resetSandboxes(sourceKey, {
                design: Utils.parseBoolean(req.param('design')),
                captions: Utils.parseBoolean(req.param('captions'))
            });
        });
    }, 204));
    /**
     * @api {post} /api/admin/source/:dataSource/setDefaults Set default styles and captions
     * @apiName SetDefaultSourceStyles
     * @apiGroup DataSources
     * @apiPermission action:admin.styles
     * @apiDescription Set default design styles and/or captions for the given data-source.
     *
     * @apiParam {string}           dataSource     Key of the data-source
     * @apiParam {object}           [styles]       New default styles for the data-source
     * @apiParam {type:NodeStyle[]} styles.node    Node styles
     * @apiParam {type:EdgeStyle[]} styles.edge    Edge styles
     * @apiParam {object}           [captions]     New default captions for the data-source
     * @apiParam {type:NodeCaption} captions.nodes Nodes captions
     * @apiParam {type:EdgeCaption} captions.edges Edges captions
     */
    app.post('/api/admin/source/:dataSource/setDefaults', api.respond(req => {
        return Access.hasAction(req, 'admin.styles', req.param('dataSource')).then(() => {
            const source = Data.resolveSource(req.param('dataSource'));
            return source.setDesignDefaults(req.param('styles'), req.param('captions'));
        });
    }, 204));
    // all the other APIs other than connect needs "admin.config"
    app.all('/api/admin/source*', api.proxy(req => {
        return Access.hasAction(req, 'admin.config');
    }));
    // source index-mapping
    /**
     * @api {get} /api/admin/source/:dataSource/hidden/nodeProperties Get hidden node-properties
     * @apiName getHiddenNodeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Get the list of node-properties hidden for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     */
    app.get('/api/admin/source/:dataSource/hidden/nodeProperties', api.respond(req => {
        return Promise.resolve(Data.resolveSource(req.param('dataSource')).getHiddenNodeProperties());
    }));
    /**
     * @api {get} /api/admin/source/:dataSource/hidden/edgeProperties Get hidden edge-properties
     * @apiName getHiddenEdgeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Get the list of edge-properties hidden for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     */
    app.get('/api/admin/source/:dataSource/hidden/edgeProperties', api.respond(req => {
        return Promise.resolve(Data.resolveSource(req.param('dataSource')).getHiddenEdgeProperties());
    }));
    /**
     * @api {get} /api/admin/source/:dataSource/noIndex/nodeProperties Get non-indexed node-properties
     * @apiName getNoIndexNodeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Get the list of node-properties that are not indexed for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     */
    app.get('/api/admin/source/:dataSource/noIndex/nodeProperties', api.respond(req => {
        return Promise.resolve(Data.resolveSource(req.param('dataSource')).getNoIndexNodeProperties());
    }));
    /**
     * @api {get} /api/admin/source/:dataSource/noIndex/edgeProperties Get non-indexed edge-properties
     * @apiName getNoIndexEdgeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Get the list of edge-properties that re not indexed for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     */
    app.get('/api/admin/source/:dataSource/noIndex/edgeProperties', api.respond(req => {
        return Promise.resolve(Data.resolveSource(req.param('dataSource')).getNoIndexEdgeProperties());
    }));
    /**
     * @api {put} /api/admin/source/:dataSource/hidden/nodeProperties Set hidden node-properties
     * @apiName setHiddenNodeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Set the list of node-properties that are hidden for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string[]} properties List of property names
     */
    app.put('/api/admin/source/:dataSource/hidden/nodeProperties', api.respond(req => {
        return Data.resolveSource(req.param('dataSource')).setHiddenNodeProperties(req.param('properties', []));
    }));
    /**
     * @api {put} /api/admin/source/:dataSource/hidden/edgeProperties Set hidden edge-properties
     * @apiName setHiddenEdgeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Set the list of edge-properties that are hidden for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string[]} properties List of property names
     */
    app.put('/api/admin/source/:dataSource/hidden/edgeProperties', api.respond(req => {
        return Data.resolveSource(req.param('dataSource')).setHiddenEdgeProperties(req.param('properties', []));
    }));
    /**
     * @api {put} /api/admin/source/:dataSource/noIndex/nodeProperties Set non-indexed node-properties
     * @apiName setNoIndexNodeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Set the list of node-properties that are not indexed for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string[]} properties List of property names
     */
    app.put('/api/admin/source/:dataSource/noIndex/nodeProperties', api.respond(req => {
        return Data.resolveSource(req.param('dataSource')).setNoIndexNodeProperties(req.param('properties', []));
    }));
    /**
     * @api {put} /api/admin/source/:dataSource/noIndex/edgeProperties Set non-indexed edge-properties
     * @apiName setNoIndexEdgeProperties
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Set the list of edge-properties that are not indexed for the given data-source.
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string[]} properties List of property names
     */
    app.put('/api/admin/source/:dataSource/noIndex/edgeProperties', api.respond(req => {
        return Data.resolveSource(req.param('dataSource')).setNoIndexEdgeProperties(req.param('properties', []));
    }));
    /**
     * @api {get} /api/admin/sources Get all data-sources information
     * @apiName getAllSourceInfo
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Get information for all data-source, including data-sources that do not exist online.
     *
     * @apiSuccess {object[]} sources Data-source information
     * @apiSuccess {string} sources.lastSeen Last time this data-source was seen online (ISO-8601 date)
     * @apiSuccess {string} sources.indexedDate Last time this data-source was indexed (ISO-8601 date)
     * @apiSuccess {string} sources.key Key of the data-source (when is has been connected before, `null` otherwise)
     * @apiSuccess {string} sources.host Host of the data-source
     * @apiSuccess {string} sources.port Port of the data-source
     * @apiSuccess {string} sources.storeId Unique store identifier of the graph database (when it has been connected before, `null` otherwise)
     * @apiSuccess {string} sources.state State code if the data-source (`"ready"` , `"offline"` ...)
     * @apiSuccess {number} sources.visualizationCount Number of visualizations that exist for this data-source
     * @apiSuccess {number} sources.configIndex The index of the data-source's config (if the config still exists, `null` otherwise)
     */
    app.get('/api/admin/sources', api.respond(() => {
        return Data.getAllSources();
    }));
    /**
     * @api {post} /api/admin/sources/config Create a new data-source configuration
     * @apiName createSourceConfig
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Create a new data-source configuration (contains a graph database configuration and an index configuration).
     *
     * @apiParam {string} name Name of the data-source
     * @apiParam {object} graphDb The configuration options of the graph database
     * @apiParam {string} graphDb.vendor The vendor of the graph database (`"neo4j"`, `"allegroGraph"`...)
     * @apiParam {object} index The configuration options of the index
     * @apiParam {object} index.vendor The vendor of the index (`"elasticSearch"`)
     * @apiParam {string} index.host Host of the index server
     * @apiParam {number} index.port Port of the index server
     * @apiParam {boolean} index.forceReindex Whether to re-index this graph database at each start of Linkurious
     * @apiParam {boolean} index.dynamicMapping Whether to enable automatic property-types detection for enhanced search
     */
    app.post('/api/admin/sources/config', api.respond(req => {
        return Data.createSource({
            name: req.param('name'),
            graphdb: req.param('graphDb') || req.param('graphdb'),
            index: req.param('index')
        });
    }, 201));
    /**
     * @api {delete} /api/admin/sources/config/:configIndex Delete a data-source configuration
     * @apiName deleteSourceConfig
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Delete a data-source configuration that has currently no connected data-source.
     *
     * @apiParam {number} configIndex Index of a data-source configuration
     */
    app.delete('/api/admin/sources/config/:configIndex', api.respond(req => {
        return Data.deleteSourceConfig(Utils.tryParsePosInt(req.param('configIndex'), 'configIndex', false));
    }, 204));
    /**
     * @api {delete} /api/admin/sources/data/:sourceKey Delete all data-source data
     * @apiName deleteSourceData
     * @apiGroup DataSources
     * @apiPermission authenticated
     * @apiPermission action:admin.config
     * @apiDescription Delete all data of data-source (visualizations, access rights, widgets, full-text indexes).
     *                 Optionally merge visualizations and widgets into another data-source instead of deleting them.
     *                 Warning: when merging into another data-source, visualizations may break if node and edge IDs are not the same in to target data-source.
     *
     * @apiParam {string} sourceKey Key of a disconnected data-source which data must be deleted
     * @apiParam {string} merge_into Key of the data-source to merge visualizations and widgets into
     *
     * @apiSuccess {boolean} migrated True if the affected items have been migrated to another data-source, false if they have been deleted
     * @apiSuccess {object} affected Affected object counts
     * @apiSuccess {number} affected.visualizations Number of migrated/deleted visualizations (with their widgets)
     * @apiSuccess {number} affected.folders Number of migrated/deleted visualization folders
     * @apiSuccess {number} affected.alerts Number of migrated/deleted alerts
     * @apiSuccess {number} affected.matches Number of migrated/deleted matches
     * @apiSuccess {number} affected.graphQueries Number of migrated/deleted graph queries
     */
    app.delete('/api/admin/sources/data/:sourceKey', api.respond(req => {
        const sourceKey = req.param('sourceKey');
        Utils.checkSourceKey(sourceKey);
        const mergeInto = req.param('merge_into');
        Utils.checkSourceKey(mergeInto, 'mergeInto', true);
        return Data.deleteSourceData(sourceKey, mergeInto);
    }, 200));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic291cmNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9hZG1pbi9zb3VyY2UuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dBS0c7QUFDSCxZQUFZLENBQUM7QUFFYixnQkFBZ0I7QUFDaEIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBRXBDLFdBQVc7QUFDWCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUM1QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDN0IsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztBQUMvQixNQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0FBRW5ELFNBQVM7QUFDVCxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUVwRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXlCRztBQUVIOzs7Ozs7Ozs7Ozs7O0dBYUc7QUFFSDs7Ozs7O0dBTUc7QUFFSDs7Ozs7O0dBTUc7QUFFSCxNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsR0FBRztJQUUzQixtQkFBbUI7SUFFbkI7Ozs7Ozs7O09BUUc7SUFDSCxHQUFHLENBQUMsSUFBSSxDQUFDLDRDQUE0QyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDdkUsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ3RELCtDQUErQztZQUMvQyxJQUFJLENBQUMsYUFBYSxDQUNoQixLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsRUFBRSxpQkFBaUIsQ0FBQyxDQUN0RSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSixrQkFBa0I7SUFFbEI7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN4RSxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzFDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDaEUsT0FBTyxnQkFBZ0IsQ0FBQyxjQUFjLENBQ3BDLFNBQVMsRUFDVDtnQkFDRSxNQUFNLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMvQyxRQUFRLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3BELENBQ0YsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFVDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQUMsMkNBQTJDLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN0RSxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLGNBQWMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM5RSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztZQUMzRCxPQUFPLE1BQU0sQ0FBQyxpQkFBaUIsQ0FDN0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFDbkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FDdEIsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFFVCw2REFBNkQ7SUFDN0QsR0FBRyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzVDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7SUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKLHVCQUF1QjtJQUV2Qjs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMscURBQXFELEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUMvRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0lBQ2hHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMscURBQXFELEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUMvRSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0lBQ2hHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsc0RBQXNELEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNoRixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDO0lBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7T0FRRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsc0RBQXNELEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNoRixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxDQUFDO0lBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7O09BU0c7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHFEQUFxRCxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDL0UsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FDeEUsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQzVCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUo7Ozs7Ozs7OztPQVNHO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyxxREFBcUQsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQy9FLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQ3hFLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUM1QixDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKOzs7Ozs7Ozs7T0FTRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsc0RBQXNELEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNoRixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUN6RSxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FDNUIsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFSjs7Ozs7Ozs7O09BU0c7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUFDLHNEQUFzRCxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDaEYsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FDekUsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQzVCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRUo7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWtCRztJQUNILEdBQUcsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUU7UUFDN0MsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUN0RCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDdkIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ3ZCLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ3JELEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztTQUMxQixDQUFDLENBQUM7SUFDTCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUVUOzs7Ozs7Ozs7T0FTRztJQUNILEdBQUcsQ0FBQyxNQUFNLENBQUMsd0NBQXdDLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNyRSxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FDNUIsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFFLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FDckUsQ0FBQztJQUNKLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBRVQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bb0JHO0lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ2pFLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVoQyxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzFDLEtBQUssQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVuRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDckQsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMifQ==