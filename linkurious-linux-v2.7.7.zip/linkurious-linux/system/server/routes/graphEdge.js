"use strict";
/**
 * LINKURIOUS CONFIDENTIAL
 * Copyright Linkurious SAS 2012 - 2019
 */
// services
const LKE = require("../services/index");
const DataProxy = LKE.getDataProxy();
const Utils = LKE.getUtils();
const Access = LKE.getAccess();
// locals
const LkEdgeAttributes = require("../lib/validators/LkEdgeAttributes");
const api = require("../services/webServer/api");
module.exports = (app) => {
    /**
     * @api {get} /api/:dataSource/graph/edges/count Get edges count
     * @apiName GetEdgesCount
     * @apiGroup Edges
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get the number of edges in the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     *
     * @apiSuccess {number} count The number of edges
     *
     * @apiSuccessExample {json} Success-Response:
     *   HTTP/1.1 200 OK
     *   {
     *     "count": 42
     *   }
     */
    app.get('/api/:dataSource/graph/edges/count', api.respond((req) => {
        return DataProxy.getEdgeCount(req.param('dataSource'), Access.getUserCheck(req, 'graphItem.read', true)).then(count => ({ count: count }));
    }));
    /**
     * @api {get|post} /api/:dataSource/graph/edges/:id Get an edge
     * @apiName GetEdge
     * @apiGroup Edges
     * @apiPermission guest_user
     * @apiPermission apiright:graphItem.read
     *
     * @apiDescription Get an edge of the graph.
     * A subgraph made of the edge and its extremities is returned.
     *
     * @apiParam {string}   dataSource         Key of the data-source
     * @apiParam {string}   id                 ID of the edge
     * @apiParam {string}   [alternativeId]    The property to match `id` on (instead of the actual ID)
     * @apiParam {string[]} [edgesTo]          IDs of nodes that are already visible (they won't be included in the result, but their adjacent edges will be included in the `edges` field if the other nodes are in `nodes`)
     * @apiParam {boolean}  [withDigest=false] Whether to include the adjacency digest in the returned nodes
     * @apiParam {boolean}  [withDegree=false] Whether to include the degree in the returned nodes
     * @apiParam {boolean}  [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in node/edge statistics
     *
     * @apiUse ReturnSubGraph
     */
    const getEdgeHandler = api.respond((req) => {
        return DataProxy.getEdge({
            sourceKey: req.param('dataSource'),
            id: req.param('id'),
            alternativeId: Utils.parseString(req.param('alternativeId')),
            edgesTo: Utils.parseStringArray(req.param('edgesTo')),
            withDigest: Utils.parseBoolean(req.param('withDigest')),
            withDegree: Utils.parseBoolean(req.param('withDegree'))
        }, Access.getUserCheck(req, 'graphItem.read', true));
    });
    app.get('/api/:dataSource/graph/edges/:id', getEdgeHandler);
    app.post('/api/:dataSource/graph/edges/:id', getEdgeHandler);
    /**
     * @api {post} /api/:dataSource/graph/edges Create an edge
     * @apiName PostEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.create
     *
     * @apiDescription Add an edge to the graph.
     *
     * @apiParam {string}  dataSource         Key of the data-source
     * @apiParam {string}  source             ID of the source node
     * @apiParam {string}  target             ID of the target node
     * @apiParam {string}  type               Type of the edge
     * @apiParam {object}  properties         Properties of the edge
     * @apiParam {boolean} [withAccess=false] Whether to include access (`readable`,`editable`,`writable`) in edge statistics
     *
     * @apiUse ReturnEdgeOnCreate
     */
    app.post('/api/:dataSource/graph/edges', api.respond((req) => {
        return DataProxy.createEdge(LkEdgeAttributes.parse(req), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.create'));
    }, 201));
    /**
     * @api {patch} /api/:dataSource/graph/edges/:id Update an edge
     * @apiName PatchEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.edit
     *
     * @apiDescription Update a subset of properties of an edge. Keep every other property of the edge unchanged.
     * It's not possible to update the type of an edge.
     *
     * @apiParam {string}   dataSource          Key of the data-source
     * @apiParam {string}   id                  ID of the edge to update
     * @apiParam {object}   [properties]        Properties to update or create
     * @apiParam {string[]} [deletedProperties] Properties to delete
     * @apiParam {number}   [readAt]            Read timestamp in epoch time
     *
     * @apiUse ReturnEdgeOnUpdate
     */
    app.patch('/api/:dataSource/graph/edges/:id', api.respond((req) => {
        return DataProxy.updateEdge(req.param('id'), {
            data: Utils.parseObject(req.param('properties')),
            deletedProperties: Utils.parseStringArray(req.param('deletedProperties')),
            readAt: Utils.tryParsePosInt(req.param('readAt'), 'readAt', true)
        }, req.param('dataSource'), Access.getUserCheck(req, 'graphItem.edit'));
    }));
    /**
     * @api {delete} /api/:dataSource/graph/edges/:id Delete an edge
     * @apiName DeleteEdge
     * @apiGroup Edges
     * @apiPermission authenticated
     * @apiPermission apiright:graphItem.delete
     *
     * @apiDescription Delete an edge from the graph.
     *
     * @apiParam {string} dataSource Key of the data-source
     * @apiParam {string} id         ID of the edge to delete
     *
     * @apiSuccessExample {none} Success-Response:
     *   HTTP/1.1 204 No Content
     */
    app.delete('/api/:dataSource/graph/edges/:id', api.respond((req) => {
        return DataProxy.deleteEdge(req.param('id'), req.param('dataSource'), Access.getUserCheck(req, 'graphItem.delete'));
    }, 204));
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGhFZGdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc2VydmVyL3JvdXRlcy9ncmFwaEVkZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRztBQUVILFdBQVc7QUFDWCx5Q0FBMEM7QUFDMUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ3JDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUM3QixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7QUFFL0IsU0FBUztBQUNULHVFQUF3RTtBQUN4RSxpREFBa0Q7QUFvRGxELGlCQUFTLENBQUMsR0FBdUIsRUFBUSxFQUFFO0lBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FrQkc7SUFDSCxHQUFHLENBQUMsR0FBRyxDQUNMLG9DQUFvQyxFQUNwQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBb0IsRUFBRSxFQUFFO1FBQ25DLE9BQU8sU0FBUyxDQUFDLFlBQVksQ0FDM0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQVcsRUFDakMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQ2pELENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BbUJHO0lBQ0gsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUMxRCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQ3RCO1lBQ0UsU0FBUyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXO1lBQzVDLEVBQUUsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBVztZQUM3QixhQUFhLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzVELE9BQU8sRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNyRCxVQUFVLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELFVBQVUsRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDeEQsRUFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FDakQsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0gsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUM1RCxHQUFHLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0lBRTdEOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILEdBQUcsQ0FBQyxJQUFJLENBQ04sOEJBQThCLEVBQzlCLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsVUFBVSxDQUN6QixnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQzNCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXLEVBQ2pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQzdDLENBQUM7SUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7Ozs7OztPQWlCRztJQUNILEdBQUcsQ0FBQyxLQUFLLENBQ1Asa0NBQWtDLEVBQ2xDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFvQixFQUFFLEVBQUU7UUFDbkMsT0FBTyxTQUFTLENBQUMsVUFBVSxDQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBVyxFQUN6QjtZQUNFLElBQUksRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEQsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUN6RSxNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUM7U0FDbEUsRUFDRCxHQUFHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBVyxFQUNqQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUMzQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUVGOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FDUixrQ0FBa0MsRUFDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtRQUNuQyxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQ3pCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFXLEVBQ3pCLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFXLEVBQ2pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQzdDLENBQUM7SUFDSixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQ1IsQ0FBQztBQUNKLENBQUMsQ0FBQyJ9